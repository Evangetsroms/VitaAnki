package app.vitaanki.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.content.res.Configuration;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.util.LruCache;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int PICK_DECK = 4101;
    private static final int[] CARD_SIZES = {20, 24, 28, 32};
    private static final int[] UI_SIZES = {16, 18, 20};
    private static final String[] THEMES = {"Cyberpunk dark", "Cyberpunk light", "Sepia", "Aquatic Ambience", "Synthwave"};
    private static final String[] FONTS = {"Sans", "Serif", "Monospace"};
    private static final long MAX_OFFLINE_INTERVAL = 3650;
    private static final int NEW_CARD_BATCH_SIZE = 20;
    private static final int MAX_EDITABLE_CARDS = 2000;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable liveQueueRefresh = this::refreshLiveQueue;
    private final Runnable offlineLearningRefresh = this::refreshOfflineLearning;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final LruCache<String, Bitmap> cardImages = new LruCache<String, Bitmap>(8 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount(); }
    };
    private android.content.SharedPreferences prefs;
    private DeckStore deckStore;
    private DeckData offlineDeck;
    private DeckData activeDeck;
    private DeckData managingDeck;
    private AnkiConnectClient pcClient;
    private List<String> pcDeckNames = new ArrayList<>();
    private List<VitaReceiverClient.Device> vitaDevices = new ArrayList<>();
    private List<VitaReceiverClient.RemoteDeck> remoteVitaDecks = new ArrayList<>();
    private String selectedPcDeck = "";
    private String activeVitaPin = "";
    private String remoteVitaPin = "";
    private String remoteVitaStatus = "";
    private VitaReceiverClient.Device selectedVita;
    private boolean transferScanAttempted;
    private String screen = "home";
    private String status = "Offline and ready";
    private String transferStatus = "The Vita will be found automatically on your local Wi-Fi.";
    private int themeIndex;
    private int cardSizeIndex = 2;
    private int uiSizeIndex = 1;
    private int fontIndex;
    private int confettiMode = 1;
    private boolean animatedFlip = true;
    private boolean busy;
    private boolean activityResumed;
    private boolean answerShown;
    private boolean flipping;
    private int cardIndex = -1;
    private int browserIndex;
    private boolean browserAnswer;
    private int reviewed;
    private int newCardsThisSession;
    private int liveNew;
    private int liveLearn;
    private int liveReview;
    private String lastDeckKey = "";
    private FrameLayout pageFrame;
    private LinearLayout pageColumn;
    private EditText pcHostInput;
    private EditText pcPortInput;
    private EditText pcKeyInput;
    private EditText vitaPinInput;
    private EditText cardFrontEditor;
    private EditText cardBackEditor;
    private FrameLayout studyCardFace;
    private TextView studyCardFaceLabel;
    private LinearLayout studyFlipControls;
    private int studyCardViewport;
    private TextView transferStatusView;
    private long editingCardId;
    private int manageVisibleCount = 50;
    private TextView remoteVitaStatusView;

    private final Theme[] palette = {
            new Theme("#07090D", "#141820", "#1D2430", "#F5F6FA", "#9CA5B6", "#FF3AA8", "#44F58A", "#FFD34F", "#FF667A"),
            new Theme("#F7F8FB", "#FFFFFF", "#E9ECF3", "#1D2230", "#626B7D", "#C00070", "#008B4D", "#8A6500", "#C43150"),
            new Theme("#F4E9D6", "#E7D6B8", "#D9C5A2", "#382A1D", "#78674E", "#A85F38", "#617B46", "#9A702C", "#A4463C"),
            new Theme("#071922", "#0D2935", "#123C49", "#ECFBFA", "#9BC8C9", "#45D9CE", "#71E8C0", "#F0CB77", "#FF8E89"),
            new Theme("#090711", "#1A1530", "#2A2148", "#F7F0FF", "#B4A7C8", "#E34DFF", "#4DE7D8", "#FFB84D", "#FF688B")
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("vitaanki", MODE_PRIVATE);
        deckStore = new DeckStore(this);
        themeIndex = prefs.getInt("theme", 0);
        cardSizeIndex = prefs.getInt("cardSize", 2);
        uiSizeIndex = prefs.getInt("uiSize", 1);
        fontIndex = prefs.getInt("font", 0);
        confettiMode = prefs.getInt("confetti", 1);
        animatedFlip = prefs.getBoolean("flip", true);
        selectedPcDeck = prefs.getString("pcDeck", "");
        lastDeckKey = prefs.getString("lastDeck", "");
        loadInitialDeck();
        updateSystemBars();
        render();
    }

    private void loadInitialDeck() {
        List<File> files = deckStore.listDeckFiles();
        File chosen = null;
        for (File file : files) if (file.getName().equals(lastDeckKey)) chosen = file;
        if (chosen == null && !files.isEmpty()) chosen = files.get(0);
        if (chosen != null) {
            try {
                offlineDeck = deckStore.load(chosen);
                activeDeck = offlineDeck;
                reviewed = 0;
                cardIndex = nextDueIndex(-1);
                status = offlineDeck.cards.size() + " cards ready · progress saves on this device";
            } catch (Exception e) { status = e.getMessage(); }
        }
    }

    private Theme theme() { return palette[Math.max(0, Math.min(themeIndex, palette.length - 1))]; }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private int textSize(int base) { return base + (uiSizeIndex == 0 ? -1 : uiSizeIndex == 1 ? 1 : 3); }

    private void updateSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(color(theme().bg));
        window.setNavigationBarColor(color(theme().bg));
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            int flags = themeIndex == 1 || themeIndex == 2 ? View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : 0;
            if (android.os.Build.VERSION.SDK_INT >= 26 && (themeIndex == 1 || themeIndex == 2)) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            window.getDecorView().setSystemUiVisibility(flags);
        }
    }

    private int color(String value) { return android.graphics.Color.parseColor(value); }

    private void render() {
        if (flipping && studyCardFace != null) {
            studyCardFace.animate().cancel();
            flipping = false;
        }
        studyCardFace = null;
        studyCardFaceLabel = null;
        studyFlipControls = null;
        updateSystemBars();
        pageFrame = new FrameLayout(this);
        pageFrame.setBackgroundColor(color(theme().bg));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        pageColumn = new LinearLayout(this);
        pageColumn.setOrientation(LinearLayout.VERTICAL);
        pageColumn.setPadding(dp(18), dp(16), dp(18), dp(26));
        scroll.addView(pageColumn, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        pageFrame.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            pageFrame.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets systemBars = insets.getInsets(WindowInsets.Type.systemBars());
                pageColumn.setPadding(dp(18), dp(16) + systemBars.top, dp(18), dp(26) + systemBars.bottom);
                return insets;
            });
        }
        setContentView(pageFrame);
        if (android.os.Build.VERSION.SDK_INT >= 35) pageFrame.requestApplyInsets();
        if ("home".equals(screen)) drawHome();
        else if ("study".equals(screen)) drawStudy();
        else if ("decks".equals(screen)) drawDecks();
        else if ("manage".equals(screen)) drawManageDeck();
        else if ("card-editor".equals(screen)) drawCardEditor();
        else if ("browser".equals(screen)) drawBrowser();
        else if ("sync".equals(screen)) drawSync();
        else if ("transfer".equals(screen)) drawTransfer();
        else if ("settings".equals(screen)) drawSettings();
    }

    private void addHeader(String title, String subtitle) {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        if (!"home".equals(screen)) {
            Button back = smallButton("‹", theme().accent);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(46), dp(44));
            bp.rightMargin = dp(10);
            header.addView(back, bp);
            back.setOnClickListener(v -> goBack());
        } else {
            TextView mark = text("V", 21, theme().bg, true);
            mark.setGravity(Gravity.CENTER);
            mark.setBackground(shape(theme().accent, theme().accent, 14));
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(44), dp(44));
            mp.rightMargin = dp(10);
            header.addView(mark, mp);
        }
        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView titleView = text(title, 23, theme().fg, true);
        titleBox.addView(titleView);
        if (subtitle != null && !subtitle.isEmpty()) titleBox.addView(text(subtitle, 13, theme().muted, false));
        header.addView(titleBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        pageColumn.addView(header, margin(0, 0, 0, 15));
    }

    private void drawHome() {
        addHeader("VitaAnki Mobile", "Your pocket study deck");
        if (offlineDeck != null) {
            panel("ACTIVE DECK", displayDeckName(offlineDeck.name) + "  ·  " + offlineDeck.cards.size() + " cards", "Offline progress is saved on this device.");
        } else panel("NO DECK YET", "Import an Anki .apkg or .tsv file to begin.", "You can also connect to Anki Desktop over Wi-Fi.");
        button("Start studying", "Open the current offline or live deck", theme().accent, () -> {
            if (activeDeck != null && "live".equals(activeDeck.mode)) screen = "study";
            else startOfflineStudy();
        });
        button("Deck library", "Create decks, manage cards, and choose what to study", theme().green, () -> { screen = "decks"; render(); });
        button("Import a deck", "Add .apkg or tab-separated .tsv", theme().yellow, this::pickDeck);
        button("Card browser", "Flip through cards without changing progress", theme().accent, () -> { screen = "browser"; browserIndex = Math.max(0, cardIndex); browserAnswer = false; render(); });
        button("Connect to PC Anki", "Use the same AnkiConnect link as VitaAnki", theme().green, () -> { screen = "sync"; render(); });
        button("Send deck to Vita", "Transfer over Wi-Fi into VitaAnki", theme().yellow, this::openTransfer);
        button("Download from Vita", "Browse and copy decks from VitaAnki", theme().green, this::openTransfer);
        button("Settings", "Themes, text, answer flip, and confetti", theme().accent, () -> { screen = "settings"; render(); });
        TextView footer = text(status, 13, theme().muted, false);
        footer.setGravity(Gravity.CENTER);
        pageColumn.addView(footer, margin(4, 14, 4, 0));
    }

    private void drawStudy() {
        String mode = activeDeck != null && "live".equals(activeDeck.mode) ? "LIVE · ANKI DESKTOP" : "OFFLINE · SAVED ON DEVICE";
        addHeader("Study", mode);
        int newCount = 0, learnCount = 0, reviewCount = 0;
        if (activeDeck != null && "live".equals(activeDeck.mode)) {
            newCount = liveNew; learnCount = liveLearn; reviewCount = liveReview;
        } else if (activeDeck != null) {
            long now = System.currentTimeMillis() / 1000L;
            for (CardData card : activeDeck.cards) {
                if (card.state == 0) newCount++;
                else if (card.dueAt <= now && card.state == 1) learnCount++;
                else if (card.dueAt <= now && card.state == 2) reviewCount++;
            }
        }
        LinearLayout counts = new LinearLayout(this);
        counts.setOrientation(LinearLayout.HORIZONTAL);
        counts.addView(stat("NEW", String.valueOf(newCount), theme().accent), new LinearLayout.LayoutParams(0, dp(66), 1));
        counts.addView(stat("LEARNING", String.valueOf(learnCount), theme().yellow), new LinearLayout.LayoutParams(0, dp(66), 1));
        counts.addView(stat("REVIEW", String.valueOf(reviewCount), theme().green), new LinearLayout.LayoutParams(0, dp(66), 1));
        counts.addView(stat("DONE", String.valueOf(reviewed), theme().muted), new LinearLayout.LayoutParams(0, dp(66), 1));
        pageColumn.addView(counts, margin(0, 0, 0, 12));

        CardData card = currentCard();
        LinearLayout cardPanel = new LinearLayout(this);
        cardPanel.setOrientation(LinearLayout.VERTICAL);
        cardPanel.setPadding(dp(18), dp(16), dp(18), dp(18));
        cardPanel.setBackground(shape(theme().panel, theme().accent, 18));
        studyCardFaceLabel = text(card == null ? "SESSION" : answerShown ? "ANSWER" : "QUESTION", 12, theme().muted, true);
        cardPanel.addView(studyCardFaceLabel, margin(0, 0, 0, 10));
        int viewport = Math.max(245, Math.min(460, (int)(getResources().getDisplayMetrics().heightPixels / getResources().getDisplayMetrics().density * 0.43f)));
        studyCardViewport = viewport;
        studyCardFace = new FrameLayout(this);
        studyCardFace.addView(buildCardFace(card, answerShown, CARD_SIZES[Math.max(0, Math.min(cardSizeIndex, CARD_SIZES.length - 1))], viewport),
                new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        cardPanel.addView(studyCardFace, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(viewport)));
        if (card != null) enableTapToFlip(cardPanel, this::toggleCardFace);
        pageColumn.addView(cardPanel, margin(0, 0, 0, 12));

        if (card == null) {
            int unseenNew = 0;
            if (activeDeck != null && !"live".equals(activeDeck.mode))
                for (CardData item : activeDeck.cards) if (item.state == 0) unseenNew++;
            boolean batchComplete = unseenNew > 0 && newCardsThisSession >= NEW_CARD_BATCH_SIZE;
            TextView complete = text(activeDeck != null && "live".equals(activeDeck.mode)
                    ? "No new or due cards right now."
                    : batchComplete
                    ? "20 new cards studied. Learning steps and reviews are prioritized; continue with another batch when ready."
                    : "Nothing is due right now. Your saved progress is intact.", 16, theme().muted, false);
            complete.setGravity(Gravity.CENTER);
            pageColumn.addView(complete, margin(0, 4, 0, 12));
            if (batchComplete) button("Continue with next 20 new cards", "Due learning and review cards still come first", theme().accent, () -> {
                newCardsThisSession = 0;
                cardIndex = nextDueIndex(-1);
                answerShown = false;
                status = "Started the next paced batch.";
                render();
            });
            button("Browse cards", "Preview without rating", theme().accent, () -> { browserIndex = 0; browserAnswer = false; screen = "browser"; render(); });
        } else {
            studyFlipControls = new LinearLayout(this);
            studyFlipControls.setOrientation(LinearLayout.VERTICAL);
            populateStudyFlipControls(studyFlipControls, answerShown);
            pageColumn.addView(studyFlipControls, margin(0, 0, 0, 8));
        }
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        Button undo = smallButton("Undo last", theme().yellow);
        bottom.addView(undo, new LinearLayout.LayoutParams(0, dp(48), 1));
        undo.setOnClickListener(v -> undoLast());
        Button browse = smallButton("Card browser", theme().muted);
        LinearLayout.LayoutParams br = new LinearLayout.LayoutParams(0, dp(48), 1);
        br.leftMargin = dp(8);
        bottom.addView(browse, br);
        browse.setOnClickListener(v -> { browserIndex = Math.max(0, cardIndex); browserAnswer = false; screen = "browser"; render(); });
        pageColumn.addView(bottom, margin(0, 5, 0, 0));
        if (activeDeck != null && !"live".equals(activeDeck.mode) && activeDeck.sourceFile != null)
            button("Manage cards", "Add, edit, or delete cards in this deck", theme().yellow, () -> openManageDeck(activeDeck.sourceFile));
        if (busy) addBusy();
        if (!status.isEmpty()) pageColumn.addView(text(status, 13, theme().muted, false), margin(2, 9, 2, 0));
    }

    private Button ratingButton(String label, String accent, int rating) {
        Button button = smallButton(label, accent);
        button.setTextSize(textSize(16));
        button.setMinHeight(dp(56));
        button.setOnClickListener(v -> rate(rating));
        return button;
    }

    private void populateStudyFlipControls(LinearLayout controls, boolean showAnswer) {
        controls.removeAllViews();
        if (!showAnswer) {
            Button show = smallButton("Show answer", theme().accent);
            show.setTextSize(textSize(16));
            show.setMinHeight(dp(58));
            show.setContentDescription("Show the answer");
            show.setOnClickListener(v -> reveal());
            controls.addView(show, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
            return;
        }
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(ratingButton("Again", theme().red, 0), new LinearLayout.LayoutParams(0, dp(58), 1));
        row1.addView(ratingButton("Hard", theme().yellow, 1), new LinearLayout.LayoutParams(0, dp(58), 1));
        controls.addView(row1, margin(0, 0, 0, 7));
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(ratingButton("Good", theme().green, 2), new LinearLayout.LayoutParams(0, dp(58), 1));
        row2.addView(ratingButton("Easy", theme().accent, 3), new LinearLayout.LayoutParams(0, dp(58), 1));
        controls.addView(row2, margin(0, 0, 0, 0));
    }

    private View buildCardFace(CardData card, boolean answer, int size, int viewportHeight) {
        String body = card == null ? "" : answer ? card.back : card.front;
        boolean hasImage = card != null && !answer && !card.frontImages.isEmpty();
        if (!hasImage) {
            ScrollView scroll = new ScrollView(this);
            scroll.setFillViewport(true);
            scroll.addView(cardText(body, size), new ScrollView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return scroll;
        }

        boolean landscape = getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels;
        LinearLayout split = new LinearLayout(this);
        split.setOrientation(landscape ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        split.setGravity(Gravity.CENTER);
        split.setBackgroundColor(color(theme().panel2));

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setPadding(dp(8), dp(8), dp(8), dp(8));
        image.setBackground(shape(theme().panel2, theme().accent, 8));
        int targetWidth = Math.max(180, getResources().getDisplayMetrics().widthPixels / 2);
        int targetHeight = Math.max(dp(120), dp(viewportHeight / 2));
        Bitmap bitmap = loadCardImage(card.frontImages.get(0), targetWidth, targetHeight);
        if (bitmap != null) image.setImageBitmap(bitmap);
        else image.setContentDescription("Image could not be loaded");

        ScrollView textScroll = new ScrollView(this);
        textScroll.setFillViewport(true);
        textScroll.addView(cardText(body, size), new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (landscape) {
            split.addView(image, new LinearLayout.LayoutParams(0, dp(viewportHeight), 1));
            split.addView(textScroll, new LinearLayout.LayoutParams(0, dp(viewportHeight), 1));
        } else {
            split.addView(image, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
            split.addView(textScroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        }
        return split;
    }

    private TextView cardText(String value, int size) {
        TextView face = text(value, size, theme().fg, false);
        face.setGravity(Gravity.CENTER);
        face.setLineSpacing(dp(5), 1.12f);
        face.setTypeface(fontIndex == 1 ? android.graphics.Typeface.SERIF
                : fontIndex == 2 ? android.graphics.Typeface.MONOSPACE : android.graphics.Typeface.SANS_SERIF);
        face.setPadding(dp(12), dp(10), dp(12), dp(10));
        return face;
    }

    private void enableTapToFlip(View view, Runnable action) {
        view.setOnClickListener(v -> action.run());
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) enableTapToFlip(group.getChildAt(i), action);
        }
    }

    private Bitmap loadCardImage(String path, int targetWidth, int targetHeight) {
        if (path == null || path.isEmpty()) return null;
        Bitmap cached = cardImages.get(path);
        if (cached != null && !cached.isRecycled()) return cached;
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
        int sample = 1;
        while (bounds.outWidth / (sample * 2) >= targetWidth && bounds.outHeight / (sample * 2) >= targetHeight)
            sample *= 2;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        try {
            Bitmap bitmap = BitmapFactory.decodeFile(path, options);
            if (bitmap != null) cardImages.put(path, bitmap);
            return bitmap;
        } catch (OutOfMemoryError ignored) {
            return null;
        }
    }

    private View stat(String label, String value, String accent) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackground(shape(theme().panel, accent, 12));
        TextView labelView = text(label, 10, theme().muted, true);
        labelView.setGravity(Gravity.CENTER);
        box.addView(labelView);
        TextView valueView = text(value, 21, accent, true);
        valueView.setGravity(Gravity.CENTER);
        box.addView(valueView);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        params.setMargins(dp(2), dp(2), dp(2), dp(2));
        box.setLayoutParams(params);
        return box;
    }

    private void drawDecks() {
        addHeader("Deck library", "Choose an offline deck");
        button("Create deck", "Start a text deck, then add cards", theme().yellow, this::showCreateDeckDialog);
        button("Import deck", "Pick an .apkg or .tsv from this device", theme().muted, this::pickDeck);
        List<File> files = deckStore.listDeckFiles();
        if (files.isEmpty()) pageColumn.addView(text("No decks yet. Create or import one to get started.", 16, theme().muted, false), margin(0, 15, 0, 0));
        for (File file : files) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(14), dp(11), dp(12), dp(11));
            card.setBackground(shape(theme().panel, theme().panel2, 14));
            card.addView(text(displayDeckName(stripExt(file.getName())), 17, theme().fg, true));
            card.addView(text(file.getName().toLowerCase(Locale.US).endsWith(".apkg") ? "Anki package" : "Tab-separated deck", 12, theme().muted, false));
            LinearLayout actions = new LinearLayout(this);
            Button study = smallButton("Study", theme().green);
            Button manage = smallButton("Cards", theme().accent);
            Button delete = smallButton("Delete", theme().red);
            for (Button action : new Button[]{study, manage, delete}) {
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(44), 1);
                params.leftMargin = dp(4);
                params.rightMargin = dp(4);
                actions.addView(action, params);
            }
            study.setOnClickListener(v -> openDeck(file));
            manage.setOnClickListener(v -> openManageDeck(file));
            delete.setOnClickListener(v -> confirmDeleteDeck(file));
            card.addView(actions, margin(-4, 8, -4, 0));
            pageColumn.addView(card, margin(0, 0, 0, 8));
        }
        button("Send a deck to Vita", "Use the Vita’s one-time Wi-Fi receiver", theme().accent, this::openTransfer);
        button("Download from Vita", "Browse decks on the nearby Vita", theme().green, this::openTransfer);
    }

    private void drawManageDeck() {
        addHeader("Manage cards", managingDeck == null ? "Choose a deck first" : displayDeckName(managingDeck.name));
        if (managingDeck == null) {
            pageColumn.addView(text("Open the deck library and choose Cards beside a deck.", 15, theme().muted, false));
            return;
        }
        pageColumn.addView(text(managingDeck.cards.size() + " cards · edits stay on this device", 13, theme().muted, false), margin(0, 0, 0, 9));
        button("Add card", "Create a question and answer", theme().yellow, () -> openCardEditor(0));
        button("Delete deck", "Remove this deck and its saved progress", theme().red, () -> confirmDeleteDeck(managingDeck.sourceFile));
        if (managingDeck.cards.isEmpty()) {
            pageColumn.addView(text("This deck is empty. Add the first card above.", 15, theme().muted, false), margin(0, 12, 0, 4));
            return;
        }
        int count = Math.min(managingDeck.cards.size(), manageVisibleCount);
        for (int i = 0; i < count; i++) {
            CardData cardData = managingDeck.cards.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(9), dp(8), dp(9));
            row.setBackground(shape(theme().panel, theme().panel2, 12));
            LinearLayout faces = new LinearLayout(this);
            faces.setOrientation(LinearLayout.VERTICAL);
            faces.addView(text(cardPreview(cardData.front), 14, theme().fg, true));
            faces.addView(text(cardPreview(cardData.back), 12, theme().muted, false));
            row.addView(faces, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            Button edit = smallButton("Edit", theme().accent);
            row.addView(edit, new LinearLayout.LayoutParams(dp(64), dp(42)));
            edit.setOnClickListener(v -> openCardEditor(cardData.id));
            Button delete = smallButton("×", theme().red);
            LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(dp(44), dp(42));
            deleteParams.leftMargin = dp(5);
            row.addView(delete, deleteParams);
            delete.setContentDescription("Delete card");
            delete.setOnClickListener(v -> confirmDeleteCard(cardData));
            pageColumn.addView(row, margin(0, 0, 0, 6));
        }
        if (count < managingDeck.cards.size()) button("Show next cards", "Showing " + count + " of " + managingDeck.cards.size(), theme().muted, () -> { manageVisibleCount += 50; render(); });
    }

    private void drawCardEditor() {
        CardData existing = findManagedCard(editingCardId);
        addHeader(editingCardId == 0 ? "New card" : "Edit card", managingDeck == null ? "" : displayDeckName(managingDeck.name));
        if (managingDeck == null || (editingCardId != 0 && existing == null)) {
            pageColumn.addView(text("That card is no longer available.", 15, theme().muted, false));
            return;
        }
        pageColumn.addView(text("Question", 14, theme().muted, true), margin(0, 0, 0, 4));
        cardFrontEditor = multilineInput("Enter the question", existing == null ? "" : existing.front, 5);
        pageColumn.addView(cardFrontEditor, margin(0, 0, 0, 12));
        pageColumn.addView(text("Answer", 14, theme().muted, true), margin(0, 0, 0, 4));
        cardBackEditor = multilineInput("Enter the answer", existing == null ? "" : existing.back, 5);
        pageColumn.addView(cardBackEditor, margin(0, 0, 0, 14));
        button("Save card", "Save this question and answer", theme().green, this::saveCardEditor);
        button("Cancel", "Return to the card list", theme().muted, () -> { screen = "manage"; render(); });
    }

    private void drawBrowser() {
        addHeader("Card browser", activeDeck == null ? "No deck selected" : displayDeckName(activeDeck.name));
        List<CardData> cards = activeDeck == null ? new ArrayList<>() : activeDeck.cards;
        if (cards.isEmpty()) {
            pageColumn.addView(text("Choose or import a deck first.", 16, theme().muted, false));
            return;
        }
        browserIndex = Math.max(0, Math.min(browserIndex, cards.size() - 1));
        CardData card = cards.get(browserIndex);
        pageColumn.addView(text("CARD " + (browserIndex + 1) + " / " + cards.size(), 13, theme().muted, true), margin(0, 0, 0, 8));
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(16), dp(18), dp(16));
        panel.setBackground(shape(theme().panel, theme().accent, 18));
        panel.addView(text(browserAnswer ? "ANSWER" : "QUESTION", 12, theme().muted, true), margin(0, 0, 0, 12));
        panel.addView(buildCardFace(card, browserAnswer, CARD_SIZES[cardSizeIndex], 360),
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(360)));
        enableTapToFlip(panel, () -> { browserAnswer = !browserAnswer; render(); });
        pageColumn.addView(panel, margin(0, 0, 0, 10));
        button(browserAnswer ? "Show question" : "Show answer", "Browsing never changes scheduling", theme().accent, () -> { browserAnswer = !browserAnswer; render(); });
        LinearLayout nav = new LinearLayout(this);
        Button previous = smallButton("Previous", theme().muted);
        Button next = smallButton("Next", theme().green);
        nav.addView(previous, new LinearLayout.LayoutParams(0, dp(50), 1));
        nav.addView(next, new LinearLayout.LayoutParams(0, dp(50), 1));
        pageColumn.addView(nav, margin(0, 0, 0, 0));
        previous.setOnClickListener(v -> { browserIndex = (browserIndex + cards.size() - 1) % cards.size(); browserAnswer = false; render(); });
        next.setOnClickListener(v -> { browserIndex = (browserIndex + 1) % cards.size(); browserAnswer = false; render(); });
    }

    private void drawSync() {
        addHeader("PC Anki connection", "Manual connection over your home Wi-Fi");
        pageColumn.addView(text("Use the same AnkiConnect setup as on Vita. Anki Desktop must be open on the PC. Keep this connection on a trusted private network.", 14, theme().muted, false), margin(0, 0, 0, 12));
        pcHostInput = input("PC Wi-Fi address, for example 192.168.1.20", InputType.TYPE_CLASS_TEXT);
        pcHostInput.setText(prefs.getString("pcHost", ""));
        pageColumn.addView(pcHostInput, margin(0, 0, 0, 8));
        pcPortInput = input("AnkiConnect port (usually 8765)", InputType.TYPE_CLASS_NUMBER);
        pcPortInput.setText(prefs.getString("pcPort", "8765"));
        pageColumn.addView(pcPortInput, margin(0, 0, 0, 8));
        pcKeyInput = input("AnkiConnect API key", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pcKeyInput.setText(SecretStore.load(this));
        pageColumn.addView(pcKeyInput, margin(0, 0, 0, 8));
        button(busy ? "Connecting…" : "Save and find PC decks", "Loads deck names only after you press this", theme().green, this::testPc);
        if (pcDeckNames.isEmpty()) {
            pageColumn.addView(text("On the PC, AnkiConnect must allow connections from your home network (webBindAddress 0.0.0.0). The PC and phone must be on the same Wi-Fi.", 13, theme().muted, false), margin(0, 12, 0, 0));
        } else {
            pageColumn.addView(text("Choose a deck to start a live review session:", 14, theme().fg, true), margin(0, 14, 0, 8));
            for (String deckName : pcDeckNames) {
                button("Study · " + deckName, "Live ratings go to Anki Desktop", theme().accent, () -> connectPcDeck(deckName));
            }
            button("Refresh PC deck list", "Ask AnkiConnect again", theme().muted, this::testPc);
            button("Send a PC deck to Vita", "Exports card faces as a Vita-readable .tsv", theme().yellow, this::openTransfer);
        }
        pageColumn.addView(text(status, 13, theme().muted, false), margin(0, 8, 0, 0));
        if (busy) addBusy();
    }

    private void drawTransfer() {
        remoteVitaStatusView = null;
        addHeader("Vita deck transfer", "Send decks to Vita or download them here");
        panel("ON YOUR VITA", "Open VitaAnki → Send from Android", "Keep both devices on the same Wi-Fi. VitaAnki Mobile finds the Vita automatically; no IP address is needed.");
        if (!transferScanAttempted) {
            transferScanAttempted = true;
            transferStatus = "Looking for VitaAnki on this Wi-Fi…";
            main.post(this::findVitaReceivers);
        }
        if (selectedVita != null && !busy) {
            pageColumn.addView(text(vitaDevices.size() > 1 ? "VitaAnki receiver selected." : "VitaAnki receiver found.", 14, theme().green, true), margin(0, 0, 0, 6));
        } else if (!busy && vitaDevices.size() > 1) {
            pageColumn.addView(text("More than one VitaAnki receiver was found. Choose the Vita you’re using:", 13, theme().muted, false), margin(0, 0, 0, 4));
            for (int i = 0; i < vitaDevices.size(); i++) {
                final VitaReceiverClient.Device device = vitaDevices.get(i);
                button("Choose VitaAnki receiver " + (i + 1), "Select this nearby Vita", theme().accent, () -> {
                    selectedVita = device;
                    transferStatus = "Receiver selected. Enter the code shown on the Vita.";
                    render();
                });
            }
        }
        if (!busy) button("Find Vita again", "Search this Wi-Fi network", theme().muted, this::findVitaReceivers);
        if (busy && !remoteVitaStatus.isEmpty()) {
            remoteVitaStatusView = text(remoteVitaStatus, 13, theme().muted, false);
            pageColumn.addView(remoteVitaStatusView, margin(0, 4, 0, 6));
        }

        if (selectedVita != null && !busy) {
            pageColumn.addView(text("Enter the short-lived confirmation code shown on the Vita:", 13, theme().muted, false), margin(0, 8, 0, 4));
            vitaPinInput = input("One-time code shown on Vita", InputType.TYPE_CLASS_NUMBER);
            vitaPinInput.setText(activeVitaPin);
            pageColumn.addView(vitaPinInput, margin(0, 0, 0, 10));
            pageColumn.addView(text("Download from Vita", 16, theme().fg, true), margin(0, 0, 0, 4));
            button("Load Vita decks", "List .apkg and .tsv decks on the Vita", theme().green, this::loadVitaDecks);
            if (!remoteVitaStatus.isEmpty()) {
                remoteVitaStatusView = text(remoteVitaStatus, 13, theme().muted, false);
                pageColumn.addView(remoteVitaStatusView, margin(0, 4, 0, 6));
            }
            if (!busy && remoteVitaPin.equals(activeVitaPin)) {
                for (VitaReceiverClient.RemoteDeck remote : remoteVitaDecks) {
                    LinearLayout row = new LinearLayout(this);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    row.setPadding(dp(10), dp(5), dp(8), dp(5));
                    row.setBackground(shape(theme().panel, theme().panel2, 11));
                    LinearLayout info = new LinearLayout(this);
                    info.setOrientation(LinearLayout.VERTICAL);
                    info.addView(text(remote.filename, 13, theme().fg, true));
                    info.addView(text(readableBytes(remote.size), 11, theme().muted, false));
                    row.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                    Button download = smallButton("Download", theme().green);
                    row.addView(download, new LinearLayout.LayoutParams(dp(96), dp(44)));
                    download.setOnClickListener(v -> downloadVitaDeck(remote));
                    pageColumn.addView(row, margin(0, 0, 0, 6));
                }
                if (remoteVitaDecks.isEmpty() && !remoteVitaPin.isEmpty() && remoteVitaStatus.isEmpty())
                    pageColumn.addView(text("No downloadable decks were found on the Vita.", 13, theme().muted, false), margin(0, 4, 0, 6));
            }
            pageColumn.addView(text("Send to Vita", 16, theme().fg, true), margin(0, 10, 0, 4));
            List<File> files = deckStore.listDeckFiles();
            if (files.isEmpty()) pageColumn.addView(text("Import a deck before sending it.", 14, theme().muted, false));
            else for (File file : files) {
                String detail = deckStore.hasEdits(file)
                        ? "Sends your current card text as TSV; images are not included"
                        : file.getName().toLowerCase(Locale.US).endsWith(".apkg")
                        ? "Keeps the original Anki package" : "Sends the Vita-compatible text deck";
                button("Send · " + displayDeckName(stripExt(file.getName())), detail, theme().accent, () -> sendFileToVita(file));
            }
        }
        pageColumn.addView(text("You can also connect to PC Anki and send a selected deck as .tsv. That carries the rendered question and answer text; media and Anki scheduling stay on the PC.", 13, theme().muted, false), margin(0, 10, 0, 4));
        if (!pcDeckNames.isEmpty() && selectedVita != null && !busy) {
            pageColumn.addView(text("PC decks", 15, theme().fg, true), margin(0, 6, 0, 4));
            for (String name : pcDeckNames) button("Send PC deck · " + name, "Creates a text deck VitaAnki can import", theme().yellow, () -> exportPcDeckToVita(name));
        } else if (pcDeckNames.isEmpty()) {
            button("Connect to PC Anki", "Find a PC deck to send", theme().muted, () -> { screen = "sync"; render(); });
        }
        transferStatusView = text(transferStatus, 13, theme().muted, false);
        pageColumn.addView(transferStatusView, margin(0, 8, 0, 0));
        if (busy) addBusy();
    }

    private void drawSettings() {
        addHeader("Settings", "Make it comfortable to read");
        settingRow("Color theme", THEMES[themeIndex], "Choose cyberpunk, sepia, or Aquatic Ambience", () -> { themeIndex = (themeIndex + 1) % THEMES.length; prefs.edit().putInt("theme", themeIndex).apply(); render(); });
        settingRow("Card text size", CARD_SIZES[cardSizeIndex] + " sp", "Changes question and answer text", () -> { cardSizeIndex = (cardSizeIndex + 1) % CARD_SIZES.length; prefs.edit().putInt("cardSize", cardSizeIndex).apply(); render(); });
        settingRow("Menu text size", UI_SIZES[uiSizeIndex] + " sp", "Makes buttons and menus larger", () -> { uiSizeIndex = (uiSizeIndex + 1) % UI_SIZES.length; prefs.edit().putInt("uiSize", uiSizeIndex).apply(); render(); });
        settingRow("Font", FONTS[fontIndex], "Sans, serif, or monospaced", () -> { fontIndex = (fontIndex + 1) % FONTS.length; prefs.edit().putInt("font", fontIndex).apply(); render(); });
        settingRow("Answer flip", animatedFlip ? "Animated" : "Instant", "Toggle the card turn", () -> { animatedFlip = !animatedFlip; prefs.edit().putBoolean("flip", animatedFlip).apply(); render(); });
        settingRow("Confetti", new String[]{"Off", "Good + Easy", "Easy only"}[confettiMode], "Brief celebration after a remembered card", () -> { confettiMode = (confettiMode + 1) % 3; prefs.edit().putInt("confetti", confettiMode).apply(); render(); });
        panel("PROGRESS", "Offline ratings save after every answer.", "AnkiConnect live ratings are sent to PC Anki immediately.");
    }

    private void settingRow(String title, String value, String detail, Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(11), dp(12), dp(11));
        row.setBackground(shape(theme().panel, theme().panel2, 14));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.addView(text(title, textSize(15), theme().fg, true));
        info.addView(text(value, 13, theme().accent, true));
        info.addView(text(detail, 11, theme().muted, false));
        row.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(text("›", 24, theme().accent, true));
        pageColumn.addView(row, margin(0, 0, 0, 8));
        row.setOnClickListener(v -> action.run());
    }

    private void panel(String title, String mainText, String detail) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(shape(theme().panel, theme().panel2, 16));
        card.addView(text(title, 11, theme().accent, true), margin(0, 0, 0, 5));
        card.addView(text(mainText, 17, theme().fg, true), margin(0, 0, 0, 3));
        card.addView(text(detail, 13, theme().muted, false));
        pageColumn.addView(card, margin(0, 0, 0, 12));
    }

    private void button(String title, String detail, String accent, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(12), dp(11), dp(14), dp(11));
        card.setBackground(shape(theme().panel, theme().panel2, 15));
        View accentMarker = new View(this);
        accentMarker.setBackground(shape(accent, accent, 3));
        LinearLayout.LayoutParams markerParams = new LinearLayout.LayoutParams(dp(3), dp(34));
        markerParams.rightMargin = dp(12);
        card.addView(accentMarker, markerParams);
        LinearLayout textBlock = new LinearLayout(this);
        textBlock.setOrientation(LinearLayout.VERTICAL);
        textBlock.addView(text(title, textSize(16), theme().fg, true));
        if (detail != null && !detail.isEmpty()) textBlock.addView(text(detail, 12, theme().muted, false));
        card.addView(textBlock, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView arrow = text("›", 24, accent, true);
        card.addView(arrow);
        pageColumn.addView(card, margin(0, 0, 0, 8));
        card.setMinimumHeight(dp(58));
        card.setOnClickListener(v -> { if (!busy) action.run(); });
        card.setClickable(true);
        card.setFocusable(true);
    }

    private Button smallButton(String label, String accent) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(color(accent));
        button.setTextSize(textSize(14));
        button.setAllCaps(false);
        button.setPadding(dp(8), dp(3), dp(8), dp(3));
        button.setBackground(shape(theme().panel, theme().panel2, 12));
        return button;
    }

    private TextView text(String value, int size, String color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value == null ? "" : value);
        view.setTextColor(color(color));
        view.setTextSize(textSize(size));
        if (bold) view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        view.setLineSpacing(dp(2), 1.05f);
        return view;
    }

    private EditText input(String hint, int inputType) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setHint(hint);
        edit.setTextColor(color(theme().fg));
        edit.setHintTextColor(color(theme().muted));
        edit.setTextSize(15);
        edit.setInputType(inputType);
        edit.setPadding(dp(13), dp(5), dp(13), dp(5));
        edit.setBackground(shape(theme().panel, theme().panel2, 12));
        edit.setSelectAllOnFocus(false);
        return edit;
    }

    private GradientDrawable shape(String fill, String stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color(fill));
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(1), color(stroke));
        return drawable;
    }

    private LinearLayout.LayoutParams margin(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private void addBusy() {
        TextView text = text("Working…", 14, theme().accent, true);
        text.setGravity(Gravity.CENTER);
        pageColumn.addView(text, margin(0, 10, 0, 4));
    }

    private CardData currentCard() {
        if (activeDeck == null || cardIndex < 0 || cardIndex >= activeDeck.cards.size()) return null;
        return activeDeck.cards.get(cardIndex);
    }

    private int nextDueIndex(int after) {
        if (activeDeck == null || activeDeck.cards.isEmpty()) return -1;
        long now = System.currentTimeMillis() / 1000L;
        int size = activeDeck.cards.size();
        for (int state : new int[]{1, 2, 0}) {
            for (int step = 1; step <= size; step++) {
                int index = (after + step + size) % size;
                CardData card = activeDeck.cards.get(index);
                if (card.state != state) continue;
                if (state == 0) {
                    if (newCardsThisSession < NEW_CARD_BATCH_SIZE) return index;
                } else if (card.dueAt <= now) {
                    return index;
                }
            }
        }
        return -1;
    }

    private void scheduleLiveQueueRefresh() {
        main.removeCallbacks(liveQueueRefresh);
        if (!activityResumed || !"study".equals(screen) || activeDeck == null ||
                !"live".equals(activeDeck.mode) || cardIndex >= 0 || liveLearn <= 0 || busy) return;
        main.postDelayed(liveQueueRefresh, 10_000L);
    }

    private void scheduleOfflineLearningRefresh() {
        main.removeCallbacks(offlineLearningRefresh);
        if (!activityResumed || !"study".equals(screen) || activeDeck == null ||
                "live".equals(activeDeck.mode) || cardIndex >= 0 || busy) return;
        boolean learningWaiting = false;
        for (CardData card : activeDeck.cards) if (card.state == 1) { learningWaiting = true; break; }
        if (learningWaiting) main.postDelayed(offlineLearningRefresh, 5_000L);
    }

    private void refreshOfflineLearning() {
        if (!activityResumed || !"study".equals(screen) || activeDeck == null ||
                "live".equals(activeDeck.mode) || cardIndex >= 0 || busy) return;
        cardIndex = nextDueIndex(-1);
        if (cardIndex >= 0) {
            answerShown = false;
            status = "A learning step is due.";
            render();
        } else {
            scheduleOfflineLearningRefresh();
        }
    }

    private void refreshLiveQueue() {
        if (!activityResumed || !"study".equals(screen) || activeDeck == null ||
                !"live".equals(activeDeck.mode) || cardIndex >= 0 || liveLearn <= 0 || busy) return;
        DeckData targetDeck = activeDeck;
        AnkiConnectClient targetClient = pcClient;
        busy = true;
        status = "Waiting for Anki’s next learning step…";
        render();
        worker.execute(() -> {
            try {
                List<CardData> cards = targetClient.fetchStudyCards(targetDeck.name);
                int[] counts = readCounts(targetClient, targetDeck.name);
                main.post(() -> {
                    if (activeDeck != targetDeck || !"live".equals(activeDeck.mode)) return;
                    activeDeck.cards.clear();
                    activeDeck.cards.addAll(cards);
                    liveNew = counts[0]; liveLearn = counts[1]; liveReview = counts[2];
                    cardIndex = cards.isEmpty() ? -1 : 0;
                    answerShown = false;
                    busy = false;
                    status = cards.isEmpty() ? "No learning step is due yet; checking again soon." : "Anki learning step is ready.";
                    render();
                    scheduleLiveQueueRefresh();
                });
            } catch (Exception e) {
                main.post(() -> {
                    if (activeDeck != targetDeck) return;
                    busy = false;
                    status = safeMessage(e);
                    render();
                    scheduleLiveQueueRefresh();
                });
            }
        });
    }

    private void startOfflineStudy() {
        if (offlineDeck == null) {
            List<File> files = deckStore.listDeckFiles();
            if (!files.isEmpty()) openDeck(files.get(0));
            else toast("Import a deck first.");
            return;
        }
        activeDeck = offlineDeck;
        reviewed = 0;
        newCardsThisSession = 0;
        cardIndex = nextDueIndex(-1);
        answerShown = false;
        screen = "study";
        status = "Offline progress is saved on this device.";
        render();
        scheduleOfflineLearningRefresh();
    }

    private void openDeck(File file) {
        try {
            offlineDeck = deckStore.load(file);
            activeDeck = offlineDeck;
            reviewed = 0;
            newCardsThisSession = 0;
            cardIndex = nextDueIndex(-1);
            answerShown = false;
            status = offlineDeck.cards.size() + " cards ready · progress saved on this device";
            screen = "study";
            render();
            scheduleOfflineLearningRefresh();
        } catch (Exception e) {
            screen = "decks";
            render();
            toast(e.getMessage() == null ? "Could not load that deck." : e.getMessage());
        }
    }

    private void reveal() {
        flipTo(true);
    }

    private void toggleCardFace() {
        flipTo(!answerShown);
    }

    private void flipTo(boolean showAnswer) {
        if (currentCard() == null || answerShown == showAnswer || flipping) return;
        if (!animatedFlip || studyCardFace == null || studyCardFaceLabel == null) {
            answerShown = showAnswer;
            render();
            return;
        }
        flipping = true;
        CardData flippingCard = currentCard();
        long flippingCardId = flippingCard.id;
        float turnDirection = showAnswer ? 1f : -1f;
        int cardTextSize = CARD_SIZES[Math.max(0, Math.min(cardSizeIndex, CARD_SIZES.length - 1))];
        int viewport = studyCardViewport;
        FrameLayout face = studyCardFace;
        TextView label = studyCardFaceLabel;
        float cameraDistance = dp(9000);
        face.animate().cancel();
        face.setCameraDistance(cameraDistance);
        face.setPivotX(face.getWidth() / 2f);
        face.setPivotY(face.getHeight() / 2f);
        face.animate().rotationY(90f * turnDirection).scaleX(0.99f)
                .setDuration(155).setInterpolator(new AccelerateInterpolator(1.15f)).withEndAction(() -> {
            if (!"study".equals(screen) || currentCard() == null || currentCard().id != flippingCardId) {
                flipping = false;
                return;
            }
            answerShown = showAnswer;
            label.setText(showAnswer ? "ANSWER" : "QUESTION");
            if (studyFlipControls != null) populateStudyFlipControls(studyFlipControls, showAnswer);
            face.removeAllViews();
            face.addView(buildCardFace(flippingCard, showAnswer, cardTextSize, viewport),
                    new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            enableTapToFlip(face, this::toggleCardFace);
            face.setCameraDistance(cameraDistance);
            face.setPivotX(face.getWidth() / 2f);
            face.setPivotY(face.getHeight() / 2f);
            face.setRotationY(-90f * turnDirection);
            face.setScaleX(0.99f);
            face.animate().rotationY(0f).scaleX(1f)
                    .setDuration(185).setInterpolator(new DecelerateInterpolator(1.15f))
                    .withEndAction(() -> flipping = false).start();
        }).start();
    }

    private void rate(int rating) {
        CardData card = currentCard();
        if (card == null || !answerShown || busy || flipping) return;
        undo = new UndoState(card.id, card.intervalDays, card.dueAt, card.state, reviewed, cardIndex, newCardsThisSession);
        if (activeDeck != null && "live".equals(activeDeck.mode)) {
            busy = true;
            render();
            worker.execute(() -> {
                try {
                    pcClient.answer(card.id, rating + 1);
                    List<CardData> cards = pcClient.fetchStudyCards(activeDeck.name);
                    int[] counts = readCounts(pcClient, activeDeck.name);
                    main.post(() -> {
                        activeDeck.cards.clear(); activeDeck.cards.addAll(cards);
                        liveNew = counts[0]; liveLearn = counts[1]; liveReview = counts[2];
                        reviewed++; cardIndex = activeDeck.cards.isEmpty() ? -1 : 0; answerShown = false;
                        busy = false; status = "Rating sent to Anki Desktop."; showConfetti(rating); render(); scheduleLiveQueueRefresh();
                    });
                } catch (Exception e) { main.post(() -> { busy = false; status = safeMessage(e); render(); scheduleLiveQueueRefresh(); }); }
            });
            return;
        }
        long now = System.currentTimeMillis() / 1000L;
        int previousState = card.state;
        if (previousState == 0) newCardsThisSession++;
        long next;
        if (rating == 0) next = 0;
        else if (rating == 1 && previousState != 2) next = 0;
        else if (rating == 1) next = card.intervalDays < 1 ? 1 : Math.max(1, (card.intervalDays * 12L + 9L) / 10L);
        else if (rating == 2) next = card.intervalDays < 1 ? 1 : card.intervalDays * 2L;
        else next = card.intervalDays < 1 ? 4 : card.intervalDays * 3L;
        card.intervalDays = (int)Math.min(next, MAX_OFFLINE_INTERVAL);
        card.dueAt = rating == 0 ? now + 60 : rating == 1 && previousState != 2 ? now + 300 : now + card.intervalDays * 86400L;
        card.state = (rating == 0 || (rating == 1 && previousState != 2)) ? 1 : 2;
        reviewed++;
        deckStore.saveProgress(activeDeck, reviewed);
        showConfetti(rating);
        cardIndex = nextDueIndex(cardIndex);
        answerShown = false;
        status = "Progress saved on this device.";
        render();
        scheduleOfflineLearningRefresh();
    }

    private UndoState undo;

    private void undoLast() {
        if (undo == null || activeDeck == null) { toast("Nothing to undo yet."); return; }
        if ("live".equals(activeDeck.mode)) {
            busy = true; render();
            worker.execute(() -> {
                try {
                    pcClient.undo();
                    List<CardData> cards = pcClient.fetchStudyCards(activeDeck.name);
                    int[] counts = readCounts(pcClient, activeDeck.name);
                    main.post(() -> {
                        activeDeck.cards.clear(); activeDeck.cards.addAll(cards);
                        liveNew = counts[0]; liveLearn = counts[1]; liveReview = counts[2];
                        reviewed = Math.max(0, reviewed - 1); cardIndex = activeDeck.cards.isEmpty() ? -1 : 0;
                        answerShown = true; undo = null; busy = false; status = "Undid the last PC review."; render(); scheduleLiveQueueRefresh();
                    });
                } catch (Exception e) { main.post(() -> { busy = false; status = safeMessage(e); render(); scheduleLiveQueueRefresh(); }); }
            });
            return;
        }
        for (CardData card : activeDeck.cards) if (card.id == undo.cardId) {
            card.intervalDays = undo.interval; card.dueAt = undo.due; card.state = undo.state;
            reviewed = undo.reviewed;
            newCardsThisSession = undo.newCardsThisSession;
            cardIndex = activeDeck.cards.indexOf(card);
            answerShown = true;
            deckStore.saveProgress(activeDeck, reviewed);
            this.undo = null;
            status = "Last rating undone; progress saved.";
            render();
            return;
        }
        toast("Could not find the card to undo.");
    }

    private void showConfetti(int rating) {
        if (confettiMode == 0 || (confettiMode == 2 && rating != 3) || (confettiMode == 1 && rating < 2)) return;
        ConfettiOverlay overlay = new ConfettiOverlay(this, theme());
        pageFrame.addView(overlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overlay.start(() -> pageFrame.removeView(overlay));
    }

    private void showCreateDeckDialog() {
        EditText name = input("Deck name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        new AlertDialog.Builder(this)
                .setTitle("Create a deck")
                .setMessage("You can add questions and answers next.")
                .setView(name)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Create", (dialog, which) -> {
                    try {
                        File file = deckStore.createDeck(name.getText().toString());
                        openManageDeck(file);
                    } catch (Exception e) {
                        toast(e.getMessage() == null ? "Could not create the deck." : e.getMessage());
                    }
                }).show();
    }

    private void openManageDeck(File file) {
        try {
            if (sameDeck(offlineDeck, file)) managingDeck = offlineDeck;
            else managingDeck = deckStore.load(file);
            manageVisibleCount = 50;
            screen = "manage";
            render();
        } catch (Exception e) {
            toast(e.getMessage() == null ? "Could not open that deck." : e.getMessage());
        }
    }

    private void openCardEditor(long cardId) {
        editingCardId = cardId;
        screen = "card-editor";
        render();
    }

    private void saveCardEditor() {
        if (managingDeck == null || cardFrontEditor == null || cardBackEditor == null) return;
        String front = cardFrontEditor.getText().toString().trim();
        String back = cardBackEditor.getText().toString().trim();
        if (front.isEmpty()) { toast("Enter a question first."); return; }
        if (back.isEmpty()) { toast("Enter an answer first."); return; }
        CardData card = editingCardId == 0 ? null : findManagedCard(editingCardId);
        boolean added = false;
        String previousFront = null;
        String previousBack = null;
        if (card == null) {
            if (editingCardId != 0) { toast("That card is no longer available."); return; }
            if (managingDeck.cards.size() >= MAX_EDITABLE_CARDS) { toast("A deck can contain up to 2,000 cards on this device."); return; }
            card = new CardData(deckStore.newCardId(managingDeck), front, back);
            managingDeck.cards.add(card);
            editingCardId = card.id;
            added = true;
        } else {
            previousFront = card.front;
            previousBack = card.back;
            card.front = front;
            card.back = back;
        }
        try {
            deckStore.saveEdits(managingDeck);
            refreshManagedDeckReferences();
            screen = "manage";
            render();
        } catch (Exception e) {
            if (added) managingDeck.cards.remove(card);
            else {
                card.front = previousFront;
                card.back = previousBack;
            }
            editingCardId = added ? 0 : editingCardId;
            toast(e.getMessage() == null ? "Could not save the card." : e.getMessage());
        }
    }

    private CardData findManagedCard(long id) {
        if (managingDeck == null || id == 0) return null;
        for (CardData card : managingDeck.cards) if (card.id == id) return card;
        return null;
    }

    private String cardPreview(String value) {
        String preview = value == null ? "" : value.replaceAll("\\s+", " ").trim();
        if (preview.length() > 88) preview = preview.substring(0, 85) + "…";
        return preview;
    }

    private boolean sameDeck(DeckData deck, File file) {
        return deck != null && deck.sourceFile != null && file != null &&
                deck.sourceFile.getAbsolutePath().equals(file.getAbsolutePath());
    }

    private boolean sameDeck(DeckData left, DeckData right) {
        return left != null && sameDeck(left, right == null ? null : right.sourceFile);
    }

    private void refreshManagedDeckReferences() {
        boolean wasOffline = sameDeck(offlineDeck, managingDeck);
        boolean wasActiveOffline = activeDeck != null && !"live".equals(activeDeck.mode) && sameDeck(activeDeck, managingDeck);
        if (wasOffline) offlineDeck = managingDeck;
        if (wasActiveOffline) {
            activeDeck = managingDeck;
            cardIndex = nextDueIndex(-1);
            answerShown = false;
            status = managingDeck.cards.size() + " cards ready · changes saved on this device";
        }
    }

    private void confirmDeleteCard(CardData card) {
        new AlertDialog.Builder(this)
                .setTitle("Delete this card?")
                .setMessage(cardPreview(card.front))
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> deleteCard(card))
                .show();
    }

    private void deleteCard(CardData card) {
        if (managingDeck == null) return;
        int removedAt = -1;
        for (int i = 0; i < managingDeck.cards.size(); i++) {
            if (managingDeck.cards.get(i).id == card.id) {
                managingDeck.cards.remove(i);
                removedAt = i;
                break;
            }
        }
        try {
            deckStore.saveEdits(managingDeck);
            refreshManagedDeckReferences();
            render();
        } catch (Exception e) {
            if (removedAt >= 0) managingDeck.cards.add(removedAt, card);
            toast(e.getMessage() == null ? "Could not delete that card." : e.getMessage());
            render();
        }
    }

    private void confirmDeleteDeck(File file) {
        new AlertDialog.Builder(this)
                .setTitle("Delete this deck?")
                .setMessage("This removes “" + displayDeckName(stripExt(file.getName())) +
                        "” and its saved study progress from this device.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete deck", (dialog, which) -> deleteDeck(file))
                .show();
    }

    private void deleteDeck(File file) {
        try {
            boolean removesActive = activeDeck != null && !"live".equals(activeDeck.mode) && sameDeck(activeDeck, file);
            deckStore.deleteDeck(file);
            if (sameDeck(offlineDeck, file)) offlineDeck = null;
            if (removesActive) {
                activeDeck = null;
                cardIndex = -1;
                answerShown = false;
                if ("study".equals(screen)) screen = "home";
            }
            if (sameDeck(managingDeck, file)) managingDeck = null;
            status = "Deck deleted from this device.";
            screen = "decks";
            render();
        } catch (Exception e) {
            toast(e.getMessage() == null ? "Could not delete that deck." : e.getMessage());
        }
    }

    private EditText multilineInput(String hint, String value, int lines) {
        EditText edit = new EditText(this);
        edit.setSingleLine(false);
        edit.setMinLines(lines);
        edit.setMaxLines(lines + 3);
        edit.setGravity(Gravity.TOP | Gravity.START);
        edit.setHint(hint);
        edit.setText(value);
        edit.setTextColor(color(theme().fg));
        edit.setHintTextColor(color(theme().muted));
        edit.setTextSize(16);
        edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        edit.setPadding(dp(13), dp(10), dp(13), dp(10));
        edit.setBackground(shape(theme().panel, theme().panel2, 12));
        edit.setVerticalScrollBarEnabled(true);
        return edit;
    }

    private void pickDeck() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "text/tab-separated-values", "text/plain"});
        try { startActivityForResult(intent, PICK_DECK); }
        catch (Exception e) { toast("Could not open the Android file picker."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_DECK || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            File file = deckStore.importUri(uri);
            openDeck(file);
        } catch (Exception e) { toast(e.getMessage() == null ? "Could not import that deck." : e.getMessage()); }
    }

    private void testPc() {
        savePcConfig();
        AnkiConnectClient client = newPcClient();
        busy = true; status = "Contacting Anki Desktop…"; render();
        worker.execute(() -> {
            try {
                List<String> names = client.deckNames();
                main.post(() -> { pcClient = client; pcDeckNames = names; busy = false; status = "Connected to Anki Desktop · " + names.size() + " decks"; render(); });
            } catch (Exception e) { main.post(() -> { busy = false; status = safeMessage(e); render(); }); }
        });
    }

    private void connectPcDeck(String name) {
        savePcConfig();
        AnkiConnectClient client = newPcClient();
        pcClient = client;
        selectedPcDeck = name;
        prefs.edit().putString("pcDeck", name).apply();
        busy = true; status = "Loading due cards from Anki Desktop…"; render();
        worker.execute(() -> {
            try {
                List<CardData> cards = client.fetchStudyCards(name);
                int[] counts = readCounts(client, name);
                main.post(() -> {
                    activeDeck = new DeckData(name, null); activeDeck.mode = "live"; activeDeck.cards.addAll(cards);
                    liveNew = counts[0]; liveLearn = counts[1]; liveReview = counts[2];
                    reviewed = 0; cardIndex = cards.isEmpty() ? -1 : 0; answerShown = false; busy = false;
                    screen = "study"; status = cards.size() + " due/new cards loaded from PC Anki."; render(); scheduleLiveQueueRefresh();
                });
            } catch (Exception e) { main.post(() -> { busy = false; status = safeMessage(e); render(); }); }
        });
    }

    private int[] readCounts(AnkiConnectClient client, String name) {
        try { return client.studyCounts(name); }
        catch (Exception ignored) { return new int[3]; }
    }

    private AnkiConnectClient newPcClient() {
        return new AnkiConnectClient(prefs.getString("pcHost", ""), parsePort(prefs.getString("pcPort", "8765"), 8765), SecretStore.load(this));
    }

    private void savePcConfig() {
        String host = pcHostInput == null ? prefs.getString("pcHost", "") : pcHostInput.getText().toString().trim();
        String port = pcPortInput == null ? prefs.getString("pcPort", "8765") : pcPortInput.getText().toString().trim();
        String key = pcKeyInput == null ? SecretStore.load(this) : pcKeyInput.getText().toString().trim();
        prefs.edit().putString("pcHost", host).putString("pcPort", port).apply();
        SecretStore.save(this, key);
    }

    private void saveVitaConfig() {
        if (vitaPinInput != null) activeVitaPin = vitaPinInput.getText().toString().trim();
    }

    private void openTransfer() {
        screen = "transfer";
        transferScanAttempted = false;
        selectedVita = null;
        vitaDevices = new ArrayList<>();
        remoteVitaDecks = new ArrayList<>();
        remoteVitaPin = "";
        remoteVitaStatus = "";
        transferStatus = "Looking for VitaAnki on this Wi-Fi…";
        render();
    }

    private void findVitaReceivers() {
        if (!"transfer".equals(screen) || busy) return;
        busy = true;
        transferScanAttempted = true;
        remoteVitaDecks.clear();
        remoteVitaPin = "";
        remoteVitaStatus = "";
        transferStatus = "Looking for VitaAnki on this Wi-Fi…";
        render();
        worker.execute(() -> {
            List<VitaReceiverClient.Device> found = null;
            String error = null;
            try { found = VitaReceiverClient.discover(); }
            catch (Exception e) { error = safeMessage(e); }
            final List<VitaReceiverClient.Device> result = found == null ? new ArrayList<>() : found;
            final String failure = error;
            main.post(() -> {
                busy = false;
                vitaDevices = result;
                selectedVita = result.size() == 1 ? result.get(0) : null;
                if (failure != null) transferStatus = failure;
                else if (result.size() == 1) transferStatus = "Ready to send a deck.";
                else if (result.size() > 1) transferStatus = "Found " + result.size() + " VitaAnki receivers. Choose the Vita you’re using.";
                else transferStatus = "No Vita found. Keep Send from Android open on the Vita, check that both devices are on the same non-guest Wi-Fi and that the router allows them to communicate, then search again.";
                if ("transfer".equals(screen)) render();
            });
        });
    }

    private void loadVitaDecks() {
        saveVitaConfig();
        String pin = activeVitaPin;
        VitaReceiverClient.Device receiver = selectedVita;
        if (receiver == null) { toast("Find VitaAnki on Wi-Fi first."); return; }
        if (pin.length() != 6) { toast("Enter the six-digit code shown on the Vita."); return; }
        busy = true;
        remoteVitaDecks.clear();
        remoteVitaPin = pin;
        remoteVitaStatus = "Loading decks from VitaAnki…";
        render();
        worker.execute(() -> {
            try {
                List<VitaReceiverClient.RemoteDeck> decks = VitaReceiverClient.listDecks(receiver, pin);
                main.post(() -> {
                    busy = false;
                    remoteVitaDecks = decks;
                    remoteVitaStatus = decks.isEmpty() ? "No transferable decks are available on the Vita." :
                            "Found " + decks.size() + " deck" + (decks.size() == 1 ? "" : "s") + " on the Vita.";
                    if ("transfer".equals(screen)) render();
                });
            } catch (Exception e) {
                main.post(() -> {
                    busy = false;
                    remoteVitaDecks.clear();
                    remoteVitaStatus = safeMessage(e);
                    if ("transfer".equals(screen)) render();
                });
            }
        });
    }

    private void downloadVitaDeck(VitaReceiverClient.RemoteDeck deck) {
        saveVitaConfig();
        String pin = activeVitaPin;
        VitaReceiverClient.Device receiver = selectedVita;
        if (receiver == null) { toast("Find VitaAnki on Wi-Fi first."); return; }
        if (pin.length() != 6) { toast("Enter the six-digit code shown on the Vita."); return; }
        if (!pin.equals(remoteVitaPin)) { toast("Load the Vita deck list again with the current code."); return; }
        busy = true;
        remoteVitaStatus = "Downloading " + deck.filename + "…";
        render();
        worker.execute(() -> {
            try {
                final int[] lastPercent = {-1};
                File received = VitaReceiverClient.download(receiver, pin, deck, deckStore.getDeckFolder(), (done, total) -> {
                    int percent = (int)(done * 100 / Math.max(1, total));
                    if (percent == lastPercent[0]) return;
                    lastPercent[0] = percent;
                    main.post(() -> {
                        remoteVitaStatus = "Downloading… " + percent + "%";
                        if (remoteVitaStatusView != null) remoteVitaStatusView.setText(remoteVitaStatus);
                    });
                });
                main.post(() -> {
                    busy = false;
                    remoteVitaDecks.clear();
                    remoteVitaPin = "";
                    remoteVitaStatus = "Downloaded " + received.getName() + ". It is now in the deck library.";
                    status = remoteVitaStatus;
                    if ("transfer".equals(screen)) render();
                });
            } catch (Exception e) {
                main.post(() -> {
                    busy = false;
                    remoteVitaStatus = safeMessage(e);
                    if ("transfer".equals(screen)) render();
                });
            }
        });
    }

    private String readableBytes(long bytes) {
        if (bytes >= 1024L * 1024L) return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
        return Math.max(1, (bytes + 1023L) / 1024L) + " KB";
    }

    private int parsePort(String value, int fallback) {
        try { int n = Integer.parseInt(value.trim()); return n > 0 && n < 65536 ? n : fallback; }
        catch (Exception e) { return fallback; }
    }

    private void sendFileToVita(File file) {
        saveVitaConfig();
        String pin = activeVitaPin;
        VitaReceiverClient.Device receiver = selectedVita;
        if (receiver == null) { toast("Find a VitaAnki receiver first."); return; }
        if (pin.length() != 6) { toast("Enter the six-digit code shown on the Vita."); return; }
        busy = true; transferStatus = "Sending deck to VitaAnki…"; render();
        worker.execute(() -> {
            File editedCopy = null;
            try {
                File payload = file;
                if (deckStore.hasEdits(file)) {
                    DeckData current = deckStore.load(file);
                    editedCopy = deckStore.exportTsv(current, getCacheDir());
                    payload = editedCopy;
                }
                VitaReceiverClient.send(payload, receiver, pin, (sent, total) -> main.post(() -> {
                    transferStatus = total <= 0 ? "Sending…" : "Sending… " + (int)(sent * 100 / total) + "%";
                    if (transferStatusView != null) transferStatusView.setText(transferStatus);
                }));
                main.post(() -> { busy = false; activeVitaPin = ""; selectedVita = null; vitaDevices.clear(); remoteVitaDecks.clear(); remoteVitaPin = ""; remoteVitaStatus = ""; transferStatus = "Deck received by VitaAnki. Restart Send from Android on the Vita before another transfer."; status = transferStatus; render(); });
            } catch (Exception e) { main.post(() -> { busy = false; transferStatus = safeMessage(e); render(); }); }
            finally { if (editedCopy != null) editedCopy.delete(); }
        });
    }

    private void exportPcDeckToVita(String name) {
        saveVitaConfig();
        String pin = activeVitaPin;
        VitaReceiverClient.Device receiver = selectedVita;
        if (receiver == null) { toast("Find a VitaAnki receiver first."); return; }
        if (pin.length() != 6) { toast("Enter the six-digit code shown on the Vita."); return; }
        AnkiConnectClient client = pcClient == null ? newPcClient() : pcClient;
        busy = true; transferStatus = "Building a Vita-compatible text copy…"; render();
        worker.execute(() -> {
            File temp = null;
            try {
                temp = client.exportTsv(name, getCacheDir());
                final File result = temp;
                main.post(() -> { transferStatus = "Sending PC deck to VitaAnki…"; render(); });
                VitaReceiverClient.send(result, receiver, pin, (sent, total) -> main.post(() -> {
                    transferStatus = "Sending PC deck… " + (int)(sent * 100 / Math.max(1, total)) + "%";
                    if (transferStatusView != null) transferStatusView.setText(transferStatus);
                }));
                main.post(() -> { busy = false; activeVitaPin = ""; selectedVita = null; vitaDevices.clear(); remoteVitaDecks.clear(); remoteVitaPin = ""; remoteVitaStatus = ""; transferStatus = "PC deck sent as a .tsv text copy. Restart Send from Android on the Vita before another transfer."; render(); });
            } catch (Exception e) { main.post(() -> { busy = false; transferStatus = safeMessage(e); render(); }); }
            finally { if (temp != null) temp.delete(); }
        });
    }

    private void goHome() { screen = "home"; render(); }
    private void goBack() {
        if ("card-editor".equals(screen)) screen = "manage";
        else if ("manage".equals(screen)) screen = "decks";
        else screen = "home";
        render();
    }
    private String stripExt(String name) { int dot = name.lastIndexOf('.'); return dot > 0 ? name.substring(0, dot) : name; }
    private String displayDeckName(String name) { return name == null ? "" : name.replace('_', ' ').replaceAll("\\s+", " ").trim(); }
    private String safeMessage(Exception e) { String message = e.getMessage(); return message == null || message.trim().isEmpty() ? "Connection failed. Check both devices and try again." : message; }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    @Override public void onBackPressed() {
        if (!"home".equals(screen)) goBack();
        else super.onBackPressed();
    }

    @Override protected void onPause() { activityResumed = false; main.removeCallbacks(liveQueueRefresh); main.removeCallbacks(offlineLearningRefresh); super.onPause(); }
    @Override protected void onResume() { super.onResume(); activityResumed = true; scheduleLiveQueueRefresh(); scheduleOfflineLearningRefresh(); }
    @Override protected void onDestroy() {
        super.onDestroy();
        main.removeCallbacks(liveQueueRefresh);
        main.removeCallbacks(offlineLearningRefresh);
        
        worker.shutdownNow();
    }

    private static final class UndoState {
        final long cardId, due;
        final int interval, state, reviewed, index, newCardsThisSession;
        UndoState(long cardId, int interval, long due, int state, int reviewed, int index, int newCardsThisSession) {
            this.cardId = cardId; this.interval = interval; this.due = due; this.state = state; this.reviewed = reviewed; this.index = index; this.newCardsThisSession = newCardsThisSession;
        }
    }

    private static final class Theme {
        final String bg, panel, panel2, fg, muted, accent, green, yellow, red;
        Theme(String bg, String panel, String panel2, String fg, String muted, String accent, String green, String yellow, String red) {
            this.bg = bg; this.panel = panel; this.panel2 = panel2; this.fg = fg; this.muted = muted; this.accent = accent; this.green = green; this.yellow = yellow; this.red = red;
        }
    }

    private static final class ConfettiOverlay extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float[] x = new float[44], y = new float[44], spin = new float[44];
        private final int[] colors = new int[44];
        private final Theme palette;
        private long started;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private Runnable finish;
        private final Runnable frame = new Runnable() {
            @Override public void run() {
                invalidate();
                if (System.currentTimeMillis() - started < 1350) handler.postDelayed(this, 24);
                else if (finish != null) finish.run();
            }
        };
        ConfettiOverlay(Activity activity, Theme palette) {
            super(activity); this.palette = palette;
            java.util.Random random = new java.util.Random();
            int[] swatches = {ColorParse(palette.accent), ColorParse(palette.green), ColorParse(palette.yellow), ColorParse(palette.red)};
            for (int i = 0; i < x.length; i++) { x[i] = random.nextFloat(); y[i] = random.nextFloat(); spin[i] = random.nextFloat() * 6.28f; colors[i] = swatches[i % swatches.length]; }
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }
        void start(Runnable finish) { this.finish = finish; started = System.currentTimeMillis(); handler.post(frame); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float progress = Math.min(1f, (System.currentTimeMillis() - started) / 1350f);
            paint.setAlpha((int)(230 * (1f - progress * 0.25f)));
            for (int i = 0; i < x.length; i++) {
                float px = x[i] * getWidth() + (float)Math.sin(spin[i] + progress * 5) * dp(20);
                float py = (y[i] + progress * (0.7f + (i % 7) * 0.04f)) * getHeight();
                paint.setColor(colors[i]);
                canvas.save(); canvas.rotate((spin[i] * 50 + progress * 360) % 360, px, py);
                canvas.drawRoundRect(new RectF(px - dp(4), py - dp(7), px + dp(4), py + dp(7)), dp(2), dp(2), paint);
                canvas.restore();
            }
        }
        private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density); }
        private static int ColorParse(String color) { return android.graphics.Color.parseColor(color); }
    }
}
