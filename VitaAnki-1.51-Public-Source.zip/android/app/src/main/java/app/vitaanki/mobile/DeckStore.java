package app.vitaanki.mobile;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.text.Html;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class DeckStore {
    private static final int MAX_CARDS = 2000;
    private static final Pattern CLOZE = Pattern.compile("\\{\\{c(\\d+)::(.*?)(?:::([^}]*))?\\}\\}", Pattern.CASE_INSENSITIVE);
    private static final Pattern IMAGE_SRC = Pattern.compile("(?i)<img[^>]+src\\s*=\\s*['\\\"]?([^'\\\"\\s>]+)");
    private final Context context;
    private final File deckFolder;

    DeckStore(Context context) {
        this.context = context.getApplicationContext();
        this.deckFolder = new File(this.context.getFilesDir(), "decks");
        if (!deckFolder.exists()) deckFolder.mkdirs();
        ensureBundledDeck();
    }

    private void ensureBundledDeck() {
        copyBundledAsset("VitaAnki_Sample.tsv");
    }

    private void copyBundledAsset(String name) {
        if (context.getSharedPreferences("vitaanki", Context.MODE_PRIVATE).getBoolean("deletedBundled:" + name, false)) return;
        File bundled = new File(deckFolder, name);
        if (bundled.exists()) return;
        try (InputStream in = context.getAssets().open(name);
             FileOutputStream out = new FileOutputStream(bundled)) {
            byte[] buffer = new byte[16384];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        } catch (Exception ignored) { }
    }

    List<File> listDeckFiles() {
        File[] files = deckFolder.listFiles((dir, name) -> {
            String lower = name.toLowerCase(Locale.US);
            return lower.endsWith(".apkg") || lower.endsWith(".tsv");
        });
        List<File> result = new ArrayList<>();
        if (files != null) {
            java.util.Arrays.sort(files, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
            result.addAll(java.util.Arrays.asList(files));
        }
        return result;
    }

    File importUri(Uri uri) throws Exception {
        String name = displayName(uri);
        String safe = new File(name).getName().replaceAll("[^A-Za-z0-9._ -]", "_");
        if (safe.isEmpty()) safe = "imported-deck.tsv";
        File destination = new File(deckFolder, safe);
        if (destination.exists()) {
            String base = safe;
            int dot = safe.lastIndexOf('.');
            String extension = dot >= 0 ? safe.substring(dot) : "";
            if (dot >= 0) base = safe.substring(0, dot);
            destination = new File(deckFolder, base + "-" + System.currentTimeMillis() + extension);
        }
        ContentResolver resolver = context.getContentResolver();
        try (InputStream in = resolver.openInputStream(uri); FileOutputStream out = new FileOutputStream(destination)) {
            if (in == null) throw new IllegalArgumentException("Could not open that file.");
            byte[] buffer = new byte[16384];
            int n;
            long total = 0;
            while ((n = in.read(buffer)) > 0) {
                total += n;
                if (total > 512L * 1024L * 1024L) throw new IllegalArgumentException("Deck is larger than 512 MB.");
                out.write(buffer, 0, n);
            }
        } catch (Exception e) {
            destination.delete();
            throw e;
        }
        return destination;
    }

    private String displayName(Uri uri) {
        try (Cursor cursor = context.getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) { }
        String segment = uri.getLastPathSegment();
        return segment == null ? "imported-deck.tsv" : segment;
    }

    DeckData load(File file) throws Exception {
        String lower = file.getName().toLowerCase(Locale.US);
        DeckData deck = new DeckData(stripExtension(file.getName()), file);
        if (lower.endsWith(".tsv")) loadTsv(file, deck);
        else if (lower.endsWith(".apkg")) loadApkg(file, deck);
        else throw new IllegalArgumentException("Choose an .apkg or .tsv deck.");
        applyEdits(deck);
        applyProgress(deck);
        return deck;
    }

    File createDeck(String requestedName) throws Exception {
        String base = requestedName == null ? "" : requestedName.trim();
        if (base.toLowerCase(Locale.US).endsWith(".tsv")) base = base.substring(0, base.length() - 4);
        base = base.replaceAll("[^A-Za-z0-9._ -]", "_").trim();
        base = base.replaceAll("[. ]+$", "");
        if (base.isEmpty()) throw new IllegalArgumentException("Enter a deck name.");
        if (base.length() > 110) base = base.substring(0, 110).trim();
        File destination = new File(deckFolder, base + ".tsv");
        int suffix = 2;
        while (destination.exists()) destination = new File(deckFolder, base + " (" + suffix++ + ").tsv");
        try (FileOutputStream out = new FileOutputStream(destination)) { out.flush(); }
        return destination;
    }

    File getDeckFolder() { return deckFolder; }

    boolean hasEdits(File source) { return source != null && editFile(source).isFile(); }

    long newCardId(DeckData deck) {
        long maximum = 0;
        for (CardData card : deck.cards) maximum = Math.max(maximum, card.id);
        String preferenceKey = "nextCardId:" + key(deck);
        android.content.SharedPreferences prefs = context.getSharedPreferences("vitaanki", Context.MODE_PRIVATE);
        long next = Math.max(maximum + 1, prefs.getLong(preferenceKey, 1));
        prefs.edit().putLong(preferenceKey, next + 1).apply();
        return next;
    }

    void saveEdits(DeckData deck) throws Exception {
        if (deck == null || deck.sourceFile == null) throw new IllegalArgumentException("Choose a saved deck first.");
        JSONObject root = new JSONObject();
        root.put("version", 1);
        JSONArray cards = new JSONArray();
        for (CardData card : deck.cards) {
            JSONObject item = new JSONObject();
            item.put("id", card.id);
            item.put("front", card.front);
            item.put("back", card.back);
            item.put("interval", card.intervalDays);
            item.put("state", card.state);
            item.put("due", card.dueAt);
            JSONArray images = new JSONArray();
            for (String image : card.frontImages) images.put(image);
            item.put("frontImages", images);
            cards.put(item);
        }
        root.put("cards", cards);
        File destination = editFile(deck.sourceFile);
        File temporary = new File(destination.getParentFile(), destination.getName() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(temporary)) {
            out.write(root.toString().getBytes(StandardCharsets.UTF_8));
            out.flush();
            out.getFD().sync();
        }
        if (!temporary.renameTo(destination)) {
            destination.delete();
            if (!temporary.renameTo(destination)) {
                temporary.delete();
                throw new java.io.IOException("Could not save the card changes.");
            }
        }
    }

    File exportTsv(DeckData deck, File outputDirectory) throws Exception {
        String base = deck.name == null ? "VitaAnki-deck" : deck.name;
        base = base.replaceAll("[^A-Za-z0-9._-]", "_");
        if (base.isEmpty()) base = "VitaAnki-deck";
        if (base.length() < 2) base = base + "Deck";
        if (base.length() > 96) base = base.substring(0, 96);
        File output = File.createTempFile(base + "-", ".tsv", outputDirectory);
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(output), StandardCharsets.UTF_8))) {
            for (CardData card : deck.cards) {
                writer.write(tsvField(card.front));
                writer.write('\t');
                writer.write(tsvField(card.back));
                writer.write('\n');
            }
        } catch (Exception e) {
            output.delete();
            throw e;
        }
        return output;
    }

    void deleteDeck(File file) throws Exception {
        if (file == null || !file.getParentFile().equals(deckFolder)) throw new IllegalArgumentException("That deck cannot be deleted.");
        String deckKey = file.getName();
        File edits = editFile(file);
        if (file.exists() && !file.delete()) throw new java.io.IOException("Could not delete that deck file.");
        edits.delete();
        File mediaDir = new File(deckFolder, stripExtension(file.getName()) + "_media");
        if (file.getName().toLowerCase(Locale.US).endsWith(".apkg")) {
            boolean anotherPackageUsesMedia = false;
            for (File other : listDeckFiles()) {
                if (other.getName().toLowerCase(Locale.US).endsWith(".apkg") &&
                        stripExtension(other.getName()).equalsIgnoreCase(stripExtension(file.getName()))) {
                    anotherPackageUsesMedia = true;
                    break;
                }
            }
            if (!anotherPackageUsesMedia) deleteTree(mediaDir);
        }
        android.content.SharedPreferences prefs = context.getSharedPreferences("vitaanki", Context.MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = prefs.edit().remove("progress:" + deckKey)
                .remove("reviewed:" + deckKey).remove("nextCardId:" + deckKey);
        if ("VitaAnki_Sample.tsv".equals(deckKey))
            editor.putBoolean("deletedBundled:" + deckKey, true);
        if (deckKey.equals(prefs.getString("lastDeck", ""))) editor.remove("lastDeck");
        editor.apply();
    }

    private void applyEdits(DeckData deck) {
        File saved = editFile(deck.sourceFile);
        if (!saved.isFile()) return;
        try {
            byte[] bytes = new byte[(int)Math.min(saved.length(), 64L * 1024L * 1024L)];
            try (InputStream in = new java.io.FileInputStream(saved)) {
                int offset = 0;
                while (offset < bytes.length) {
                    int count = in.read(bytes, offset, bytes.length - offset);
                    if (count < 0) throw new java.io.IOException("Incomplete edit file.");
                    offset += count;
                }
            }
            JSONObject root = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
            JSONArray array = root.optJSONArray("cards");
            if (array == null) return;
            List<CardData> edited = new ArrayList<>();
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                CardData card = new CardData(item.getLong("id"), item.optString("front", ""), item.optString("back", ""));
                card.intervalDays = item.optInt("interval", 0);
                card.state = item.optInt("state", 0);
                card.dueAt = item.optLong("due", 0);
                JSONArray images = item.optJSONArray("frontImages");
                if (images != null) for (int j = 0; j < images.length(); j++) card.frontImages.add(images.optString(j, ""));
                edited.add(card);
            }
            deck.cards.clear();
            deck.cards.addAll(edited);
        } catch (Exception ignored) { }
    }

    private File editFile(File source) {
        return new File(deckFolder, source.getName() + ".vitaanki.json");
    }

    private static String tsvField(String value) {
        return (value == null ? "" : value).replace('\t', ' ').replace("\r\n", "\n")
                .replace('\r', ' ').replace('\n', ' ');
    }

    private static void deleteTree(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteTree(child);
        }
        file.delete();
    }

    private void loadTsv(File file, DeckData deck) throws Exception {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new java.io.FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            long id = 1;
            while (deck.cards.size() < MAX_CARDS && (line = reader.readLine()) != null) {
                if (line.startsWith("\ufeff")) line = line.substring(1);
                int tab = line.indexOf('\t');
                if (tab < 0) continue;
                String front = line.substring(0, tab);
                int extra = line.indexOf('\t', tab + 1);
                String back = line.substring(tab + 1, extra < 0 ? line.length() : extra);
                if (front.trim().isEmpty() && back.trim().isEmpty()) continue;
                deck.cards.add(new CardData(id++, front, back));
            }
        }
    }

    private void loadApkg(File packageFile, DeckData deck) throws Exception {
        File databaseFile = new File(context.getCacheDir(), "anki-import-" + System.nanoTime() + ".db");
        Map<String, String> mediaFiles;
        try (ZipFile zip = new ZipFile(packageFile)) {
            ZipEntry entry = zip.getEntry("collection.anki2");
            if (entry == null) entry = zip.getEntry("collection.anki21");
            if (entry == null) throw new IllegalArgumentException("This package has no collection.anki2 database. In Anki, export with ‘support older Anki versions’ enabled.");
            if (entry.getSize() > 256L * 1024L * 1024L) throw new IllegalArgumentException("The deck database is larger than 256 MB.");
            mediaFiles = extractMedia(zip, packageFile);
            try (InputStream in = zip.getInputStream(entry); FileOutputStream out = new FileOutputStream(databaseFile)) {
                byte[] buffer = new byte[8192];
                int n;
                long total = 0;
                while ((n = in.read(buffer)) > 0) {
                    total += n;
                    if (total > 256L * 1024L * 1024L) throw new IllegalArgumentException("The deck database is larger than 256 MB.");
                    out.write(buffer, 0, n);
                }
            }
        }
        SQLiteDatabase db = null;
        try {
            db = SQLiteDatabase.openDatabase(databaseFile.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            Map<String, List<String>> modelFields = readModelFields(db);
            try (Cursor c = db.rawQuery("SELECT c.id, c.ord, c.ivl, c.queue, c.due, col.crt, n.flds, n.mid " +
                    "FROM cards c JOIN notes n ON n.id=c.nid CROSS JOIN col " +
                    "WHERE c.queue >= 0 ORDER BY c.due, c.id LIMIT " + MAX_CARDS, null)) {
                while (c.moveToNext()) {
                    long id = c.getLong(0);
                    int ord = c.getInt(1);
                    int ivl = c.getInt(2);
                    int queue = c.getInt(3);
                    long due = c.getLong(4);
                    long created = c.getLong(5);
                    String fields = c.getString(6);
                    String[] fieldNames = modelFields.containsKey(String.valueOf(c.getLong(7)))
                            ? modelFields.get(String.valueOf(c.getLong(7))).toArray(new String[0]) : new String[0];
                    String[] parts = fields == null ? new String[0] : fields.split("\u001f", -1);
                    if (parts.length == 0) continue;
                    String front;
                    String back;
                    if (parts[0].contains("{{c")) {
                        front = cloze(parts[0], ord, false);
                        back = cloze(parts[0], ord, true);
                    } else {
                        int frontIndex = namedField(fieldNames, "Question", "Front", "Prompt");
                        int backIndex = namedField(fieldNames, "Answer", "Back", "Solution");
                        if (frontIndex < 0) frontIndex = ord == 1 && parts.length > 1 ? 1 : 0;
                        if (backIndex < 0) backIndex = parts.length > 1 ? (frontIndex == 0 ? 1 : 0) : frontIndex;
                        if (frontIndex >= parts.length) frontIndex = 0;
                        if (backIndex >= parts.length) backIndex = parts.length > 1 ? 1 : 0;
                        front = parts[frontIndex];
                        back = parts[backIndex];
                    }
                    CardData card = new CardData(id, plainText(front), plainText(back));
                    card.frontImages.addAll(findImages(parts, mediaFiles));
                    card.intervalDays = ivl;
                    if (queue == 2) { card.state = 2; card.dueAt = created + due * 86400L; }
                    else if (queue == 1 || queue == 3) { card.state = 1; card.dueAt = due; }
                    deck.cards.add(card);
                }
            }
        } catch (Exception e) {
            if (e instanceof IllegalArgumentException) throw e;
            throw new IllegalArgumentException("The Anki database could not be read. Try exporting an older-compatible .apkg package.", e);
        } finally {
            if (db != null) db.close();
            databaseFile.delete();
        }
    }

    private Map<String, String> extractMedia(ZipFile zip, File packageFile) throws Exception {
        Map<String, String> paths = new HashMap<>();
        ZipEntry manifest = zip.getEntry("media");
        if (manifest == null) return paths;
        StringBuilder json = new StringBuilder();
        try (InputStream in = zip.getInputStream(manifest); InputStreamReader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
            char[] buffer = new char[4096];
            int n;
            while ((n = reader.read(buffer)) > 0) {
                if (json.length() + n > 4 * 1024 * 1024) throw new IllegalArgumentException("The package media index is too large.");
                json.append(buffer, 0, n);
            }
        }
        JSONObject mapping = new JSONObject(json.toString());
        String deckStem = stripExtension(packageFile.getName()).replaceAll("[^A-Za-z0-9._-]", "_");
        File mediaDir = new File(deckFolder, deckStem + "_media");
        if (!mediaDir.exists() && !mediaDir.mkdirs()) throw new IllegalArgumentException("Could not create the deck media folder.");
        java.util.Iterator<String> keys = mapping.keys();
        long total = 0;
        while (keys.hasNext()) {
            String entryName = keys.next();
            String original = mapping.optString(entryName, "").replace('\\', '/');
            int slash = original.lastIndexOf('/');
            String fileName = slash >= 0 ? original.substring(slash + 1) : original;
            fileName = fileName.replaceAll("[^A-Za-z0-9._-]", "_");
            if (fileName.isEmpty() || fileName.equals(".") || fileName.equals("..")) continue;
            ZipEntry media = zip.getEntry(entryName);
            if (media == null || media.getSize() > 64L * 1024L * 1024L) continue;
            File destination = new File(mediaDir, fileName);
            if (!destination.exists()) {
                try (InputStream in = zip.getInputStream(media); FileOutputStream out = new FileOutputStream(destination)) {
                    byte[] buffer = new byte[16384];
                    int n;
                    long written = 0;
                    while ((n = in.read(buffer)) > 0) {
                        written += n; total += n;
                        if (written > 64L * 1024L * 1024L || total > 256L * 1024L * 1024L)
                            throw new IllegalArgumentException("Deck media exceeds the 256 MB import limit.");
                        out.write(buffer, 0, n);
                    }
                } catch (Exception e) { destination.delete(); throw e; }
            }
            paths.put(original, destination.getAbsolutePath());
            paths.put(fileName, destination.getAbsolutePath());
        }
        return paths;
    }

    private Map<String, List<String>> readModelFields(SQLiteDatabase db) {
        Map<String, List<String>> result = new HashMap<>();
        try (Cursor cursor = db.rawQuery("SELECT models FROM col LIMIT 1", null)) {
            if (!cursor.moveToFirst()) return result;
            JSONObject models = new JSONObject(cursor.getString(0));
            java.util.Iterator<String> ids = models.keys();
            while (ids.hasNext()) {
                String id = ids.next();
                JSONObject model = models.optJSONObject(id);
                JSONArray fields = model == null ? null : model.optJSONArray("flds");
                if (fields == null) continue;
                List<String> names = new ArrayList<>();
                for (int i = 0; i < fields.length(); i++) {
                    JSONObject field = fields.optJSONObject(i);
                    names.add(field == null ? "" : field.optString("name", ""));
                }
                result.put(id, names);
            }
        } catch (Exception ignored) { }
        return result;
    }

    private static int namedField(String[] fields, String... names) {
        for (int i = 0; i < fields.length; i++)
            for (String name : names) if (name.equalsIgnoreCase(fields[i])) return i;
        return -1;
    }

    private static List<String> findImages(String[] fields, Map<String, String> mediaFiles) {
        Set<String> result = new LinkedHashSet<>();
        for (String field : fields) {
            Matcher matcher = IMAGE_SRC.matcher(field == null ? "" : field);
            while (matcher.find()) {
                String src = matcher.group(1).replace('\\', '/');
                int slash = src.lastIndexOf('/');
                String basename = slash >= 0 ? src.substring(slash + 1) : src;
                String path = mediaFiles.get(src);
                if (path == null) path = mediaFiles.get(basename);
                if (path != null) result.add(path);
            }
        }
        return new ArrayList<>(result);
    }

    private static String cloze(String text, int wanted, boolean revealAll) {
        Matcher m = CLOZE.matcher(text);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            String replacement;
            if (!revealAll && Integer.parseInt(m.group(1)) == wanted + 1) {
                replacement = m.group(3) == null ? "[…]" : m.group(3);
            } else replacement = m.group(2);
            m.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(out);
        return out.toString();
    }

    static String plainText(String html) {
        if (html == null) return "";
        String normalized = html.replaceAll("(?i)<br\\s*/?>", "\n").replaceAll("(?i)</(div|p|li)\\s*>", "\n");
        String text = android.os.Build.VERSION.SDK_INT >= 24
                ? Html.fromHtml(normalized, Html.FROM_HTML_MODE_LEGACY).toString()
                : Html.fromHtml(normalized).toString();
        return text.replace('\u00a0', ' ').replaceAll("[\\t ]+", " ").replaceAll(" *\\n *", "\n").trim();
    }

    private static String stripExtension(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    void saveProgress(DeckData deck, int reviewed) {
        try {
            JSONArray array = new JSONArray();
            for (CardData card : deck.cards) {
                JSONObject obj = new JSONObject();
                obj.put("id", card.id);
                obj.put("interval", card.intervalDays);
                obj.put("state", card.state);
                obj.put("due", card.dueAt);
                array.put(obj);
            }
            context.getSharedPreferences("vitaanki", Context.MODE_PRIVATE).edit()
                    .putString("progress:" + key(deck), array.toString())
                    .putInt("reviewed:" + key(deck), reviewed)
                    .putString("lastDeck", key(deck)).apply();
        } catch (Exception ignored) { }
    }

    int readReviewed(DeckData deck) {
        return context.getSharedPreferences("vitaanki", Context.MODE_PRIVATE)
                .getInt("reviewed:" + key(deck), 0);
    }

    private void applyProgress(DeckData deck) {
        String raw = context.getSharedPreferences("vitaanki", Context.MODE_PRIVATE)
                .getString("progress:" + key(deck), null);
        if (raw == null) return;
        try {
            JSONArray array = new JSONArray(raw);
            java.util.HashMap<Long, JSONObject> saved = new java.util.HashMap<>();
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                saved.put(obj.getLong("id"), obj);
            }
            for (CardData card : deck.cards) {
                JSONObject obj = saved.get(card.id);
                if (obj == null) continue;
                card.intervalDays = obj.optInt("interval", card.intervalDays);
                card.state = obj.optInt("state", card.state);
                card.dueAt = obj.optLong("due", card.dueAt);
            }
        } catch (Exception ignored) { }
    }

    private String key(DeckData deck) {
        return deck.sourceFile == null ? deck.name : deck.sourceFile.getName();
    }
}
