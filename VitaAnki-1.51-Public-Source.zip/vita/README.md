# VitaAnki for PS Vita

VitaAnki is an independent PS Vita flashcard app. Version 1.51 imports compatible Anki `.apkg` packages and tab-separated `.tsv` decks for offline study, and can optionally connect to Anki Desktop through AnkiConnect.

## Current public preview

- Review offline with a local scheduler or connect manually to an Anki Desktop deck.
- Browse folders and review due cards across the selected folder.
- Set per-deck new-card limits and Again, Hard, Good, and Easy timing.
- Import compatible `.apkg` and `.tsv` decks from `ux0:data/VitaAnki/decks/`.
- Browse cards without rating them; supported image cards show an image beside the question.
- Create and manage decks, transfer decks with Android over local Wi-Fi, and customize fonts, text size, themes, and review controls.
- The public preview includes only a small generic sample deck. Background music is disabled in this stability package.

Direct AnkiWeb sync is not implemented. Live PC review requires Anki Desktop and AnkiConnect on the same private Wi-Fi network. Offline review uses the Vita's local scheduler; live review uses Anki Desktop's scheduler.

## Import a deck

1. Export a deck from Anki Desktop as `.apkg` and enable compatibility for older Anki versions if available, or prepare a UTF-8 tab-separated `.tsv` file.
2. Copy the file to `ux0:data/VitaAnki/decks/` with VitaShell.
3. Open **Import**, choose **Rescan**, select the file, and choose **Import & Study**.

A TSV row contains a question, a tab, and an answer. Imported APKG support is limited; complex templates, audio, and some note types are not rendered.

## Transfer with Android

Connect both devices to the same local Wi-Fi. Open **Deck Transfer** on the Vita and start the receiver. Enter the short-lived code on Android, then send a deck or download one from the Vita. Keep the receiver screen open until transfer finishes. Some guest networks isolate devices and block discovery.

## Connect to Anki Desktop

Install AnkiConnect in Anki Desktop and restart Anki. Configure it for your trusted private LAN and set a strong API key. Copy `sync.example.ini` to `ux0:data/VitaAnki/sync.ini`, then enter your PC's private LAN address, exact deck name, and key. In VitaAnki, choose **Sync with PC** and connect. Never publish your real `sync.ini` or API key.

## Build

Install VitaSDK, CMake, Ninja, and the libraries used by this project (`libvita2d`, `libzip`, `curl`, and `jansson`). From the repository root:

```sh
cmake -S vita -B build -DCMAKE_TOOLCHAIN_FILE="$VITASDK/share/vita.toolchain.cmake" -DVITA_BUNDLE_PICTURE_DECK=OFF
cmake --build build
```

The build creates `vitaanki.vpk`. The public source package contains a generic sample deck and no soundtrack or personal deck files.
