#include <ctype.h>
#include <math.h>
#include <psp2/apputil.h>
#include <psp2/common_dialog.h>
#include <psp2/ctrl.h>
#include <psp2/ime_dialog.h>
#include <psp2/io/dirent.h>
#include <psp2/kernel/processmgr.h>
#include <psp2/sysmodule.h>
#include <psp2/touch.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <vita2d.h>
#include "anki_connect.h"
#include "anki_music.h"
#include "android_transfer.h"
#include "vitaanki.h"

#define SCREEN_W 960
#define SCREEN_H 544
#define APP_VERSION "1.51"
#define UI_TEXT_SCALE (1.18f * selected_ui_text_scale())
#define CARD_FLIP_FRAMES 12
#define LIVE_REFRESH_SECONDS 10
#define DEFAULT_NEW_CARD_LIMIT 20
#define STUDY_MORE_BATCH_SIZE 20

#define DECK_PATH "ux0:data/VitaAnki/cards.tsv"
#define APKG_PATH "ux0:data/VitaAnki/import.apkg"
#define DECK_FOLDER "ux0:data/VitaAnki/decks"
#define INCLUDED_DECK_PATH "ux0:data/VitaAnki/decks/VitaAnki_Sample.tsv"
#define BUNDLED_DECK_PATH "app0:decks/VitaAnki_Sample.tsv"
#define INCLUDED_PICTURE_DECK_PATH "ux0:data/VitaAnki/decks/VitaAnki_Sample_Pictures.apkg"
#define BUNDLED_PICTURE_DECK_PATH "app0:decks/VitaAnki_Sample_Pictures.apkg"
#define PROGRESS_PATH "ux0:data/VitaAnki/progress.tsv"
#define ACTIVE_DECK_PATH "ux0:data/VitaAnki/active-deck.txt"
#define ACTIVE_DECK_TEMP_PATH "ux0:data/VitaAnki/active-deck.tmp"
#define ACTIVE_DECK_BACKUP_PATH "ux0:data/VitaAnki/active-deck.bak"
#define SETTINGS_PATH "ux0:data/VitaAnki/settings.ini"
#define SETTINGS_TEMP_PATH "ux0:data/VitaAnki/settings.tmp"
#define SETTINGS_BACKUP_PATH "ux0:data/VitaAnki/settings.bak"
#define MIN_VALID_CLOCK_EPOCH 1577836800LL
#define MAX_VALID_CLOCK_EPOCH 4102444800LL
#define MAX_INTERVAL_DAYS 36500
#define MAX_DECKS 48
#define MAX_FOLDERS 16
#define FOLDER_NAME_SIZE 64
#define FOLDER_STORE_PATH "ux0:data/VitaAnki/folders.tsv"
#define FOLDER_STORE_TEMP_PATH "ux0:data/VitaAnki/folders.tmp"
#define FOLDER_STORE_BACKUP_PATH "ux0:data/VitaAnki/folders.bak"
#define ADDED_CARD_ID_BASE 7000000000000000000LL
#define LIST_ROW_Y 132
#define LIST_ROW_H 62
#define LIST_VISIBLE 4
#define SPLIT_CARD_TEXT_WIDTH 340
#define SPLIT_CARD_IMAGE_X 440
#define SPLIT_CARD_IMAGE_Y 150
#define SPLIT_CARD_IMAGE_WIDTH 450
#define SPLIT_CARD_IMAGE_HEIGHT 270
#define IMAGE_VIEWER_X 16
#define IMAGE_VIEWER_Y 16
#define IMAGE_VIEWER_WIDTH 928
#define IMAGE_VIEWER_HEIGHT 512
#define SETTINGS_COUNT 13
#define PRESET_THEME_COUNT 9
#define CUSTOM_COLOR_COUNT 12
#define THEME_CUSTOM_MODE PRESET_THEME_COUNT
#define BROWSER_STICK_BUTTONS 0
#define BROWSER_STICK_SCROLL 1
#define FONT_MODE_COUNT 10
#define CONFETTI_CAPACITY 160
#define CONFETTI_PER_SUCCESS 40

typedef enum {
    SCREEN_HOME,
    SCREEN_STUDY,
    SCREEN_BROWSER,
    SCREEN_DECKS,
    SCREEN_IMPORT,
    SCREEN_SETTINGS,
    SCREEN_SYNC,
    SCREEN_ANDROID_TRANSFER,
    SCREEN_CREATE_DECK,
    SCREEN_CREATE_TARGET,
    SCREEN_DECK_SETTINGS,
    SCREEN_THEME_EDITOR,
    SCREEN_FOLDERS
} AppScreen;

typedef struct {
    char path[512];
    char name[128];
    char folder[FOLDER_NAME_SIZE];
    int is_apkg;
} DeckEntry;

typedef struct {
    int x;
    int y;
    int w;
    int h;
} UiRect;

typedef struct {
    int new_card_limit;
    int again_minutes;
    int hard_minutes;
    int good_days;
    int easy_days;
    int new_cards_day_key;
    int new_cards_today;
    int new_cards_extra_today;
} DeckStudySettings;

typedef struct {
    unsigned int white;
    unsigned int muted;
    unsigned int accent;
    unsigned int panel;
    unsigned int panel_hi;
    unsigned int background;
    unsigned int green;
    unsigned int yellow;
    unsigned int red;
} ColorTheme;

typedef struct {
    int valid;
    int live;
    int queued;
    long long card_id;
    int previous_index;
    int previous_interval_days;
    long long previous_due;
    CardState previous_state;
    int previous_reviewed;
    int previous_new_cards_this_session;
    int previous_new_cards_today;
    int rating;
} UndoRecord;

typedef struct {
    float x;
    float y;
    float vx;
    float vy;
    int width;
    int height;
    unsigned int color;
    int active;
} ConfettiPiece;

static Card *cards = NULL;
static int card_capacity = 0;
static DeckEntry deck_entries[MAX_DECKS];
static int deck_count = 0;
static char folder_names[MAX_FOLDERS][FOLDER_NAME_SIZE];
static int folder_count = 0;
static int folder_selection = 0;
static int folder_action_selection = 0;
static int folder_actions_focus = 0;
static int folder_ime_action = 0;
/* 0 = all decks, 1 = unfiled, 2+ = named folders. */
static int deck_folder_filter = 0;
static int deck_folder_filter_focus = 0;
static int deck_settings_deck_index = -1;
static int deck_due_count[MAX_DECKS];
static unsigned char deck_due_count_known[MAX_DECKS];
static int all_decks_mode = 0;
static int all_decks_loading = 0;
static int all_decks_cursor = -1;
static int all_decks_due_total = 0;
static int card_count = 0;
static int card_index = 0;
static int current_deck_index = -1;
static int home_selection = 0;
static int list_selection = 0;
static int list_focus_actions = 0;
static int list_action_selection = 0;
static int deck_list_gear_focus = 0;
static int settings_selection = 0;
static int settings_edit_armed = 0;
static int deck_settings_selection = 0;
static int deck_settings_editing = 0;
static int show_answer = 0;
static int browser_index = 0;
static int browser_show_answer = 0;
static int show_card_images = 1;
static int large_study_buttons = 0;
static int study_layout_settings_migrated = 0;
static int image_focus_open = 0;
static float image_focus_zoom = 1.5f;
static float image_focus_pan_x = 0.0f;
static float image_focus_pan_y = 0.0f;
static int browser_button_selection = 2;
static int study_button_selection = 0;
static int transfer_selection = 0;
static int header_focus_active = 0;
static int analog_input_latched = 0;
static int analog_rating_latched = 0;
static int analog_browser_latched = 0;
static int analog_repeat_frames = 0;
static float card_scroll_position = 0.0f;
static float browser_scroll_position = 0.0f;
static int selected_rating = 2;
static int clock_warning_active = 0;
static int undo_error = 0;
static int jump_dialog_open = 0;
static int jump_selection = 13;
static int jump_error = 0;
static int delete_dialog_open = 0;
static int delete_selection = 0;
static int delete_dialog_stage = 1;
static int create_cancel_dialog_open = 0;
static int create_selection = 0;
static int create_target_deck_index = -1;
static int create_target_selection = 0;
static int create_card_count = 0;
static int create_error = 0;
static int create_ime_open = 0;
static int create_ime_field = -1;
static int ime_module_loaded = 0;
static int apputil_initialized = 0;
static char create_deck_name[96] = "";
static char folder_ime_name[FOLDER_NAME_SIZE] = "";
static char create_question[FIELD_SIZE] = "";
static char create_answer[FIELD_SIZE] = "";
static char create_draft_path[512] = "";
static char create_status[160] = "";
static char deck_status[160] = "";
static int delete_error = 0;
static DeckStudySettings current_deck_settings = {DEFAULT_NEW_CARD_LIMIT, 1, 5, 1, 4, 0, 0, 0};
static DeckStudySettings edit_deck_settings = {DEFAULT_NEW_CARD_LIMIT, 1, 5, 1, 4, 0, 0, 0};
static char edit_deck_settings_path[512] = "";
static uint16_t create_ime_buffer[SCE_IME_DIALOG_MAX_TEXT_LENGTH + 1];
static uint16_t create_ime_initial[SCE_IME_DIALOG_MAX_TEXT_LENGTH + 1];
static char jump_input[8] = "";
static UndoRecord undo_record;
static int reviewed = 0;
static int new_cards_this_session = 0;
static int study_idle_frames = 0;
static time_t live_refresh_after = 0;
static int demo_mode = 0;
static int import_error = 0;
static int import_error_code = 0;
static int live_sync = 0;
static int sync_error = 0;
static int sync_queue_error = 0;
static char sync_message[160] = "";
static int apkg_mode = 0;
static int font_mode = 0;
static int text_size_mode = 1;
static int ui_text_mode = 1;
static int color_theme_mode = 0;
static int custom_background_color = 0;
static int custom_accent_color = 0;
static int theme_editor_focus = 0;
static int flip_animation_mode = 1;
static int flip_frames_remaining = 0;
static int flip_from_answer = 0;
static int flip_to_answer = 0;
static int music_muted = 0;
static int music_setting_migration = 0;
static int click_sounds_enabled = 1;
static int click_volume = 1;
static int browser_stick_mode = BROWSER_STICK_BUTTONS;
static int confetti_mode = 1;
static int review_control_mode = 0;
static uint32_t confetti_rng = 0xA71C0FFEu;
static int confetti_next_slot = 0;
static ConfettiPiece confetti[CONFETTI_CAPACITY];
static int touch_was_down = 0;
static int touch_min_x = 0;
static int touch_min_y = 0;
static int touch_width = 1920;
static int touch_height = 1080;
static char current_deck_name[128] = "Demo deck";
static char current_deck_path[512] = "";
static char current_progress_path[96] = PROGRESS_PATH;
static char saved_deck_path[512] = "";
static AppScreen current_screen = SCREEN_HOME;
static AppScreen browser_return_screen = SCREEN_HOME;
static AppScreen create_return_screen = SCREEN_IMPORT;
static vita2d_pgf *font_pgf = NULL;
static vita2d_pgf *font_serif_pgf = NULL;
static vita2d_pgf *font_sans_pgf = NULL;
static vita2d_pgf *font_serif_italic_pgf = NULL;
static vita2d_pgf *font_sans_italic_pgf = NULL;
static vita2d_pgf *font_serif_bold_pgf = NULL;
static vita2d_pgf *font_sans_bold_pgf = NULL;
static vita2d_pgf *font_serif_bold_italic_pgf = NULL;
static vita2d_pgf *font_sans_bold_italic_pgf = NULL;
static vita2d_texture *card_image_texture = NULL;
static char card_image_path_cached[FIELD_SIZE] = "";
static AnkiStudyCounts offline_counts_cache = {0, 0, 0};
static time_t offline_counts_refresh_at = 0;
static int offline_counts_cache_valid = 0;
static char cached_card_lines[FIELD_SIZE * 2 + 1];
static uint16_t cached_card_line_offsets[FIELD_SIZE];
static int cached_card_line_count = 0;
static int cached_card_line_bytes = 0;
static const char *cached_card_line_source = NULL;
static const vita2d_pgf *cached_card_line_font = NULL;
static uint32_t cached_card_line_hash = 0;
static size_t cached_card_line_source_length = 0;
static int cached_card_line_width = 0;
static float cached_card_line_scale = 0.0f;
static int cached_card_line_font_mode = -1;
static int cached_card_line_text_size_mode = -1;
static int cached_card_line_ui_text_mode = -1;
static int cached_card_line_cache_valid = 0;

static unsigned int WHITE = RGBA8(244, 247, 255, 255);
static unsigned int MUTED = RGBA8(155, 170, 190, 255);
static unsigned int ACCENT = RGBA8(112, 184, 255, 255);
static unsigned int PANEL = RGBA8(25, 35, 53, 255);
static unsigned int PANEL_HI = RGBA8(37, 52, 75, 255);
static unsigned int BG = RGBA8(13, 19, 31, 255);
static unsigned int GREEN = RGBA8(135, 220, 165, 255);
static unsigned int YELLOW = RGBA8(255, 202, 112, 255);
static unsigned int RED = RGBA8(255, 130, 130, 255);
static const unsigned int RAINBOW_COLORS[] = {
    RGBA8(245, 70, 70, 255), RGBA8(255, 150, 45, 255),
    RGBA8(255, 220, 60, 255), RGBA8(70, 205, 100, 255),
    RGBA8(65, 145, 245, 255), RGBA8(170, 90, 225, 255)
};

int vitaanki_reserve_cards(Card **target, int *allocated_capacity, int required) {
    if (!target || !allocated_capacity || required < 0 || required > MAX_CARDS) return 0;
    if (required <= *allocated_capacity) return 1;

    int new_capacity = *allocated_capacity > 0 ? *allocated_capacity : 32;
    while (new_capacity < required) {
        if (new_capacity > MAX_CARDS / 2) {
            new_capacity = MAX_CARDS;
            break;
        }
        new_capacity *= 2;
    }
    Card *resized = realloc(*target, (size_t)new_capacity * sizeof(Card));
    if (!resized) return 0;
    *target = resized;
    *allocated_capacity = new_capacity;
    return 1;
}

static const ColorTheme color_themes[] = {
    /* Cyberpunk dark: black base with bright pink and green accents. */
    {RGBA8(245, 245, 249, 255), RGBA8(165, 165, 178, 255),
     RGBA8(255, 55, 165, 255), RGBA8(20, 20, 27, 255),
     RGBA8(34, 34, 44, 255), RGBA8(5, 6, 9, 255),
     RGBA8(57, 255, 126, 255), RGBA8(255, 220, 72, 255),
     RGBA8(255, 89, 113, 255)},
    /* Cyberpunk light: white base and the same paired accents. */
    {RGBA8(28, 25, 34, 255), RGBA8(92, 86, 101, 255),
     RGBA8(198, 0, 104, 255), RGBA8(255, 255, 255, 255),
     RGBA8(237, 233, 242, 255), RGBA8(248, 248, 251, 255),
     RGBA8(0, 137, 72, 255), RGBA8(151, 98, 0, 255),
     RGBA8(194, 38, 76, 255)},
    /* Sepia: warm paper and ink, with restrained earthy accents. */
    {RGBA8(55, 43, 28, 255), RGBA8(117, 101, 78, 255),
     RGBA8(142, 90, 45, 255), RGBA8(232, 218, 190, 255),
     RGBA8(220, 199, 161, 255), RGBA8(245, 235, 213, 255),
     RGBA8(91, 116, 55, 255), RGBA8(153, 112, 44, 255),
     RGBA8(164, 78, 63, 255)},
    /* Synthwave: near-black base, electric magenta and cyan. */
    {RGBA8(246, 242, 255, 255), RGBA8(164, 151, 190, 255),
     RGBA8(231, 76, 255, 255), RGBA8(20, 14, 34, 255),
     RGBA8(39, 24, 62, 255), RGBA8(6, 4, 13, 255),
     RGBA8(54, 226, 218, 255), RGBA8(255, 181, 71, 255),
     RGBA8(255, 87, 127, 255)},
    /* Arctic: white base with deep blue and teal accents. */
    {RGBA8(25, 39, 54, 255), RGBA8(86, 108, 128, 255),
     RGBA8(0, 117, 160, 255), RGBA8(255, 255, 255, 255),
     RGBA8(228, 243, 250, 255), RGBA8(245, 251, 255, 255),
     RGBA8(0, 117, 99, 255), RGBA8(137, 96, 0, 255),
     RGBA8(178, 47, 66, 255)},
    /* Aquatic: deep blue with a coordinated family of sea-glass accents. */
    {RGBA8(231, 248, 246, 255), RGBA8(126, 177, 176, 255),
     RGBA8(75, 220, 210, 255), RGBA8(12, 34, 43, 255),
     RGBA8(23, 57, 66, 255), RGBA8(4, 18, 27, 255),
     RGBA8(89, 218, 183, 255), RGBA8(186, 218, 143, 255),
     RGBA8(221, 126, 145, 255)},
    /* Rose: light canvas, ink-dark panels, and pink shades kept together. */
    {RGBA8(48, 29, 43, 255), RGBA8(130, 96, 119, 255),
     RGBA8(210, 76, 144, 255), RGBA8(255, 247, 251, 255),
     RGBA8(245, 224, 236, 255), RGBA8(252, 242, 247, 255),
     RGBA8(120, 145, 104, 255), RGBA8(170, 121, 71, 255),
     RGBA8(192, 69, 105, 255)},
    /* Evergreen: dark forest base with calm green accents. */
    {RGBA8(233, 245, 232, 255), RGBA8(143, 173, 145, 255),
     RGBA8(126, 211, 145, 255), RGBA8(15, 31, 24, 255),
     RGBA8(28, 50, 37, 255), RGBA8(7, 17, 12, 255),
     RGBA8(118, 205, 143, 255), RGBA8(199, 196, 116, 255),
     RGBA8(208, 117, 113, 255)},
    /* Moonlight: near-black panels with cool, restrained blue-grey accents. */
    {RGBA8(239, 243, 250, 255), RGBA8(148, 163, 184, 255),
     RGBA8(151, 184, 220, 255), RGBA8(21, 27, 39, 255),
     RGBA8(35, 44, 61, 255), RGBA8(9, 12, 20, 255),
     RGBA8(130, 191, 166, 255), RGBA8(208, 180, 130, 255),
     RGBA8(209, 135, 151, 255)}
};

static const float text_scales[] = {0.84f, 1.0f, 1.18f, 1.38f, 1.62f};
static const char *text_size_labels[] = {"Small", "Standard", "Large", "Extra large", "Huge"};
static const float ui_text_scales[] = {1.0f, 1.1f, 1.2f};
static const char *ui_text_labels[] = {"Standard", "Large", "Extra large"};
static const char *color_theme_labels[] = {"Cyberpunk dark", "Cyberpunk light", "Sepia",
                                           "Synthwave", "Arctic", "Aquatic", "Rose",
                                           "Evergreen", "Moonlight", "Custom theme"};
static const unsigned int custom_background_colors[CUSTOM_COLOR_COUNT] = {
    RGBA8(5, 6, 9, 255), RGBA8(28, 31, 41, 255), RGBA8(6, 20, 35, 255),
    RGBA8(24, 11, 33, 255), RGBA8(8, 24, 17, 255), RGBA8(4, 25, 32, 255),
    RGBA8(54, 40, 28, 255), RGBA8(245, 235, 213, 255), RGBA8(250, 250, 252, 255),
    RGBA8(35, 20, 50, 255), RGBA8(47, 18, 28, 255), RGBA8(32, 42, 49, 255)
};
static const unsigned int custom_accent_colors[CUSTOM_COLOR_COUNT] = {
    RGBA8(255, 55, 165, 255), RGBA8(57, 255, 126, 255), RGBA8(75, 220, 210, 255),
    RGBA8(190, 116, 255, 255), RGBA8(88, 146, 255, 255), RGBA8(255, 202, 72, 255),
    RGBA8(255, 92, 120, 255), RGBA8(179, 127, 76, 255), RGBA8(181, 237, 69, 255),
    RGBA8(255, 132, 54, 255), RGBA8(255, 107, 122, 255), RGBA8(117, 208, 255, 255)
};
static const char *flip_animation_labels[] = {"Instant", "Animated"};
static const char *confetti_labels[] = {"Off", "Good + Easy", "Easy only"};
static const char *click_volume_labels[] = {"Quiet", "Medium", "Loud"};
static const char *font_labels[] = {"System default", "Bold system PGF", "Sans", "Serif",
                                    "Sans italic", "Serif italic", "Sans bold", "Serif bold",
                                    "Sans bold italic", "Serif bold italic"};
static const UiRect settings_rows[SETTINGS_COUNT] = {
    {52, 128, 420, 42}, {52, 173, 420, 42}, {52, 218, 420, 42},
    {52, 263, 420, 42}, {52, 308, 420, 42}, {52, 353, 420, 42},
    {488, 128, 420, 42}, {488, 173, 420, 42}, {488, 218, 420, 42},
    {488, 263, 420, 42}, {488, 308, 420, 42}, {488, 353, 420, 42},
    {488, 398, 420, 42}
};

static const Card demo_cards[] = {
    {"What is the functional unit of skeletal muscle?", "The sarcomere: the segment between two Z discs.", 1, 0, 0, CARD_STATE_NEW},
    {"Which neurotransmitter is released at the neuromuscular junction?", "Acetylcholine (ACh), released by the motor neuron.", 2, 0, 0, CARD_STATE_NEW},
    {"What structure stores calcium ions in a muscle fiber?", "The sarcoplasmic reticulum.", 3, 0, 0, CARD_STATE_NEW},
};

static const UiRect home_buttons[4] = {
    {60, 126, 408, 126}, {492, 126, 408, 126},
    {60, 270, 408, 126}, {492, 270, 408, 126}
};
static const UiRect back_button = {48, 16, 88, 44};
static const UiRect sync_button = {60, 410, 408, 48};
static const UiRect android_transfer_button = {492, 410, 408, 48};
static const UiRect android_transfer_start_button = {60, 420, 300, 54};
static const UiRect android_transfer_decks_button = {378, 420, 210, 54};
static const UiRect sync_connect_button = {60, 116, 840, 92};
static const UiRect deck_browser_button = {60, 458, 220, 52};
static const UiRect deck_delete_button = {294, 458, 220, 52};
static const UiRect deck_rename_button = {528, 458, 220, 52};
static const UiRect undo_button = {824, 16, 88, 44};
static const UiRect study_more_button = {332, 348, 296, 54};
static const UiRect browser_jump_button = {240, 458, 190, 52};

static int file_exists(const char *path);
static void recover_atomic_file(const char *destination, const char *temporary,
                                const char *backup);
static int atomic_replace_file(const char *temporary, const char *destination,
                               const char *backup);
static void begin_pc_sync(void);
static void select_offline_source(void);
static int has_study_card(void);
static void open_create_deck(void);
static void begin_create_ime(int field);
static void update_create_ime(void);
static void activate_create_selection(void);
static void request_cancel_create(void);
static void confirm_delete_selected(void);
static void apply_deck_rename(const char *name);
static void handle_touch(int x, int y);
static void save_settings(void);
static void normalize_tsv_field(char *text);
static void load_folder_metadata(void);
static int save_folder_metadata(void);
static void open_folder_manager(void);
static void activate_folder_action(int action);
static void apply_folder_ime_name(const char *name);
static void open_card_browser_for_deck(int index);
static void update_deck_due_count_cache(void);
static int count_due_cards_in_loaded_deck(void);
static void recalculate_all_deck_due_total(void);
static int select_all_due_decks(void);
static int advance_all_due_decks(int start_index);
static int has_next_all_due_deck(void);
static int study_more_available(void);

static vita2d_pgf *custom_font_for_mode(int mode) {
    switch (mode) {
        case 2: return font_sans_pgf;
        case 3: return font_serif_pgf;
        case 4: return font_sans_italic_pgf;
        case 5: return font_serif_italic_pgf;
        case 6: return font_sans_bold_pgf;
        case 7: return font_serif_bold_pgf;
        case 8: return font_sans_bold_italic_pgf;
        case 9: return font_serif_bold_italic_pgf;
        default: return NULL;
    }
}

static void release_custom_font(int mode) {
    vita2d_pgf **font = NULL;
    switch (mode) {
        case 2: font = &font_sans_pgf; break;
        case 3: font = &font_serif_pgf; break;
        case 4: font = &font_sans_italic_pgf; break;
        case 5: font = &font_serif_italic_pgf; break;
        case 6: font = &font_sans_bold_pgf; break;
        case 7: font = &font_serif_bold_pgf; break;
        case 8: font = &font_sans_bold_italic_pgf; break;
        case 9: font = &font_serif_bold_italic_pgf; break;
    }
    if (font && *font) {
        vita2d_free_pgf(*font);
        *font = NULL;
    }
}

static void release_custom_fonts(void) {
    for (int mode = 2; mode < FONT_MODE_COUNT; mode++) release_custom_font(mode);
}

static int font_mode_available(int mode) {
    if (mode == 0 || mode == 1) return 1;
    if (mode < 2 || mode >= FONT_MODE_COUNT) return 0;
    if (custom_font_for_mode(mode)) return 1;

    char path[64];
    snprintf(path, sizeof(path), "sa0:data/font/pgf/ltn%d.pgf", mode - 2);
    vita2d_pgf *font = vita2d_load_custom_pgf(path);
    if (!font) return 0;
    switch (mode) {
        case 2: font_sans_pgf = font; break;
        case 3: font_serif_pgf = font; break;
        case 4: font_sans_italic_pgf = font; break;
        case 5: font_serif_italic_pgf = font; break;
        case 6: font_sans_bold_pgf = font; break;
        case 7: font_serif_bold_pgf = font; break;
        case 8: font_sans_bold_italic_pgf = font; break;
        case 9: font_serif_bold_italic_pgf = font; break;
    }
    return 1;
}

static float selected_text_scale(void) {
    if (text_size_mode < 0 || text_size_mode > 4) text_size_mode = 1;
    return text_scales[text_size_mode];
}

static float selected_ui_text_scale(void) {
    if (ui_text_mode < 0 || ui_text_mode > 2) ui_text_mode = 1;
    return ui_text_scales[ui_text_mode];
}

static void apply_color_theme(int mode) {
    if (mode < 0 || mode > THEME_CUSTOM_MODE) mode = 0;
    color_theme_mode = mode;
    if (mode == THEME_CUSTOM_MODE) {
        BG = custom_background_colors[custom_background_color];
        ACCENT = custom_accent_colors[custom_accent_color];
        GREEN = ACCENT;
        YELLOW = ACCENT;
        RED = ACCENT;
        if (custom_background_color == 7 || custom_background_color == 8) {
            WHITE = RGBA8(38, 34, 36, 255);
            MUTED = RGBA8(112, 98, 94, 255);
            PANEL = custom_background_color == 7 ? RGBA8(239, 228, 204, 255)
                                                  : RGBA8(235, 237, 243, 255);
            PANEL_HI = custom_background_color == 7 ? RGBA8(224, 210, 181, 255)
                                                     : RGBA8(218, 223, 235, 255);
        } else {
            WHITE = color_themes[0].white;
            MUTED = color_themes[0].muted;
            PANEL = color_themes[0].panel;
            PANEL_HI = color_themes[0].panel_hi;
        }
        return;
    }
    WHITE = color_themes[mode].white;
    MUTED = color_themes[mode].muted;
    ACCENT = color_themes[mode].accent;
    PANEL = color_themes[mode].panel;
    PANEL_HI = color_themes[mode].panel_hi;
    BG = color_themes[mode].background;
    GREEN = color_themes[mode].green;
    YELLOW = color_themes[mode].yellow;
    RED = color_themes[mode].red;
}

static void draw_text_scaled(int x, int y, unsigned int color, float scale,
                             const char *text, float size_factor) {
    float actual_scale = scale * size_factor * UI_TEXT_SCALE;
    if (custom_font_for_mode(font_mode))
        vita2d_pgf_draw_text(custom_font_for_mode(font_mode), x, y, color, actual_scale, text);
    else if (font_pgf) {
        vita2d_pgf_draw_text(font_pgf, x, y, color, actual_scale, text);
        if (font_mode == 1) vita2d_pgf_draw_text(font_pgf, x + 1, y, color, actual_scale, text);
    }
}

static void draw_text(int x, int y, unsigned int color, float scale, const char *text) {
    draw_text_scaled(x, y, color, scale, text, 1.0f);
}

static void draw_card_text(int x, int y, unsigned int color, float scale, const char *text) {
    draw_text_scaled(x, y, color, scale, text, selected_text_scale());
}

static int text_width_scaled(float scale, const char *text, float size_factor) {
    float actual_scale = scale * size_factor * UI_TEXT_SCALE;
    if (custom_font_for_mode(font_mode))
        return vita2d_pgf_text_width(custom_font_for_mode(font_mode), actual_scale, text);
    if (font_pgf)
        return vita2d_pgf_text_width(font_pgf, actual_scale, text);
    return 0;
}

static int text_width(float scale, const char *text) {
    return text_width_scaled(scale, text, 1.0f);
}

static int card_text_width(float scale, const char *text) {
    return text_width_scaled(scale, text, selected_text_scale());
}

static void draw_fit_text(int x, int y, unsigned int color, float scale,
                          const char *text, int max_width) {
    char fitted[160];
    size_t source_length = strlen(text);
    size_t keep = source_length < sizeof(fitted) - 1 ? source_length : sizeof(fitted) - 4;
    int truncated = source_length > keep;
    do {
        memcpy(fitted, text, keep);
        fitted[keep] = '\0';
        if (truncated) strncat(fitted, "...", sizeof(fitted) - strlen(fitted) - 1);
        if (text_width(scale, fitted) <= max_width || keep == 0) break;
        keep--;
        truncated = 1;
    } while (1);
    draw_text(x, y, color, scale, fitted);
}

static int inside(UiRect rect, int x, int y) {
    return x >= rect.x && y >= rect.y && x < rect.x + rect.w && y < rect.y + rect.h;
}

static void draw_button(UiRect rect, const char *label, const char *subtitle,
                        unsigned int accent, int selected) {
    unsigned int fill = selected ? PANEL_HI : PANEL;
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, fill);
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, 4, accent);
    if (selected) {
        vita2d_draw_rectangle(rect.x, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x + rect.w - 3, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x, rect.y + rect.h - 3, rect.w, 3, accent);
    }
    draw_fit_text(rect.x + 20, rect.y + 48, WHITE, 0.88f, label, rect.w - 40);
    if (subtitle) draw_fit_text(rect.x + 20, rect.y + 82, MUTED, 0.58f, subtitle, rect.w - 40);
}

static void draw_compact_button(UiRect rect, const char *label,
                               unsigned int accent, int selected) {
    unsigned int fill = selected ? PANEL_HI : PANEL;
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, fill);
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, 3, accent);
    if (selected) {
        vita2d_draw_rectangle(rect.x, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x + rect.w - 3, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x, rect.y + rect.h - 3, rect.w, 3, accent);
    }
    draw_fit_text(rect.x + 16, rect.y + rect.h / 2 + 6, WHITE, 0.60f,
                  label, rect.w - 32);
}

static void draw_header(const char *title, const char *subtitle) {
    if (current_screen == SCREEN_HOME) {
        draw_text(48, 48, ACCENT, 1.0f, title);
        if (subtitle) draw_fit_text(48, 78, MUTED, 0.5f, subtitle, 690);
    } else {
        draw_compact_button(back_button, "BACK", ACCENT, header_focus_active == 1);
        int title_x = current_screen == SCREEN_STUDY ? 148 : 184;
        draw_fit_text(title_x, 48, ACCENT, 0.94f, title, 560);
        if (subtitle) draw_fit_text(title_x, 78, MUTED, 0.5f, subtitle, 540);
    }
    vita2d_draw_rectangle(48, 94, 864, 2, PANEL_HI);
}

static void draw_wrapped_mode(const char *text, int x, int y, int max_width, float scale,
                              unsigned int color, int card_size) {
    char line[280] = {0};
    char word[120];
    const char *p = text;
    int line_y = y;
    float size_factor = card_size ? selected_text_scale() : 1.0f;
    int line_height = (int)(39.0f * size_factor * UI_TEXT_SCALE);

    while (*p) {
        int n = 0;
        while (*p == ' ' || *p == '\n' || *p == '\r') p++;
        while (*p && *p != ' ' && *p != '\n' && *p != '\r' && n < (int)sizeof(word) - 1)
            word[n++] = *p++;
        word[n] = '\0';
        if (n == 0) break;

        size_t line_length = strlen(line);
        size_t word_length = strlen(word);
        if (line[0] && line_length + 1 + word_length >= sizeof(line)) {
            if (card_size) draw_card_text(x, line_y, color, scale, line);
            else draw_text(x, line_y, color, scale, line);
            line_y += line_height;
            memcpy(line, word, word_length + 1);
            continue;
        }

        char candidate[280];
        size_t candidate_length = line[0] ? line_length + 1 + word_length : word_length;
        if (line[0]) {
            memcpy(candidate, line, line_length);
            candidate[line_length] = ' ';
            memcpy(candidate + line_length + 1, word, word_length + 1);
        } else {
            memcpy(candidate, word, word_length + 1);
        }

        if (line[0] && text_width_scaled(scale, candidate, size_factor) > max_width) {
            if (card_size) draw_card_text(x, line_y, color, scale, line);
            else draw_text(x, line_y, color, scale, line);
            line_y += line_height;
            memcpy(line, word, word_length + 1);
        } else {
            memcpy(line, candidate, candidate_length + 1);
        }
    }

    if (line[0]) {
        if (card_size) draw_card_text(x, line_y, color, scale, line);
        else draw_text(x, line_y, color, scale, line);
    }
}

static void draw_wrapped(const char *text, int x, int y, int max_width, float scale,
                         unsigned int color) {
    draw_wrapped_mode(text, x, y, max_width, scale, color, 0);
}

static int next_card_line(const char **cursor, char line[256], int max_width, float scale) {
    const char *p = *cursor;
    line[0] = '\0';
    while (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t') p++;
    if (!*p) {
        *cursor = p;
        return 0;
    }

    for (;;) {
        char word[240];
        int n = 0;
        const char *word_start = p;
        while (*p && *p != ' ' && *p != '\n' && *p != '\r' && *p != '\t' && n < (int)sizeof(word) - 1)
            word[n++] = *p++;
        word[n] = '\0';
        if (n == 0) break;

        size_t line_length = strlen(line);
        size_t candidate_length = line[0] ? line_length + 1 + (size_t)n : (size_t)n;
        if (candidate_length >= 256) {
            *cursor = word_start;
            return 1;
        }
        char candidate[256];
        if (line[0]) {
            memcpy(candidate, line, line_length);
            candidate[line_length] = ' ';
            memcpy(candidate + line_length + 1, word, (size_t)n + 1);
        } else {
            memcpy(candidate, word, (size_t)n + 1);
        }
        if (line[0] && card_text_width(scale, candidate) > max_width) {
            *cursor = word_start;
            return 1;
        }
        memcpy(line, candidate, candidate_length + 1);
        while (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t') p++;
        if (!*p) break;
    }
    *cursor = p;
    return line[0] != '\0';
}

static uint32_t card_line_text_hash(const char *text, size_t *length) {
    uint32_t hash = 2166136261u;
    size_t count = 0;
    while (text && text[count]) {
        hash ^= (unsigned char)text[count++];
        hash *= 16777619u;
    }
    *length = count;
    return hash;
}

static void ensure_card_line_cache(const char *text, int max_width, float scale) {
    if (!text) text = "";
    size_t source_length = 0;
    uint32_t source_hash = card_line_text_hash(text, &source_length);
    vita2d_pgf *selected_font = custom_font_for_mode(font_mode);
    if (!selected_font) selected_font = font_pgf;
    if (cached_card_line_cache_valid && cached_card_line_source == text &&
        cached_card_line_font == selected_font && cached_card_line_hash == source_hash &&
        cached_card_line_source_length == source_length && cached_card_line_width == max_width &&
        cached_card_line_scale == scale && cached_card_line_font_mode == font_mode &&
        cached_card_line_text_size_mode == text_size_mode &&
        cached_card_line_ui_text_mode == ui_text_mode)
        return;

    cached_card_line_cache_valid = 0;
    cached_card_line_count = 0;
    cached_card_line_bytes = 0;
    const char *cursor = text;
    char line[256];
    while (cached_card_line_count < FIELD_SIZE &&
           next_card_line(&cursor, line, max_width, scale)) {
        size_t line_length = strlen(line);
        if (cached_card_line_bytes + (int)line_length + 1 >=
            (int)sizeof(cached_card_lines))
            break;
        cached_card_line_offsets[cached_card_line_count] = (uint16_t)cached_card_line_bytes;
        memcpy(cached_card_lines + cached_card_line_bytes, line, line_length + 1);
        cached_card_line_bytes += (int)line_length + 1;
        cached_card_line_count++;
    }

    cached_card_line_source = text;
    cached_card_line_font = selected_font;
    cached_card_line_hash = source_hash;
    cached_card_line_source_length = source_length;
    cached_card_line_width = max_width;
    cached_card_line_scale = scale;
    cached_card_line_font_mode = font_mode;
    cached_card_line_text_size_mode = text_size_mode;
    cached_card_line_ui_text_mode = ui_text_mode;
    cached_card_line_cache_valid = 1;
}

static int card_line_height(void) {
    int height = (int)(39.0f * selected_text_scale() * UI_TEXT_SCALE);
    return height > 0 ? height : 1;
}

static int card_glyph_height(float scale) {
    float actual_scale = scale * selected_text_scale() * UI_TEXT_SCALE;
    const char *sample = "Mg";
    int height = 0;
    vita2d_pgf *custom = custom_font_for_mode(font_mode);
    if (custom) height = vita2d_pgf_text_height(custom, actual_scale, sample);
    else if (font_pgf) height = vita2d_pgf_text_height(font_pgf, actual_scale, sample);
    if (height <= 0) height = card_line_height() / 2;
    if (height > card_line_height()) height = card_line_height();
    return height;
}

static int card_line_count(const char *text, int max_width, float scale) {
    ensure_card_line_cache(text, max_width, scale);
    return cached_card_line_count;
}

static int card_scroll_limit(const char *text, int max_width, float scale, int viewport_height) {
    int visible_lines = viewport_height / card_line_height() + 1;
    int limit = card_line_count(text, max_width, scale) - visible_lines;
    return limit > 0 ? limit : 0;
}

static void draw_card_viewport(const char *text, int x, int y, int max_width, float scale,
                               unsigned int color, float scroll_lines, int viewport_height) {
    ensure_card_line_cache(text, max_width, scale);
    int line_height = card_line_height();
    int first_line = (int)scroll_lines;
    if (first_line < 0) first_line = 0;
    /* PGF's y coordinate is the text baseline, so let glyphs extend above it. */
    int clip_top = y - card_glyph_height(scale);
    vita2d_set_clip_rectangle(x, clip_top, x + max_width, y + viewport_height);
    vita2d_enable_clipping();
    for (int line_index = first_line; line_index < cached_card_line_count; line_index++) {
        float visible_y = (float)y + ((float)line_index - scroll_lines) * (float)line_height;
        if (visible_y >= (float)(y + viewport_height)) break;
        if (visible_y + line_height > (float)y) {
            const char *line = cached_card_lines + cached_card_line_offsets[line_index];
            draw_card_text(x, (int)visible_y, color, scale, line);
        }
    }
    vita2d_disable_clipping();
}

static vita2d_texture *get_card_image(const char *path) {
    if (!path || !*path) return NULL;
    if (!strcmp(card_image_path_cached, path)) return card_image_texture;
    if (card_image_texture) {
        vita2d_free_texture(card_image_texture);
        card_image_texture = NULL;
    }
    snprintf(card_image_path_cached, sizeof(card_image_path_cached), "%s", path);
    const char *extension = strrchr(path, '.');
    if (extension && (!strcasecmp(extension, ".jpg") || !strcasecmp(extension, ".jpeg")))
        card_image_texture = vita2d_load_JPEG_file(path);
    else if (extension && !strcasecmp(extension, ".png"))
        card_image_texture = vita2d_load_PNG_file(path);
    return card_image_texture;
}

static void draw_card_image_half(const char *path, int x, int y, int width, int height) {
    vita2d_draw_rectangle(x, y, width, height, PANEL_HI);
    vita2d_draw_rectangle(x, y, width, 3, ACCENT);
    vita2d_texture *texture = get_card_image(path);
    if (!texture) {
        draw_fit_text(x + 12, y + height / 2, MUTED, 0.45f, "IMAGE UNAVAILABLE", width - 24);
        return;
    }
    unsigned int image_width = vita2d_texture_get_width(texture);
    unsigned int image_height = vita2d_texture_get_height(texture);
    if (!image_width || !image_height) return;
    float scale_x = (float)(width - 12) / (float)image_width;
    float scale_y = (float)(height - 12) / (float)image_height;
    float scale = scale_x < scale_y ? scale_x : scale_y;
    float draw_width = (float)image_width * scale;
    float draw_height = (float)image_height * scale;
    float draw_x = (float)x + ((float)width - draw_width) * 0.5f;
    float draw_y = (float)y + ((float)height - draw_height) * 0.5f;
    vita2d_draw_texture_scale(texture, draw_x, draw_y, scale, scale);
}

static const char *browser_image_path(void) {
    if (!show_card_images || browser_show_answer || card_count <= 0 ||
        browser_index < 0 || browser_index >= card_count) return "";
    return cards[browser_index].front_image;
}

static const char *study_image_path(void) {
    if (!show_card_images || show_answer || flip_frames_remaining > 0 || !has_study_card())
        return "";
    return cards[card_index].front_image;
}

static const char *focused_image_path(void) {
    return current_screen == SCREEN_STUDY ? study_image_path() : browser_image_path();
}

static void clamp_image_viewer_pan(void) {
    const int viewport_width = IMAGE_VIEWER_WIDTH;
    const int viewport_height = IMAGE_VIEWER_HEIGHT;
    vita2d_texture *texture = get_card_image(focused_image_path());
    if (!texture) {
        image_focus_pan_x = 0.0f;
        image_focus_pan_y = 0.0f;
        return;
    }
    float width = (float)vita2d_texture_get_width(texture);
    float height = (float)vita2d_texture_get_height(texture);
    if (width <= 0.0f || height <= 0.0f) return;
    float fit_x = (float)(viewport_width - 16) / width;
    float fit_y = (float)(viewport_height - 16) / height;
    float scale = (fit_x < fit_y ? fit_x : fit_y) * image_focus_zoom;
    float max_x = (width * scale - (float)viewport_width) * 0.5f;
    float max_y = (height * scale - (float)viewport_height) * 0.5f;
    if (max_x < 0.0f) max_x = 0.0f;
    if (max_y < 0.0f) max_y = 0.0f;
    if (image_focus_pan_x < -max_x) image_focus_pan_x = -max_x;
    if (image_focus_pan_x > max_x) image_focus_pan_x = max_x;
    if (image_focus_pan_y < -max_y) image_focus_pan_y = -max_y;
    if (image_focus_pan_y > max_y) image_focus_pan_y = max_y;
}

static void toggle_image_viewer_zoom(void) {
    image_focus_zoom = image_focus_zoom > 1.0f ? 1.0f : 1.5f;
    clamp_image_viewer_pan();
}

static void pan_image_viewer(float x, float y) {
    if (image_focus_zoom <= 1.0f) return;
    image_focus_pan_x += x;
    image_focus_pan_y += y;
    clamp_image_viewer_pan();
}

static void draw_image_viewer(void) {
    const int x = IMAGE_VIEWER_X, y = IMAGE_VIEWER_Y;
    const int width = IMAGE_VIEWER_WIDTH, height = IMAGE_VIEWER_HEIGHT;
    vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, BG);
    vita2d_draw_rectangle(x, y, width, height, PANEL);
    vita2d_texture *texture = get_card_image(focused_image_path());
    if (!texture) {
        draw_text(82, 270, MUTED, 0.70f, "IMAGE UNAVAILABLE");
    } else {
        float image_width = (float)vita2d_texture_get_width(texture);
        float image_height = (float)vita2d_texture_get_height(texture);
        if (image_width > 0.0f && image_height > 0.0f) {
            float scale_x = (float)(width - 16) / image_width;
            float scale_y = (float)(height - 16) / image_height;
            float scale = (scale_x < scale_y ? scale_x : scale_y) * image_focus_zoom;
            float draw_width = image_width * scale;
            float draw_height = image_height * scale;
            float draw_x = (float)x + ((float)width - draw_width) * 0.5f + image_focus_pan_x;
            float draw_y = (float)y + ((float)height - draw_height) * 0.5f + image_focus_pan_y;
            vita2d_set_clip_rectangle(x + 4, y + 4, x + width - 4, y + height - 4);
            vita2d_enable_clipping();
            vita2d_draw_texture_scale(texture, draw_x, draw_y, scale, scale);
            vita2d_disable_clipping();
        }
    }
}

static void draw_card_scrollbar(const char *text, int x, int y, int max_width,
                               float scale, float scroll_lines, int viewport_height) {
    int total_lines = card_line_count(text, max_width, scale);
    int visible_lines = viewport_height / card_line_height() + 1;
    int maximum = total_lines - visible_lines;
    if (maximum <= 0) return;

    const int track_height = 166;
    int thumb_height = track_height * visible_lines / total_lines;
    if (thumb_height < 18) thumb_height = 18;
    if (thumb_height > track_height) thumb_height = track_height;
    int thumb_y = y + (int)((float)(track_height - thumb_height) * scroll_lines /
                            (float)maximum);
    vita2d_draw_rectangle(x, y, 5, track_height, PANEL_HI);
    vita2d_draw_rectangle(x, thumb_y, 5, thumb_height, ACCENT);
}

static const char *study_card_text(void) {
    if (card_count <= 0 || card_index < 0 || card_index >= card_count) return "";
    return show_answer ? cards[card_index].back : cards[card_index].front;
}

static int displayed_answer_side(void) {
    if (flip_frames_remaining <= 0) return show_answer;
    int progress = CARD_FLIP_FRAMES - flip_frames_remaining;
    return progress < CARD_FLIP_FRAMES / 2 ? flip_from_answer : flip_to_answer;
}

static void set_study_answer_side(int answer) {
    answer = answer ? 1 : 0;
    if (flip_frames_remaining > 0 || card_count <= 0 ||
        card_index < 0 || card_index >= card_count || answer == show_answer) return;
    card_scroll_position = 0.0f;
    if (!flip_animation_mode) {
        show_answer = answer;
        return;
    }
    flip_from_answer = show_answer;
    flip_to_answer = answer;
    show_answer = answer;
    flip_frames_remaining = CARD_FLIP_FRAMES;
}

static void advance_study_flip(void) {
    if (flip_frames_remaining > 0) flip_frames_remaining--;
}

static const char *browser_card_text(void) {
    if (card_count <= 0 || browser_index < 0 || browser_index >= card_count) return "";
    return browser_show_answer ? cards[browser_index].back : cards[browser_index].front;
}

static void scroll_visible_card_by(float delta) {
    if (current_screen == SCREEN_STUDY) {
        if (flip_frames_remaining > 0) return;
        int split = show_card_images && has_study_card() && !displayed_answer_side() &&
                    cards[card_index].front_image[0];
        int limit = card_scroll_limit(study_card_text(), split ? SPLIT_CARD_TEXT_WIDTH : 790,
                                      split ? 0.84f : 0.95f, split ? 210 : 160);
        card_scroll_position += delta;
        if (card_scroll_position < 0.0f) card_scroll_position = 0.0f;
        if (card_scroll_position > (float)limit) card_scroll_position = (float)limit;
    } else if (current_screen == SCREEN_BROWSER) {
        int split = show_card_images && card_count > 0 && !browser_show_answer &&
                    cards[browser_index].front_image[0];
        int limit = card_scroll_limit(browser_card_text(), split ? SPLIT_CARD_TEXT_WIDTH : 790,
                                      split ? 0.84f : 0.95f, split ? 210 : 160);
        browser_scroll_position += delta;
        if (browser_scroll_position < 0.0f) browser_scroll_position = 0.0f;
        if (browser_scroll_position > (float)limit) browser_scroll_position = (float)limit;
    }
}

static void scroll_visible_card(int direction) {
    scroll_visible_card_by((float)direction);
}

static void load_settings(void) {
    recover_atomic_file(SETTINGS_PATH, SETTINGS_TEMP_PATH, SETTINGS_BACKUP_PATH);
    FILE *file = fopen(SETTINGS_PATH, "r");
    if (!file) {
        study_layout_settings_migrated = 1;
        return;
    }
    char line[128];
    while (fgets(line, sizeof(line), file)) {
        int value;
        if (sscanf(line, "font=%d", &value) == 1) font_mode = value;
        else if (sscanf(line, "text_size=%d", &value) == 1) text_size_mode = value;
        else if (sscanf(line, "ui_text=%d", &value) == 1) ui_text_mode = value;
        else if (sscanf(line, "theme_v2=%d", &value) == 1) color_theme_mode = value;
        else if (sscanf(line, "custom_background=%d", &value) == 1) custom_background_color = value;
        else if (sscanf(line, "custom_accent=%d", &value) == 1) custom_accent_color = value;
        else if (sscanf(line, "flip_animation=%d", &value) == 1) flip_animation_mode = value;
        else if (sscanf(line, "music_muted=%d", &value) == 1) music_muted = value;
        else if (sscanf(line, "music_setting_migration=%d", &value) == 1) music_setting_migration = value;
        else if (sscanf(line, "click_sounds=%d", &value) == 1) click_sounds_enabled = value;
        else if (sscanf(line, "click_volume=%d", &value) == 1) click_volume = value;
        else if (sscanf(line, "confetti=%d", &value) == 1) confetti_mode = value;
        else if (sscanf(line, "review_controls=%d", &value) == 1) review_control_mode = value;
        else if (sscanf(line, "browser_stick_mode=%d", &value) == 1) browser_stick_mode = value;
        else if (sscanf(line, "show_card_images=%d", &value) == 1) show_card_images = value;
        else if (sscanf(line, "large_study_buttons=%d", &value) == 1) large_study_buttons = value;
        else if (sscanf(line, "study_layout_migration=%d", &value) == 1)
            study_layout_settings_migrated = value;
    }
    fclose(file);
    int migrate_study_layout = !study_layout_settings_migrated;
    if (migrate_study_layout) {
        large_study_buttons = 0;
        study_layout_settings_migrated = 1;
    }
    if (font_mode < 0 || font_mode >= FONT_MODE_COUNT) font_mode = 0;
    if (text_size_mode < 0 || text_size_mode > 4) text_size_mode = 1;
    if (ui_text_mode < 0 || ui_text_mode > 2) ui_text_mode = 1;
    if (color_theme_mode < 0 || color_theme_mode > THEME_CUSTOM_MODE)
        color_theme_mode = 0;
    if (custom_background_color < 0 || custom_background_color >= CUSTOM_COLOR_COUNT)
        custom_background_color = 0;
    if (custom_accent_color < 0 || custom_accent_color >= CUSTOM_COLOR_COUNT)
        custom_accent_color = 0;
    apply_color_theme(color_theme_mode);
    if (flip_animation_mode < 0 || flip_animation_mode > 1) flip_animation_mode = 1;
    music_muted = music_muted ? 1 : 0;
    music_setting_migration = music_setting_migration ? 1 : 0;
    click_sounds_enabled = click_sounds_enabled ? 1 : 0;
    if (click_volume < 0 || click_volume > 2) click_volume = 1;
    if (confetti_mode < 0 || confetti_mode > 2) confetti_mode = 1;
    if (review_control_mode < 0 || review_control_mode > 1) review_control_mode = 0;
    if (browser_stick_mode < BROWSER_STICK_BUTTONS || browser_stick_mode > BROWSER_STICK_SCROLL)
        browser_stick_mode = BROWSER_STICK_BUTTONS;
    show_card_images = show_card_images ? 1 : 0;
    large_study_buttons = large_study_buttons ? 1 : 0;
    if (migrate_study_layout) save_settings();
}

static void save_settings(void) {
    recover_atomic_file(SETTINGS_PATH, SETTINGS_TEMP_PATH, SETTINGS_BACKUP_PATH);
    remove(SETTINGS_TEMP_PATH);
    FILE *file = fopen(SETTINGS_TEMP_PATH, "w");
    if (!file) return;
    int ok = fprintf(file, "font=%d\ntext_size=%d\nui_text=%d\ntheme_v2=%d\ncustom_background=%d\ncustom_accent=%d\nflip_animation=%d\nmusic_muted=%d\nmusic_setting_migration=%d\nclick_sounds=%d\nclick_volume=%d\nconfetti=%d\nreview_controls=%d\nbrowser_stick_mode=%d\nshow_card_images=%d\nlarge_study_buttons=%d\nstudy_layout_migration=%d\n",
                     font_mode, text_size_mode, ui_text_mode, color_theme_mode,
                     custom_background_color, custom_accent_color, flip_animation_mode,
                     music_muted, music_setting_migration,
                     click_sounds_enabled, click_volume,
                     confetti_mode, review_control_mode, browser_stick_mode, show_card_images,
                     large_study_buttons, study_layout_settings_migrated) >= 0;
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(SETTINGS_TEMP_PATH, SETTINGS_PATH, SETTINGS_BACKUP_PATH))
        remove(SETTINGS_TEMP_PATH);
}

static int clock_date_is_invalid(void) {
    time_t now = time(NULL);
    if (now == (time_t)-1) return 1;
    long long epoch = (long long)now;
    return epoch < MIN_VALID_CLOCK_EPOCH || epoch >= MAX_VALID_CLOCK_EPOCH;
}

static void refresh_clock_warning(void) {
    clock_warning_active = !live_sync && !demo_mode && clock_date_is_invalid();
}

static int file_exists(const char *path) {
    FILE *file = fopen(path, "rb");
    if (!file) return 0;
    fclose(file);
    return 1;
}

static void recover_atomic_file(const char *destination, const char *temporary,
                                const char *backup) {
    int has_destination = file_exists(destination);
    int has_temporary = file_exists(temporary);
    int has_backup = file_exists(backup);
    if (has_destination) {
        if (has_temporary) remove(temporary);
        if (has_backup) remove(backup);
        return;
    }
    if (has_backup && has_temporary && rename(temporary, destination) == 0) {
        remove(backup);
        return;
    }
    if (has_backup && rename(backup, destination) == 0) {
        if (has_temporary) remove(temporary);
        return;
    }
    if (has_temporary) remove(temporary);
}

static int atomic_replace_file(const char *temporary, const char *destination,
                               const char *backup) {
    int has_destination = file_exists(destination);
    remove(backup);
    if (has_destination && rename(destination, backup) != 0) return 0;
    if (rename(temporary, destination) != 0) {
        if (has_destination) rename(backup, destination);
        return 0;
    }
    if (has_destination) remove(backup);
    return 1;
}

static void copy_file_if_missing(const char *source, const char *destination) {
    if (file_exists(destination)) return;
    FILE *input = fopen(source, "rb");
    if (!input) return;
    char temporary[640];
    int length = snprintf(temporary, sizeof(temporary), "%s.tmp", destination);
    if (length < 0 || (size_t)length >= sizeof(temporary)) {
        fclose(input);
        return;
    }
    remove(temporary);
    FILE *output = fopen(temporary, "wb");
    if (!output) {
        fclose(input);
        return;
    }

    char buffer[8192];
    size_t bytes;
    int ok = 1;
    while ((bytes = fread(buffer, 1, sizeof(buffer), input)) > 0) {
        if (fwrite(buffer, 1, bytes, output) != bytes) {
            ok = 0;
            break;
        }
    }
    if (ferror(input)) ok = 0;
    if (fclose(output) != 0) ok = 0;
    if (fclose(input) != 0) ok = 0;
    if (ok && rename(temporary, destination) == 0) return;
    remove(temporary);
}

static int has_extension(const char *name, const char *extension) {
    const char *dot = strrchr(name, '.');
    if (!dot) return 0;
    while (*dot && *extension) {
        if (tolower((unsigned char)*dot) != tolower((unsigned char)*extension)) return 0;
        dot++;
        extension++;
    }
    return *dot == '\0' && *extension == '\0';
}

static int deck_path_is_deletable(const char *path) {
    if (!path) return 0;
    char folder_prefix[128];
    int prefix_length = snprintf(folder_prefix, sizeof(folder_prefix), "%s/", DECK_FOLDER);
    if (prefix_length <= 0 || (size_t)prefix_length >= sizeof(folder_prefix) ||
        strncmp(path, folder_prefix, (size_t)prefix_length) != 0)
        return 0;
    if (!strcmp(path, INCLUDED_DECK_PATH) || !strcmp(path, INCLUDED_PICTURE_DECK_PATH))
        return 0;
    const char *filename = path + prefix_length;
    if (strchr(filename, '/') || strchr(filename, '\\')) return 0;
    struct stat info;
    return (has_extension(filename, ".apkg") || has_extension(filename, ".tsv")) &&
           stat(path, &info) == 0 && S_ISREG(info.st_mode);
}

static void add_deck(const char *path, const char *filename, int is_apkg) {
    if (deck_count >= MAX_DECKS) return;
    for (int i = 0; i < deck_count; i++)
        if (!strcmp(deck_entries[i].path, path)) return;

    DeckEntry *entry = &deck_entries[deck_count++];
    snprintf(entry->path, sizeof(entry->path), "%s", path);
    snprintf(entry->name, sizeof(entry->name), "%s", filename);
    char *dot = strrchr(entry->name, '.');
    if (dot) *dot = '\0';
    entry->is_apkg = is_apkg;
}

static int deck_index_for_path(const char *path) {
    if (!path || !path[0]) return -1;
    for (int i = 0; i < deck_count; i++)
        if (!strcmp(deck_entries[i].path, path)) return i;
    return -1;
}

static int compare_decks(const void *left, const void *right) {
    const DeckEntry *a = (const DeckEntry *)left;
    const DeckEntry *b = (const DeckEntry *)right;
    return strcmp(a->name, b->name);
}

static int folder_index_by_name(const char *name) {
    if (!name || !name[0]) return -1;
    for (int i = 0; i < folder_count; i++)
        if (!strcmp(folder_names[i], name)) return i;
    return -1;
}

static int ensure_folder_name(const char *name) {
    if (!name || !name[0]) return -1;
    int existing = folder_index_by_name(name);
    if (existing >= 0) return existing;
    if (folder_count >= MAX_FOLDERS) return -1;
    snprintf(folder_names[folder_count], sizeof(folder_names[folder_count]), "%s", name);
    return folder_count++;
}

static void load_folder_metadata(void) {
    folder_count = 0;
    for (int i = 0; i < deck_count; i++) deck_entries[i].folder[0] = '\0';
    recover_atomic_file(FOLDER_STORE_PATH, FOLDER_STORE_TEMP_PATH,
                        FOLDER_STORE_BACKUP_PATH);
    FILE *file = fopen(FOLDER_STORE_PATH, "r");
    if (!file) return;
    char line[768];
    while (fgets(line, sizeof(line), file)) {
        char *end = strpbrk(line, "\r\n");
        if (end) *end = '\0';
        if (!strncmp(line, "F\t", 2)) {
            ensure_folder_name(line + 2);
        } else if (!strncmp(line, "D\t", 2)) {
            char *path = line + 2;
            char *folder = strchr(path, '\t');
            if (!folder) continue;
            *folder++ = '\0';
            if (!path[0] || !folder[0]) continue;
            for (int i = 0; i < deck_count; i++) {
                if (!strcmp(deck_entries[i].path, path)) {
                    snprintf(deck_entries[i].folder, sizeof(deck_entries[i].folder),
                             "%s", folder);
                    ensure_folder_name(folder);
                    break;
                }
            }
        }
    }
    fclose(file);
}

static int save_folder_metadata(void) {
    recover_atomic_file(FOLDER_STORE_PATH, FOLDER_STORE_TEMP_PATH,
                        FOLDER_STORE_BACKUP_PATH);
    remove(FOLDER_STORE_TEMP_PATH);
    FILE *file = fopen(FOLDER_STORE_TEMP_PATH, "w");
    if (!file) return 0;
    int ok = 1;
    for (int i = 0; i < folder_count && ok; i++)
        ok = fprintf(file, "F\t%s\n", folder_names[i]) >= 0;
    for (int i = 0; i < deck_count && ok; i++)
        if (deck_entries[i].folder[0])
            ok = fprintf(file, "D\t%s\t%s\n", deck_entries[i].path,
                         deck_entries[i].folder) >= 0;
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(FOLDER_STORE_TEMP_PATH, FOLDER_STORE_PATH,
                                    FOLDER_STORE_BACKUP_PATH)) {
        remove(FOLDER_STORE_TEMP_PATH);
        return 0;
    }
    return 1;
}

static int deck_matches_folder_filter(int index) {
    if (index < 0 || index >= deck_count) return 0;
    if (deck_folder_filter == 0) return 1;
    if (deck_folder_filter == 1) return deck_entries[index].folder[0] == '\0';
    int folder = deck_folder_filter - 2;
    return folder >= 0 && folder < folder_count &&
           !strcmp(deck_entries[index].folder, folder_names[folder]);
}

static int visible_deck_count(void) {
    int count = 0;
    for (int i = 0; i < deck_count; i++)
        if (deck_matches_folder_filter(i)) count++;
    return count;
}

static int deck_index_at_visible_position(int position) {
    if (position < 0) return -1;
    for (int i = 0, visible = 0; i < deck_count; i++) {
        if (!deck_matches_folder_filter(i)) continue;
        if (visible++ == position) return i;
    }
    return -1;
}

static int visible_position_for_deck(int index) {
    if (index < 0 || index >= deck_count) return -1;
    int visible = 0;
    for (int i = 0; i < deck_count; i++) {
        if (!deck_matches_folder_filter(i)) continue;
        if (i == index) return visible;
        visible++;
    }
    return -1;
}

static void open_folder_manager(void) {
    int current_folder = current_deck_index >= 0 && current_deck_index < deck_count
                       ? folder_index_by_name(deck_entries[current_deck_index].folder) : -1;
    folder_selection = current_folder >= 0 ? current_folder + 2 : 0;
    folder_action_selection = 0;
    folder_actions_focus = 0;
    deck_folder_filter_focus = 0;
    header_focus_active = 0;
    create_status[0] = '\0';
    current_screen = SCREEN_FOLDERS;
}

static void close_folder_manager(void) {
    int selected = current_deck_index >= 0
                 ? visible_position_for_deck(current_deck_index) : -1;
    list_selection = selected >= 0 ? selected + 1 : 0;
    list_focus_actions = 0;
    deck_list_gear_focus = 0;
    deck_folder_filter_focus = 0;
    header_focus_active = 0;
    current_screen = SCREEN_DECKS;
}

static void activate_folder_action(int action) {
    if (action == 0) {
        folder_ime_action = 1;
        folder_ime_name[0] = '\0';
        begin_create_ime(3);
    } else if (action == 1 && folder_selection >= 2) {
        int index = folder_selection - 2;
        if (index >= 0 && index < folder_count) {
            folder_ime_action = 2;
            snprintf(folder_ime_name, sizeof(folder_ime_name), "%s", folder_names[index]);
            begin_create_ime(3);
        }
    } else if (action == 1) {
        snprintf(create_status, sizeof(create_status), "Select a folder before renaming it.");
        create_error = 0;
    } else if (action == 2) close_folder_manager();
}

static void scan_decks(void) {
    char selected_path[512] = "";
    int selected_index_before = current_screen == SCREEN_DECKS
                              ? (list_selection > 0
                                 ? deck_index_at_visible_position(list_selection - 1) : -1)
                              : list_selection;
    if (selected_index_before >= 0 && selected_index_before < deck_count)
        snprintf(selected_path, sizeof(selected_path), "%s", deck_entries[selected_index_before].path);
    deck_count = 0;
    if (file_exists(APKG_PATH)) add_deck(APKG_PATH, "import.apkg", 1);

    SceUID directory = sceIoDopen(DECK_FOLDER);
    if (directory >= 0) {
        SceIoDirent item;
        memset(&item, 0, sizeof(item));
        while (sceIoDread(directory, &item) > 0) {
            if (item.d_name[0] == '.' ||
                (!has_extension(item.d_name, ".apkg") && !has_extension(item.d_name, ".tsv"))) {
                memset(&item, 0, sizeof(item));
                continue;
            }
            char path[512];
            int length = snprintf(path, sizeof(path), "%s/%s", DECK_FOLDER, item.d_name);
            if (length < 0 || (size_t)length >= sizeof(path)) {
                memset(&item, 0, sizeof(item));
                continue;
            }
            add_deck(path, item.d_name, has_extension(item.d_name, ".apkg"));
            memset(&item, 0, sizeof(item));
        }
        sceIoDclose(directory);
    }

    if (file_exists(DECK_PATH)) add_deck(DECK_PATH, "cards.tsv", 0);
    qsort(deck_entries, (size_t)deck_count, sizeof(deck_entries[0]), compare_decks);

    current_deck_index = deck_index_for_path(current_deck_path);
    int selected_index = deck_index_for_path(selected_path);
    load_folder_metadata();
    if (deck_folder_filter > folder_count + 1) deck_folder_filter = 0;
    deck_folder_filter_focus = 0;
    memset(deck_due_count_known, 0, sizeof(deck_due_count_known));
    if (current_screen == SCREEN_IMPORT) {
        if (selected_index >= 0) list_selection = selected_index;
        else if (deck_count == 0) list_selection = 0;
        else if (list_selection >= deck_count) list_selection = deck_count - 1;
    } else if (selected_index >= 0) {
        int visible = visible_position_for_deck(selected_index);
        list_selection = visible >= 0 ? visible + 1 : 0;
    } else if (current_deck_index >= 0) {
        int visible = visible_position_for_deck(current_deck_index);
        list_selection = visible >= 0 ? visible + 1 : 0;
    } else if (list_selection > visible_deck_count()) list_selection = 0;
}

static void load_saved_deck_path(void) {
    recover_atomic_file(ACTIVE_DECK_PATH, ACTIVE_DECK_TEMP_PATH, ACTIVE_DECK_BACKUP_PATH);
    FILE *file = fopen(ACTIVE_DECK_PATH, "r");
    if (!file) return;
    if (fgets(saved_deck_path, sizeof(saved_deck_path), file)) {
        char *end = strpbrk(saved_deck_path, "\r\n");
        if (end) *end = '\0';
    }
    fclose(file);
}

static int save_active_deck(void) {
    if (!current_deck_path[0]) return 0;
    recover_atomic_file(ACTIVE_DECK_PATH, ACTIVE_DECK_TEMP_PATH, ACTIVE_DECK_BACKUP_PATH);
    remove(ACTIVE_DECK_TEMP_PATH);
    FILE *file = fopen(ACTIVE_DECK_TEMP_PATH, "w");
    if (!file) return 0;
    int ok = fprintf(file, "%s\n", current_deck_path) >= 0;
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(ACTIVE_DECK_TEMP_PATH, ACTIVE_DECK_PATH,
                                    ACTIVE_DECK_BACKUP_PATH)) {
        remove(ACTIVE_DECK_TEMP_PATH);
        return 0;
    }
    return 1;
}

static unsigned int deck_path_hash(const char *deck_path) {
    unsigned int hash = 2166136261u;
    for (const unsigned char *p = (const unsigned char *)deck_path; *p; p++) {
        hash ^= *p;
        hash *= 16777619u;
    }
    return hash;
}

static void added_cards_path_for_deck(const char *deck_path, char *output, size_t capacity) {
    snprintf(output, capacity, "ux0:data/VitaAnki/additions_%08x.tsv",
             deck_path_hash(deck_path));
}

static void progress_path_for_deck(const char *deck_path, char *output, size_t capacity) {
    if (!strcmp(deck_path, APKG_PATH) || !strcmp(deck_path, DECK_PATH)) {
        snprintf(output, capacity, "%s", PROGRESS_PATH);
        return;
    }
    snprintf(output, capacity, "ux0:data/VitaAnki/progress_%08x.tsv",
             deck_path_hash(deck_path));
}

static void set_progress_path(const char *deck_path) {
    progress_path_for_deck(deck_path, current_progress_path, sizeof(current_progress_path));
}

static int added_card_row(char *row, char **front, char **back, char **image) {
    char *end = strpbrk(row, "\r\n");
    if (end) *end = '\0';
    *front = row;
    if (strlen(*front) >= 3 && (unsigned char)(*front)[0] == 0xEF &&
        (unsigned char)(*front)[1] == 0xBB && (unsigned char)(*front)[2] == 0xBF)
        *front += 3;
    char *tab = strchr(row, '\t');
    if (!tab) return 0;
    *tab++ = '\0';
    if (*front != row) *front = row + 3;
    *back = tab;
    char *image_tab = strchr(tab, '\t');
    *image = NULL;
    if (image_tab) {
        *image_tab++ = '\0';
        *image = image_tab;
    }
    return (*front)[0] || (*back)[0];
}

static int append_added_cards_to_loaded_deck(const char *deck_path, int base_count) {
    char additions_path[96];
    added_cards_path_for_deck(deck_path, additions_path, sizeof(additions_path));
    if (!file_exists(additions_path)) return base_count;
    FILE *file = fopen(additions_path, "r");
    if (!file) return -7;
    int count = base_count;
    int added_index = 0;
    char row[FIELD_SIZE * 3 + 16];
    while (count < MAX_CARDS && fgets(row, sizeof(row), file)) {
        if (!strchr(row, '\n') && !feof(file)) {
            int ch;
            while ((ch = fgetc(file)) != '\n' && ch != EOF) {}
            continue;
        }
        char *front, *back, *image;
        if (!added_card_row(row, &front, &back, &image)) continue;
        if (!vitaanki_reserve_cards(&cards, &card_capacity, count + 1)) {
            fclose(file);
            return -8;
        }
        Card *card = &cards[count];
        snprintf(card->front, FIELD_SIZE, "%.*s", FIELD_SIZE - 1, front);
        snprintf(card->back, FIELD_SIZE, "%.*s", FIELD_SIZE - 1, back);
        snprintf(card->front_image, FIELD_SIZE, "%.*s", FIELD_SIZE - 1,
                 image ? image : "");
        normalize_tsv_field(card->front);
        normalize_tsv_field(card->back);
        normalize_tsv_field(card->front_image);
        card->card_id = ADDED_CARD_ID_BASE + added_index++;
        card->interval_days = 0;
        card->due = 0;
        card->state = CARD_STATE_NEW;
        count++;
    }
    int failed = ferror(file);
    if (fclose(file) != 0) failed = 1;
    return failed ? -7 : count;
}

static int count_added_cards(const char *deck_path) {
    char additions_path[96];
    added_cards_path_for_deck(deck_path, additions_path, sizeof(additions_path));
    FILE *file = fopen(additions_path, "r");
    if (!file) return 0;
    int count = 0;
    char row[FIELD_SIZE * 3 + 16];
    while (count < MAX_CARDS && fgets(row, sizeof(row), file)) {
        if (!strchr(row, '\n') && !feof(file)) {
            int ch;
            while ((ch = fgetc(file)) != '\n' && ch != EOF) {}
            continue;
        }
        char *front, *back, *image;
        if (added_card_row(row, &front, &back, &image)) count++;
    }
    fclose(file);
    return count;
}

static int count_due_added_cards(const char *deck_path, const char *progress_path,
                                 long long now) {
    int added_count = count_added_cards(deck_path);
    if (added_count <= 0) return 0;
    FILE *file = fopen(progress_path, "r");
    if (!file) return 0;
    int due_count = 0;
    char row[128];
    while (fgets(row, sizeof(row), file)) {
        long long card_id, due;
        int interval, state = CARD_STATE_NEW;
        int fields = sscanf(row, "%lld\t%d\t%lld\t%d", &card_id, &interval, &due, &state);
        if (fields < 3 || card_id < ADDED_CARD_ID_BASE) continue;
        long long ordinal = card_id - ADDED_CARD_ID_BASE;
        if (ordinal >= added_count) continue;
        if (fields < 4)
            state = interval > 0 ? CARD_STATE_REVIEW
                  : due > 0 ? CARD_STATE_LEARNING : CARD_STATE_NEW;
        if (state != CARD_STATE_NEW && due <= now) due_count++;
    }
    fclose(file);
    return due_count;
}

static DeckStudySettings default_deck_study_settings(void) {
    DeckStudySettings settings = {DEFAULT_NEW_CARD_LIMIT, 1, 5, 1, 4, 0, 0, 0};
    return settings;
}

static int current_local_day_key(void) {
    time_t now = time(NULL);
    struct tm *local = localtime(&now);
    if (!local) return 0;
    return (local->tm_year + 1900) * 10000 + (local->tm_mon + 1) * 100 + local->tm_mday;
}

static int reset_daily_new_card_state(DeckStudySettings *settings) {
    int today = current_local_day_key();
    if (!settings || today <= 0 || settings->new_cards_day_key == today) return 0;
    settings->new_cards_day_key = today;
    settings->new_cards_today = 0;
    settings->new_cards_extra_today = 0;
    return 1;
}

static void deck_settings_path_for(const char *deck_path, char *output, size_t capacity) {
    unsigned int hash = 2166136261u;
    for (const unsigned char *p = (const unsigned char *)deck_path; p && *p; p++) {
        hash ^= *p;
        hash *= 16777619u;
    }
    snprintf(output, capacity, "ux0:data/VitaAnki/deck_settings_%08x.ini", hash);
}

static int int_in_choices(int value, const int *choices, int count) {
    for (int i = 0; i < count; i++) if (value == choices[i]) return 1;
    return 0;
}

static DeckStudySettings load_deck_study_settings(const char *deck_path) {
    DeckStudySettings settings = default_deck_study_settings();
    if (!deck_path || !deck_path[0]) return settings;

    char path[96], temporary[112], backup[112];
    deck_settings_path_for(deck_path, path, sizeof(path));
    snprintf(temporary, sizeof(temporary), "%s.tmp", path);
    snprintf(backup, sizeof(backup), "%s.bak", path);
    recover_atomic_file(path, temporary, backup);
    FILE *file = fopen(path, "r");
    if (!file) return settings;

    char line[96];
    while (fgets(line, sizeof(line), file)) {
        int value;
        if (sscanf(line, "new_limit=%d", &value) == 1) settings.new_card_limit = value;
        else if (sscanf(line, "again_minutes=%d", &value) == 1) settings.again_minutes = value;
        else if (sscanf(line, "hard_minutes=%d", &value) == 1) settings.hard_minutes = value;
        else if (sscanf(line, "good_days=%d", &value) == 1) settings.good_days = value;
        else if (sscanf(line, "easy_days=%d", &value) == 1) settings.easy_days = value;
        else if (sscanf(line, "new_cards_day=%d", &value) == 1) settings.new_cards_day_key = value;
        else if (sscanf(line, "new_cards_today=%d", &value) == 1) settings.new_cards_today = value;
        else if (sscanf(line, "new_cards_extra_today=%d", &value) == 1)
            settings.new_cards_extra_today = value;
    }
    fclose(file);

    static const int new_limits[] = {5, 10, 20, 30, 50};
    static const int minute_steps[] = {1, 5, 10, 15, 30};
    static const int good_intervals[] = {1, 2, 3, 4, 7, 14};
    static const int easy_intervals[] = {3, 4, 7, 14, 30};
    if (!int_in_choices(settings.new_card_limit, new_limits, 5)) settings.new_card_limit = DEFAULT_NEW_CARD_LIMIT;
    if (!int_in_choices(settings.again_minutes, minute_steps, 5)) settings.again_minutes = 1;
    if (!int_in_choices(settings.hard_minutes, minute_steps, 5)) settings.hard_minutes = 5;
    if (!int_in_choices(settings.good_days, good_intervals, 6)) settings.good_days = 1;
    if (!int_in_choices(settings.easy_days, easy_intervals, 5)) settings.easy_days = 4;
    if (settings.new_cards_today < 0 || settings.new_cards_today > MAX_CARDS)
        settings.new_cards_today = 0;
    if (settings.new_cards_extra_today < 0 ||
        settings.new_cards_extra_today > MAX_CARDS - settings.new_card_limit)
        settings.new_cards_extra_today = 0;
    reset_daily_new_card_state(&settings);
    return settings;
}

static int save_deck_study_settings(const char *deck_path, DeckStudySettings settings) {
    if (!deck_path || !deck_path[0]) return 0;
    char path[96], temporary[112], backup[112];
    deck_settings_path_for(deck_path, path, sizeof(path));
    snprintf(temporary, sizeof(temporary), "%s.tmp", path);
    snprintf(backup, sizeof(backup), "%s.bak", path);
    recover_atomic_file(path, temporary, backup);
    remove(temporary);
    FILE *file = fopen(temporary, "w");
    if (!file) return 0;
    int ok = fprintf(file, "new_limit=%d\nagain_minutes=%d\nhard_minutes=%d\ngood_days=%d\neasy_days=%d\nnew_cards_day=%d\nnew_cards_today=%d\nnew_cards_extra_today=%d\n",
                     settings.new_card_limit, settings.again_minutes, settings.hard_minutes,
                     settings.good_days, settings.easy_days, settings.new_cards_day_key,
                     settings.new_cards_today, settings.new_cards_extra_today) >= 0;
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(temporary, path, backup)) {
        remove(temporary);
        return 0;
    }
    return 1;
}

static void open_deck_settings(int index) {
    if (index < 0 || index >= deck_count) return;
    deck_settings_deck_index = index;
    list_focus_actions = 0;
    deck_list_gear_focus = 1;
    snprintf(edit_deck_settings_path, sizeof(edit_deck_settings_path), "%s", deck_entries[index].path);
    edit_deck_settings = load_deck_study_settings(edit_deck_settings_path);
    deck_settings_selection = 0;
    deck_settings_editing = 0;
    current_screen = SCREEN_DECK_SETTINGS;
}

static void change_deck_setting(int setting, int direction) {
    static const int new_limits[] = {5, 10, 20, 30, 50};
    static const int minute_steps[] = {1, 5, 10, 15, 30};
    static const int good_intervals[] = {1, 2, 3, 4, 7, 14};
    static const int easy_intervals[] = {3, 4, 7, 14, 30};
    if (setting == 5) {
        int index = deck_settings_deck_index;
        if (index < 0 || index >= deck_count) return;
        char old_folder[FOLDER_NAME_SIZE];
        snprintf(old_folder, sizeof(old_folder), "%s", deck_entries[index].folder);
        int current = folder_index_by_name(old_folder) + 1;
        int choices = folder_count + 1;
        int next = (current + (direction >= 0 ? 1 : choices - 1)) % choices;
        deck_entries[index].folder[0] = '\0';
        if (next > 0)
            snprintf(deck_entries[index].folder, sizeof(deck_entries[index].folder),
                     "%s", folder_names[next - 1]);
        if (!save_folder_metadata()) {
            snprintf(deck_entries[index].folder, sizeof(deck_entries[index].folder), "%s", old_folder);
            snprintf(deck_status, sizeof(deck_status), "Folder assignment could not be saved.");
        } else {
            deck_status[0] = '\0';
            recalculate_all_deck_due_total();
        }
        return;
    }
    int *value = NULL;
    const int *choices = NULL;
    int count = 0;
    if (setting == 0) { value = &edit_deck_settings.new_card_limit; choices = new_limits; count = 5; }
    else if (setting == 1) { value = &edit_deck_settings.again_minutes; choices = minute_steps; count = 5; }
    else if (setting == 2) { value = &edit_deck_settings.hard_minutes; choices = minute_steps; count = 5; }
    else if (setting == 3) { value = &edit_deck_settings.good_days; choices = good_intervals; count = 6; }
    else if (setting == 4) { value = &edit_deck_settings.easy_days; choices = easy_intervals; count = 5; }
    if (!value || !choices || count <= 0) return;
    int index = 0;
    while (index < count && choices[index] != *value) index++;
    if (index >= count) index = 0;
    index = (index + (direction >= 0 ? 1 : count - 1)) % count;
    *value = choices[index];
    if (!save_deck_study_settings(edit_deck_settings_path, edit_deck_settings))
        snprintf(deck_status, sizeof(deck_status), "Could not save deck settings. Check free storage.");
    else deck_status[0] = '\0';
    if (current_deck_path[0] && !strcmp(current_deck_path, edit_deck_settings_path))
        current_deck_settings = edit_deck_settings;
}

static int load_tsv(const char *path) {
    FILE *file = fopen(path, "r");
    if (!file) return -7;

    int count = 0;
    char row[FIELD_SIZE * 2 + 4];
    while (count < MAX_CARDS && fgets(row, sizeof(row), file)) {
        if (!strchr(row, '\n') && !feof(file)) {
            int ch;
            while ((ch = fgetc(file)) != '\n' && ch != EOF) {}
            continue;
        }
        char *end = strpbrk(row, "\r\n");
        if (end) *end = '\0';
        char *front = row;
        if (strlen(front) >= 3 && (unsigned char)front[0] == 0xEF &&
            (unsigned char)front[1] == 0xBB && (unsigned char)front[2] == 0xBF) front += 3;
        char *tab = strchr(row, '\t');
        if (!tab) continue;
        *tab++ = '\0';
        if (front != row) front = row + 3;
        char *extra_field = strchr(tab, '\t');
        if (extra_field) *extra_field = '\0';
        if (!front[0] && !tab[0]) continue;
        if (!vitaanki_reserve_cards(&cards, &card_capacity, count + 1)) {
            fclose(file);
            return -8;
        }
        snprintf(cards[count].front, FIELD_SIZE, "%.*s", FIELD_SIZE - 1, front);
        snprintf(cards[count].back, FIELD_SIZE, "%.*s", FIELD_SIZE - 1, tab);
        normalize_tsv_field(cards[count].front);
        normalize_tsv_field(cards[count].back);
        cards[count].front_image[0] = '\0';
        cards[count].card_id = count + 1;
        cards[count].interval_days = 0;
        cards[count].due = 0;
        cards[count].state = CARD_STATE_NEW;
        count++;
    }
    fclose(file);
    return count;
}

static void load_progress(void) {
    char temporary[128];
    char backup[128];
    snprintf(temporary, sizeof(temporary), "%s.tmp", current_progress_path);
    snprintf(backup, sizeof(backup), "%s.bak", current_progress_path);
    recover_atomic_file(current_progress_path, temporary, backup);
    FILE *file = fopen(current_progress_path, "r");
    if (!file) return;
    char row[128];
    while (fgets(row, sizeof(row), file)) {
        if (!strchr(row, '\n') && !feof(file)) {
            int ch;
            while ((ch = fgetc(file)) != '\n' && ch != EOF) {}
            continue;
        }
        long long card_id;
        long long due;
        int interval;
        int stored_state = -1;
        int fields = sscanf(row, "%lld\t%d\t%lld\t%d",
                            &card_id, &interval, &due, &stored_state);
        if (fields < 3 || card_id <= 0) continue;
        for (int i = 0; i < card_count; i++) {
            if (cards[i].card_id == card_id) {
                cards[i].interval_days = interval;
                cards[i].due = due;
                if (fields >= 4 && stored_state >= CARD_STATE_NEW &&
                    stored_state <= CARD_STATE_REVIEW)
                    cards[i].state = (CardState)stored_state;
                else if (interval > 0)
                    cards[i].state = CARD_STATE_REVIEW;
                else if (due > 0)
                    cards[i].state = CARD_STATE_LEARNING;
                else
                    cards[i].state = CARD_STATE_NEW;
                break;
            }
        }
    }
    fclose(file);
}

static void save_progress(void) {
    char temporary[128];
    char backup[128];
    snprintf(temporary, sizeof(temporary), "%s.tmp", current_progress_path);
    snprintf(backup, sizeof(backup), "%s.bak", current_progress_path);
    recover_atomic_file(current_progress_path, temporary, backup);
    remove(temporary);
    FILE *file = fopen(temporary, "w");
    if (!file) return;
    int ok = 1;
    for (int i = 0; i < card_count; i++)
        if (fprintf(file, "%lld\t%d\t%lld\t%d\n", cards[i].card_id,
                    cards[i].interval_days, cards[i].due, (int)cards[i].state) < 0) {
            ok = 0;
            break;
        }
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(temporary, current_progress_path, backup))
        remove(temporary);
}

static int find_next_due(void) {
    if (card_count <= 0) return -1;
    if (reset_daily_new_card_state(&current_deck_settings) && current_deck_path[0])
        save_deck_study_settings(current_deck_path, current_deck_settings);
    long long now = (long long)time(NULL);
    int start = card_index >= 0 && card_index < card_count ? card_index : 0;
    const CardState priority[] = {
        CARD_STATE_LEARNING,
        CARD_STATE_REVIEW,
        CARD_STATE_NEW
    };
    for (int pass = 0; pass < (int)(sizeof(priority) / sizeof(priority[0])); pass++) {
        for (int step = 0; step < card_count; step++) {
            int i = (start + step) % card_count;
            if (cards[i].state != priority[pass]) continue;
            if (all_decks_mode && cards[i].state == CARD_STATE_NEW) continue;
            if (cards[i].state == CARD_STATE_NEW) {
                if (current_deck_settings.new_cards_today <
                    current_deck_settings.new_card_limit + current_deck_settings.new_cards_extra_today)
                    return i;
            } else if (cards[i].due <= now) {
                return i;
            }
        }
    }
    return -1;
}

static int has_study_card(void) {
    return card_count > 0 && card_index >= 0 && card_index < card_count;
}

static int daily_new_card_limit_reached(void) {
    return current_deck_settings.new_cards_today >=
           current_deck_settings.new_card_limit + current_deck_settings.new_cards_extra_today;
}

static int unseen_new_card_count(void) {
    int count = 0;
    if (live_sync) return 0;
    for (int i = 0; i < card_count; i++)
        if (cards[i].state == CARD_STATE_NEW) count++;
    return count;
}

static int study_more_increment(void) {
    int remaining_room = MAX_CARDS - current_deck_settings.new_card_limit -
                         current_deck_settings.new_cards_extra_today;
    int increment = STUDY_MORE_BATCH_SIZE;
    if (increment > remaining_room) increment = remaining_room;
    return increment > 0 ? increment : 0;
}

static void activate_study_more(void) {
    if (!study_more_available()) return;
    int increment = study_more_increment();
    if (increment <= 0) return;
    current_deck_settings.new_cards_extra_today += increment;
    if (!save_deck_study_settings(current_deck_path, current_deck_settings))
        snprintf(deck_status, sizeof(deck_status), "More cards unlocked, but the daily choice could not be saved.");
    else
        deck_status[0] = '\0';
    card_index = find_next_due();
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_position = 0.0f;
}

static AnkiStudyCounts current_study_counts(int *valid) {
    AnkiStudyCounts counts = {0, 0, 0};
    if (live_sync) {
        *valid = anki_connect_get_study_counts(&counts);
        return counts;
    }

    time_t now = time(NULL);
    if (!offline_counts_cache_valid || now < 0 || now >= offline_counts_refresh_at) {
        long long epoch = (long long)now;
        for (int i = 0; i < card_count; i++) {
            if (cards[i].state == CARD_STATE_NEW) counts.new_count++;
            else if (cards[i].state == CARD_STATE_LEARNING) counts.learning_count++;
            else if (cards[i].state == CARD_STATE_REVIEW && cards[i].due <= epoch)
                counts.review_count++;
        }
        offline_counts_cache = counts;
        offline_counts_refresh_at = now >= 0 ? now + 1 : now;
        offline_counts_cache_valid = 1;
    }
    *valid = 1;
    return offline_counts_cache;
}

static int study_more_available(void) {
    if (live_sync || all_decks_mode || !daily_new_card_limit_reached() ||
        unseen_new_card_count() <= 0) return 0;
    int counts_valid = 0;
    AnkiStudyCounts counts = current_study_counts(&counts_valid);
    return counts_valid && counts.learning_count == 0;
}

static uint32_t confetti_random(void) {
    confetti_rng ^= confetti_rng << 13;
    confetti_rng ^= confetti_rng >> 17;
    confetti_rng ^= confetti_rng << 5;
    return confetti_rng;
}

static void clear_confetti(void) {
    for (int i = 0; i < CONFETTI_CAPACITY; i++) confetti[i].active = 0;
    confetti_next_slot = 0;
}

static void start_confetti(void) {
    if (confetti_mode == 0) return;
    const unsigned int colors[] = {ACCENT, GREEN, YELLOW, RED, ACCENT};
    int added = 0;
    for (int scanned = 0; scanned < CONFETTI_CAPACITY && added < CONFETTI_PER_SUCCESS; scanned++) {
        int slot = (confetti_next_slot + scanned) % CONFETTI_CAPACITY;
        if (confetti[slot].active) continue;
        uint32_t r = confetti_random();
        confetti[slot].x = (float)(r % SCREEN_W);
        confetti[slot].y = -(float)(confetti_random() % 90);
        confetti[slot].vx = (float)((int)(confetti_random() % 7) - 3) * 0.45f;
        confetti[slot].vy = 3.5f + (float)(confetti_random() % 5) * 0.8f;
        confetti[slot].width = 4 + (int)(confetti_random() % 5);
        confetti[slot].height = 7 + (int)(confetti_random() % 6);
        confetti[slot].color = colors[confetti_random() % (sizeof(colors) / sizeof(colors[0]))];
        confetti[slot].active = 1;
        confetti_next_slot = (slot + 1) % CONFETTI_CAPACITY;
        added++;
    }
}

static void update_confetti(void) {
    if (confetti_mode == 0) return;
    for (int i = 0; i < CONFETTI_CAPACITY; i++) {
        if (!confetti[i].active) continue;
        confetti[i].x += confetti[i].vx;
        confetti[i].y += confetti[i].vy;
        confetti[i].vy += 0.035f;
        if (confetti[i].x < -10) confetti[i].x = SCREEN_W + 8;
        else if (confetti[i].x > SCREEN_W + 10) confetti[i].x = -8;
        if (confetti[i].y > SCREEN_H + 12) confetti[i].active = 0;
    }
}

static void draw_confetti(void) {
    if (confetti_mode == 0) return;
    for (int i = 0; i < CONFETTI_CAPACITY; i++) {
        if (confetti[i].active && confetti[i].y > -15 && confetti[i].y < SCREEN_H)
            vita2d_draw_rectangle(confetti[i].x, confetti[i].y,
                                  confetti[i].width, confetti[i].height,
                                  confetti[i].color);
    }
}

static int select_deck(int index) {
    if (index < 0 || index >= deck_count) return 0;
    if (!all_decks_loading) {
        all_decks_mode = 0;
        all_decks_cursor = -1;
    }
    AppScreen previous_screen = current_screen;
    offline_counts_cache_valid = 0;
    anki_connect_note_offline_deck();
    live_sync = 0;
    apkg_mode = 0;
    sync_queue_error = 0;
    demo_mode = 0;
    import_error = 0;
    import_error_code = 0;
    reviewed = 0;
    new_cards_this_session = 0;
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_position = 0.0f;
    selected_rating = 2;
    undo_record.valid = 0;
    undo_error = 0;
    card_count = 0;

    DeckEntry *entry = &deck_entries[index];
    int music_was_running = entry->is_apkg && anki_music_is_running();
    int resume_music = music_was_running && !anki_music_is_muted();
    if (music_was_running) anki_music_stop();
    int loaded;
    if (entry->is_apkg) {
        int reload_custom_font = font_pgf != NULL;
        if (card_image_texture) {
            vita2d_free_texture(card_image_texture);
            card_image_texture = NULL;
            card_image_path_cached[0] = '\0';
        }
        if (reload_custom_font) release_custom_fonts();
        free(cards);
        cards = NULL;
        card_capacity = 0;
        loaded = import_apkg(entry->path, &cards, &card_capacity, MAX_CARDS);
        if (reload_custom_font && !font_mode_available(font_mode)) {
            font_mode = 0;
            save_settings();
        }
    } else {
        loaded = load_tsv(entry->path);
    }
    if (loaded >= 0) loaded = append_added_cards_to_loaded_deck(entry->path, loaded);
    if (resume_music) anki_music_start();
    if (loaded < 0) {
        import_error = 1;
        import_error_code = loaded;
        current_screen = (previous_screen == SCREEN_DECKS || previous_screen == SCREEN_SYNC)
                       ? previous_screen : SCREEN_IMPORT;
        return 0;
    }

    card_count = loaded;
    apkg_mode = entry->is_apkg;
    current_deck_index = index;
    snprintf(current_deck_name, sizeof(current_deck_name), "%s", entry->name);
    snprintf(current_deck_path, sizeof(current_deck_path), "%s", entry->path);
    set_progress_path(entry->path);
    current_deck_settings = load_deck_study_settings(entry->path);
    load_progress();
    deck_due_count[index] = count_due_cards_in_loaded_deck();
    deck_due_count_known[index] = 1;
    recalculate_all_deck_due_total();
    card_index = card_count > 0 ? find_next_due() : 0;
    save_active_deck();
    if (previous_screen == SCREEN_DECKS) {
        snprintf(deck_status, sizeof(deck_status), "Selected: %s", current_deck_name);
        current_screen = SCREEN_DECKS;
    } else if (previous_screen == SCREEN_SYNC) {
        snprintf(sync_message, sizeof(sync_message), "Offline deck selected: %s", current_deck_name);
        current_screen = SCREEN_SYNC;
    } else {
        current_screen = SCREEN_STUDY;
    }
    return 1;
}

static int count_due_cards_for_deck(int index) {
    if (index < 0 || index >= deck_count) return -1;
    if (deck_entries[index].is_apkg) {
        char progress_path[96];
        char progress_temp[112];
        char progress_backup[112];
        progress_path_for_deck(deck_entries[index].path, progress_path,
                               sizeof(progress_path));
        snprintf(progress_temp, sizeof(progress_temp), "%s.tmp", progress_path);
        snprintf(progress_backup, sizeof(progress_backup), "%s.bak", progress_path);
        recover_atomic_file(progress_path, progress_temp, progress_backup);
        int due = count_due_apkg_cards(deck_entries[index].path, progress_path,
                                       (long long)time(NULL));
        if (due < 0) return due;
        return due + count_due_added_cards(deck_entries[index].path, progress_path,
                                           (long long)time(NULL));
    }
    Card *saved_cards = cards;
    int saved_capacity = card_capacity;
    int saved_count = card_count;
    char saved_progress_path[sizeof(current_progress_path)];
    snprintf(saved_progress_path, sizeof(saved_progress_path), "%s", current_progress_path);

    cards = NULL;
    card_capacity = 0;
    card_count = 0;
    DeckEntry *entry = &deck_entries[index];
    int loaded = load_tsv(entry->path);
    int due = -1;
    if (loaded >= 0) {
        loaded = append_added_cards_to_loaded_deck(entry->path, loaded);
    }
    if (loaded >= 0) {
        card_count = loaded;
        set_progress_path(entry->path);
        load_progress();
        long long now = (long long)time(NULL);
        due = 0;
        for (int i = 0; i < card_count; i++)
            if (cards[i].state != CARD_STATE_NEW && cards[i].due <= now) due++;
    }

    free(cards);
    cards = saved_cards;
    card_capacity = saved_capacity;
    card_count = saved_count;
    snprintf(current_progress_path, sizeof(current_progress_path), "%s", saved_progress_path);
    return due;
}

static int count_due_cards_in_loaded_deck(void) {
    long long now = (long long)time(NULL);
    int due = 0;
    for (int i = 0; i < card_count; i++)
        if (cards[i].state != CARD_STATE_NEW && cards[i].due <= now) due++;
    return due;
}

static void recalculate_all_deck_due_total(void) {
    int total = 0;
    for (int i = 0; i < deck_count; i++) {
        if (deck_due_count_known[i] && deck_due_count[i] >= 0 &&
            deck_matches_folder_filter(i))
            total += deck_due_count[i];
    }
    all_decks_due_total = total;
}

static void cycle_deck_folder_filter(int direction) {
    int choices = folder_count + 2;
    if (choices < 2) choices = 2;
    int next = (deck_folder_filter + (direction >= 0 ? 1 : choices - 1)) % choices;
    int selected_index = list_selection > 0
                       ? deck_index_at_visible_position(list_selection - 1) : -1;
    deck_folder_filter = next;
    if (selected_index >= 0) {
        int visible = visible_position_for_deck(selected_index);
        if (visible >= 0) list_selection = visible + 1;
        else list_selection = 0;
    }
    list_focus_actions = 0;
    deck_list_gear_focus = 0;
    recalculate_all_deck_due_total();
}

static void update_deck_due_count_cache(void) {
    if (current_screen != SCREEN_DECKS) return;
    for (int i = 0; i < deck_count; i++) {
        if (!deck_matches_folder_filter(i) || deck_due_count_known[i]) continue;
        int due = count_due_cards_for_deck(i);
        deck_due_count[i] = due;
        deck_due_count_known[i] = 1;
        recalculate_all_deck_due_total();
        return;
    }
}

static int advance_all_due_decks(int start_index) {
    if (deck_count <= 0) return 0;
    AppScreen return_screen = current_screen;
    int previous_reviewed = reviewed;
    int previous_new_cards = new_cards_this_session;
    for (int step = 0; step < deck_count; step++) {
        int index = (start_index + step) % deck_count;
        if (index == all_decks_cursor) continue;
        if (!deck_matches_folder_filter(index)) continue;
        if (!deck_due_count_known[index]) {
            int due = count_due_cards_for_deck(index);
            if (due < 0) continue;
            deck_due_count[index] = due;
            deck_due_count_known[index] = 1;
        }
        if (deck_due_count[index] <= 0) continue;

        all_decks_loading = 1;
        all_decks_mode = 1;
        int loaded = select_deck(index);
        all_decks_loading = 0;
        all_decks_mode = 1;
        if (!loaded) continue;
        reviewed = previous_reviewed;
        new_cards_this_session = previous_new_cards;
        current_screen = return_screen;
        card_index = find_next_due();
        if (card_index < 0) {
            deck_due_count[index] = count_due_cards_in_loaded_deck();
            continue;
        }
        all_decks_cursor = index;
        show_answer = 0;
        flip_frames_remaining = 0;
        card_scroll_position = 0.0f;
        recalculate_all_deck_due_total();
        return 1;
    }
    current_screen = return_screen;
    card_index = -1;
    recalculate_all_deck_due_total();
    return 0;
}

static int select_all_due_decks(void) {
    if (deck_count <= 0) return 0;
    all_decks_mode = 0;
    all_decks_cursor = -1;
    for (int i = 0; i < deck_count; i++) {
        if (!deck_matches_folder_filter(i)) continue;
        if (deck_due_count_known[i]) {
            if (deck_due_count[i] < 0) {
                snprintf(deck_status, sizeof(deck_status), "Could not count due cards in %s.",
                         deck_entries[i].name);
                return 0;
            }
            continue;
        }
        int due = count_due_cards_for_deck(i);
        if (due < 0) {
            snprintf(deck_status, sizeof(deck_status), "Could not count due cards in %s.",
                     deck_entries[i].name);
            return 0;
        }
        deck_due_count[i] = due;
        deck_due_count_known[i] = 1;
    }
    recalculate_all_deck_due_total();
    if (all_decks_due_total <= 0) {
        all_decks_mode = 0;
        snprintf(deck_status, sizeof(deck_status), "No review or learning cards are due across your decks.");
        return 0;
    }
    all_decks_mode = 1;
    all_decks_cursor = -1;
    reviewed = 0;
    new_cards_this_session = 0;
    undo_record.valid = 0;
    return advance_all_due_decks(0);
}

static int has_next_all_due_deck(void) {
    for (int i = 0; i < deck_count; i++) {
        if (i == all_decks_cursor || !deck_matches_folder_filter(i)) continue;
        if (deck_due_count_known[i] && deck_due_count[i] > 0) return 1;
    }
    return 0;
}

static void load_demo_deck(void) {
    offline_counts_cache_valid = 0;
    demo_mode = 1;
    apkg_mode = 0;
    sync_queue_error = 0;
    import_error = 0;
    import_error_code = 0;
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_position = 0.0f;
    selected_rating = 2;
    undo_record.valid = 0;
    undo_error = 0;
    current_deck_index = -1;
    current_deck_path[0] = '\0';
    current_progress_path[0] = '\0';
    current_deck_settings = default_deck_study_settings();
    snprintf(current_deck_name, sizeof(current_deck_name), "Demo deck");
    int demo_count = (int)(sizeof(demo_cards) / sizeof(demo_cards[0]));
    if (!vitaanki_reserve_cards(&cards, &card_capacity, demo_count)) {
        card_count = 0;
        card_index = 0;
        return;
    }
    card_count = demo_count;
    for (int i = 0; i < card_count; i++) cards[i] = demo_cards[i];
    card_index = 0;
}

static int find_saved_deck(void) {
    for (int i = 0; i < deck_count; i++)
        if (saved_deck_path[0] && !strcmp(deck_entries[i].path, saved_deck_path)) return i;
    for (int i = 0; i < deck_count; i++)
        if (!strcmp(deck_entries[i].path, INCLUDED_DECK_PATH)) return i;
    return deck_count > 0 ? 0 : -1;
}

static size_t utf8_to_utf16(const char *input, uint16_t *output, size_t capacity) {
    size_t written = 0;
    const unsigned char *p = (const unsigned char *)input;
    if (!input || !output || capacity == 0) return 0;
    while (*p && written + 1 < capacity) {
        uint32_t codepoint;
        size_t count;
        if (*p < 0x80) { codepoint = *p; count = 1; }
        else if ((*p & 0xE0) == 0xC0 && p[1] && (p[1] & 0xC0) == 0x80) {
            codepoint = ((uint32_t)(p[0] & 0x1F) << 6) | (p[1] & 0x3F);
            count = 2;
        } else if ((*p & 0xF0) == 0xE0 && p[1] && p[2] &&
                   (p[1] & 0xC0) == 0x80 && (p[2] & 0xC0) == 0x80) {
            codepoint = ((uint32_t)(p[0] & 0x0F) << 12) |
                        ((uint32_t)(p[1] & 0x3F) << 6) | (p[2] & 0x3F);
            count = 3;
        } else if ((*p & 0xF8) == 0xF0 && p[1] && p[2] && p[3] &&
                   (p[1] & 0xC0) == 0x80 && (p[2] & 0xC0) == 0x80 &&
                   (p[3] & 0xC0) == 0x80) {
            codepoint = ((uint32_t)(p[0] & 0x07) << 18) |
                        ((uint32_t)(p[1] & 0x3F) << 12) |
                        ((uint32_t)(p[2] & 0x3F) << 6) | (p[3] & 0x3F);
            count = 4;
        } else { codepoint = '?'; count = 1; }
        if (codepoint <= 0xFFFF) {
            output[written++] = (uint16_t)codepoint;
        } else {
            if (written + 2 >= capacity) break;
            codepoint -= 0x10000;
            output[written++] = (uint16_t)(0xD800 | (codepoint >> 10));
            output[written++] = (uint16_t)(0xDC00 | (codepoint & 0x3FF));
        }
        p += count;
    }
    output[written] = 0;
    return written;
}

static int utf16_to_utf8(const uint16_t *input, char *output, size_t capacity) {
    size_t used = 0;
    if (!input || !output || capacity == 0) return 0;
    for (size_t i = 0; input[i]; i++) {
        uint32_t codepoint = input[i];
        if (codepoint >= 0xD800 && codepoint <= 0xDBFF &&
            input[i + 1] >= 0xDC00 && input[i + 1] <= 0xDFFF) {
            codepoint = 0x10000 + ((codepoint - 0xD800) << 10) +
                        (input[++i] - 0xDC00);
        }
        unsigned char bytes[4];
        size_t count;
        if (codepoint < 0x80) { bytes[0] = (unsigned char)codepoint; count = 1; }
        else if (codepoint < 0x800) {
            bytes[0] = 0xC0 | (codepoint >> 6);
            bytes[1] = 0x80 | (codepoint & 0x3F); count = 2;
        } else if (codepoint < 0x10000) {
            bytes[0] = 0xE0 | (codepoint >> 12);
            bytes[1] = 0x80 | ((codepoint >> 6) & 0x3F);
            bytes[2] = 0x80 | (codepoint & 0x3F); count = 3;
        } else {
            bytes[0] = 0xF0 | (codepoint >> 18);
            bytes[1] = 0x80 | ((codepoint >> 12) & 0x3F);
            bytes[2] = 0x80 | ((codepoint >> 6) & 0x3F);
            bytes[3] = 0x80 | (codepoint & 0x3F); count = 4;
        }
        if (used + count >= capacity) return 0;
        memcpy(output + used, bytes, count);
        used += count;
    }
    output[used] = '\0';
    return 1;
}

static void normalize_tsv_field(char *text) {
    if (!text) return;
    for (char *p = text; *p; p++)
        if (*p == '\t' || *p == '\r' || *p == '\n') *p = ' ';
    size_t length = strlen(text);
    while (length > 0 && (text[length - 1] == ' ' || text[length - 1] == '\t'))
        text[--length] = '\0';
    char *start = text;
    while (*start == ' ' || *start == '\t') start++;
    if (start != text) memmove(text, start, strlen(start) + 1);

    size_t i = 0;
    while (text[i]) {
        size_t length = strlen(text + i);
        size_t apostrophe_bytes = 0;
        if (length >= 3 && (unsigned char)text[i] == 0xE2 &&
            (unsigned char)text[i + 1] == 0x80 &&
            ((unsigned char)text[i + 2] == 0x98 ||
             (unsigned char)text[i + 2] == 0x99 ||
             (unsigned char)text[i + 2] == 0x9B)) apostrophe_bytes = 3;
        else if (length >= 3 && (unsigned char)text[i] == 0xEF &&
                 (unsigned char)text[i + 1] == 0xBC &&
                 (unsigned char)text[i + 2] == 0x87) apostrophe_bytes = 3;
        else if (length >= 2 && (unsigned char)text[i] == 0xCA &&
                 (unsigned char)text[i + 1] == 0xBC) apostrophe_bytes = 2;
        if (apostrophe_bytes) {
            text[i] = '\'';
            memmove(text + i + 1, text + i + apostrophe_bytes,
                    strlen(text + i + apostrophe_bytes) + 1);
            i++;
        } else i++;
    }
}

static int ensure_text_input(void) {
    if (!apputil_initialized) {
        if (sceAppUtilInit(&(SceAppUtilInitParam){}, &(SceAppUtilBootParam){}) < 0)
            return 0;
        apputil_initialized = 1;
        sceCommonDialogSetConfigParam(&(SceCommonDialogConfigParam){});
    }
    if (!ime_module_loaded) {
        if (sceSysmoduleLoadModule(SCE_SYSMODULE_IME) < 0) return 0;
        ime_module_loaded = 1;
    }
    return 1;
}

static void apply_folder_ime_name(const char *name) {
    if (!name || !name[0]) {
        snprintf(create_status, sizeof(create_status), "Folder names cannot be empty.");
        create_error = 1;
        return;
    }
    int existing = folder_index_by_name(name);
    int previous_count = folder_count;
    char previous_names[MAX_FOLDERS][FOLDER_NAME_SIZE];
    char previous_assignments[MAX_DECKS][FOLDER_NAME_SIZE];
    memcpy(previous_names, folder_names, sizeof(previous_names));
    for (int i = 0; i < deck_count; i++)
        snprintf(previous_assignments[i], sizeof(previous_assignments[i]), "%s",
                 deck_entries[i].folder);
    int selected_folder = -1;
    if (folder_ime_action == 1) {
        if (existing >= 0) {
            snprintf(create_status, sizeof(create_status), "That folder already exists.");
            create_error = 1;
            return;
        }
        int created = ensure_folder_name(name);
        if (created < 0) {
            snprintf(create_status, sizeof(create_status), "Folder limit reached (%d).", MAX_FOLDERS);
            create_error = 1;
            return;
        }
        selected_folder = created;
    } else if (folder_ime_action == 2) {
        int index = folder_selection - 2;
        if (index < 0 || index >= folder_count) return;
        if (existing >= 0 && existing != index) {
            snprintf(create_status, sizeof(create_status), "That folder already exists.");
            create_error = 1;
            return;
        }
        char old_name[FOLDER_NAME_SIZE];
        snprintf(old_name, sizeof(old_name), "%s", folder_names[index]);
        snprintf(folder_names[index], sizeof(folder_names[index]), "%s", name);
        for (int i = 0; i < deck_count; i++)
            if (!strcmp(deck_entries[i].folder, old_name))
                snprintf(deck_entries[i].folder, sizeof(deck_entries[i].folder), "%s", name);
        selected_folder = index;
    }
    if (!save_folder_metadata()) {
        folder_count = previous_count;
        memcpy(folder_names, previous_names, sizeof(folder_names));
        for (int i = 0; i < deck_count; i++)
            snprintf(deck_entries[i].folder, sizeof(deck_entries[i].folder), "%s",
                     previous_assignments[i]);
        snprintf(create_status, sizeof(create_status),
                 "Folder could not be saved. Check Vita storage and try again.");
        create_error = 1;
        return;
    }
    folder_selection = selected_folder + 2;
    folder_actions_focus = 0;
    header_focus_active = 0;
    snprintf(create_status, sizeof(create_status), "%s",
             folder_ime_action == 1 ? "Folder created." : "Folder renamed.");
    create_error = 0;
}

static void begin_create_ime(int field) {
    if (field < 0 || field > 4 || !ensure_text_input()) {
        char *status = field == 4 ? deck_status : create_status;
        size_t status_size = field == 4 ? sizeof(deck_status) : sizeof(create_status);
        snprintf(status, status_size, "Text entry is unavailable. Restart VitaAnki and try again.");
        create_error = 1;
        return;
    }
    const char *initial = field == 0 ? create_deck_name
                        : field == 1 ? create_question
                        : field == 2 ? create_answer
                        : field == 3 ? folder_ime_name
                        : deck_settings_deck_index >= 0 && deck_settings_deck_index < deck_count
                            ? deck_entries[deck_settings_deck_index].name : "";
    utf8_to_utf16(initial, create_ime_initial,
                  sizeof(create_ime_initial) / sizeof(create_ime_initial[0]));
    memset(create_ime_buffer, 0, sizeof(create_ime_buffer));
    SceImeDialogParam param;
    sceImeDialogParamInit(&param);
    param.supportedLanguages = SCE_IME_LANGUAGE_ENGLISH;
    param.languagesForced = SCE_TRUE;
    param.type = SCE_IME_TYPE_DEFAULT;
    /* All VitaAnki text fields are stored as one TSV field, so a line break
       key is not useful here. Keep the IME confirm key available for submit. */
    param.option = SCE_IME_OPTION_NO_ASSISTANCE;
    param.dialogMode = SCE_IME_DIALOG_DIALOG_MODE_WITH_CANCEL;
    param.textBoxMode = SCE_IME_DIALOG_TEXTBOX_MODE_DEFAULT;
    param.enterLabel = SCE_IME_ENTER_LABEL_DEFAULT;
    param.title = (field == 0 || field == 4) ? u"Deck name"
                 : field == 1 ? u"Question"
                 : field == 2 ? u"Answer"
                 : field == 3 ? u"Folder name" : u"Deck name";
    param.maxTextLength = (field == 0 || field == 3 || field == 4) ? 60 : 480;
    param.initialText = create_ime_initial;
    param.inputTextBuffer = create_ime_buffer;
    int result = sceImeDialogInit(&param);
    if (result < 0) {
        char *status = field == 4 ? deck_status : create_status;
        size_t status_size = field == 4 ? sizeof(deck_status) : sizeof(create_status);
        snprintf(status, status_size, "Vita text keyboard could not open (0x%08X).", (unsigned int)result);
        create_error = 1;
        return;
    }
    create_ime_field = field;
    create_ime_open = 1;
    create_error = 0;
}

static void update_create_ime(void) {
    if (!create_ime_open || sceImeDialogGetStatus() != SCE_COMMON_DIALOG_STATUS_FINISHED)
        return;
    SceImeDialogResult result;
    memset(&result, 0, sizeof(result));
    int field = create_ime_field;
    int get_result_status = sceImeDialogGetResult(&result);
    sceImeDialogTerm();
    create_ime_open = 0;
    if (get_result_status < 0) {
        char *status = field == 4 ? deck_status : create_status;
        size_t status_size = field == 4 ? sizeof(deck_status) : sizeof(create_status);
        snprintf(status, status_size,
                 "Could not read the keyboard result. Your previous text is unchanged.");
        create_error = 1;
    } else if (result.button == SCE_IME_DIALOG_BUTTON_ENTER ||
               (field >= 0 && field <= 2 && create_ime_buffer[0])) {
        char converted[FIELD_SIZE];
        if (!utf16_to_utf8(create_ime_buffer, converted, sizeof(converted))) {
            char *status = field == 4 ? deck_status : create_status;
            size_t status_size = field == 4 ? sizeof(deck_status) : sizeof(create_status);
            snprintf(status, status_size, "Text is too long. Shorten it and try again.");
            create_error = 1;
        } else {
            normalize_tsv_field(converted);
        if (field == 0) {
            snprintf(create_deck_name, sizeof(create_deck_name), "%.*s", (int)sizeof(create_deck_name) - 1, converted);
        } else if (field == 1) {
            snprintf(create_question, sizeof(create_question), "%s", converted);
        } else if (field == 2) {
            snprintf(create_answer, sizeof(create_answer), "%s", converted);
        } else if (field == 3) {
            snprintf(folder_ime_name, sizeof(folder_ime_name), "%s", converted);
            apply_folder_ime_name(folder_ime_name);
        } else if (field == 4) {
            apply_deck_rename(converted);
        }
        if (field != 3 && field != 4 && result.button == SCE_IME_DIALOG_BUTTON_ENTER) {
            snprintf(create_status, sizeof(create_status), "Text saved.");
            create_error = 0;
        } else if (field != 3 && field != 4) {
            snprintf(create_status, sizeof(create_status), "Text kept. You can continue editing it.");
            create_error = 0;
        }
        }
    } else if (field == 3) {
        snprintf(create_status, sizeof(create_status), "%s",
                 folder_ime_action == 1 ? "Folder creation canceled." : "Folder rename canceled.");
        create_error = 0;
    } else if (field == 4) {
        snprintf(deck_status, sizeof(deck_status), "Deck name unchanged.");
        create_error = 0;
    } else {
        snprintf(create_status, sizeof(create_status),
                 "Text entry canceled. Your previous text is unchanged.");
        create_error = 0;
    }
    create_ime_field = -1;
    folder_ime_action = 0;
}

static int create_target_is_available(int index) {
    return index >= 0 && index < deck_count;
}

static void create_target_storage_path(int index, char *output, size_t capacity) {
    if (index < 0 || index >= deck_count) {
        if (capacity) output[0] = '\0';
        return;
    }
    const DeckEntry *entry = &deck_entries[index];
    if (!entry->is_apkg &&
        (deck_path_is_deletable(entry->path) || !strcmp(entry->path, DECK_PATH)))
        snprintf(output, capacity, "%s", entry->path);
    else
        added_cards_path_for_deck(entry->path, output, capacity);
}

static int create_target_count(void) {
    return deck_count + 1;
}

static int create_target_index_at(int position) {
    if (position <= 0) return -1;
    int index = position - 1;
    return create_target_is_available(index) ? index : -1;
}

static int create_question_selection(void) {
    return create_target_deck_index < 0 ? 2 : 1;
}

static int create_answer_selection(void) {
    return create_target_deck_index < 0 ? 3 : 2;
}

static int create_add_selection(void) {
    return create_target_deck_index < 0 ? 4 : 3;
}

static int create_save_selection(void) {
    return create_target_deck_index < 0 ? 5 : 4;
}

static int create_cancel_selection(void) {
    return create_target_deck_index < 0 ? 6 : 5;
}

static void open_create_target_picker(void) {
    create_target_selection = 0;
    if (create_target_deck_index >= 0) {
        if (create_target_is_available(create_target_deck_index))
            create_target_selection = create_target_deck_index + 1;
    }
    header_focus_active = 0;
    current_screen = SCREEN_CREATE_TARGET;
}

static void choose_create_target(int position) {
    if (position < 0 || position >= create_target_count()) return;
    create_target_deck_index = create_target_index_at(position);
    create_selection = 0;
    create_status[0] = '\0';
    create_error = 0;
    header_focus_active = 0;
    current_screen = SCREEN_CREATE_DECK;
}

static void open_create_deck(void) {
    create_return_screen = current_screen;
    create_target_deck_index = -1;
    create_deck_name[0] = '\0';
    create_question[0] = '\0';
    create_answer[0] = '\0';
    create_status[0] = '\0';
    create_card_count = 0;
    create_error = 0;
    create_selection = 0;
    create_cancel_dialog_open = 0;
    create_draft_path[0] = '\0';
    for (int attempt = 0; attempt < 100; attempt++) {
        int length = snprintf(create_draft_path, sizeof(create_draft_path),
                              "%s/.vitaanki_draft_%08lx_%02d.tmp", DECK_FOLDER,
                              (unsigned long)time(NULL), attempt);
        if (length <= 0 || (size_t)length >= sizeof(create_draft_path)) break;
        if (!file_exists(create_draft_path)) {
            FILE *draft = fopen(create_draft_path, "wb");
            if (draft && fclose(draft) == 0) break;
            create_draft_path[0] = '\0';
            break;
        }
        create_draft_path[0] = '\0';
    }
    if (!create_draft_path[0]) {
        snprintf(create_status, sizeof(create_status), "Could not create a draft in the VitaAnki decks folder.");
        create_error = 1;
    } else {
        snprintf(create_status, sizeof(create_status), "Enter a name, question, and answer. Add cards, then save.");
    }
    current_screen = SCREEN_CREATE_DECK;
}

static void create_add_card(void) {
    char question[FIELD_SIZE];
    char answer[FIELD_SIZE];
    snprintf(question, sizeof(question), "%s", create_question);
    snprintf(answer, sizeof(answer), "%s", create_answer);
    normalize_tsv_field(question);
    normalize_tsv_field(answer);
    if (!question[0] || !answer[0]) {
        snprintf(create_status, sizeof(create_status), "Enter both a question and an answer before adding a card.");
        create_error = 1;
        return;
    }
    if (create_card_count >= MAX_CARDS) {
        snprintf(create_status, sizeof(create_status), "This deck reached the %d-card limit.", MAX_CARDS);
        create_error = 1;
        return;
    }
    FILE *draft = fopen(create_draft_path, "ab");
    if (!draft) {
        snprintf(create_status, sizeof(create_status), "Draft file could not be opened. Cancel and start again.");
        create_error = 1;
        return;
    }
    int ok = fprintf(draft, "%s\t%s\n", question, answer) >= 0;
    if (fclose(draft) != 0) ok = 0;
    if (!ok) {
        snprintf(create_status, sizeof(create_status), "Card could not be saved to the draft.");
        create_error = 1;
        return;
    }
    create_card_count++;
    create_question[0] = '\0';
    create_answer[0] = '\0';
    snprintf(create_status, sizeof(create_status), "Card %d saved in this deck draft.", create_card_count);
    create_error = 0;
}

static void deck_filename_base(const char *name, char *base, size_t capacity) {
    size_t used = 0;
    int underscore = 0;
    if (!base || capacity == 0) return;
    base[0] = '\0';
    for (const unsigned char *p = (const unsigned char *)name;
         p && *p && used < capacity - 1; p++) {
        if ((*p >= 'A' && *p <= 'Z') || (*p >= 'a' && *p <= 'z') ||
            (*p >= '0' && *p <= '9')) {
            base[used++] = (char)*p;
            underscore = 0;
        } else if (used > 0 && !underscore) {
            base[used++] = '_';
            underscore = 1;
        }
    }
    while (used > 0 && base[used - 1] == '_') used--;
    base[used] = '\0';
}

static int move_optional_deck_sidecar(const char *source, const char *destination,
                                      int *moved) {
    *moved = 0;
    if (!file_exists(source)) return 1;
    if (file_exists(destination) || rename(source, destination) != 0) return 0;
    *moved = 1;
    return 1;
}

static void apply_deck_rename(const char *name) {
    int index = deck_settings_deck_index;
    if (index < 0 || index >= deck_count ||
        !deck_path_is_deletable(deck_entries[index].path)) {
        snprintf(deck_status, sizeof(deck_status), "Built-in decks cannot be renamed.");
        return;
    }
    char base[64];
    deck_filename_base(name, base, sizeof(base));
    if (!base[0]) {
        snprintf(deck_status, sizeof(deck_status), "Use letters or numbers in the deck name.");
        return;
    }

    char old_path[512];
    char new_path[512];
    snprintf(old_path, sizeof(old_path), "%s", deck_entries[index].path);
    const char *extension = strrchr(old_path, '.');
    if (!extension || (!has_extension(old_path, ".tsv") &&
                       !has_extension(old_path, ".apkg"))) {
        snprintf(deck_status, sizeof(deck_status), "This deck type cannot be renamed.");
        return;
    }
    int new_length = snprintf(new_path, sizeof(new_path), "%s/%s%s",
                              DECK_FOLDER, base, extension);
    if (new_length <= 0 || (size_t)new_length >= sizeof(new_path)) {
        snprintf(deck_status, sizeof(deck_status), "That deck name is too long.");
        return;
    }
    if (!strcmp(old_path, new_path)) {
        snprintf(deck_status, sizeof(deck_status), "Deck name unchanged.");
        return;
    }
    if (file_exists(new_path)) {
        snprintf(deck_status, sizeof(deck_status), "A deck with that name already exists.");
        return;
    }

    char old_progress[96], new_progress[96];
    char old_settings[96], new_settings[96];
    char old_additions[96], new_additions[96];
    char old_progress_temp[112], old_progress_backup[112];
    char old_settings_temp[112], old_settings_backup[112];
    char new_progress_temp[112], new_progress_backup[112];
    char new_settings_temp[112], new_settings_backup[112];
    char old_additions_temp[112], old_additions_backup[112];
    char new_additions_temp[112], new_additions_backup[112];
    progress_path_for_deck(old_path, old_progress, sizeof(old_progress));
    progress_path_for_deck(new_path, new_progress, sizeof(new_progress));
    deck_settings_path_for(old_path, old_settings, sizeof(old_settings));
    deck_settings_path_for(new_path, new_settings, sizeof(new_settings));
    added_cards_path_for_deck(old_path, old_additions, sizeof(old_additions));
    added_cards_path_for_deck(new_path, new_additions, sizeof(new_additions));
    snprintf(old_progress_temp, sizeof(old_progress_temp), "%s.tmp", old_progress);
    snprintf(old_progress_backup, sizeof(old_progress_backup), "%s.bak", old_progress);
    snprintf(old_settings_temp, sizeof(old_settings_temp), "%s.tmp", old_settings);
    snprintf(old_settings_backup, sizeof(old_settings_backup), "%s.bak", old_settings);
    snprintf(new_progress_temp, sizeof(new_progress_temp), "%s.tmp", new_progress);
    snprintf(new_progress_backup, sizeof(new_progress_backup), "%s.bak", new_progress);
    snprintf(new_settings_temp, sizeof(new_settings_temp), "%s.tmp", new_settings);
    snprintf(new_settings_backup, sizeof(new_settings_backup), "%s.bak", new_settings);
    snprintf(old_additions_temp, sizeof(old_additions_temp), "%s.tmp", old_additions);
    snprintf(old_additions_backup, sizeof(old_additions_backup), "%s.bak", old_additions);
    snprintf(new_additions_temp, sizeof(new_additions_temp), "%s.tmp", new_additions);
    snprintf(new_additions_backup, sizeof(new_additions_backup), "%s.bak", new_additions);
    recover_atomic_file(old_progress, old_progress_temp, old_progress_backup);
    recover_atomic_file(old_settings, old_settings_temp, old_settings_backup);
    recover_atomic_file(new_progress, new_progress_temp, new_progress_backup);
    recover_atomic_file(new_settings, new_settings_temp, new_settings_backup);
    recover_atomic_file(old_additions, old_additions_temp, old_additions_backup);
    recover_atomic_file(new_additions, new_additions_temp, new_additions_backup);
    if (file_exists(new_progress) || file_exists(new_settings) ||
        file_exists(new_additions)) {
        snprintf(deck_status, sizeof(deck_status),
                 "That name has saved study data already. Choose a different name.");
        return;
    }

    if (rename(old_path, new_path) != 0) {
        snprintf(deck_status, sizeof(deck_status), "Deck could not be renamed. Check Vita storage.");
        return;
    }
    int moved_progress = 0;
    int moved_settings = 0;
    int moved_additions = 0;
    int sidecars_ok = move_optional_deck_sidecar(old_progress, new_progress,
                                                  &moved_progress) &&
                      move_optional_deck_sidecar(old_settings, new_settings,
                                                  &moved_settings) &&
                      move_optional_deck_sidecar(old_additions, new_additions,
                                                  &moved_additions);
    if (!sidecars_ok) {
        if (moved_additions) rename(new_additions, old_additions);
        if (moved_settings) rename(new_settings, old_settings);
        if (moved_progress) rename(new_progress, old_progress);
        rename(new_path, old_path);
        snprintf(deck_status, sizeof(deck_status),
                 "Deck data could not be moved safely. The original name was restored.");
        return;
    }

    int was_current = current_deck_path[0] && !strcmp(current_deck_path, old_path);
    int was_saved = saved_deck_path[0] && !strcmp(saved_deck_path, old_path);
    snprintf(deck_entries[index].path, sizeof(deck_entries[index].path), "%s", new_path);
    if (!save_folder_metadata()) {
        snprintf(deck_entries[index].path, sizeof(deck_entries[index].path), "%s", old_path);
        if (moved_additions) rename(new_additions, old_additions);
        if (moved_settings) rename(new_settings, old_settings);
        if (moved_progress) rename(new_progress, old_progress);
        rename(new_path, old_path);
        snprintf(deck_status, sizeof(deck_status),
                 "Deck name could not be saved. The original name was restored.");
        return;
    }

    char current_path_before[512];
    snprintf(current_path_before, sizeof(current_path_before), "%s", current_deck_path);
    if (was_current || was_saved) {
        snprintf(current_deck_path, sizeof(current_deck_path), "%s", new_path);
        if (!save_active_deck()) {
            snprintf(deck_entries[index].path, sizeof(deck_entries[index].path), "%s", old_path);
            save_folder_metadata();
            if (moved_additions) rename(new_additions, old_additions);
            if (moved_settings) rename(new_settings, old_settings);
            if (moved_progress) rename(new_progress, old_progress);
            rename(new_path, old_path);
            snprintf(current_deck_path, sizeof(current_deck_path), "%s", current_path_before);
            if (was_current) set_progress_path(old_path);
            snprintf(deck_status, sizeof(deck_status),
                     "Active deck setting could not be saved. The original name was restored.");
            return;
        }
        if (!was_current)
            snprintf(current_deck_path, sizeof(current_deck_path), "%s", current_path_before);
    }
    if (was_saved) snprintf(saved_deck_path, sizeof(saved_deck_path), "%s", new_path);
    if (was_current) {
        snprintf(current_deck_path, sizeof(current_deck_path), "%s", new_path);
        set_progress_path(new_path);
        snprintf(current_deck_name, sizeof(current_deck_name), "%s", base);
    }

    scan_decks();
    int updated_index = deck_index_for_path(new_path);
    if (updated_index >= 0) {
        deck_settings_deck_index = updated_index;
        snprintf(edit_deck_settings_path, sizeof(edit_deck_settings_path), "%s", new_path);
        int visible = visible_position_for_deck(updated_index);
        list_selection = visible >= 0 ? visible + 1 : 0;
        if (was_current) current_deck_index = updated_index;
    }
    snprintf(deck_status, sizeof(deck_status), "Renamed deck to %s.", base);
}

static int append_create_draft_to_deck(const char *destination) {
    char temporary[640];
    char backup[640];
    int temp_length = snprintf(temporary, sizeof(temporary), "%s.vitaanki.tmp", destination);
    int backup_length = snprintf(backup, sizeof(backup), "%s.vitaanki.bak", destination);
    if (temp_length <= 0 || (size_t)temp_length >= sizeof(temporary) ||
        backup_length <= 0 || (size_t)backup_length >= sizeof(backup)) return 0;

    recover_atomic_file(destination, temporary, backup);
    remove(temporary);
    int source_exists = file_exists(destination);
    FILE *source = source_exists ? fopen(destination, "rb") : NULL;
    FILE *draft = fopen(create_draft_path, "rb");
    FILE *output = fopen(temporary, "wb");
    if ((source_exists && !source) || !draft || !output) {
        if (source) fclose(source);
        if (draft) fclose(draft);
        if (output) fclose(output);
        remove(temporary);
        return 0;
    }

    char buffer[4096];
    size_t bytes;
    size_t source_bytes = 0;
    int last_source_byte = -1;
    int ok = 1;
    if (source) {
        while ((bytes = fread(buffer, 1, sizeof(buffer), source)) > 0) {
            if (fwrite(buffer, 1, bytes, output) != bytes) {
                ok = 0;
                break;
            }
            source_bytes += bytes;
            last_source_byte = (unsigned char)buffer[bytes - 1];
        }
        if (ferror(source)) ok = 0;
    }
    if (ok && source_bytes > 0 && last_source_byte != '\n' && last_source_byte != '\r' &&
        fputc('\n', output) == EOF) ok = 0;
    while (ok && (bytes = fread(buffer, 1, sizeof(buffer), draft)) > 0)
        if (fwrite(buffer, 1, bytes, output) != bytes) ok = 0;
    if (ferror(draft)) ok = 0;
    if (source && fclose(source) != 0) ok = 0;
    if (fclose(draft) != 0) ok = 0;
    if (fclose(output) != 0) ok = 0;
    if (!ok || !atomic_replace_file(temporary, destination, backup)) {
        remove(temporary);
        return 0;
    }
    return 1;
}

static void create_save_deck(void) {
    if (create_card_count <= 0 || !create_draft_path[0]) {
        snprintf(create_status, sizeof(create_status), "Add at least one complete card before saving.");
        create_error = 1;
        return;
    }

    if (create_target_deck_index >= 0) {
        int index = create_target_deck_index;
        if (!create_target_is_available(index)) {
            snprintf(create_status, sizeof(create_status),
                     "That deck is no longer available. Choose another deck.");
            create_error = 1;
            return;
        }
        char destination[512];
        char deck_path[512];
        char name[128];
        snprintf(deck_path, sizeof(deck_path), "%s", deck_entries[index].path);
        create_target_storage_path(index, destination, sizeof(destination));
        snprintf(name, sizeof(name), "%s", deck_entries[index].name);
        int added = create_card_count;
        if (!append_create_draft_to_deck(destination)) {
            snprintf(create_status, sizeof(create_status),
                     "Cards could not be saved to %s. The original deck was kept intact.", name);
            create_error = 1;
            return;
        }

        remove(create_draft_path);
        create_draft_path[0] = '\0';
        create_card_count = 0;
        create_question[0] = '\0';
        create_answer[0] = '\0';
        current_screen = SCREEN_DECKS;
        deck_folder_filter = 0;
        deck_folder_filter_focus = 0;
        scan_decks();
        int updated_index = deck_index_for_path(deck_path);
        if (updated_index >= 0) {
            int visible = visible_position_for_deck(updated_index);
            list_selection = visible >= 0 ? visible + 1 : 0;
            list_focus_actions = 0;
            deck_list_gear_focus = 0;
            select_deck(updated_index);
            current_screen = SCREEN_DECKS;
            snprintf(deck_status, sizeof(deck_status), "Added %d card%s to %s.",
                     added, added == 1 ? "" : "s", name);
        } else {
            snprintf(deck_status, sizeof(deck_status),
                     "Cards saved to %s, but rescan the deck list to refresh it.", name);
        }
        create_target_deck_index = -1;
        return;
    }

    if (!create_deck_name[0]) {
        snprintf(create_status, sizeof(create_status), "Enter a deck name before saving.");
        create_error = 1;
        return;
    }
    char base[64];
    deck_filename_base(create_deck_name, base, sizeof(base));
    if (!base[0]) {
        snprintf(create_status, sizeof(create_status), "Use letters or numbers in the deck name.");
        create_error = 1;
        return;
    }

    char destination[512];
    int available = 0;
    for (int suffix = 1; suffix <= 100; suffix++) {
        struct stat info;
        if (suffix == 1)
            snprintf(destination, sizeof(destination), "%s/%s.tsv", DECK_FOLDER, base);
        else
            snprintf(destination, sizeof(destination), "%s/%s_%d.tsv", DECK_FOLDER, base, suffix);
        if (stat(destination, &info) != 0) { available = 1; break; }
    }
    if (!available || rename(create_draft_path, destination) != 0) {
        snprintf(create_status, sizeof(create_status), "Could not save the deck. Check free space and try again.");
        create_error = 1;
        return;
    }
    create_draft_path[0] = '\0';
    int created_cards = create_card_count;
    create_card_count = 0;
    current_screen = SCREEN_DECKS;
    deck_folder_filter = 0;
    deck_folder_filter_focus = 0;
    scan_decks();
    int index = deck_index_for_path(destination);
    if (index >= 0) {
        int visible = visible_position_for_deck(index);
        list_selection = visible >= 0 ? visible + 1 : 0;
        list_focus_actions = 0;
        deck_list_gear_focus = 0;
    }
    if (index >= 0 && select_deck(index)) {
        snprintf(deck_status, sizeof(deck_status), "Created %s with %d cards.",
                 deck_entries[index].name, created_cards);
        current_screen = SCREEN_DECKS;
    } else {
        snprintf(create_status, sizeof(create_status), "Deck saved, but VitaAnki could not open it. Select it from Decks.");
        create_error = 1;
        current_screen = SCREEN_DECKS;
    }
}

static void discard_create_deck(void) {
    if (create_ime_open) {
        sceImeDialogAbort();
        sceImeDialogTerm();
        create_ime_open = 0;
    }
    if (create_draft_path[0]) remove(create_draft_path);
    create_draft_path[0] = '\0';
    create_cancel_dialog_open = 0;
    current_screen = create_return_screen;
}

static void request_cancel_create(void) {
    if (create_card_count == 0 && !create_deck_name[0] &&
        !create_question[0] && !create_answer[0]) {
        discard_create_deck();
        return;
    }
    create_cancel_dialog_open = 1;
    create_selection = 0;
}

static void confirm_delete_selected(void) {
    int index = deck_settings_deck_index;
    if (index < 0 || index >= deck_count ||
        !deck_path_is_deletable(deck_entries[index].path)) {
        delete_error = 1;
        return;
    }
    char path[512];
    char name[128];
    snprintf(path, sizeof(path), "%s", deck_entries[index].path);
    snprintf(name, sizeof(name), "%s", deck_entries[index].name);
    int was_current = current_deck_path[0] && !strcmp(current_deck_path, path);
    char progress[128];
    progress_path_for_deck(path, progress, sizeof(progress));
    if (remove(path) != 0) {
        delete_error = 1;
        return;
    }
    int progress_removed = !file_exists(progress) || remove(progress) == 0;
    char sidecar[160];
    snprintf(sidecar, sizeof(sidecar), "%s.tmp", progress);
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    snprintf(sidecar, sizeof(sidecar), "%s.bak", progress);
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    added_cards_path_for_deck(path, sidecar, sizeof(sidecar));
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    strncat(sidecar, ".tmp", sizeof(sidecar) - strlen(sidecar) - 1);
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    added_cards_path_for_deck(path, sidecar, sizeof(sidecar));
    strncat(sidecar, ".bak", sizeof(sidecar) - strlen(sidecar) - 1);
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    deck_settings_path_for(path, sidecar, sizeof(sidecar));
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    deck_settings_path_for(path, sidecar, sizeof(sidecar));
    strncat(sidecar, ".tmp", sizeof(sidecar) - strlen(sidecar) - 1);
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    deck_settings_path_for(path, sidecar, sizeof(sidecar));
    strncat(sidecar, ".bak", sizeof(sidecar) - strlen(sidecar) - 1);
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    if (was_current) {
        current_deck_path[0] = '\0';
        saved_deck_path[0] = '\0';
        remove(ACTIVE_DECK_PATH);
    }
    snprintf(deck_status, sizeof(deck_status), progress_removed
             ? "Deleted %s and its local study progress."
             : "Deleted %s, but a progress sidecar could not be removed.", name);
    delete_error = 0;
    delete_dialog_open = 0;
    scan_decks();
    if (was_current) {
        int fallback = find_saved_deck();
        if (fallback >= 0) {
            if (!select_deck(fallback)) load_demo_deck();
        } else load_demo_deck();
        current_screen = SCREEN_DECKS;
        scan_decks();
    }
    current_screen = SCREEN_DECKS;
}

static void advance_delete_confirmation(void) {
    if (delete_selection == 0) {
        if (delete_dialog_stage == 2) {
            delete_dialog_stage = 1;
            delete_selection = 0;
            delete_error = 0;
        } else {
            delete_dialog_open = 0;
            delete_error = 0;
        }
        return;
    }
    if (delete_dialog_stage == 1) {
        delete_dialog_stage = 2;
        delete_selection = 0;
        delete_error = 0;
        return;
    }
    confirm_delete_selected();
}

static void activate_create_selection(void) {
    if (create_cancel_dialog_open) {
        if (create_selection == 0) discard_create_deck();
        else create_cancel_dialog_open = 0;
        return;
    }
    if (create_selection == 0) open_create_target_picker();
    else if (create_target_deck_index < 0 && create_selection == 1) begin_create_ime(0);
    else if (create_selection == create_question_selection()) begin_create_ime(1);
    else if (create_selection == create_answer_selection()) begin_create_ime(2);
    else if (create_selection == create_add_selection()) create_add_card();
    else if (create_selection == create_save_selection()) create_save_deck();
    else if (create_selection == create_cancel_selection()) request_cancel_create();
}

static void maybe_start_confetti(int rating) {
    if ((confetti_mode == 1 && rating >= 2) || (confetti_mode == 2 && rating == 3))
        start_confetti();
}

static int next_interval_days(int interval, int rating) {
    long long next;
    if (rating == 0) return 0;
    if (rating == 1) next = interval < 1 ? 1 : ((long long)interval * 12 + 9) / 10;
    else if (rating == 2)
        next = interval < 1 ? current_deck_settings.good_days : (long long)interval * 2;
    else next = interval < 1 ? current_deck_settings.easy_days : (long long)interval * 3;
    if (next > MAX_INTERVAL_DAYS) next = MAX_INTERVAL_DAYS;
    return (int)next;
}

static void rate_card(int rating) {
    if (rating < 0 || rating > 3 || flip_frames_remaining > 0 || card_count <= 0 ||
        card_index < 0 || card_index >= card_count) return;
    if (!live_sync) offline_counts_cache_valid = 0;
    UndoRecord last_review = {0};
    last_review.card_id = cards[card_index].card_id;
    last_review.previous_index = card_index;
    last_review.previous_reviewed = reviewed;
    last_review.previous_new_cards_this_session = new_cards_this_session;
    last_review.previous_new_cards_today = current_deck_settings.new_cards_today;
    last_review.rating = rating;
    if (live_sync) {
        if (!anki_connect_answer(cards[card_index].card_id, rating + 1)) {
            sync_error = 1;
            return;
        }
        last_review.valid = 1;
        last_review.live = 1;
        undo_record = last_review;
        undo_error = 0;
        maybe_start_confetti(rating);
        reviewed++;
        int refreshed = anki_connect_reload(cards, card_capacity);
        live_refresh_after = time(NULL) + LIVE_REFRESH_SECONDS;
        if (refreshed < 0) {
            sync_error = 1;
            card_count = 0;
            return;
        }
        card_count = refreshed;
        card_index = 0;
        show_answer = 0;
        flip_frames_remaining = 0;
        card_scroll_position = 0.0f;
        selected_rating = 2;
        return;
    }

    Card *card = &cards[card_index];
    int was_new = card->state == CARD_STATE_NEW;
    if (was_new) {
        new_cards_this_session++;
        current_deck_settings.new_cards_today++;
    }
    last_review.previous_interval_days = card->interval_days;
    last_review.previous_due = card->due;
    last_review.previous_state = card->state;
    int interval = card->interval_days;
    CardState previous_state = card->state;
    long long now = (long long)time(NULL);
    if (rating == 0) {
        card->interval_days = 0;
        card->due = now + (long long)current_deck_settings.again_minutes * 60LL;
        card->state = CARD_STATE_LEARNING;
    } else if (rating == 1 && previous_state != CARD_STATE_REVIEW) {
        card->interval_days = 0;
        card->due = now + (long long)current_deck_settings.hard_minutes * 60LL;
        card->state = CARD_STATE_LEARNING;
    } else {
        card->interval_days = next_interval_days(interval, rating);
        card->due = now + (long long)card->interval_days * 86400LL;
        card->state = CARD_STATE_REVIEW;
    }
    if (apkg_mode) {
        last_review.queued = anki_connect_queue_review(card->card_id, rating + 1);
        if (!last_review.queued) sync_queue_error = 1;
    }
    last_review.valid = 1;
    undo_record = last_review;
    undo_error = 0;
    maybe_start_confetti(rating);
    reviewed++;
    save_progress();
    if (was_new) {
        if (!save_deck_study_settings(current_deck_path, current_deck_settings))
            snprintf(deck_status, sizeof(deck_status), "Card saved, but today's new-card count could not be saved.");
        else
            deck_status[0] = '\0';
    }
    if (current_deck_index >= 0 && current_deck_index < deck_count) {
        deck_due_count[current_deck_index] = count_due_cards_in_loaded_deck();
        deck_due_count_known[current_deck_index] = 1;
        recalculate_all_deck_due_total();
    }
    card_index = find_next_due();
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_position = 0.0f;
    selected_rating = 2;
}

static int find_card_index_by_id(long long card_id) {
    for (int i = 0; i < card_count; i++)
        if (cards[i].card_id == card_id) return i;
    return -1;
}

static void undo_last_rating(void) {
    if (!undo_record.valid) return;
    UndoRecord last_review = undo_record;

    if (last_review.live) {
        if (!anki_connect_undo()) {
            undo_error = 1;
            return;
        }
        int refreshed = anki_connect_reload(cards, card_capacity);
        live_refresh_after = time(NULL) + LIVE_REFRESH_SECONDS;
        reviewed = last_review.previous_reviewed;
        new_cards_this_session = last_review.previous_new_cards_this_session;
        undo_record.valid = 0;
        if (refreshed < 0) {
            sync_error = 1;
            card_count = 0;
            undo_error = 1;
            return;
        }
        card_count = refreshed;
        int index = find_card_index_by_id(last_review.card_id);
        if (index < 0) {
            card_index = 0;
            show_answer = 0;
            undo_error = 1;
        } else {
            card_index = index;
            show_answer = 1;
            undo_error = 0;
        }
    } else {
        if (last_review.queued &&
            !anki_connect_cancel_queued_review(last_review.card_id, last_review.rating + 1)) {
            undo_error = 1;
            return;
        }
        int index = find_card_index_by_id(last_review.card_id);
        if (index < 0 && last_review.previous_index >= 0 &&
            last_review.previous_index < card_count)
            index = last_review.previous_index;
        if (index < 0) {
            undo_error = 1;
            return;
        }
        cards[index].interval_days = last_review.previous_interval_days;
        cards[index].due = last_review.previous_due;
        cards[index].state = last_review.previous_state;
        current_deck_settings.new_cards_today = last_review.previous_new_cards_today;
        int daily_settings_saved = save_deck_study_settings(current_deck_path, current_deck_settings);
        save_progress();
        if (current_deck_index >= 0 && current_deck_index < deck_count) {
            deck_due_count[current_deck_index] = count_due_cards_in_loaded_deck();
            deck_due_count_known[current_deck_index] = 1;
            recalculate_all_deck_due_total();
        }
        reviewed = last_review.previous_reviewed;
        new_cards_this_session = last_review.previous_new_cards_this_session;
        card_index = index;
        show_answer = 1;
        undo_error = !daily_settings_saved;
    }

    flip_frames_remaining = 0;
    card_scroll_position = 0.0f;
    selected_rating = last_review.rating;
    undo_record.valid = 0;
    current_screen = SCREEN_STUDY;
}

static void toggle_music(void) {
#ifdef VITAANKI_DISABLE_MUSIC
    music_muted = 1;
#else
    music_muted = !anki_music_is_muted();
    anki_music_set_muted(music_muted);
    save_settings();
#endif
}

static void draw_home(void) {
    draw_header("VitaAnki v" APP_VERSION, "A pocket-sized Anki study companion");
    char study_subtitle[160];
    if (live_sync) snprintf(study_subtitle, sizeof(study_subtitle), "Live deck  |  %d cards due", card_count);
    else if (all_decks_mode)
        snprintf(study_subtitle, sizeof(study_subtitle), "All decks  |  %d cards due", all_decks_due_total);
    else snprintf(study_subtitle, sizeof(study_subtitle), "%s  |  %d cards", current_deck_name, card_count);

    draw_button(home_buttons[0], "Study", study_subtitle, ACCENT, home_selection == 0);
    draw_button(home_buttons[1], "Choose a deck", "Switch your offline study deck", GREEN, home_selection == 1);
    draw_button(home_buttons[2], "Create", "Make your own deck and cards", YELLOW, home_selection == 2);
    draw_button(home_buttons[3], "Settings", "Fonts, card size, themes, and review controls", ACCENT, home_selection == 3);
    draw_compact_button(sync_button, "ANKICONNECT", GREEN, home_selection == 4);
    draw_compact_button(android_transfer_button, "DECK TRANSFER", YELLOW, home_selection == 5);
    if (clock_warning_active)
        draw_fit_text(48, 488, YELLOW, 0.48f,
                      "Vita date/time looks wrong. Offline review times may be incorrect.", 860);
    draw_fit_text(48, 520, MUTED, 0.46f, anki_connect_get_status(), 860);
}

static void toggle_android_transfer_receiver(void) {
    AndroidTransferState state = android_transfer_get_state();
    if (state == ANDROID_TRANSFER_STARTING || state == ANDROID_TRANSFER_WAITING ||
        state == ANDROID_TRANSFER_RECEIVING || state == ANDROID_TRANSFER_LISTING ||
        state == ANDROID_TRANSFER_SENDING) {
        android_transfer_stop();
        return;
    }
    if (live_sync) {
        select_offline_source();
        current_screen = SCREEN_ANDROID_TRANSFER;
    }
    android_transfer_start();
}

static void draw_android_transfer(void) {
    AndroidTransferState state = android_transfer_get_state();
    draw_header("Deck transfer", "VitaAnki Mobile");
    draw_fit_text(72, 142, WHITE, 0.68f, "Enter this code in the Android app:", 816);

    draw_text(72, 204, MUTED, 0.58f, "CONFIRMATION CODE");
    draw_text(72, 256, ACCENT, 1.12f,
              state == ANDROID_TRANSFER_IDLE || state == ANDROID_TRANSFER_STOPPED
                  ? "------" : android_transfer_get_pin());

    draw_fit_text(72, 316, state == ANDROID_TRANSFER_ERROR ? RED :
                  state == ANDROID_TRANSFER_RECEIVED ? GREEN : WHITE, 0.56f,
                  android_transfer_get_message(), 816);
    if (state == ANDROID_TRANSFER_RECEIVING || state == ANDROID_TRANSFER_SENDING) {
        char progress[48];
        snprintf(progress, sizeof(progress), "%s deck: %d%%",
                 state == ANDROID_TRANSFER_RECEIVING ? "Receiving" : "Sending",
                 android_transfer_get_progress());
        draw_text(72, 364, ACCENT, 0.54f, progress);
    } else if (state == ANDROID_TRANSFER_RECEIVED) {
        draw_fit_text(72, 364, GREEN, 0.50f, android_transfer_get_filename(), 420);
    }

    int button_focus = !header_focus_active;
    draw_compact_button(android_transfer_start_button,
        state == ANDROID_TRANSFER_STARTING || state == ANDROID_TRANSFER_WAITING ||
        state == ANDROID_TRANSFER_RECEIVING || state == ANDROID_TRANSFER_LISTING ||
        state == ANDROID_TRANSFER_SENDING
            ? "STOP RECEIVER" : "START RECEIVER", ACCENT,
        button_focus && transfer_selection == 0);
    draw_compact_button(android_transfer_decks_button, "OPEN DECKS", GREEN,
                        button_focus && transfer_selection == 1);
}

static void draw_sync(void) {
    const char *deck_name = anki_connect_get_deck_name();
    if (!deck_name || !deck_name[0]) deck_name = "No deck configured";
    char subtitle[160];
    snprintf(subtitle, sizeof(subtitle), "%s%.112s",
             live_sync ? "Connected to " : "Configured deck: ", deck_name);
    draw_header("AnkiConnect", subtitle);
    draw_button(sync_connect_button,
                live_sync ? "DISCONNECT FROM ANKICONNECT"
                          : anki_connect_is_configured() ? "CONNECT TO ANKICONNECT" : "SETUP NEEDED",
                live_sync ? "Return Home and choose Study to use your offline deck."
                          : anki_connect_is_configured() ? "Connect to the deck shown above when you are ready."
                                                         : "Edit sync.ini on the Vita to connect to Anki Desktop.",
                live_sync ? RED : ACCENT, !header_focus_active);

    draw_text(72, 244, MUTED, 0.62f, "Connection status");
    const char *status = sync_message[0] ? sync_message : anki_connect_get_status();
    draw_wrapped(status, 72, 282, 812, 0.58f,
                 sync_error ? RED : WHITE);
    if (!anki_connect_is_configured())
        draw_wrapped("Setup: copy sync.example.ini to ux0:data/VitaAnki/sync.ini, then enter your PC address, exact deck name, and AnkiConnect key.",
                     72, 342, 812, 0.46f, MUTED);
    else
        draw_wrapped("Offline reviews are saved on the Vita, then sent to this Anki Desktop deck the next time you connect. AnkiConnect does not use AnkiWeb.",
                     72, 354, 812, 0.48f, MUTED);
    draw_fit_text(72, 492, MUTED, 0.46f,
                  "Study starts from the Home screen.", 812);
}

static void select_offline_source(void) {
    int offline_index = current_deck_index;
    if (live_sync) {
        anki_connect_note_offline_deck();
        live_sync = 0;
        live_refresh_after = 0;
        sync_error = 0;
        undo_record.valid = 0;
        if (offline_index >= 0 && offline_index < deck_count) {
            if (!select_deck(offline_index)) load_demo_deck();
        } else {
            load_demo_deck();
        }
    }
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_position = 0.0f;
    sync_message[0] = '\0';
    current_screen = SCREEN_SYNC;
}

static void activate_sync_selection(void) {
    if (live_sync) select_offline_source();
    else begin_pc_sync();
}

static int first_visible_deck(int importing) {
    int first = list_selection - 1;
    if (first < 0) first = 0;
    int item_count = importing ? deck_count : visible_deck_count() + 1;
    if (first + LIST_VISIBLE > item_count) first = item_count - LIST_VISIBLE;
    if (first < 0) first = 0;
    return first;
}

static int list_action_count(int importing) {
    return importing ? 3 : 2;
}

static UiRect list_action_rect(int importing, int action) {
    if (importing) {
        if (action == 0) return (UiRect){60, 458, 210, 52};
        if (action == 1) return (UiRect){282, 458, 154, 52};
        return (UiRect){450, 458, 220, 52};
    }
    if (action == 0) return (UiRect){60, 458, 220, 52};
    return (UiRect){294, 458, 220, 52};
}

static UiRect deck_settings_gear_rect(UiRect row) {
    return (UiRect){row.x + row.w - 48, row.y + 8, 38, 38};
}

static void draw_deck_settings_gear(UiRect rect, int selected) {
    unsigned int color = selected ? ACCENT : MUTED;
    unsigned int fill = selected ? PANEL_HI : PANEL;
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, fill);
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, 2, color);
    vita2d_draw_rectangle(rect.x, rect.y + rect.h - 2, rect.w, 2, color);
    vita2d_draw_rectangle(rect.x, rect.y, 2, rect.h, color);
    vita2d_draw_rectangle(rect.x + rect.w - 2, rect.y, 2, rect.h, color);
    int cx = rect.x + rect.w / 2;
    int cy = rect.y + rect.h / 2;
    vita2d_draw_rectangle(cx - 3, cy - 15, 6, 30, color);
    vita2d_draw_rectangle(cx - 15, cy - 3, 30, 6, color);
    vita2d_draw_fill_circle((float)cx, (float)cy, 10.0f, color);
    vita2d_draw_fill_circle((float)cx, (float)cy, 4.0f, fill);
}

static const char *import_error_code_name(int code) {
    switch (code) {
        case -1: return "IMP-APKG-01";
        case -2: return "IMP-APKG-02";
        case -3: return "IMP-APKG-03";
        case -4: return "IMP-APKG-04";
        case -5: return "IMP-APKG-05";
        case -6: return "IMP-APKG-06";
        case -7: return "IMP-TSV-01";
        case -8: return "IMP-TSV-02";
        case -9: return "IMP-APKG-09";
        default: return "IMP-UNKNOWN";
    }
}

static const char *import_error_cause(int code) {
    switch (code) {
        case -1: return "The file could not be opened as an Anki package.";
        case -2: return "No collection.anki2 or collection.anki21 database was found.";
        case -3: return "The Vita SQLite reader could not open the collection database.";
        case -4: return "The package opened, but its Anki card table could not be read.";
        case -5: return "The database stopped returning cards before the import finished.";
        case -6: return "The Vita ran out of memory while creating the imported cards.";
        case -7: return "The selected deck file could not be reopened.";
        case -8: return "The Vita ran out of memory while loading this TSV deck.";
        case -9: return "SQLite memory setup failed before the import could start.";
        default: return "The selected deck could not be loaded.";
    }
}

static const char *import_error_recovery(int code) {
    switch (code) {
        case -1: return "Copy a valid .apkg into the decks folder, then rescan.";
        case -2: return "Export again from Anki with Support older Anki versions enabled.";
        case -3: return "Re-export as compatible, close other apps, and retry.";
        case -4: return "Re-export from Anki with compatibility enabled.";
        case -5: return "The collection may be incomplete; export it again from Anki.";
        case -6: return "Close other apps and try a smaller deck.";
        case -7: return "Check the file in ux0:data/VitaAnki/decks, then rescan.";
        case -8: return "Try a smaller TSV or shorter card fields.";
        case -9: return "Close and reopen VitaAnki; share this code if it happens again.";
        default: return "Check the deck file and try importing it again.";
    }
}

static void draw_deck_list(int importing) {
    const char *title = importing ? "Deck file issue" : "Choose a deck";
    char subtitle[160];
    if (importing) {
        snprintf(subtitle, sizeof(subtitle), "Review the error, then rescan or choose another deck.");
    } else {
        snprintf(subtitle, sizeof(subtitle), "Offline decks and due counts");
    }
    draw_header(title, subtitle);

    if (!importing) {
        UiRect filter = {60, 100, 840, 26};
        int filter_choices = folder_count + 2;
        int member_count = visible_deck_count();
        char label[128];
        const char *folder_name = deck_folder_filter == 0 ? "All decks"
                                : deck_folder_filter == 1 ? "Unfiled"
                                : (deck_folder_filter - 2 < folder_count
                                   ? folder_names[deck_folder_filter - 2] : "All decks");
        snprintf(label, sizeof(label), "FOLDER  %s  (%d deck%s)   %d / %d",
                 folder_name, member_count, member_count == 1 ? "" : "s",
                 deck_folder_filter + 1, filter_choices);
        vita2d_draw_rectangle(filter.x, filter.y, filter.w, filter.h,
                              deck_folder_filter_focus ? PANEL_HI : PANEL);
        unsigned int edge = deck_folder_filter_focus ? ACCENT : PANEL_HI;
        vita2d_draw_rectangle(filter.x, filter.y, filter.w, 2, edge);
        vita2d_draw_rectangle(filter.x, filter.y + filter.h - 2, filter.w, 2, edge);
        vita2d_draw_rectangle(filter.x, filter.y, 2, filter.h, edge);
        vita2d_draw_rectangle(filter.x + filter.w - 2, filter.y, 2, filter.h, edge);
        draw_text(filter.x + 16, filter.y + 19, ACCENT, 0.46f, "<");
        draw_fit_text(filter.x + 48, filter.y + 19, WHITE, 0.40f, label, filter.w - 96);
        draw_text(filter.x + filter.w - 30, filter.y + 19, ACCENT, 0.46f, ">");
    }

    if (deck_count == 0 && importing) {
        draw_text(76, 188, WHITE, 0.82f, "No deck files found");
        draw_wrapped("In VitaShell, copy a .apkg or .tsv file to ux0:data/VitaAnki/decks, then choose Rescan. The bundled sample deck is normally listed here.",
                     76, 230, 790, 0.68f, MUTED);
    } else {
        int first = first_visible_deck(importing);
        int visible_count = importing ? deck_count : visible_deck_count();
        int visible_items = importing ? deck_count : visible_count + 1;
        int all_counts_known = 1;
        int count_error = 0;
        int total_due = 0;
        for (int i = 0; i < deck_count; i++) {
            if (!deck_matches_folder_filter(i)) continue;
            if (!deck_due_count_known[i]) all_counts_known = 0;
            else if (deck_due_count[i] < 0) {
                all_counts_known = 0;
                count_error = 1;
            } else total_due += deck_due_count[i];
        }
        for (int row = 0; row < LIST_VISIBLE; row++) {
            int item = first + row;
            if (item >= visible_items) break;
            UiRect rect = {60, LIST_ROW_Y + row * LIST_ROW_H, 840, 54};
            if (!importing && item == 0) {
                int row_focused = list_selection == 0 && !header_focus_active &&
                                  !list_focus_actions && !deck_folder_filter_focus;
                unsigned int fill = row_focused ? PANEL_HI : PANEL;
                vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, fill);
                vita2d_draw_rectangle(rect.x, rect.y, 4, rect.h,
                                      all_decks_mode ? GREEN : (row_focused ? ACCENT : PANEL));
                if (row_focused) {
                    vita2d_draw_rectangle(rect.x, rect.y, rect.w, 2, ACCENT);
                    vita2d_draw_rectangle(rect.x + rect.w - 2, rect.y, 2, rect.h, ACCENT);
                    vita2d_draw_rectangle(rect.x, rect.y + rect.h - 2, rect.w, 2, ACCENT);
                }
                draw_text(rect.x + 18, rect.y + 26, WHITE, 0.68f, "All due reviews");
                if (all_counts_known) {
                    char due_text[96];
                    snprintf(due_text, sizeof(due_text), "%d due across %d deck%s",
                             total_due, visible_count, visible_count == 1 ? "" : "s");
                    draw_text(rect.x + 18, rect.y + 46, MUTED, 0.42f, due_text);
                } else {
                    draw_text(rect.x + 18, rect.y + 46, MUTED, 0.42f,
                              count_error ? "Some due counts are unavailable."
                                          : "Checking due cards across decks...");
                }
                if (all_decks_mode)
                    draw_text(rect.x + rect.w - 112, rect.y + 34, GREEN, 0.42f, "CURRENT");
                continue;
            }
            int index = importing ? item : deck_index_at_visible_position(item - 1);
            if (index < 0 || index >= deck_count) continue;
            int active = current_deck_path[0] &&
                         !strcmp(deck_entries[index].path, current_deck_path);
            int row_focused = item == list_selection &&
                              !header_focus_active && !list_focus_actions &&
                              !deck_folder_filter_focus &&
                              (importing || !deck_list_gear_focus);
            unsigned int fill = row_focused ? PANEL_HI : PANEL;
            vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, fill);
            vita2d_draw_rectangle(rect.x, rect.y, 4, rect.h,
                                  active ? GREEN : (row_focused ? ACCENT : PANEL));
            if (row_focused) {
                vita2d_draw_rectangle(rect.x, rect.y, rect.w, 2, ACCENT);
                vita2d_draw_rectangle(rect.x + rect.w - 2, rect.y, 2, rect.h, ACCENT);
                vita2d_draw_rectangle(rect.x, rect.y + rect.h - 2, rect.w, 2, ACCENT);
            }
            draw_fit_text(rect.x + 18, rect.y + 26, WHITE, 0.68f, deck_entries[index].name, 660);
            char detail[160];
            const char *format = deck_entries[index].is_apkg ? "Anki package" : "TSV deck";
            if (deck_due_count_known[index] && deck_due_count[index] >= 0) {
                snprintf(detail, sizeof(detail), "%s  |  %d due for review%s%s", format,
                         deck_due_count[index], deck_entries[index].folder[0] ? "  |  " : "",
                         deck_entries[index].folder);
            } else if (deck_due_count_known[index]) {
                snprintf(detail, sizeof(detail), "%s  |  due count unavailable", format);
            } else {
                snprintf(detail, sizeof(detail), "%s  |  checking due count...", format);
            }
            draw_fit_text(rect.x + 18, rect.y + 46, MUTED, 0.42f, detail, 660);
            if (active && !all_decks_mode)
                draw_text(rect.x + rect.w - 112, rect.y + 34, GREEN, 0.42f, "CURRENT");
            if (!importing)
                draw_deck_settings_gear(deck_settings_gear_rect(rect),
                                        item == list_selection && deck_list_gear_focus &&
                                        !header_focus_active && !list_focus_actions);
        }
        if (importing && !import_error && deck_count > 0 &&
            list_selection >= 0 && list_selection < deck_count) {
            struct stat file_info;
            char preview[256];
            const DeckEntry *entry = &deck_entries[list_selection];
            if (stat(entry->path, &file_info) == 0 && file_info.st_size >= 0) {
                unsigned long long bytes = (unsigned long long)file_info.st_size;
                char size_text[32];
                if (bytes >= 1024ULL * 1024ULL)
                    snprintf(size_text, sizeof(size_text), "%llu MB", bytes / (1024ULL * 1024ULL));
                else
                    snprintf(size_text, sizeof(size_text), "%llu KB", bytes / 1024ULL);
                snprintf(preview, sizeof(preview), "Preview: %s  |  %s  |  %s  |  checked when opened",
                         entry->name, entry->is_apkg ? ".apkg Anki package" : ".tsv text deck", size_text);
            } else {
                snprintf(preview, sizeof(preview), "Preview: %s  |  file details unavailable; rescan before importing",
                         entry->name);
            }
            draw_fit_text(62, 406, MUTED, 0.44f, preview, 814);
        } else if (!import_error && !importing && visible_count == 0) {
            draw_fit_text(62, 406, MUTED, 0.48f, "This folder has no decks.", 814);
        }
    }

    if (deck_status[0]) draw_fit_text(62, 434, GREEN, 0.42f, deck_status, 814);

    if (import_error) {
        char recovery[256];
        snprintf(recovery, sizeof(recovery), "%s  Fix: %s",
                 import_error_cause(import_error_code), import_error_recovery(import_error_code));
        draw_fit_text(76, 397, RED, 0.47f,
                      import_error_code_name(import_error_code), 800);
        draw_wrapped(recovery, 76, 416, 800, 0.37f, WHITE);
        if (import_error_code == -3 || import_error_code == -6 || import_error_code == -9)
            draw_fit_text(76, 447, MUTED, 0.31f, import_apkg_diagnostic(), 800);
    }

    int action_focus = list_focus_actions && !header_focus_active;
    draw_compact_button(list_action_rect(importing, 0), importing ? "IMPORT & STUDY" : "RESCAN",
                        importing ? GREEN : YELLOW, action_focus && list_action_selection == 0);
    draw_compact_button(list_action_rect(importing, 1), importing ? "RESCAN" : "FOLDERS", YELLOW,
                        action_focus && list_action_selection == 1);
    if (importing) {
        draw_compact_button(list_action_rect(1, 2), "CREATE DECK + CARDS", ACCENT,
                            action_focus && list_action_selection == 2);
        draw_fit_text(680, 490, MUTED, 0.43f, "New deck? Start here", 220);
    }
}

static UiRect create_target_rect(void) {
    return (UiRect){72, 104, 816, 50};
}

static UiRect create_name_rect(void) {
    return (UiRect){72, 164, 816, 48};
}

static UiRect create_question_rect(void) {
    return (UiRect){72, create_target_deck_index < 0 ? 222 : 164,
                    816, create_target_deck_index < 0 ? 82 : 94};
}

static UiRect create_answer_rect(void) {
    return (UiRect){72, create_target_deck_index < 0 ? 316 : 270,
                    816, create_target_deck_index < 0 ? 82 : 94};
}

static void draw_create_target_picker(void) {
        draw_header("Choose destination", "Create a new deck or add cards to any deck");
    int item_count = create_target_count();
    int first = create_target_selection - 1;
    if (first < 0) first = 0;
    if (first + LIST_VISIBLE > item_count) first = item_count - LIST_VISIBLE;
    if (first < 0) first = 0;
    for (int row = 0; row < LIST_VISIBLE; row++) {
        int item = first + row;
        if (item >= item_count) break;
        UiRect rect = {60, LIST_ROW_Y + row * LIST_ROW_H, 840, 54};
        int selected = item == create_target_selection && !header_focus_active;
        unsigned int edge = selected ? ACCENT : PANEL;
        vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, selected ? PANEL_HI : PANEL);
        vita2d_draw_rectangle(rect.x, rect.y, 4, rect.h, edge);
        if (selected) {
            vita2d_draw_rectangle(rect.x, rect.y, rect.w, 2, ACCENT);
            vita2d_draw_rectangle(rect.x + rect.w - 2, rect.y, 2, rect.h, ACCENT);
            vita2d_draw_rectangle(rect.x, rect.y + rect.h - 2, rect.w, 2, ACCENT);
        }
        if (item == 0) {
            draw_text(rect.x + 18, rect.y + 25, WHITE, 0.58f, "Create a new deck");
            draw_text(rect.x + 18, rect.y + 46, MUTED, 0.40f, "Start with a blank deck");
        } else {
            int index = create_target_index_at(item);
            if (index < 0) continue;
            draw_fit_text(rect.x + 18, rect.y + 25, WHITE, 0.58f,
                          deck_entries[index].name, rect.w - 36);
            draw_text(rect.x + 18, rect.y + 46, MUTED, 0.40f,
                      deck_entries[index].is_apkg
                          ? "Anki deck; added cards stay on Vita"
                          : "Vita deck");
        }
    }
    draw_fit_text(62, 432, MUTED, 0.40f,
                  "Added cards are saved on your Vita. Original Anki decks stay unchanged.", 836);
}

static void draw_create_deck(void) {
    char subtitle[80];
    snprintf(subtitle, sizeof(subtitle), "%d card%s ready to save", create_card_count,
             create_card_count == 1 ? "" : "s");
    int creating_new = create_target_deck_index < 0;
    draw_header(creating_new ? "Create a deck" : "Add cards", subtitle);

    UiRect target = create_target_rect();
    int target_focused = create_selection == 0 && !header_focus_active;
    vita2d_draw_rectangle(target.x, target.y, target.w, target.h,
                          target_focused ? PANEL_HI : PANEL);
    unsigned int target_edge = target_focused ? ACCENT : PANEL_HI;
    vita2d_draw_rectangle(target.x, target.y, target.w, 3, target_edge);
    vita2d_draw_rectangle(target.x, target.y, 3, target.h, target_edge);
    if (target_focused) {
        vita2d_draw_rectangle(target.x + target.w - 3, target.y, 3, target.h, ACCENT);
        vita2d_draw_rectangle(target.x, target.y + target.h - 3, target.w, 3, ACCENT);
    }
    draw_text(target.x + 18, target.y + 21, MUTED, 0.40f, "DESTINATION");
    const char *target_name = creating_new ? "Create a new deck"
        : (create_target_deck_index < deck_count
           ? deck_entries[create_target_deck_index].name : "Choose a deck");
    draw_fit_text(target.x + 180, target.y + 32, WHITE, 0.54f, target_name, 550);
    draw_text(target.x + target.w - 38, target.y + 33, ACCENT, 0.62f, ">");

    if (creating_new) {
        UiRect name = create_name_rect();
        int focused = create_selection == 1 && !header_focus_active;
        vita2d_draw_rectangle(name.x, name.y, name.w, name.h, focused ? PANEL_HI : PANEL);
        unsigned int edge = focused ? ACCENT : PANEL_HI;
        vita2d_draw_rectangle(name.x, name.y, name.w, 3, edge);
        vita2d_draw_rectangle(name.x, name.y, 3, name.h, edge);
        if (focused) {
            vita2d_draw_rectangle(name.x + name.w - 3, name.y, 3, name.h, ACCENT);
            vita2d_draw_rectangle(name.x, name.y + name.h - 3, name.w, 3, ACCENT);
        }
        draw_text(name.x + 18, name.y + 30, MUTED, 0.44f, "DECK NAME");
        draw_fit_text(name.x + 180, name.y + 31, create_deck_name[0] ? WHITE : MUTED,
                      0.53f, create_deck_name[0] ? create_deck_name : "Name your deck",
                      name.w - 200);
    }

    UiRect fields[] = {create_question_rect(), create_answer_rect()};
    const char *labels[] = {"QUESTION", "ANSWER"};
    const char *values[] = {create_question, create_answer};
    int selections[] = {create_question_selection(), create_answer_selection()};
    for (int i = 0; i < 2; i++) {
        int focused = create_selection == selections[i] && !header_focus_active;
        vita2d_draw_rectangle(fields[i].x, fields[i].y, fields[i].w, fields[i].h,
                              focused ? PANEL_HI : PANEL);
        unsigned int edge = focused ? ACCENT : PANEL_HI;
        vita2d_draw_rectangle(fields[i].x, fields[i].y, fields[i].w, 3, edge);
        vita2d_draw_rectangle(fields[i].x, fields[i].y, 3, fields[i].h, edge);
        if (focused) {
            vita2d_draw_rectangle(fields[i].x + fields[i].w - 3, fields[i].y, 3,
                                  fields[i].h, ACCENT);
            vita2d_draw_rectangle(fields[i].x, fields[i].y + fields[i].h - 3,
                                  fields[i].w, 3, ACCENT);
        }
        draw_text(fields[i].x + 18, fields[i].y + 24, MUTED, 0.42f, labels[i]);
        if (values[i][0])
            draw_wrapped(values[i], fields[i].x + 18, fields[i].y + 52,
                         fields[i].w - 36, 0.47f, WHITE);
        else
            draw_text(fields[i].x + 18, fields[i].y + 56, MUTED, 0.48f,
                      i == 0 ? "Add a question" : "Add an answer");
    }
    if (create_status[0])
        draw_fit_text(72, 430, create_error ? RED : MUTED, 0.42f, create_status, 816);
    draw_compact_button((UiRect){60, 458, 210, 52}, "ADD CARD", ACCENT,
                        !header_focus_active && create_selection == create_add_selection());
    draw_compact_button((UiRect){294, 458, 210, 52}, creating_new ? "SAVE DECK" : "SAVE CARDS", GREEN,
                        !header_focus_active && create_selection == create_save_selection());
    draw_compact_button((UiRect){528, 458, 170, 52}, "CANCEL", RED,
                        !header_focus_active && create_selection == create_cancel_selection());
}

static void draw_deck_settings(void) {
    const char *name = (deck_settings_deck_index >= 0 && deck_settings_deck_index < deck_count)
        ? deck_entries[deck_settings_deck_index].name : "Selected deck";
    draw_header("Deck settings", name);
    const char *labels[6] = {"New cards per day", "Again learning step",
                             "Hard learning step", "Good first interval",
                             "Easy first interval", "Folder"};
    char values[6][FOLDER_NAME_SIZE];
    snprintf(values[0], sizeof(values[0]), "%d cards today",
             edit_deck_settings.new_card_limit + edit_deck_settings.new_cards_extra_today);
    snprintf(values[1], sizeof(values[1]), "%d min", edit_deck_settings.again_minutes);
    snprintf(values[2], sizeof(values[2]), "%d min", edit_deck_settings.hard_minutes);
    snprintf(values[3], sizeof(values[3]), "%d day%s", edit_deck_settings.good_days,
             edit_deck_settings.good_days == 1 ? "" : "s");
    snprintf(values[4], sizeof(values[4]), "%d day%s", edit_deck_settings.easy_days,
             edit_deck_settings.easy_days == 1 ? "" : "s");
    const char *folder = deck_settings_deck_index >= 0 && deck_settings_deck_index < deck_count
                       ? deck_entries[deck_settings_deck_index].folder : "";
    snprintf(values[5], sizeof(values[5]), "%s", folder[0] ? folder : "Unfiled");
    for (int i = 0; i < 6; i++) {
        int y = 106 + i * 52;
        UiRect row = {60, y, 840, 46};
        int focused = i == deck_settings_selection && !header_focus_active;
        vita2d_draw_rectangle(row.x, row.y, row.w, row.h,
                              focused ? PANEL_HI : PANEL);
        unsigned int edge = focused
                          ? (deck_settings_editing ? ACCENT : PANEL_HI) : PANEL_HI;
        vita2d_draw_rectangle(row.x, row.y, row.w, 3, edge);
        vita2d_draw_rectangle(row.x, row.y, 3, row.h, edge);
        if (focused) {
            vita2d_draw_rectangle(row.x + row.w - 3, row.y, 3, row.h, edge);
            vita2d_draw_rectangle(row.x, row.y + row.h - 3, row.w, 3, edge);
        }
        draw_text(82, y + 29, WHITE, 0.55f, labels[i]);
        draw_fit_text(510, y + 29, GREEN, 0.55f, values[i], 174);
        unsigned int adjust_color = focused && deck_settings_editing
                                  ? ACCENT : MUTED;
        draw_compact_button((UiRect){704, y + 3, 62, 40}, "-", adjust_color,
                            focused && deck_settings_editing);
        draw_compact_button((UiRect){778, y + 3, 62, 40}, "+", adjust_color,
                            focused && deck_settings_editing);
    }
    int renamable = deck_settings_deck_index >= 0 && deck_settings_deck_index < deck_count &&
                    deck_path_is_deletable(deck_entries[deck_settings_deck_index].path);
    int deletable = renamable;
    draw_compact_button(deck_browser_button, "CARD BROWSER", ACCENT,
                        deck_settings_selection == 6 && !header_focus_active);
    draw_compact_button(deck_rename_button, renamable ? "RENAME DECK" : "RENAME",
                        renamable ? YELLOW : MUTED,
                        renamable && deck_settings_selection == 8 && !header_focus_active);
    draw_compact_button(deck_delete_button, deletable ? "DELETE DECK" : "BUILT-IN DECK",
                        RED, deletable && deck_settings_selection == 7 && !header_focus_active);
    if (deck_status[0]) draw_fit_text(72, 524, RED, 0.40f, deck_status, 816);
}

static UiRect folder_action_rect(int action) {
    static const UiRect rects[] = {
        {60, 458, 220, 52}, {294, 458, 220, 52}, {528, 458, 220, 52}
    };
    return action >= 0 && action < 3 ? rects[action] : (UiRect){0, 0, 0, 0};
}

static void draw_folder_manager(void) {
    draw_header("Manage folders", "Organize decks into groups such as Biology, History, or Units.");
    int item_count = folder_count + 2;
    int first = folder_selection - 1;
    if (first < 0) first = 0;
    if (first + LIST_VISIBLE > item_count) first = item_count - LIST_VISIBLE;
    if (first < 0) first = 0;
    for (int row = 0; row < LIST_VISIBLE; row++) {
        int item = first + row;
        if (item >= item_count) break;
        UiRect rect = {60, LIST_ROW_Y + row * LIST_ROW_H, 360, 54};
        int selected = item == folder_selection && !folder_actions_focus && !header_focus_active;
        unsigned int edge = selected ? ACCENT : PANEL;
        vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, selected ? PANEL_HI : PANEL);
        vita2d_draw_rectangle(rect.x, rect.y, 4, rect.h, edge);
        if (selected) {
            vita2d_draw_rectangle(rect.x, rect.y, rect.w, 2, ACCENT);
            vita2d_draw_rectangle(rect.x + rect.w - 2, rect.y, 2, rect.h, ACCENT);
            vita2d_draw_rectangle(rect.x, rect.y + rect.h - 2, rect.w, 2, ACCENT);
        }
        const char *name = item == 0 ? "All folders" : item == 1 ? "Unfiled" : folder_names[item - 2];
        int deck_total = 0;
        for (int i = 0; i < deck_count; i++) {
            if (item == 0 ||
                (item == 1 && !deck_entries[i].folder[0]) ||
                (item >= 2 && !strcmp(deck_entries[i].folder, folder_names[item - 2])))
                deck_total++;
        }
        char detail[48];
        snprintf(detail, sizeof(detail), "%d deck%s", deck_total, deck_total == 1 ? "" : "s");
        draw_text(rect.x + 18, rect.y + 26, WHITE, 0.68f, name);
        draw_text(rect.x + 18, rect.y + 46, MUTED, 0.42f, detail);
    }
    UiRect members = {440, LIST_ROW_Y, 460, 4 * LIST_ROW_H + 8};
    vita2d_draw_rectangle(members.x, members.y, members.w, members.h, PANEL);
    vita2d_draw_rectangle(members.x, members.y, 4, members.h, ACCENT);
    const char *selected_name = folder_selection == 0 ? "All folders"
                              : folder_selection == 1 ? "Unfiled"
                              : folder_names[folder_selection - 2];
    draw_fit_text(members.x + 18, members.y + 28, WHITE, 0.60f,
                  selected_name, members.w - 34);
    draw_text(members.x + 18, members.y + 52, MUTED, 0.40f, "DECKS IN THIS GROUP");
    int shown = 0;
    int matching = 0;
    for (int i = 0; i < deck_count; i++) {
        int include = folder_selection == 0 ||
                      (folder_selection == 1 && !deck_entries[i].folder[0]) ||
                      (folder_selection >= 2 &&
                       !strcmp(deck_entries[i].folder, folder_names[folder_selection - 2]));
        if (!include) continue;
        if (shown < 5) {
            draw_fit_text(members.x + 22, members.y + 82 + shown * 34,
                          MUTED, 0.48f, deck_entries[i].name, members.w - 40);
            shown++;
        }
        matching++;
    }
    if (matching == 0)
        draw_fit_text(members.x + 22, members.y + 82, MUTED, 0.48f,
                      "No decks in this group yet.", members.w - 40);
    else if (matching > shown) {
        char more[48];
        snprintf(more, sizeof(more), "+%d more deck%s", matching - shown,
                 matching - shown == 1 ? "" : "s");
        draw_fit_text(members.x + 22, members.y + 82 + shown * 34,
                      MUTED, 0.44f, more, members.w - 40);
    }
    if (create_status[0])
        draw_fit_text(62, 432, create_error ? RED : GREEN, 0.43f, create_status, 814);
    const char *labels[3] = {"CREATE FOLDER", "RENAME FOLDER", "DONE"};
    unsigned int colors[3] = {GREEN, YELLOW, ACCENT};
    for (int action = 0; action < 3; action++) {
        int rename_available = folder_selection >= 2 && folder_selection - 2 < folder_count;
        draw_compact_button(folder_action_rect(action), labels[action],
                            action == 1 && !rename_available ? MUTED : colors[action],
                            folder_actions_focus && folder_action_selection == action);
    }
}

static void draw_delete_dialog(void) {
    vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, RGBA8(0, 0, 0, 190));
    vita2d_draw_rectangle(160, 140, 640, 264, PANEL_HI);
    vita2d_draw_rectangle(160, 140, 640, 4, RED);
    draw_text(196, 183, WHITE, 0.74f,
              delete_dialog_stage == 1 ? "Delete this deck?" : "Are you sure?");
    if (deck_settings_deck_index >= 0 && deck_settings_deck_index < deck_count)
        draw_fit_text(196, 226, ACCENT, 0.54f,
                      deck_entries[deck_settings_deck_index].name, 568);
    const char *message = delete_error
        ? "Could not delete. Check Vita storage and try again."
        : delete_dialog_stage == 1
            ? "This also removes this deck's saved study progress."
            : "This permanently deletes the deck from your Vita.";
    draw_fit_text(196, 274, delete_error ? RED : MUTED, 0.48f, message, 568);
    draw_compact_button((UiRect){220, 332, 220, 48},
                        delete_dialog_stage == 1 ? "CANCEL" : "KEEP DECK",
                        ACCENT, delete_selection == 0);
    draw_compact_button((UiRect){520, 332, 220, 48},
                        delete_dialog_stage == 1 ? "CONTINUE" : "DELETE DECK",
                        RED, delete_selection == 1);
}

static void draw_create_cancel_dialog(void) {
    vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, RGBA8(0, 0, 0, 190));
    vita2d_draw_rectangle(240, 190, 480, 180, PANEL_HI);
    vita2d_draw_rectangle(240, 190, 480, 4, RED);
    draw_text(274, 230, WHITE, 0.74f, "Discard this draft?");
    draw_wrapped("Cards in this unsaved deck will be removed.", 274, 270, 412, 0.52f, MUTED);
    draw_compact_button((UiRect){276, 310, 168, 42}, "DISCARD", RED, create_selection == 0);
    draw_compact_button((UiRect){466, 310, 168, 42}, "KEEP EDITING", GREEN, create_selection == 1);
}

static void cycle_setting(int setting, int direction) {
    if (setting == 0) {
        int previous_font_mode = font_mode;
        for (int step = 0; step < FONT_MODE_COUNT; step++) {
            int candidate = (font_mode +
                             (direction >= 0 ? step + 1 : FONT_MODE_COUNT - 1 - step) +
                             FONT_MODE_COUNT) % FONT_MODE_COUNT;
            if (font_mode_available(candidate)) {
                font_mode = candidate;
                break;
            }
        }
        if (font_mode != previous_font_mode) release_custom_font(previous_font_mode);
    } else if (setting == 1) {
        ui_text_mode = (ui_text_mode + (direction >= 0 ? 1 : 2)) % 3;
    } else if (setting == 2) {
        text_size_mode = (text_size_mode + (direction >= 0 ? 1 : 4)) % 5;
    } else if (setting == 3) {
        flip_animation_mode = !flip_animation_mode;
        if (!flip_animation_mode) flip_frames_remaining = 0;
    } else if (setting == 4) {
        show_card_images = !show_card_images;
        image_focus_open = 0;
        image_focus_pan_x = 0.0f;
        image_focus_pan_y = 0.0f;
        if (!show_card_images && card_image_texture) {
            vita2d_free_texture(card_image_texture);
            card_image_texture = NULL;
            card_image_path_cached[0] = '\0';
        }
    } else if (setting == 5) {
        large_study_buttons = !large_study_buttons;
    } else if (setting == 6) {
        review_control_mode = !review_control_mode;
    } else if (setting == 7) {
        browser_stick_mode = browser_stick_mode == BROWSER_STICK_BUTTONS
                           ? BROWSER_STICK_SCROLL : BROWSER_STICK_BUTTONS;
        analog_input_latched = 0;
    } else if (setting == 8) {
        confetti_mode = (confetti_mode + (direction >= 0 ? 1 : 2)) % 3;
        if (confetti_mode == 0) clear_confetti();
    } else if (setting == 9) {
        /* Keep custom editing reachable without trapping the user on the custom value. */
        int theme_count = THEME_CUSTOM_MODE + 1;
        color_theme_mode = (color_theme_mode + (direction >= 0 ? 1 : theme_count - 1)) % theme_count;
        apply_color_theme(color_theme_mode);
        vita2d_set_clear_color(BG);
    } else if (setting == 10) {
#ifndef VITAANKI_DISABLE_MUSIC
        toggle_music();
#endif
        return;
    } else if (setting == 11) {
#ifndef VITAANKI_DISABLE_MUSIC
        click_sounds_enabled = !click_sounds_enabled;
#endif
    } else if (setting == 12) {
#ifndef VITAANKI_DISABLE_MUSIC
        click_volume = (click_volume + (direction >= 0 ? 1 : 2)) % 3;
        anki_music_set_click_volume(click_volume);
#endif
    }
    save_settings();
}

static void open_custom_theme_editor(void) {
    theme_editor_focus = (custom_background_color / 4) * 8 + (custom_background_color % 4);
    apply_color_theme(THEME_CUSTOM_MODE);
    vita2d_set_clear_color(BG);
    save_settings();
    current_screen = SCREEN_THEME_EDITOR;
}

static void move_settings_focus(int direction) {
    int column = settings_selection >= 6 ? 1 : 0;
    int row = column ? settings_selection - 6 : settings_selection;
    int row_count = column ? 7 : 6;

    if (direction == 0) {
        if (row == 0) {
            header_focus_active = 1;
            return;
        }
        row--;
    } else if (direction == 1) {
        if (row + 1 < row_count) row++;
    } else if (direction == 2 && column == 1) {
        column = 0;
        if (row > 5) row = 5;
    } else if (direction == 3 && column == 0) {
        column = 1;
    }

    settings_selection = column ? row + 6 : row;
    settings_edit_armed = 0;
}

static void draw_settings(void) {
    draw_header("Settings", "Reading, study, and sound");
    const char *font_label = font_labels[font_mode];
#ifdef VITAANKI_DISABLE_MUSIC
    const char *music_label = "Disabled in this stability build";
    const char *music_title = "Background music (disabled)";
    const char *click_title = "Button sounds (disabled)";
    const char *click_volume_title = "Click volume (disabled)";
    const char *click_enabled_label = "Disabled";
    const char *click_volume_label = "Disabled";
#else
    const char *music_label = anki_music_is_muted() ? "Muted"
                          : anki_music_is_available() ? "Playing"
                          : anki_music_is_running() ? "Starting..."
                          : "Unavailable / see music.log";
    const char *music_title = "Background music";
    const char *click_title = "Button click sounds";
    const char *click_volume_title = "Click sound volume";
    const char *click_enabled_label = click_sounds_enabled ? "On" : "Off";
    const char *click_volume_label = click_volume_labels[click_volume];
#endif
    const char *titles[SETTINGS_COUNT] = {"Font", "Menu and labels", "Card text size", "Answer flip",
                                          "Show card images", "Study button size",
                                          "Rating controls", "Card Browser stick input", "Confetti",
                                          "Color theme", music_title, click_title,
                                          click_volume_title};
    const char *theme_label = color_theme_mode == THEME_CUSTOM_MODE
                            ? "Custom" : color_theme_labels[color_theme_mode];
    const char *values[SETTINGS_COUNT] = {font_label, ui_text_labels[ui_text_mode],
                                          text_size_labels[text_size_mode], flip_animation_labels[flip_animation_mode],
                                          show_card_images ? "On" : "Off",
                                          large_study_buttons ? "Large" : "Compact",
                                          review_control_mode ? "Analog ratings" : "Buttons + touch",
                                          browser_stick_mode == BROWSER_STICK_BUTTONS
                                              ? "Select actions" : "Card scrolling",
                                          confetti_labels[confetti_mode],
                                          theme_label, music_label,
                                          click_enabled_label,
                                          click_volume_label};
    unsigned int colors[SETTINGS_COUNT] = {ACCENT, ACCENT, GREEN, ACCENT, GREEN, YELLOW,
                                           GREEN, ACCENT, RED, ACCENT, YELLOW, YELLOW, YELLOW};
    draw_fit_text(64, 112, ACCENT, 0.48f, "READING & CARDS", 390);
    draw_fit_text(500, 112, YELLOW, 0.48f, "STUDY & SOUND", 390);
    for (int i = 0; i < SETTINGS_COUNT; i++) {
        UiRect row = settings_rows[i];
        int chosen = i == settings_selection && !header_focus_active;
        vita2d_draw_rectangle(row.x, row.y, row.w, row.h,
                              chosen ? PANEL_HI : PANEL);
        vita2d_draw_rectangle(row.x, row.y, 4, row.h, colors[i]);
        if (chosen) {
            unsigned int focus_color = settings_edit_armed ? ACCENT : colors[i];
            vita2d_draw_rectangle(row.x, row.y, row.w, 2, focus_color);
            vita2d_draw_rectangle(row.x + row.w - 2, row.y, 2, row.h, focus_color);
            vita2d_draw_rectangle(row.x, row.y + row.h - 2, row.w, 2, focus_color);
        }
        draw_fit_text(row.x + 14, row.y + 19, WHITE, 0.49f, titles[i], 292);
        draw_fit_text(row.x + 14, row.y + 39, MUTED, 0.38f, values[i], 292);
        unsigned int arrow_fill = chosen && settings_edit_armed ? PANEL_HI : PANEL;
        vita2d_draw_rectangle(row.x + 320, row.y + 4, 42, 34, arrow_fill);
        vita2d_draw_rectangle(row.x + 372, row.y + 4, 42, 34, arrow_fill);
        unsigned int arrow_color = chosen && settings_edit_armed ? colors[i] : MUTED;
        draw_text(row.x + 332, row.y + 27, arrow_color, 0.48f, "<");
        draw_text(row.x + 384, row.y + 27, arrow_color, 0.48f, ">");
    }
    vita2d_draw_rectangle(52, 452, 856, 62, PANEL);
    vita2d_draw_rectangle(52, 452, 5, 62, ACCENT);
    draw_fit_text(76, 488, MUTED, 0.42f, "PREVIEW", 112);
    draw_card_text(210, 489, WHITE, 0.70f, "Aa Bb 123");
}

static UiRect custom_theme_swatch_rect(int row, int index) {
    int base_x = row == 0 ? 48 : 500;
    return (UiRect){base_x + (index % 4) * 96, 158 + (index / 4) * 62, 88, 54};
}

static void apply_custom_theme_swatch(int cell) {
    int grid_row = cell / 8;
    int grid_column = cell % 8;
    int color_index = grid_row * 4 + (grid_column % 4);
    if (grid_column < 4) custom_background_color = color_index;
    else custom_accent_color = color_index;
    apply_color_theme(THEME_CUSTOM_MODE);
    vita2d_set_clear_color(BG);
    save_settings();
}

static void draw_custom_theme_editor(void) {
    draw_header("Custom theme", "App colors");
    draw_text(48, 136, WHITE, 0.58f, "BACKGROUND");
    draw_text(500, 136, WHITE, 0.58f, "APP ACCENT");
    for (int row = 0; row < 2; row++) {
        for (int index = 0; index < CUSTOM_COLOR_COUNT; index++) {
            UiRect rect = custom_theme_swatch_rect(row, index);
            int chosen = row == 0 ? index == custom_background_color
                                  : index == custom_accent_color;
            int cell = (index / 4) * 8 + (row == 0 ? index % 4 : 4 + index % 4);
            int focused = cell == theme_editor_focus;
            unsigned int color = row == 0 ? custom_background_colors[index]
                                          : custom_accent_colors[index];
            vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, color);
            unsigned int border = chosen ? ACCENT : PANEL_HI;
            int thickness = chosen ? 3 : 2;
            vita2d_draw_rectangle(rect.x, rect.y, rect.w, thickness, border);
            vita2d_draw_rectangle(rect.x, rect.y + rect.h - thickness,
                                  rect.w, thickness, border);
            vita2d_draw_rectangle(rect.x, rect.y, thickness, rect.h, border);
            vita2d_draw_rectangle(rect.x + rect.w - thickness, rect.y,
                                  thickness, rect.h, border);
            if (focused) {
                vita2d_draw_rectangle(rect.x - 4, rect.y - 4, rect.w + 8, 2,
                                      RGBA8(0, 0, 0, 255));
                vita2d_draw_rectangle(rect.x - 4, rect.y + rect.h + 2,
                                      rect.w + 8, 2, RGBA8(0, 0, 0, 255));
                vita2d_draw_rectangle(rect.x - 4, rect.y - 4, 2,
                                      rect.h + 8, RGBA8(0, 0, 0, 255));
                vita2d_draw_rectangle(rect.x + rect.w + 2, rect.y - 4, 2,
                                      rect.h + 8, RGBA8(0, 0, 0, 255));
                vita2d_draw_rectangle(rect.x - 3, rect.y - 3, rect.w + 6, 2, WHITE);
                vita2d_draw_rectangle(rect.x - 3, rect.y + rect.h + 1,
                                      rect.w + 6, 2, WHITE);
                vita2d_draw_rectangle(rect.x - 3, rect.y - 3, 2, rect.h + 6, WHITE);
                vita2d_draw_rectangle(rect.x + rect.w + 1, rect.y - 3,
                                      2, rect.h + 6, WHITE);
            }
        }
    }
    int preview_y = 358;
    vita2d_draw_rectangle(48, preview_y, 864, 116, PANEL);
    vita2d_draw_rectangle(48, preview_y, 5, 116, ACCENT);
    draw_text(72, preview_y + 32, WHITE, 0.56f, "Aa Bb 123");
    static const char *rating_labels[] = {"AGAIN", "HARD", "GOOD", "EASY"};
    for (int i = 0; i < 4; i++)
        draw_compact_button((UiRect){350 + i * 134, preview_y + 34, 124, 48},
                            rating_labels[i], ACCENT, 0);
}

static void draw_flip_overlay(void) {
    if (flip_frames_remaining <= 0) return;
    const int x = 70, y = 140, width = 836, height = 291;
    int progress = CARD_FLIP_FRAMES - flip_frames_remaining;
    int half = CARD_FLIP_FRAMES / 2;
    int visible_width = progress <= half
                      ? width * (half - progress) / half
                      : width * (progress - half) / half;
    int cover_width = (width - visible_width) / 2;
    if (cover_width > 0) {
        vita2d_draw_rectangle(x, y, cover_width, height, PANEL);
        vita2d_draw_rectangle(x + width - cover_width, y, cover_width, height, PANEL);
    }
    if (progress > 0 && progress < CARD_FLIP_FRAMES) {
        int edge_left = x + cover_width - 1;
        int edge_right = x + cover_width + visible_width - 1;
        vita2d_draw_rectangle(edge_left, y + 4, 2, height - 8, ACCENT);
        if (visible_width > 4)
            vita2d_draw_rectangle(edge_right, y + 4, 2, height - 8, ACCENT);
    }
}

static UiRect study_card_panel_rect(void) {
    return (UiRect){48, 104, 864, large_study_buttons ? 334 : 376};
}

static UiRect study_button_rect(int index) {
    if (large_study_buttons)
        return (UiRect){50 + index * 174, 458, 164, 60};
    return (UiRect){230 + index * 102, 490, 92, 40};
}

static UiRect study_image_rect(void) {
    return large_study_buttons
         ? (UiRect){SPLIT_CARD_IMAGE_X, SPLIT_CARD_IMAGE_Y,
                    SPLIT_CARD_IMAGE_WIDTH, SPLIT_CARD_IMAGE_HEIGHT}
         : (UiRect){390, 136, 510, 330};
}

static void draw_study_key_icon(UiRect rect, int index, int enabled, unsigned int panel_fill) {
    int center_x = rect.x + rect.w / 2;
    int center_y = rect.y + rect.h / 2;
    int radius = rect.h >= 50 ? 11 : 8;
    unsigned int color = enabled ? WHITE : MUTED;
    if (index == 1) color = enabled ? RED : MUTED;
    else if (index == 2) color = enabled ? YELLOW : MUTED;
    else if (index == 3) color = enabled ? GREEN : MUTED;

    if (index == 0) {
        vita2d_draw_line((float)(center_x - radius + 1), (float)(center_y - radius + 1),
                         (float)(center_x + radius - 1), (float)(center_y + radius - 1), color);
        vita2d_draw_line((float)(center_x + radius - 1), (float)(center_y - radius + 1),
                         (float)(center_x - radius + 1), (float)(center_y + radius - 1), color);
    } else if (index == 1) {
        vita2d_draw_line((float)center_x, (float)(center_y - radius),
                         (float)(center_x + radius), (float)(center_y + radius - 1), color);
        vita2d_draw_line((float)(center_x + radius), (float)(center_y + radius - 1),
                         (float)(center_x - radius), (float)(center_y + radius - 1), color);
        vita2d_draw_line((float)(center_x - radius), (float)(center_y + radius - 1),
                         (float)center_x, (float)(center_y - radius), color);
    } else if (index == 2) {
        int side = radius * 2 - 2;
        int thickness = rect.h >= 50 ? 3 : 2;
        vita2d_draw_rectangle(center_x - radius + 1, center_y - radius + 1,
                              side, thickness, color);
        vita2d_draw_rectangle(center_x - radius + 1, center_y + radius - thickness,
                              side, thickness, color);
        vita2d_draw_rectangle(center_x - radius + 1, center_y - radius + 1,
                              thickness, side, color);
        vita2d_draw_rectangle(center_x + radius - thickness, center_y - radius + 1,
                              thickness, side, color);
    } else if (index == 3) {
        vita2d_draw_fill_circle((float)center_x, (float)center_y, (float)radius, color);
        vita2d_draw_fill_circle((float)center_x, (float)center_y,
                                (float)(radius - 3), panel_fill);
    } else {
        float scale = rect.h >= 50 ? 0.66f : 0.55f;
        int r_width = text_width(scale, "R");
        draw_text(center_x - r_width / 2, center_y + (rect.h >= 50 ? 8 : 7), color,
                  scale, "R");
        int stripe_width = rect.h >= 50 ? 48 : 36;
        int segment_width = stripe_width / 6;
        int stripe_x = center_x - stripe_width / 2;
        for (int segment = 0; segment < 6; segment++)
            vita2d_draw_rectangle(stripe_x + segment * segment_width,
                                  center_y + (rect.h >= 50 ? 12 : 10), segment_width, 3,
                                  enabled ? RAINBOW_COLORS[segment] : MUTED);
    }
}

static void draw_study(void) {
    if (!live_sync && reset_daily_new_card_state(&current_deck_settings)) {
        if (current_deck_path[0])
            save_deck_study_settings(current_deck_path, current_deck_settings);
        if (!has_study_card()) card_index = find_next_due();
    }
    const char *study_deck_name = live_sync ? anki_connect_get_deck_name() : current_deck_name;
    char all_decks_label[160];
    if (!study_deck_name || !study_deck_name[0]) study_deck_name = current_deck_name;
    if (all_decks_mode) {
        snprintf(all_decks_label, sizeof(all_decks_label), "All decks  |  %s", study_deck_name);
        study_deck_name = all_decks_label;
    }
    draw_header("Study", NULL);
    draw_fit_text(148, 78, MUTED, 0.5f, study_deck_name, 540);
    int counts_available = 0;
    AnkiStudyCounts counts = current_study_counts(&counts_available);
    if (all_decks_mode && counts_available) {
        counts.new_count = 0;
        counts.learning_count = 0;
        counts.review_count = all_decks_due_total;
    }
    if (counts_available && !live_sync) {
        int daily_limit = current_deck_settings.new_card_limit + current_deck_settings.new_cards_extra_today;
        int remaining = daily_limit - current_deck_settings.new_cards_today;
        if (remaining < 0) remaining = 0;
        if (counts.new_count > remaining) counts.new_count = remaining;
    }
    char new_text[24], learning_text[24], review_text[24], done_text[24];
    if (counts_available) {
        if (all_decks_mode) snprintf(new_text, sizeof(new_text), "NEW --");
        else snprintf(new_text, sizeof(new_text), "NEW %d", counts.new_count);
        snprintf(learning_text, sizeof(learning_text), "LEARN %d", counts.learning_count);
        snprintf(review_text, sizeof(review_text), all_decks_mode ? "DUE %d" : "REVIEW %d",
                 counts.review_count);
    } else {
        snprintf(new_text, sizeof(new_text), "NEW --");
        snprintf(learning_text, sizeof(learning_text), "LEARN --");
        snprintf(review_text, sizeof(review_text), "REVIEW --");
    }
    snprintf(done_text, sizeof(done_text), "DONE %d", reviewed);
    draw_fit_text(518, 78, ACCENT, 0.42f, new_text, 82);
    draw_fit_text(604, 78, YELLOW, 0.42f, learning_text, 92);
    draw_fit_text(700, 78, GREEN, 0.42f, review_text, 104);
    draw_fit_text(808, 78, MUTED, 0.42f, done_text, 100);

    int has_card = has_study_card();
    unsigned int card_state_color = ACCENT;
    if (has_card && cards[card_index].state == CARD_STATE_LEARNING)
        card_state_color = YELLOW;
    else if (has_card && cards[card_index].state == CARD_STATE_REVIEW)
        card_state_color = GREEN;
    UiRect card_panel = study_card_panel_rect();
    vita2d_draw_rectangle(card_panel.x, card_panel.y, card_panel.w, card_panel.h, PANEL);
    vita2d_draw_rectangle(card_panel.x, card_panel.y, 7, card_panel.h, card_state_color);
    draw_compact_button(undo_button, "UNDO", undo_record.valid ? YELLOW : MUTED, 0);
    int answer_visible = displayed_answer_side();
    const char *visible_text = has_card
                             ? (answer_visible ? cards[card_index].back : cards[card_index].front)
                             : "";
    const char *visible_image = has_card && !answer_visible && show_card_images
                              ? cards[card_index].front_image : "";
    int split_card = visible_image[0] != '\0';
    int split_text_width = large_study_buttons ? SPLIT_CARD_TEXT_WIDTH : 290;
    float split_text_scale = large_study_buttons ? 0.84f : 0.76f;
    int text_width = split_card ? split_text_width : 790;
    float text_scale = split_card ? split_text_scale : 0.95f;
    int text_height = split_card ? (large_study_buttons ? 210 : 260)
                                 : (large_study_buttons ? 205 : 245);
    UiRect image_rect = study_image_rect();
    if (has_card) {
        int limit = card_scroll_limit(visible_text, text_width, text_scale, text_height);
        if (card_scroll_position > (float)limit) card_scroll_position = (float)limit;
    }
    if (card_count <= 0) {
        if (live_sync && !sync_error) {
            int learning_pending = anki_connect_has_learning_cards();
            draw_text(82, 160, learning_pending ? YELLOW : MUTED, 0.72f,
                      learning_pending ? "LEARNING STEP WAITING" : "NO CARDS DUE");
            draw_wrapped(learning_pending
                             ? "Anki has cards in learning. VitaAnki checks for the next due learning step every 10 seconds."
                             : "This deck has no new or due cards right now. Check back after another card becomes due.",
                         82, 225, 780, 0.78f, WHITE);
        } else {
            draw_text(82, 160, MUTED, 0.72f,
                      import_error ? "DECK COULD NOT BE LOADED" : "NO STUDY CARDS LOADED");
            draw_wrapped(import_error
                             ? "The selected deck could not be read. Open Decks, rescan, and choose it again."
                             : "The current deck has no available study cards. Choose another deck, or re-import this one if cards are missing.",
                         82, 225, 780, 0.78f, WHITE);
        }
    } else if (!has_card) {
        int unseen_new = unseen_new_card_count();
        if (all_decks_mode && has_next_all_due_deck()) {
            draw_text(82, 160, ACCENT, 0.72f, "NEXT DECK READY");
            draw_wrapped("This deck has no more cards due. Continue to the next deck with due reviews.",
                         82, 225, 780, 0.72f, WHITE);
                draw_compact_button(study_more_button, "NEXT DUE DECK", GREEN,
                                    !header_focus_active);
        } else if (all_decks_mode) {
            draw_text(82, 160, GREEN, 0.72f, "ALL DUE CARDS COMPLETE");
            draw_wrapped("There are no more review or learning cards due across your decks.",
                         82, 225, 780, 0.72f, WHITE);
        } else if (unseen_new > 0 && study_more_available()) {
            draw_text(82, 160, ACCENT, 0.72f, "NO MORE NEW CARDS TODAY");
            int increment = study_more_increment();
            int daily_limit = current_deck_settings.new_card_limit +
                              current_deck_settings.new_cards_extra_today;
            char message[256];
            snprintf(message, sizeof(message),
                     "You've reached today's limit of %d new cards. Study More adds %d more; you can choose it again after that batch.",
                     daily_limit, increment);
            draw_wrapped(message, 82, 225, 780, 0.72f, WHITE);
            if (increment > 0) {
                char button_label[48];
                snprintf(button_label, sizeof(button_label), "STUDY %d MORE", increment);
                draw_compact_button(study_more_button, button_label, ACCENT,
                                    !header_focus_active);
            }
        } else {
            draw_text(82, 160, GREEN, 0.72f, "SESSION COMPLETE");
            draw_wrapped(counts.learning_count > 0
                             ? "A learning step is waiting and will return when due. Open this deck's settings to browse cards."
                             : "Nothing is due right now. Open this deck's settings to preview cards, or come back when the next card is due.",
                         82, 225, 780, 0.78f, WHITE);
        }
    } else if (!answer_visible) {
        draw_text(82, 156, MUTED, 0.66f, "QUESTION");
        draw_card_viewport(visible_text, 82, split_card ? 205 : 222, text_width, text_scale,
                           WHITE, card_scroll_position, text_height);
        draw_card_scrollbar(visible_text, split_card ? (large_study_buttons ? 424 : 376) : 890,
                            split_card ? 205 : 222,
                            text_width, text_scale, card_scroll_position, text_height);
        if (split_card)
            draw_card_image_half(visible_image, image_rect.x, image_rect.y,
                                 image_rect.w, image_rect.h);
    } else {
        draw_text(82, 156, MUTED, 0.66f, "ANSWER");
        draw_card_viewport(visible_text, 82, 222, 790, 0.95f,
                           WHITE, card_scroll_position, 205);
        draw_card_scrollbar(visible_text, 890, 222, 790, 0.95f,
                            card_scroll_position, 205);
    }

    unsigned int accents[5] = {ACCENT, RED, YELLOW, GREEN, ACCENT};
    for (int i = 0; i < 5; i++) {
        UiRect rect = study_button_rect(i);
        int enabled = has_card && flip_frames_remaining == 0 && (i == 0 || answer_visible);
        int selected = review_control_mode && !header_focus_active && i > 0 &&
                       i - 1 == selected_rating;
        unsigned int panel_fill = selected ? PANEL_HI : enabled ? PANEL : BG;
        vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, panel_fill);
        if (enabled && i == 4) {
            for (int segment = 0; segment < 6; segment++)
                vita2d_draw_rectangle(rect.x + segment * rect.w / 6, rect.y,
                                      (segment + 1) * rect.w / 6 - segment * rect.w / 6,
                                      3, RAINBOW_COLORS[segment]);
        } else {
            vita2d_draw_rectangle(rect.x, rect.y, rect.w, 3,
                                  enabled ? accents[i] : PANEL_HI);
        }
        if (selected) {
            vita2d_draw_rectangle(rect.x, rect.y, 3, rect.h, accents[i]);
            vita2d_draw_rectangle(rect.x + rect.w - 3, rect.y, 3, rect.h, accents[i]);
            vita2d_draw_rectangle(rect.x, rect.y + rect.h - 3, rect.w, 3, accents[i]);
        }
        draw_study_key_icon(rect, i, enabled, panel_fill);
    }
    if (undo_error)
        draw_fit_text(50, 533, RED, 0.40f,
                      "Undo failed. Check the Anki connection or pending review queue.",
                      860);
    draw_flip_overlay();
}

static void move_browser(int direction) {
    if (card_count <= 0) return;
    image_focus_open = 0;
    image_focus_pan_x = 0.0f;
    image_focus_pan_y = 0.0f;
    browser_index += direction;
    if (browser_index < 0) browser_index = card_count - 1;
    else if (browser_index >= card_count) browser_index = 0;
    browser_show_answer = 0;
    browser_scroll_position = 0.0f;
}

static void open_image_viewer(void) {
    if (!focused_image_path()[0]) return;
    header_focus_active = 0;
    image_focus_open = 1;
    image_focus_zoom = 1.5f;
    image_focus_pan_x = 0.0f;
    image_focus_pan_y = 0.0f;
    clamp_image_viewer_pan();
}

static void draw_browser(void) {
    draw_header("Card browser", current_deck_name);
    char status[64];
    snprintf(status, sizeof(status), "CARD %d OF %d", card_count > 0 ? browser_index + 1 : 0,
             card_count);
    draw_fit_text(748, 78, MUTED, 0.46f, status, 164);

    vita2d_draw_rectangle(48, 104, 864, 334, PANEL);
    vita2d_draw_rectangle(48, 104, 7, 334, ACCENT);
    if (card_count > 0) {
        int split = show_card_images && !browser_show_answer && cards[browser_index].front_image[0];
        int limit = card_scroll_limit(browser_card_text(), split ? SPLIT_CARD_TEXT_WIDTH : 790,
                                      split ? 0.84f : 0.95f, split ? 210 : 160);
        if (browser_scroll_position > (float)limit) browser_scroll_position = (float)limit;
    }
    if (card_count <= 0) {
        draw_text(82, 160, MUTED, 0.72f, "NO CARDS TO BROWSE");
        draw_wrapped("Open Import to add an Anki package or tab-separated deck.",
                     82, 222, 780, 0.78f, WHITE);
    } else {
        draw_text(82, 156, MUTED, 0.66f, browser_show_answer ? "ANSWER" : "QUESTION");
        int split = show_card_images && !browser_show_answer && cards[browser_index].front_image[0];
        draw_card_viewport(browser_card_text(), 82, split ? 205 : 222,
                           split ? SPLIT_CARD_TEXT_WIDTH : 790,
                           split ? 0.84f : 0.95f, WHITE, browser_scroll_position, split ? 210 : 160);
        draw_card_scrollbar(browser_card_text(), split ? 424 : 890, split ? 205 : 222,
                            split ? SPLIT_CARD_TEXT_WIDTH : 790, split ? 0.84f : 0.95f,
                            browser_scroll_position, split ? 210 : 160);
        if (split && show_card_images)
            draw_card_image_half(cards[browser_index].front_image, SPLIT_CARD_IMAGE_X,
                                 SPLIT_CARD_IMAGE_Y, SPLIT_CARD_IMAGE_WIDTH,
                                 SPLIT_CARD_IMAGE_HEIGHT);
    }

    int button_focus = browser_stick_mode == BROWSER_STICK_BUTTONS && !header_focus_active;
    draw_compact_button((UiRect){50, 458, 180, 52}, "PREVIOUS", ACCENT,
                        button_focus && browser_button_selection == 0);
    draw_compact_button(browser_jump_button, "JUMP TO CARD", YELLOW,
                        button_focus && browser_button_selection == 1);
    draw_compact_button((UiRect){440, 458, 310, 52},
                        browser_show_answer ? "SHOW QUESTION" : "SHOW ANSWER", GREEN,
                        button_focus && browser_button_selection == 2);
    draw_compact_button((UiRect){760, 458, 150, 52}, "NEXT", ACCENT,
                        button_focus && browser_button_selection == 3);
}

static UiRect jump_key_rect(int index) {
    int row = index / 3;
    int column = index % 3;
    return (UiRect){356 + column * 84, 204 + row * 44, 76, 38};
}

static void open_jump_dialog(void) {
    if (card_count <= 0) return;
    jump_dialog_open = 1;
    jump_selection = 13;
    jump_input[0] = '\0';
    jump_error = 0;
}

static void jump_to_entered_card(void) {
    if (!jump_input[0]) {
        jump_error = 1;
        return;
    }
    long number = strtol(jump_input, NULL, 10);
    if (number < 1 || number > card_count) {
        jump_error = 1;
        return;
    }
    browser_index = (int)number - 1;
    browser_show_answer = 0;
    browser_scroll_position = 0.0f;
    jump_dialog_open = 0;
    jump_error = 0;
}

static void activate_browser_button(void) {
    if (card_count <= 0) return;
    if (browser_button_selection == 0) move_browser(-1);
    else if (browser_button_selection == 1) open_jump_dialog();
    else if (browser_button_selection == 2) {
        browser_show_answer = !browser_show_answer;
        browser_scroll_position = 0.0f;
    } else move_browser(1);
}

static void activate_jump_selection(void) {
    if (jump_selection >= 0 && jump_selection <= 8) {
        size_t length = strlen(jump_input);
        if (length + 1 < sizeof(jump_input)) {
            jump_input[length] = (char)('1' + jump_selection);
            jump_input[length + 1] = '\0';
        }
        jump_error = 0;
    } else if (jump_selection == 9) {
        jump_input[0] = '\0';
        jump_error = 0;
    } else if (jump_selection == 10) {
        size_t length = strlen(jump_input);
        if (length + 1 < sizeof(jump_input)) {
            jump_input[length] = '0';
            jump_input[length + 1] = '\0';
        }
        jump_error = 0;
    } else if (jump_selection == 11) {
        size_t length = strlen(jump_input);
        if (length > 0) jump_input[length - 1] = '\0';
        jump_error = 0;
    } else if (jump_selection == 12) {
        jump_dialog_open = 0;
    } else if (jump_selection == 13) {
        jump_to_entered_card();
    }
}

static void move_jump_selection(unsigned int pressed) {
    if (jump_selection >= 12) {
        if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))
            jump_selection = jump_selection == 12 ? 13 : 12;
        else if (pressed & SCE_CTRL_UP)
            jump_selection = jump_selection == 12 ? 9 : 10;
        return;
    }

    int row = jump_selection / 3;
    int column = jump_selection % 3;
    if (pressed & SCE_CTRL_LEFT) column = (column + 2) % 3;
    else if (pressed & SCE_CTRL_RIGHT) column = (column + 1) % 3;
    else if (pressed & SCE_CTRL_UP) row = row > 0 ? row - 1 : 3;
    else if (pressed & SCE_CTRL_DOWN) {
        if (row < 3) row++;
        else jump_selection = column == 0 ? 12 : 13;
    }
    if (jump_selection < 12) jump_selection = row * 3 + column;
}

static void draw_jump_dialog(void) {
    vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, RGBA8(0, 0, 0, 190));
    vita2d_draw_rectangle(220, 78, 520, 398, PANEL_HI);
    vita2d_draw_rectangle(220, 78, 520, 4, ACCENT);
    draw_text(252, 112, WHITE, 0.82f, "Jump to a card");

    vita2d_draw_rectangle(356, 126, 248, 42, PANEL);
    if (jump_input[0]) draw_text(378, 155, WHITE, 0.72f, jump_input);
    else draw_text(378, 155, MUTED, 0.56f, "Card number");
    char range[80];
    snprintf(range, sizeof(range), "Enter a number from 1 to %d", card_count);
    const char *range_message = jump_error
        ? (jump_input[0] ? "That card number is out of range." : "Enter a card number first.")
        : range;
    draw_fit_text(356, 190, jump_error ? RED : MUTED, 0.46f, range_message, 350);

    static const char *labels[12] = {"1", "2", "3", "4", "5", "6", "7", "8", "9",
                                     "CLR", "0", "DEL"};
    for (int i = 0; i < 12; i++)
        draw_compact_button(jump_key_rect(i), labels[i], ACCENT, jump_selection == i);
    draw_compact_button((UiRect){340, 397, 138, 42}, "CANCEL", RED, jump_selection == 12);
    draw_compact_button((UiRect){482, 397, 138, 42}, "GO", GREEN, jump_selection == 13);
}

static void draw_ui(void) {
    vita2d_start_drawing();
    vita2d_clear_screen();
    vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, BG);
    if (current_screen == SCREEN_HOME) draw_home();
    else if (current_screen == SCREEN_STUDY) draw_study();
    else if (current_screen == SCREEN_BROWSER) draw_browser();
    else if (current_screen == SCREEN_DECKS) draw_deck_list(0);
    else if (current_screen == SCREEN_IMPORT) draw_deck_list(1);
    else if (current_screen == SCREEN_SETTINGS) draw_settings();
    else if (current_screen == SCREEN_SYNC) draw_sync();
    else if (current_screen == SCREEN_ANDROID_TRANSFER) draw_android_transfer();
    else if (current_screen == SCREEN_CREATE_DECK) draw_create_deck();
    else if (current_screen == SCREEN_CREATE_TARGET) draw_create_target_picker();
    else if (current_screen == SCREEN_DECK_SETTINGS) draw_deck_settings();
    else if (current_screen == SCREEN_THEME_EDITOR) draw_custom_theme_editor();
    else if (current_screen == SCREEN_FOLDERS) draw_folder_manager();
    if ((current_screen == SCREEN_BROWSER || current_screen == SCREEN_STUDY) && image_focus_open)
        draw_image_viewer();
    if (!image_focus_open) draw_confetti();
    if (jump_dialog_open) draw_jump_dialog();
    if (delete_dialog_open) draw_delete_dialog();
    if (create_cancel_dialog_open) draw_create_cancel_dialog();
    vita2d_end_drawing();
    if (create_ime_open) vita2d_common_dialog_update();
    vita2d_swap_buffers();
}

static void begin_pc_sync(void) {
    sync_error = 0;
    sync_message[0] = '\0';
    if (!anki_connect_is_configured()) {
        sync_error = 1;
        snprintf(sync_message, sizeof(sync_message), "%s", anki_connect_get_status());
        return;
    }

    if (!vitaanki_reserve_cards(&cards, &card_capacity, MAX_CARDS)) {
        sync_error = 1;
        snprintf(sync_message, sizeof(sync_message), "Not enough memory to prepare the live card list.");
        return;
    }

    int already_live = live_sync;
    int offline_index = current_deck_index;
    int loaded = already_live ? anki_connect_reload(cards, card_capacity)
                              : anki_connect_start(cards, card_capacity);
    if (loaded >= 0 && anki_connect_is_configured()) {
        card_count = loaded;
        live_sync = 1;
        sync_error = 0;
        reviewed = 0;
        show_answer = 0;
        flip_frames_remaining = 0;
        card_scroll_position = 0.0f;
        selected_rating = 2;
        undo_record.valid = 0;
        undo_error = 0;
        card_index = 0;
        live_refresh_after = time(NULL) + LIVE_REFRESH_SECONDS;
        snprintf(current_deck_name, sizeof(current_deck_name), "%s", anki_connect_get_deck_name());
        snprintf(sync_message, sizeof(sync_message), "Live deck selected: %.96s. Return Home and choose Study.",
                 current_deck_name);
        current_screen = SCREEN_SYNC;
    } else {
        if (anki_connect_is_configured())
            snprintf(sync_message, sizeof(sync_message), "%s", anki_connect_get_status());
        else
            snprintf(sync_message, sizeof(sync_message), "Sync settings are missing or invalid");
        sync_error = 1;
        anki_connect_stop();
        live_sync = 0;
        live_refresh_after = 0;
        if (offline_index >= 0 && offline_index < deck_count) {
            if (!select_deck(offline_index)) load_demo_deck();
        } else {
            load_demo_deck();
        }
        sync_error = 1;
        current_screen = SCREEN_SYNC;
    }
}

static void activate_home_selection(void) {
    if (home_selection == 0) {
        if (!live_sync && card_count == 0 && current_deck_index >= 0 &&
            current_deck_index < deck_count) {
            if (!select_deck(current_deck_index)) return;
        } else if (!live_sync && card_index < 0) {
            new_cards_this_session = 0;
            card_index = find_next_due();
            show_answer = 0;
        }
        current_screen = SCREEN_STUDY;
    }
    else if (home_selection == 1) {
        scan_decks();
        list_focus_actions = 0;
        deck_list_gear_focus = 0;
        int visible = visible_position_for_deck(current_deck_index);
        list_selection = visible >= 0 ? visible + 1 : 0;
        current_screen = SCREEN_DECKS;
    } else if (home_selection == 2) {
        open_create_deck();
    } else if (home_selection == 3) {
        settings_selection = 0;
        settings_edit_armed = 0;
        current_screen = SCREEN_SETTINGS;
    } else if (home_selection == 4) {
        sync_message[0] = '\0';
        sync_error = 0;
        current_screen = SCREEN_SYNC;
    } else if (home_selection == 5) {
        transfer_selection = 0;
        current_screen = SCREEN_ANDROID_TRANSFER;
    }
}

static void move_home_selection(unsigned int pressed) {
    if (pressed & SCE_CTRL_LEFT) {
        if (home_selection == 1) home_selection = 0;
        else if (home_selection == 3) home_selection = 2;
        else if (home_selection == 5) home_selection = 4;
    } else if (pressed & SCE_CTRL_RIGHT) {
        if (home_selection == 0) home_selection = 1;
        else if (home_selection == 2) home_selection = 3;
        else if (home_selection == 4) home_selection = 5;
    } else if (pressed & SCE_CTRL_UP) {
        if (home_selection == 4) home_selection = 2;
        else if (home_selection == 5) home_selection = 3;
        else if (home_selection >= 2) home_selection -= 2;
    } else if (pressed & SCE_CTRL_DOWN) {
        if (home_selection < 2) home_selection += 2;
        else if (home_selection == 2) home_selection = 4;
        else if (home_selection == 3) home_selection = 5;
    }
}

static float normalized_analog_axis(unsigned char value) {
    float amount = ((float)value - 128.0f) / 127.0f;
    float magnitude = fabsf(amount);
    const float deadzone = 0.18f;
    if (magnitude <= deadzone) return 0.0f;
    float normalized = (magnitude - deadzone) / (1.0f - deadzone);
    return amount < 0.0f ? -normalized : normalized;
}

static int analog_direction(const SceCtrlData *pad) {
    float axes[4] = {
        normalized_analog_axis(pad->lx), normalized_analog_axis(pad->ly),
        normalized_analog_axis(pad->rx), normalized_analog_axis(pad->ry)
    };
    int best = -1;
    float magnitude = 0.22f;
    for (int i = 0; i < 4; i++) {
        float candidate = fabsf(axes[i]);
        if (candidate > magnitude) { magnitude = candidate; best = i; }
    }
    if (best == 0) return axes[0] < 0.0f ? 1 : 3;
    if (best == 2) return axes[2] < 0.0f ? 1 : 3;
    if (best == 1) return axes[1] < 0.0f ? 4 : 2;
    if (best == 3) return axes[3] < 0.0f ? 4 : 2;
    return 0;
}

static unsigned int analog_navigation_pulse(const SceCtrlData *pad) {
    int direction = analog_direction(pad);
    if (direction == 0 || create_ime_open) {
        analog_input_latched = 0;
        analog_repeat_frames = 0;
        return 0;
    }
    unsigned int button = direction == 1 ? SCE_CTRL_LEFT :
                          direction == 2 ? SCE_CTRL_DOWN :
                          direction == 3 ? SCE_CTRL_RIGHT : SCE_CTRL_UP;
    if (direction != analog_input_latched) {
        analog_input_latched = direction;
        analog_repeat_frames = 0;
        return button;
    }
    analog_repeat_frames++;
    if (analog_repeat_frames >= 14 && (analog_repeat_frames - 14) % 7 == 0)
        return button;
    return 0;
}

static void update_analog_input(const SceCtrlData *pad) {
    if (image_focus_open &&
        (current_screen == SCREEN_BROWSER || current_screen == SCREEN_STUDY)) {
        float left_x = normalized_analog_axis(pad->lx);
        float right_x = normalized_analog_axis(pad->rx);
        float left_y = normalized_analog_axis(pad->ly);
        float right_y = normalized_analog_axis(pad->ry);
        float horizontal = fabsf(left_x) >= fabsf(right_x) ? left_x : right_x;
        float vertical = fabsf(left_y) >= fabsf(right_y) ? left_y : right_y;
        pan_image_viewer(horizontal * 7.0f, vertical * 7.0f);
        return;
    }
    if (current_screen == SCREEN_STUDY || current_screen == SCREEN_BROWSER) {
        float left_y = normalized_analog_axis(pad->ly);
        float right_y = normalized_analog_axis(pad->ry);
        float scroll = fabsf(left_y) >= fabsf(right_y) ? left_y : right_y;
        if (header_focus_active) {
            if (scroll > 0.22f) header_focus_active = 0;
            return;
        }
        if (scroll < -0.22f && card_scroll_position <= 0.0f) {
            header_focus_active = 1;
            return;
        }
        scroll_visible_card_by(scroll * 0.32f);
    }

    float left_x = normalized_analog_axis(pad->lx);
    float right_x = normalized_analog_axis(pad->rx);
    float horizontal = fabsf(left_x) >= fabsf(right_x) ? left_x : right_x;
    int direction = horizontal < -0.22f ? 1 : horizontal > 0.22f ? 3 : 0;
    if (current_screen == SCREEN_BROWSER) {
        if (direction == 0 || card_count <= 0) {
            analog_browser_latched = 0;
        } else if (direction != analog_browser_latched) {
            analog_browser_latched = direction;
            if (browser_stick_mode == BROWSER_STICK_BUTTONS)
                browser_button_selection = (browser_button_selection +
                                            (direction == 1 ? 3 : 1)) % 4;
            else
                move_browser(direction == 1 ? -1 : 1);
        }
    } else if (current_screen == SCREEN_STUDY && show_answer && has_study_card() &&
               review_control_mode) {
        if (direction == 0) analog_rating_latched = 0;
        else if (direction != analog_rating_latched) {
            analog_rating_latched = direction;
            selected_rating = (selected_rating + (direction == 3 ? 1 : 3)) % 4;
        }
    } else {
        analog_rating_latched = 0;
        analog_browser_latched = 0;
    }
}

static void start_delete_dialog(void) {
    if (deck_settings_deck_index < 0 || deck_settings_deck_index >= deck_count ||
        !deck_path_is_deletable(deck_entries[deck_settings_deck_index].path)) return;
    delete_selection = 0;
    delete_dialog_stage = 1;
    delete_error = 0;
    delete_dialog_open = 1;
}

static void rescan_deck_list(void) {
    all_decks_mode = 0;
    all_decks_cursor = -1;
    scan_decks();
    int item_count = current_screen == SCREEN_IMPORT ? deck_count : visible_deck_count() + 1;
    if (list_selection >= item_count) list_selection = item_count > 0 ? item_count - 1 : 0;
    import_error = 0;
    import_error_code = 0;
    deck_status[0] = '\0';
}

static void open_card_browser_for_deck(int index) {
    if (index < 0 || index >= deck_count) return;
    if ((card_count <= 0 || current_deck_index != index ||
         strcmp(current_deck_path, deck_entries[index].path)) && !select_deck(index))
        return;
    browser_index = card_index >= 0 && card_index < card_count ? card_index : 0;
    browser_show_answer = 0;
    browser_button_selection = 2;
    browser_scroll_position = 0.0f;
    image_focus_open = 0;
    jump_dialog_open = 0;
    analog_input_latched = 0;
    header_focus_active = 0;
    browser_return_screen = SCREEN_DECK_SETTINGS;
    current_screen = SCREEN_BROWSER;
}

static void activate_deck_list_action(int importing, int action) {
    if (importing && action == 0) {
        if (deck_count > 0) select_deck(list_selection);
    } else if (importing && action == 1) {
        rescan_deck_list();
    } else if (importing && action == 2) {
        open_create_deck();
    } else if (!importing && action == 0) {
        rescan_deck_list();
    } else if (!importing && action == 1) {
        open_folder_manager();
    }
}

static void activate_header_back(void) {
    header_focus_active = 0;
    if (current_screen == SCREEN_ANDROID_TRANSFER) android_transfer_stop();
    if (current_screen == SCREEN_CREATE_DECK) request_cancel_create();
    else if (current_screen == SCREEN_CREATE_TARGET) current_screen = SCREEN_CREATE_DECK;
    else if (current_screen == SCREEN_DECK_SETTINGS) {
        deck_settings_editing = 0;
        deck_list_gear_focus = 1;
        current_screen = SCREEN_DECKS;
    }
    else if (current_screen == SCREEN_FOLDERS) close_folder_manager();
    else if (current_screen == SCREEN_THEME_EDITOR) {
        current_screen = SCREEN_SETTINGS;
        settings_selection = 9;
        settings_edit_armed = 0;
    }
    else if (current_screen == SCREEN_BROWSER) current_screen = browser_return_screen;
    else current_screen = SCREEN_HOME;
}

static void handle_touch(int x, int y) {
    if (create_ime_open) return;
    if (click_sounds_enabled) anki_music_play_click();
    if (image_focus_open) {
        if (!inside((UiRect){IMAGE_VIEWER_X, IMAGE_VIEWER_Y,
                             IMAGE_VIEWER_WIDTH, IMAGE_VIEWER_HEIGHT}, x, y)) {
            image_focus_open = 0;
        } else {
            toggle_image_viewer_zoom();
        }
        return;
    }
    if (delete_dialog_open) {
        if (inside((UiRect){220, 332, 220, 48}, x, y)) {
            delete_selection = 0;
            advance_delete_confirmation();
        } else if (inside((UiRect){520, 332, 220, 48}, x, y)) {
            delete_selection = 1;
            advance_delete_confirmation();
        }
        return;
    }
    if (create_cancel_dialog_open) {
        if (inside((UiRect){276, 310, 168, 42}, x, y)) discard_create_deck();
        else if (inside((UiRect){466, 310, 168, 42}, x, y)) create_cancel_dialog_open = 0;
        return;
    }
    if (jump_dialog_open) {
        for (int i = 0; i < 12; i++) {
            if (inside(jump_key_rect(i), x, y)) {
                jump_selection = i;
                activate_jump_selection();
                return;
            }
        }
        if (inside((UiRect){340, 397, 138, 42}, x, y)) {
            jump_dialog_open = 0;
            return;
        }
        if (inside((UiRect){482, 397, 138, 42}, x, y)) {
            jump_to_entered_card();
            return;
        }
        return;
    }
    if (current_screen != SCREEN_HOME && inside(back_button, x, y)) {
        activate_header_back();
        return;
    }
    header_focus_active = 0;

    if (current_screen == SCREEN_HOME) {
        for (int i = 0; i < 4; i++) {
            if (inside(home_buttons[i], x, y)) {
                home_selection = i;
                activate_home_selection();
                return;
            }
        }
        if (inside(sync_button, x, y)) {
            home_selection = 4;
            activate_home_selection();
            return;
        }
        if (inside(android_transfer_button, x, y)) {
            home_selection = 5;
            activate_home_selection();
            return;
        }
    } else if (current_screen == SCREEN_SYNC) {
        if (inside(sync_connect_button, x, y)) {
            activate_sync_selection();
            return;
        }
    } else if (current_screen == SCREEN_ANDROID_TRANSFER) {
        if (inside(android_transfer_start_button, x, y)) {
            transfer_selection = 0;
            toggle_android_transfer_receiver();
            return;
        }
        if (inside(android_transfer_decks_button, x, y)) {
            transfer_selection = 1;
            android_transfer_stop();
            scan_decks();
            int visible = visible_position_for_deck(current_deck_index);
            list_selection = visible >= 0 ? visible + 1 : 0;
            list_focus_actions = 0;
            deck_list_gear_focus = 0;
            current_screen = SCREEN_DECKS;
            return;
        }
    } else if (current_screen == SCREEN_CREATE_DECK) {
        if (inside(create_target_rect(), x, y)) {
            create_selection = 0;
            open_create_target_picker();
        } else if (create_target_deck_index < 0 && inside(create_name_rect(), x, y)) {
            create_selection = 1;
            begin_create_ime(0);
        } else if (inside(create_question_rect(), x, y)) {
            create_selection = create_question_selection();
            begin_create_ime(1);
        } else if (inside(create_answer_rect(), x, y)) {
            create_selection = create_answer_selection();
            begin_create_ime(2);
        } else if (inside((UiRect){60, 458, 210, 52}, x, y)) {
            create_selection = create_add_selection();
            create_add_card();
        } else if (inside((UiRect){294, 458, 210, 52}, x, y)) {
            create_selection = create_save_selection();
            create_save_deck();
        } else if (inside((UiRect){528, 458, 170, 52}, x, y)) {
            create_selection = create_cancel_selection();
            request_cancel_create();
        }
    } else if (current_screen == SCREEN_CREATE_TARGET) {
        if (x >= 60 && x < 900 && y >= LIST_ROW_Y &&
            y < LIST_ROW_Y + LIST_ROW_H * LIST_VISIBLE) {
            int first = create_target_selection - 1;
            if (first < 0) first = 0;
            int item = first + (y - LIST_ROW_Y) / LIST_ROW_H;
            if (item < create_target_count()) choose_create_target(item);
        }
    } else if (current_screen == SCREEN_STUDY) {
        if (inside(undo_button, x, y)) {
            undo_last_rating();
            return;
        }
        if (!has_study_card() && all_decks_mode && has_next_all_due_deck() &&
            inside(study_more_button, x, y)) {
            advance_all_due_decks(current_deck_index + 1);
            return;
        }
        if (!has_study_card() && study_more_available() && inside(study_more_button, x, y)) {
            activate_study_more();
            return;
        }
        int button_index = -1;
        for (int i = 0; i < 5; i++) {
            if (inside(study_button_rect(i), x, y)) {
                button_index = i;
                break;
            }
        }
        if (button_index >= 0) {
                if (!has_study_card()) return;
                if (button_index == 0) {
                if (review_control_mode && show_answer) rate_card(selected_rating);
                else set_study_answer_side(!show_answer);
                }
                else if (show_answer) rate_card(button_index - 1);
        } else if (inside(study_image_rect(), x, y) && focused_image_path()[0]) {
            open_image_viewer();
        } else if (inside(study_card_panel_rect(), x, y) && has_study_card()) {
            set_study_answer_side(!show_answer);
        }
    } else if (current_screen == SCREEN_BROWSER) {
        if (inside((UiRect){50, 458, 180, 52}, x, y)) move_browser(-1);
        else if (inside(browser_jump_button, x, y)) open_jump_dialog();
        else if (inside((UiRect){440, 458, 310, 52}, x, y)) {
                browser_show_answer = !browser_show_answer;
                browser_scroll_position = 0.0f;
        }
        else if (inside((UiRect){760, 458, 150, 52}, x, y)) move_browser(1);
        else if (inside((UiRect){SPLIT_CARD_IMAGE_X, SPLIT_CARD_IMAGE_Y,
                                 SPLIT_CARD_IMAGE_WIDTH, SPLIT_CARD_IMAGE_HEIGHT}, x, y) &&
                 browser_image_path()[0]) {
            open_image_viewer();
        }
        else if (inside((UiRect){48, 104, 864, 334}, x, y) && card_count > 0) {
            browser_show_answer = !browser_show_answer;
            browser_scroll_position = 0.0f;
        }
    } else if (current_screen == SCREEN_DECKS || current_screen == SCREEN_IMPORT) {
        int importing = current_screen == SCREEN_IMPORT;
        if (!importing && inside((UiRect){60, 100, 840, 26}, x, y)) {
            header_focus_active = 0;
            list_focus_actions = 0;
            deck_folder_filter_focus = 1;
            cycle_deck_folder_filter(x < 480 ? -1 : 1);
        } else if (x >= 60 && x < 900 && y >= LIST_ROW_Y && y < LIST_ROW_Y + LIST_ROW_H * LIST_VISIBLE) {
            int row = (y - LIST_ROW_Y) / LIST_ROW_H;
            int item = first_visible_deck(importing) + row;
            int item_count = importing ? deck_count : visible_deck_count() + 1;
            if (item >= 0 && item < item_count) {
                header_focus_active = 0;
                deck_folder_filter_focus = 0;
                if (!importing && item == 0) {
                    list_selection = 0;
                    list_focus_actions = 0;
                    deck_list_gear_focus = 0;
                    deck_status[0] = '\0';
                    select_all_due_decks();
                    return;
                }
                int index = importing ? item : deck_index_at_visible_position(item - 1);
                if (index < 0 || index >= deck_count) return;
                UiRect deck_row = {60, LIST_ROW_Y + row * LIST_ROW_H, 840, 54};
                if (!importing && inside(deck_settings_gear_rect(deck_row), x, y)) {
                    list_selection = item;
                    deck_list_gear_focus = 1;
                    open_deck_settings(index);
                    return;
                }
                list_selection = importing ? index : item;
                list_focus_actions = 0;
                deck_list_gear_focus = 0;
                if (importing) {
                    import_error = 0;
                    import_error_code = 0;
                } else {
                    deck_status[0] = '\0';
                    select_deck(index);
                }
            }
        } else {
            deck_folder_filter_focus = 0;
            for (int action = 0; action < list_action_count(current_screen == SCREEN_IMPORT); action++) {
                if (inside(list_action_rect(current_screen == SCREEN_IMPORT, action), x, y)) {
                    list_focus_actions = 1;
                    list_action_selection = action;
                    activate_deck_list_action(current_screen == SCREEN_IMPORT, action);
                    return;
                }
            }
        }
    } else if (current_screen == SCREEN_FOLDERS) {
        if (x >= 60 && x < 900 && y >= LIST_ROW_Y && y < LIST_ROW_Y + LIST_ROW_H * LIST_VISIBLE) {
            int first = folder_selection - 1;
            if (first < 0) first = 0;
            int item = first + (y - LIST_ROW_Y) / LIST_ROW_H;
            if (item < folder_count + 2) {
                folder_selection = item;
                folder_actions_focus = 0;
                header_focus_active = 0;
            }
        } else {
            for (int action = 0; action < 3; action++) {
                if (!inside(folder_action_rect(action), x, y)) continue;
                folder_actions_focus = 1;
                folder_action_selection = action;
                activate_folder_action(action);
                return;
            }
        }
    } else if (current_screen == SCREEN_SETTINGS) {
        for (int setting = 0; setting < SETTINGS_COUNT; setting++) {
            if (inside(settings_rows[setting], x, y)) {
                header_focus_active = 0;
                int was_selected = settings_selection == setting;
                int was_editing = settings_edit_armed;
                int on_left_arrow = x >= settings_rows[setting].x + 320 &&
                                    x < settings_rows[setting].x + 362;
                int on_right_arrow = x >= settings_rows[setting].x + 372 &&
                                     x < settings_rows[setting].x + 414;
                settings_selection = setting;
                if (!was_selected) {
                    settings_edit_armed = 0;
                } else if (on_left_arrow || on_right_arrow) {
                    cycle_setting(setting, on_left_arrow ? -1 : 1);
                    settings_edit_armed = 1;
                } else if (!was_editing) {
                    settings_edit_armed = 1;
                } else if (setting == 9 && color_theme_mode == THEME_CUSTOM_MODE) {
                    open_custom_theme_editor();
                } else {
                    settings_edit_armed = 0;
                }
                break;
            }
        }
    } else if (current_screen == SCREEN_THEME_EDITOR) {
        for (int index = 0; index < CUSTOM_COLOR_COUNT; index++) {
            for (int row = 0; row < 2; row++) {
                if (!inside(custom_theme_swatch_rect(row, index), x, y)) continue;
                theme_editor_focus = (index / 4) * 8 + (row == 0 ? index % 4 : 4 + index % 4);
                apply_custom_theme_swatch(theme_editor_focus);
                return;
            }
        }
    } else if (current_screen == SCREEN_DECK_SETTINGS) {
        if (inside(deck_browser_button, x, y)) {
            open_card_browser_for_deck(deck_settings_deck_index);
            return;
        }
        if (inside(deck_rename_button, x, y)) {
            int renamable = deck_settings_deck_index >= 0 &&
                deck_settings_deck_index < deck_count &&
                deck_path_is_deletable(deck_entries[deck_settings_deck_index].path);
            if (renamable) {
                deck_settings_selection = 8;
                deck_settings_editing = 0;
                begin_create_ime(4);
            } else {
                snprintf(deck_status, sizeof(deck_status), "Built-in decks cannot be renamed.");
            }
            return;
        }
        if (inside(deck_delete_button, x, y)) {
            int deletable = deck_settings_deck_index >= 0 &&
                deck_settings_deck_index < deck_count &&
                deck_path_is_deletable(deck_entries[deck_settings_deck_index].path);
            if (deletable) {
                deck_settings_selection = 7;
                deck_settings_editing = 0;
                start_delete_dialog();
            } else {
                snprintf(deck_status, sizeof(deck_status), "Built-in decks cannot be deleted.");
            }
            return;
        }
        for (int setting = 0; setting < 6; setting++) {
            UiRect row = {60, 106 + setting * 52, 840, 46};
            if (inside(row, x, y)) {
                header_focus_active = 0;
                int was_selected = deck_settings_selection == setting;
                int on_minus = x >= 704 && x < 766;
                int on_plus = x >= 778 && x < 840;
                deck_settings_selection = setting;
                if (!was_selected) {
                    deck_settings_editing = 0;
                } else if (on_minus || on_plus) {
                    change_deck_setting(setting, on_minus ? -1 : 1);
                    deck_settings_editing = 1;
                } else {
                    deck_settings_editing = !deck_settings_editing;
                }
                break;
            }
        }
    }
}

static int poll_touch(int *x, int *y) {
    SceTouchData data;
    memset(&data, 0, sizeof(data));
    if (sceTouchPeek(SCE_TOUCH_PORT_FRONT, &data, 1) < 0 || data.reportNum == 0) {
        touch_was_down = 0;
        return 0;
    }

    if (touch_was_down) return 0;
    touch_was_down = 1;
    int raw_x = data.report[0].x;
    int raw_y = data.report[0].y;
    *x = (raw_x - touch_min_x) * SCREEN_W / touch_width;
    *y = (raw_y - touch_min_y) * SCREEN_H / touch_height;
    if (*x < 0) *x = 0;
    if (*x >= SCREEN_W) *x = SCREEN_W - 1;
    if (*y < 0) *y = 0;
    if (*y >= SCREEN_H) *y = SCREEN_H - 1;
    return 1;
}

int main(void) {
    SceCtrlData pad;
    SceTouchPanelInfo touch_info;
    unsigned int previous_buttons = 0;
    AppScreen previous_screen = SCREEN_HOME;

    mkdir("ux0:data/VitaAnki", 0777);
    mkdir(DECK_FOLDER, 0777);
    copy_file_if_missing(BUNDLED_DECK_PATH, INCLUDED_DECK_PATH);
    copy_file_if_missing(BUNDLED_PICTURE_DECK_PATH, INCLUDED_PICTURE_DECK_PATH);
    copy_file_if_missing("app0:/sync.example.ini", "ux0:data/VitaAnki/sync.example.ini");
    load_settings();
    anki_music_set_click_volume(click_volume);
#ifndef VITAANKI_DISABLE_MUSIC
    if (!music_setting_migration) {
        music_muted = 0;
        music_setting_migration = 1;
        save_settings();
    }
#endif
    sceSysmoduleLoadModule(SCE_SYSMODULE_SQLITE);
    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);
    sceTouchSetSamplingState(SCE_TOUCH_PORT_FRONT, SCE_TOUCH_SAMPLING_STATE_START);
    memset(&touch_info, 0, sizeof(touch_info));
    if (sceTouchGetPanelInfo(SCE_TOUCH_PORT_FRONT, &touch_info) >= 0) {
        int width = touch_info.maxDispX - touch_info.minDispX + 1;
        int height = touch_info.maxDispY - touch_info.minDispY + 1;
        if (width > 0) {
            touch_min_x = touch_info.minDispX;
            touch_width = width;
        }
        if (height > 0) {
            touch_min_y = touch_info.minDispY;
            touch_height = height;
        }
    }

    anki_connect_prepare();
    scan_decks();
    load_saved_deck_path();
    int index = find_saved_deck();
    if (index >= 0) {
        if (!select_deck(index)) load_demo_deck();
    } else {
        load_demo_deck();
    }

    vita2d_init();
    vita2d_set_clear_color(BG);
    font_pgf = vita2d_load_default_pgf();
    if (!font_pgf) {
        anki_music_stop();
        vita2d_fini();
        sceKernelExitProcess(1);
        return 1;
    }
    if (!font_mode_available(font_mode)) {
        font_mode = 0;
        save_settings();
    }
    anki_music_set_muted(music_muted);
    current_screen = SCREEN_HOME;

    for (;;) {
        sceCtrlPeekBufferPositive(0, &pad, 1);
        if (current_screen != previous_screen) {
            header_focus_active = 0;
            previous_screen = current_screen;
        }
        unsigned int analog_pressed = 0;
        if ((!create_ime_open && current_screen != SCREEN_STUDY &&
             current_screen != SCREEN_BROWSER) || jump_dialog_open ||
            delete_dialog_open || create_cancel_dialog_open)
            analog_pressed = analog_navigation_pulse(&pad);
        unsigned int pressed = (pad.buttons & ~previous_buttons) | analog_pressed;
        previous_buttons = pad.buttons;
        refresh_clock_warning();

        if (!create_ime_open && (pressed & ~((unsigned int)SCE_CTRL_START))) {
            if (click_sounds_enabled) anki_music_play_click();
        }
        if (create_ime_open) {
            update_create_ime();
        } else {
        if (jump_dialog_open) {
            if (pressed & SCE_CTRL_CIRCLE) jump_dialog_open = 0;
            else if (pressed & SCE_CTRL_CROSS) activate_jump_selection();
            else move_jump_selection(pressed);
        } else if (delete_dialog_open) {
            if (pressed & SCE_CTRL_CIRCLE) {
                delete_dialog_open = 0;
                delete_error = 0;
            } else if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT)) {
                delete_selection = delete_selection == 0 ? 1 : 0;
            } else if (pressed & SCE_CTRL_CROSS) {
                advance_delete_confirmation();
            }
        } else if (create_cancel_dialog_open) {
            if (pressed & SCE_CTRL_CIRCLE) create_cancel_dialog_open = 0;
            else if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))
                create_selection = create_selection == 0 ? 1 : 0;
            else if (pressed & SCE_CTRL_CROSS) activate_create_selection();
        } else if (header_focus_active) {
            if (pressed & SCE_CTRL_CROSS) activate_header_back();
            else if (pressed & SCE_CTRL_CIRCLE) activate_header_back();
            else if (pressed & SCE_CTRL_DOWN) {
                header_focus_active = 0;
                if (current_screen == SCREEN_DECKS) deck_folder_filter_focus = 1;
            }
        } else if (current_screen == SCREEN_HOME) {
            move_home_selection(pressed);
            if (pressed & SCE_CTRL_CROSS) activate_home_selection();
        } else if (image_focus_open &&
                   (current_screen == SCREEN_STUDY || current_screen == SCREEN_BROWSER)) {
            if (pressed & SCE_CTRL_CROSS) toggle_image_viewer_zoom();
            else if (pressed & SCE_CTRL_LEFT) pan_image_viewer(-24.0f, 0.0f);
            else if (pressed & SCE_CTRL_RIGHT) pan_image_viewer(24.0f, 0.0f);
            else if (pressed & SCE_CTRL_UP) pan_image_viewer(0.0f, -24.0f);
            else if (pressed & SCE_CTRL_DOWN) pan_image_viewer(0.0f, 24.0f);
            else if (pressed & SCE_CTRL_CIRCLE) image_focus_open = 0;
        } else if (current_screen == SCREEN_STUDY) {
            if (pressed & SCE_CTRL_LTRIGGER) undo_last_rating();
            else if ((pressed & SCE_CTRL_CROSS) && !has_study_card() && all_decks_mode &&
                     has_next_all_due_deck())
                advance_all_due_decks(current_deck_index + 1);
            else if ((pressed & SCE_CTRL_CROSS) && !has_study_card() &&
                     study_more_available())
                activate_study_more();
            else if ((pressed & SCE_CTRL_CROSS) && has_study_card()) {
                if (!show_answer) {
                    set_study_answer_side(1);
                } else if (review_control_mode) {
                    rate_card(selected_rating);
                } else {
                    set_study_answer_side(0);
                }
            }
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_TRIANGLE)) rate_card(0);
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_SQUARE)) rate_card(1);
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_CIRCLE)) rate_card(2);
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_RTRIGGER)) rate_card(3);
            else if ((pressed & SCE_CTRL_CIRCLE) && !show_answer) current_screen = SCREEN_HOME;
            else if (pressed & SCE_CTRL_UP) {
                if (card_scroll_position <= 0.0f) header_focus_active = 1;
                else scroll_visible_card(-1);
            }
            else if (pressed & SCE_CTRL_DOWN) scroll_visible_card(1);
        } else if (current_screen == SCREEN_BROWSER) {
            if (pressed & SCE_CTRL_CROSS) {
                if (browser_stick_mode == BROWSER_STICK_BUTTONS)
                    activate_browser_button();
                else {
                    browser_show_answer = !browser_show_answer;
                    browser_scroll_position = 0.0f;
                }
            }
            else if (pressed & SCE_CTRL_TRIANGLE) open_jump_dialog();
            else if (pressed & SCE_CTRL_LEFT) move_browser(-1);
            else if (pressed & SCE_CTRL_RIGHT) move_browser(1);
            else if (pressed & SCE_CTRL_UP) {
                if (browser_scroll_position <= 0.0f) header_focus_active = 1;
                else scroll_visible_card(-1);
            }
            else if (pressed & SCE_CTRL_DOWN) scroll_visible_card(1);
            else if (pressed & SCE_CTRL_CIRCLE) current_screen = browser_return_screen;
        } else if (current_screen == SCREEN_DECKS || current_screen == SCREEN_IMPORT) {
            int importing = current_screen == SCREEN_IMPORT;
            if (importing) {
                if ((pressed & SCE_CTRL_LEFT) && !list_focus_actions) {
                    list_focus_actions = 1;
                    list_action_selection = list_action_count(importing) - 1;
                } else if ((pressed & SCE_CTRL_RIGHT) && !list_focus_actions) {
                    list_focus_actions = 1;
                    list_action_selection = 0;
                } else if (list_focus_actions && (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))) {
                    int count = list_action_count(importing);
                    list_action_selection = (list_action_selection +
                        ((pressed & SCE_CTRL_RIGHT) ? 1 : count - 1)) % count;
                } else if (list_focus_actions && (pressed & SCE_CTRL_UP)) {
                    list_focus_actions = 0;
                } else if (pressed & SCE_CTRL_UP) {
                    if (list_selection > 0) list_selection--;
                    else header_focus_active = 1;
                } else if (pressed & SCE_CTRL_DOWN) {
                    if (list_focus_actions) {
                        list_focus_actions = 0;
                    } else if (list_selection + 1 < deck_count) list_selection++;
                    else {
                        list_focus_actions = 1;
                        list_action_selection = 0;
                    }
                } else if (pressed & SCE_CTRL_TRIANGLE) {
                    rescan_deck_list();
                } else if (pressed & SCE_CTRL_CROSS) {
                    if (list_focus_actions) activate_deck_list_action(importing, list_action_selection);
                    else if (deck_count > 0) select_deck(list_selection);
                } else if (pressed & SCE_CTRL_SQUARE) {
                    open_create_deck();
                } else if (pressed & SCE_CTRL_CIRCLE) {
                    current_screen = SCREEN_HOME;
                }
            } else if (list_focus_actions &&
                       (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))) {
                int count = list_action_count(0);
                list_action_selection = (list_action_selection +
                    ((pressed & SCE_CTRL_RIGHT) ? 1 : count - 1)) % count;
            } else if (list_focus_actions && (pressed & SCE_CTRL_UP)) {
                list_focus_actions = 0;
                deck_list_gear_focus = 0;
            } else if (list_focus_actions && (pressed & SCE_CTRL_CROSS)) {
                activate_deck_list_action(0, list_action_selection);
            } else if (deck_folder_filter_focus) {
                if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))
                    cycle_deck_folder_filter((pressed & SCE_CTRL_RIGHT) ? 1 : -1);
                else if (pressed & SCE_CTRL_CROSS)
                    cycle_deck_folder_filter(1);
                else if (pressed & SCE_CTRL_UP)
                    header_focus_active = 1;
                else if (pressed & SCE_CTRL_DOWN)
                    deck_folder_filter_focus = 0;
                else if (pressed & SCE_CTRL_CIRCLE)
                    current_screen = SCREEN_HOME;
            } else if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT)) {
                if (list_selection > 0 &&
                    deck_index_at_visible_position(list_selection - 1) >= 0)
                    deck_list_gear_focus = (pressed & SCE_CTRL_RIGHT) ? 1 : 0;
                else deck_list_gear_focus = 0;
            } else if (pressed & SCE_CTRL_UP) {
                if (list_selection > 0) list_selection--;
                else deck_folder_filter_focus = 1;
            } else if (pressed & SCE_CTRL_DOWN) {
                if (list_selection + 1 < visible_deck_count() + 1) list_selection++;
                else {
                    list_focus_actions = 1;
                    list_action_selection = 0;
                    deck_list_gear_focus = 0;
                }
            } else if (pressed & SCE_CTRL_TRIANGLE) {
                rescan_deck_list();
            } else if (pressed & SCE_CTRL_CROSS) {
                int selected_index = list_selection > 0
                                   ? deck_index_at_visible_position(list_selection - 1) : -1;
                if (selected_index < 0) select_all_due_decks();
                else if (deck_list_gear_focus) open_deck_settings(selected_index);
                else select_deck(selected_index);
            } else if (pressed & SCE_CTRL_SQUARE) {
                int selected_index = list_selection > 0
                                   ? deck_index_at_visible_position(list_selection - 1) : -1;
                if (selected_index >= 0) open_deck_settings(selected_index);
            } else if (pressed & SCE_CTRL_CIRCLE) {
                current_screen = SCREEN_HOME;
            }
        } else if (current_screen == SCREEN_CREATE_DECK) {
            if (pressed & SCE_CTRL_UP) {
                if (create_selection == 0) header_focus_active = 1;
                else if (create_selection >= create_add_selection())
                    create_selection = create_answer_selection();
                else create_selection--;
            } else if (pressed & SCE_CTRL_DOWN) {
                if (create_selection < create_answer_selection()) create_selection++;
                else if (create_selection == create_answer_selection())
                    create_selection = create_add_selection();
            } else if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT)) {
                if (create_selection == 0) open_create_target_picker();
                else if (create_selection >= create_add_selection()) {
                    int offset = create_selection - create_add_selection();
                    offset = (offset + ((pressed & SCE_CTRL_RIGHT) ? 1 : 2)) % 3;
                    create_selection = create_add_selection() + offset;
                }
            }
            else if (pressed & SCE_CTRL_CROSS)
                activate_create_selection();
            else if (pressed & SCE_CTRL_CIRCLE)
                request_cancel_create();
        } else if (current_screen == SCREEN_CREATE_TARGET) {
            int item_count = create_target_count();
            if (pressed & SCE_CTRL_UP) {
                if (create_target_selection > 0) create_target_selection--;
                else header_focus_active = 1;
            } else if (pressed & SCE_CTRL_DOWN) {
                if (create_target_selection + 1 < item_count) create_target_selection++;
            } else if (pressed & SCE_CTRL_CROSS) {
                choose_create_target(create_target_selection);
            } else if (pressed & SCE_CTRL_CIRCLE) {
                current_screen = SCREEN_CREATE_DECK;
            }
        } else if (current_screen == SCREEN_SETTINGS) {
            if (settings_edit_armed) {
                if (pressed & SCE_CTRL_CIRCLE) {
                    settings_edit_armed = 0;
                } else if ((pressed & SCE_CTRL_CROSS) && settings_selection == 9 &&
                           color_theme_mode == THEME_CUSTOM_MODE) {
                    open_custom_theme_editor();
                } else if (pressed & (SCE_CTRL_UP | SCE_CTRL_RIGHT)) {
                    cycle_setting(settings_selection, 1);
                } else if (pressed & (SCE_CTRL_DOWN | SCE_CTRL_LEFT)) {
                    cycle_setting(settings_selection, -1);
                }
            } else if (pressed & SCE_CTRL_UP) {
                move_settings_focus(0);
            } else if (pressed & SCE_CTRL_DOWN) {
                move_settings_focus(1);
            } else if (pressed & SCE_CTRL_LEFT) {
                move_settings_focus(2);
            } else if (pressed & SCE_CTRL_RIGHT) {
                move_settings_focus(3);
            } else if (pressed & SCE_CTRL_CROSS) {
                settings_edit_armed = 1;
            } else if (pressed & SCE_CTRL_CIRCLE) {
                current_screen = SCREEN_HOME;
            }
        } else if (current_screen == SCREEN_THEME_EDITOR) {
            if (pressed & SCE_CTRL_UP) {
                if (theme_editor_focus >= 8) theme_editor_focus -= 8;
                else header_focus_active = 1;
            } else if (pressed & SCE_CTRL_DOWN) {
                if (theme_editor_focus < 16) theme_editor_focus += 8;
            } else if (pressed & SCE_CTRL_LEFT) {
                int row = theme_editor_focus / 8;
                int column = theme_editor_focus % 8;
                theme_editor_focus = row * 8 + (column + 7) % 8;
            } else if (pressed & SCE_CTRL_RIGHT) {
                int row = theme_editor_focus / 8;
                int column = theme_editor_focus % 8;
                theme_editor_focus = row * 8 + (column + 1) % 8;
            } else if (pressed & SCE_CTRL_CROSS) {
                apply_custom_theme_swatch(theme_editor_focus);
            } else if (pressed & SCE_CTRL_CIRCLE) {
                current_screen = SCREEN_SETTINGS;
                settings_selection = 9;
                settings_edit_armed = 0;
            }
        } else if (current_screen == SCREEN_FOLDERS) {
            int item_count = folder_count + 2;
            if (folder_actions_focus &&
                (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))) {
                folder_action_selection = (folder_action_selection +
                    ((pressed & SCE_CTRL_RIGHT) ? 1 : 2)) % 3;
            } else if (folder_actions_focus && (pressed & SCE_CTRL_UP)) {
                folder_actions_focus = 0;
            } else if (folder_actions_focus && (pressed & SCE_CTRL_CROSS)) {
                activate_folder_action(folder_action_selection);
            } else if (!folder_actions_focus && (pressed & SCE_CTRL_UP)) {
                if (folder_selection > 0) folder_selection--;
                else header_focus_active = 1;
            } else if (!folder_actions_focus && (pressed & SCE_CTRL_DOWN)) {
                if (folder_selection + 1 < item_count) folder_selection++;
                else {
                    folder_actions_focus = 1;
                    folder_action_selection = 0;
                }
            } else if (!folder_actions_focus && (pressed & SCE_CTRL_RIGHT)) {
                folder_actions_focus = 1;
                folder_action_selection = 0;
            } else if (!folder_actions_focus && (pressed & SCE_CTRL_CROSS)) {
                if (folder_selection >= 2) {
                    activate_folder_action(1);
                } else {
                    folder_actions_focus = 1;
                    folder_action_selection = 0;
                }
            } else if (pressed & SCE_CTRL_CIRCLE) {
                current_screen = SCREEN_DECKS;
            }
        } else if (current_screen == SCREEN_SYNC) {
            if (pressed & SCE_CTRL_UP) header_focus_active = 1;
            else if (pressed & SCE_CTRL_CROSS) activate_sync_selection();
            else if (pressed & SCE_CTRL_CIRCLE) current_screen = SCREEN_HOME;
        } else if (current_screen == SCREEN_ANDROID_TRANSFER) {
            if (pressed & SCE_CTRL_UP) header_focus_active = 1;
            else if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))
                transfer_selection = transfer_selection == 0 ? 1 : 0;
            else if (pressed & SCE_CTRL_CROSS) {
                if (transfer_selection == 0) toggle_android_transfer_receiver();
                else {
                    android_transfer_stop();
                    scan_decks();
                    int visible = visible_position_for_deck(current_deck_index);
                    list_selection = visible >= 0 ? visible + 1 : 0;
                    list_focus_actions = 0;
                    deck_list_gear_focus = 0;
                    current_screen = SCREEN_DECKS;
                }
            }
            else if (pressed & SCE_CTRL_CIRCLE) {
                android_transfer_stop();
                current_screen = SCREEN_HOME;
            } else if (pressed & SCE_CTRL_DOWN) {
                android_transfer_stop();
                scan_decks();
                int visible = visible_position_for_deck(current_deck_index);
                list_selection = visible >= 0 ? visible + 1 : 0;
                list_focus_actions = 0;
                deck_list_gear_focus = 0;
                current_screen = SCREEN_DECKS;
            }
        } else if (current_screen == SCREEN_DECK_SETTINGS) {
            if (deck_settings_editing) {
                if (pressed & SCE_CTRL_CIRCLE) {
                    deck_settings_editing = 0;
                } else if (deck_settings_selection < 6 &&
                           (pressed & (SCE_CTRL_UP | SCE_CTRL_RIGHT))) {
                    change_deck_setting(deck_settings_selection, 1);
                } else if (deck_settings_selection < 6 &&
                           (pressed & (SCE_CTRL_DOWN | SCE_CTRL_LEFT))) {
                    change_deck_setting(deck_settings_selection, -1);
                }
            } else if (pressed & (SCE_CTRL_UP | SCE_CTRL_LEFT)) {
                if ((pressed & SCE_CTRL_UP) && deck_settings_selection == 0)
                    header_focus_active = 1;
                else if (deck_settings_selection > 0)
                    deck_settings_selection--;
            } else if (pressed & (SCE_CTRL_DOWN | SCE_CTRL_RIGHT)) {
                if (deck_settings_selection < 8) deck_settings_selection++;
            } else if (pressed & SCE_CTRL_CROSS) {
                if (deck_settings_selection == 6)
                    open_card_browser_for_deck(deck_settings_deck_index);
                else if (deck_settings_selection == 7) {
                    if (deck_settings_deck_index >= 0 && deck_settings_deck_index < deck_count &&
                        deck_path_is_deletable(deck_entries[deck_settings_deck_index].path))
                        start_delete_dialog();
                    else snprintf(deck_status, sizeof(deck_status), "Built-in decks cannot be deleted.");
                } else if (deck_settings_selection == 8) {
                    if (deck_settings_deck_index >= 0 && deck_settings_deck_index < deck_count &&
                        deck_path_is_deletable(deck_entries[deck_settings_deck_index].path))
                        begin_create_ime(4);
                    else snprintf(deck_status, sizeof(deck_status), "Built-in decks cannot be renamed.");
                }
                else deck_settings_editing = 1;
            } else if (pressed & SCE_CTRL_SQUARE) {
                start_delete_dialog();
            } else if (pressed & SCE_CTRL_CIRCLE) {
                deck_list_gear_focus = 1;
                current_screen = SCREEN_DECKS;
            }
        }
        }

        if (current_screen == SCREEN_STUDY && live_sync && card_count == 0 &&
            anki_connect_has_learning_cards()) {
            time_t now = time(NULL);
            if (live_refresh_after == 0 || now >= live_refresh_after) {
                live_refresh_after = now + LIVE_REFRESH_SECONDS;
                int refreshed = anki_connect_reload(cards, card_capacity);
                if (refreshed < 0) {
                    sync_error = 1;
                } else {
                    sync_error = 0;
                    card_count = refreshed;
                    if (card_count > 0) {
                        card_index = 0;
                        show_answer = 0;
                        flip_frames_remaining = 0;
                        card_scroll_position = 0.0f;
                        selected_rating = 2;
                    }
                }
            }
        } else if (card_count > 0 || !live_sync) {
            live_refresh_after = 0;
        }

        if (current_screen == SCREEN_STUDY && !live_sync && card_count > 0 && !has_study_card()) {
            if (++study_idle_frames >= 30) {
                study_idle_frames = 0;
                int next_due = find_next_due();
                if (next_due >= 0) {
                    card_index = next_due;
                    show_answer = 0;
                    card_scroll_position = 0.0f;
                    selected_rating = 2;
                }
            }
        } else {
            study_idle_frames = 0;
        }

        if (!jump_dialog_open) update_analog_input(&pad);
        update_deck_due_count_cache();
        update_confetti();
        int touch_x, touch_y;
        if (poll_touch(&touch_x, &touch_y)) handle_touch(touch_x, touch_y);
        draw_ui();
        advance_study_flip();
        sceKernelDelayThread(16000);
    }

    android_transfer_stop();
    if (create_ime_open) {
        sceImeDialogAbort();
        sceImeDialogTerm();
    }
    if (ime_module_loaded) sceSysmoduleUnloadModule(SCE_SYSMODULE_IME);
    if (apputil_initialized) sceAppUtilShutdown();
    anki_music_stop();
    anki_music_click_shutdown();
    if (card_image_texture) vita2d_free_texture(card_image_texture);
    release_custom_fonts();
    if (font_pgf) vita2d_free_pgf(font_pgf);
    vita2d_fini();
    anki_connect_stop();
    sceKernelExitProcess(0);
    return 0;
}
