# VitaAnki roadmap

## Delivered in Vita 1.47

- Show due review and learning counts on the deck picker and add an All Due Reviews queue across the selected folder's decks. Each deck keeps its own progress and scheduling settings.
- Add persistent deck folders with create and rename actions, folder filtering, visible folder contents, and per-deck folder assignment in Deck Settings.
- Expand the image view to nearly the full screen and remove its title and on-screen control hints.
- Make Study More available only after the Learn queue is empty; each press adds a button-accessible batch of 20 new cards.

## Delivered in Vita 1.46

- Enforce each offline deck's new-card limit per day, persist the count across app restarts, and offer repeatable Study More batches equal to that deck's daily limit.
- Connect per-deck Again/Hard learning steps and Good/Easy first intervals to offline scheduling; existing review intervals continue scaling from their current interval.
- Remove the extra deck-row highlight when focus moves to Back, the footer actions, or a deck's gear.

## Delivered in Vita 1.45

- Remove instructional text from the enlarged image viewer and expand the image viewport.
- Move Study's Undo button to the upper-right corner opposite Back.

## Delivered in Vita 1.44

- Keep Custom Theme inside the Color Theme setting and open its palette editor from that row.
- Use stick navigation to focus Settings rows, press X to edit a row, and press Circle to stop editing. Remove Settings control instructions.
- Focus a deck row's gear with left/right and open it with X; apply the same X-to-edit and Circle-to-stop flow to per-deck settings.

## Delivered in Vita 1.43

- Rework the Custom Theme Editor swatches and live preview.
- Apply the chosen custom accent to every themed accent role throughout the app.
- Remove the normal undo instruction from the bottom of Study while keeping the Undo control and error feedback.
- Package the built-in picture deck in the full VPK so its card images are available after installation.

## Delivered in Vita 1.42

- Show the selected deck name in Study, keep Choose a Deck and AnkiConnect pages in selection/connection mode, and open Card Browser from deck selection.
- Move deck settings to a gear on each deck row and move deck deletion into that deck's settings.
- Add custom background/accent palettes alongside nine preset themes, a Huge card-text size, and Quiet/Medium/Loud click volume.
- Require selecting a Settings row with X before touch arrows change it; remove repeated in-menu app logos and the Start-to-exit shortcut.
- Normalize curly apostrophes and common HTML apostrophe entities in imported cards to avoid unsupported glyphs.
- Simplify the Android transfer page around its confirmation code and explain that offline ratings are stored on Vita and sent to Anki Desktop when connected.

## Delivered in Vita 1.41

- Move music mute into Settings and arrange options in Reading & Cards and Study & Sound columns.
- Cache card text line wrapping and offline study counts so Study and Card Browser avoid repeating the same work every frame.

## Delivered in Vita 1.40

- Reduce Compact Study touch controls to small icon buttons while preserving touch ratings.
- Open a Study card image in the zoomable, pannable image viewer by tapping it.

## Delivered in Vita 1.39

- Add Large / Compact Study controls. Both keep tappable symbol buttons; Compact mode gives the card and its image more screen space.
- Show only the controller symbols on Study touch buttons, with the Again/Hard/Good/Easy words removed.

## Delivered in Vita 1.38

- Simplify Study rating buttons to controller icons with color-coded ratings; remove button instructions from the card area and use the space to show more card text.

## Delivered in Vita 1.37

- Open Card Browser images in a larger viewer; pan with either analog stick or the D-pad, and tap or press X to switch between fit and 1.5x zoom.
- Add a saved setting to hide card images across Study and Card Browser.

## Delivered in Vita 1.36

- Reflow the Android transfer instructions and status so the PIN, messages, and controls do not overlap.
- Let either analog stick navigate existing menus and action buttons, including the shared Back control.
- Add per-deck offline new-card limits and Again/Hard/Good/Easy timing settings.
- Add a second confirmation before deleting a deck and its local progress.
- Make deck creation easier to find from the Import screen.

## Delivered in Vita 1.34

- Create local question-and-answer decks with the Vita text keyboard and save them as TSV.
- Delete user-added APKG/TSV decks after confirmation, including their local review progress; protect bundled decks.
- Keep the local Wi-Fi transfer receiver open for multiple requests and add PIN-protected Vita deck listing and download endpoints for the Android companion.
- Update the Android handoff with the reverse LIST/GET protocol.

## Delivered in Vita 1.33

- Add a Card Browser stick preference: move the highlight across Previous, Jump, Show Answer, and Next, or use the sticks to scroll the card. D-pad and touch remain available.

## Delivered in 1.32 / Mobile 0.3.0

- Discover the Vita automatically on the local Wi-Fi before sending a deck. Keep the short-lived confirmation code; remove the need to find, type, or share an IP address.
- Preview the selected import file's name, format, and size, and show import error codes with causes and suggested recovery steps.
- Clarify Card Browser controls for analog sticks, D-pad, flip, jump, and back.

## Delivered in 1.20 / Mobile 0.2.0

- Import compatible APKG image media on Vita and Android. Show the first embedded image beside the question on the front and show the answer text alone after flipping. Image cards can be imported from compatible APKG packages; personal decks are not included in this public source.

## Delivered in 1.27

- Restore Aquatic Ambience playback after adding Vita SQLite allocator setup.
- Enlarge the card image viewport while keeping the full image visible.
- Match the study card accent stripe to its New, Learning, or Review state.
- Remove the header icon from Study and fix the Card Browser selection outline.

## Delivered in 1.28

- Add an optional click sound for touch and button input, with a Settings toggle.
- Let confetti bursts accumulate while earlier pieces are still falling instead of restarting the animation.

## Delivered in 1.29

- Queue click sounds on a background audio thread so touch and button handling do not wait for audio playback.
- Reuse cached card text during live-study refreshes, fetching full details only for changed or newly due cards.

## Delivered in 1.30

- Add the Vita's serif and sans PGF families in regular, italic, bold, and bold-italic styles when the system files are available.
- Smooth card-text scrolling from either analog stick while keeping D-pad scrolling in one-line steps.
- Add Aquatic, Rose, Evergreen, and Moonlight preset palettes.

## Delivered in 1.31

- Keep the top of card text visible while clipping smooth-scroll content to the card viewport.

## Backlog

- Extend the import preview with APKG card/media counts and compatibility warnings before loading the deck.
- Move the remaining live AnkiConnect answer and queue requests off the UI thread so ratings do not pause screen input while waiting on Wi-Fi.
- Expand image handling for multiple images on one card and more Anki note-template layouts.
- Add a theme editor with about nine color choices for the background and accent colors.


