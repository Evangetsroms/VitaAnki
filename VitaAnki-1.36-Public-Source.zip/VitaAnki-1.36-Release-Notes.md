# VitaAnki 1.36

- Reflowed Deck Transfer instructions and status to avoid text overlap.
- Enabled either analog stick to navigate menus and select existing controls, including Back.
- Added per-deck offline study settings for new-card session limits and Again, Hard, Good, and Easy timing.
- Added a second confirmation before a deck and its local study data are deleted.
- Made deck creation easier to find from Import.

Offline schedule settings affect local Vita decks. Live AnkiConnect reviews still use Anki Desktop's scheduler.
