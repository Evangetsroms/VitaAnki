package app.vitaanki.mobile;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

final class DeckData {
    String name;
    File sourceFile;
    String mode = "offline";
    boolean fromPc;
    final List<CardData> cards = new ArrayList<>();
    int newCount;
    int learningCount;
    int reviewCount;

    DeckData(String name, File sourceFile) {
        this.name = name;
        this.sourceFile = sourceFile;
    }
}
