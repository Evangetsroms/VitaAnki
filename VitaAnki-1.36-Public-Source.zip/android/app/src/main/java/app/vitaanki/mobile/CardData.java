package app.vitaanki.mobile;

import java.util.ArrayList;
import java.util.List;

final class CardData {
    long id;
    String front;
    String back;
    int intervalDays;
    int state;
    long dueAt;
    final List<String> frontImages = new ArrayList<>();

    CardData(long id, String front, String back) {
        this.id = id;
        this.front = front == null ? "" : front;
        this.back = back == null ? "" : back;
    }
}
