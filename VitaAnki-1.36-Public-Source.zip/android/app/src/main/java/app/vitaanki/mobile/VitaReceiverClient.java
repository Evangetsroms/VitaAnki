package app.vitaanki.mobile;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

final class VitaReceiverClient {
    private static final int DISCOVERY_PORT = 27118;
    private static final int TRANSFER_PORT = 27117;

    interface Progress { void onProgress(long sent, long total); }

    static final class Device {
        final InetAddress address;
        final int port;

        Device(InetAddress address, int port) {
            this.address = address;
            this.port = port;
        }
    }

    static final class RemoteDeck {
        final String filename;
        final long size;

        RemoteDeck(String filename, long size) {
            this.filename = filename;
            this.size = size;
        }
    }

    static void send(File file, Device device, String pin, Progress progress) throws Exception {
        if (device == null || device.address == null || device.port != TRANSFER_PORT ||
                !AnkiConnectClient.isPrivateHost(device.address.getHostAddress()))
            throw new IllegalArgumentException("Find a VitaAnki receiver on the same Wi-Fi first.");
        if (pin == null || !pin.trim().matches("[0-9]{6}"))
            throw new IllegalArgumentException("Enter the six-digit code shown on the Vita.");
        if (file == null || !file.isFile() || file.length() <= 0 || file.length() > 256L * 1024L * 1024L)
            throw new IllegalArgumentException("Choose a non-empty deck file smaller than 256 MB.");
        String filename = file.getName().replaceAll("[^A-Za-z0-9._-]", "_");
        String lower = filename.toLowerCase(Locale.US);
        if (!(lower.endsWith(".apkg") || lower.endsWith(".tsv")))
            throw new IllegalArgumentException("Only .apkg and .tsv decks can be sent to VitaAnki.");
        if (filename.contains("..") || filename.length() > 120)
            throw new IllegalArgumentException("That filename is not safe to transfer.");

        try (Socket socket = new Socket()) {
            try {
                socket.connect(new java.net.InetSocketAddress(device.address, device.port), 6000);
            } catch (IOException e) {
                throw new IOException("VitaAnki was found, but its receiver may have closed. Reopen the Vita's Send from Android screen and try again.", e);
            }
            socket.setSoTimeout(120000);
            InputStream input = new BufferedInputStream(socket.getInputStream());
            OutputStream output = new BufferedOutputStream(socket.getOutputStream());
            String header = "VITAANKI/1\t" + pin.trim() + "\t" + file.length() + "\t" + filename + "\n";
            output.write(header.getBytes(StandardCharsets.US_ASCII));
            output.flush();
            String response = readLine(input);
            if (!"READY".equals(response))
                throw new IllegalStateException(response != null && response.startsWith("ERR ") ? response.substring(4) : "VitaAnki did not accept the transfer request.");
            long total = file.length(), sent = 0;
            try (InputStream source = new BufferedInputStream(new FileInputStream(file))) {
                byte[] buffer = new byte[32768];
                while (sent < total) {
                    int wanted = (int)Math.min(buffer.length, total - sent);
                    int n = source.read(buffer, 0, wanted);
                    if (n < 0) throw new IOException("The deck file could not be read completely.");
                    if (n == 0) continue;
                    output.write(buffer, 0, n);
                    sent += n;
                    if (progress != null) progress.onProgress(sent, total);
                }
            }
            output.flush();
            socket.shutdownOutput();
            response = readLine(input);
            if (!"OK".equals(response))
                throw new IllegalStateException(response != null && response.startsWith("ERR ") ? response.substring(4) : "VitaAnki did not confirm the deck was saved.");
        }
    }

    static List<RemoteDeck> listDecks(Device device, String pin) throws Exception {
        requireDeviceAndPin(device, pin);
        try (Socket socket = connectToVita(device)) {
            socket.setSoTimeout(15000);
            InputStream input = new BufferedInputStream(socket.getInputStream());
            OutputStream output = new BufferedOutputStream(socket.getOutputStream());
            writeLine(output, "VITAANKI/LIST/1\t" + pin.trim());
            String response = readLine(input);
            if (response == null) throw new IOException("VitaAnki closed the connection before returning its deck list.");
            if (response.startsWith("ERR ")) throw new IOException(response.substring(4));
            String[] header = response.split("\\t", -1);
            if (header.length != 2 || !"OKLIST/1".equals(header[0]))
                throw new IOException("VitaAnki returned an invalid deck list.");
            int count;
            try { count = Integer.parseInt(header[1]); }
            catch (NumberFormatException e) { throw new IOException("VitaAnki returned an invalid deck count.", e); }
            if (count < 0 || count > 48) throw new IOException("VitaAnki returned an unsupported deck count.");
            List<RemoteDeck> decks = new ArrayList<>();
            for (int i = 0; i < count; i++) {
                String line = readLine(input);
                if (line == null) throw new IOException("VitaAnki closed the deck list early.");
                String[] fields = line.split("\\t", -1);
                if (fields.length != 2 || !safeDeckFilename(fields[0]))
                    throw new IOException("VitaAnki returned an invalid deck entry.");
                long size;
                try { size = Long.parseLong(fields[1]); }
                catch (NumberFormatException e) { throw new IOException("VitaAnki returned an invalid deck size.", e); }
                if (size <= 0 || size > 256L * 1024L * 1024L)
                    throw new IOException("VitaAnki listed a deck outside the supported size limit.");
                decks.add(new RemoteDeck(fields[0], size));
            }
            if (!"END".equals(readLine(input))) throw new IOException("VitaAnki did not finish the deck list.");
            return decks;
        }
    }

    static File download(Device device, String pin, RemoteDeck deck, File destinationFolder, Progress progress) throws Exception {
        requireDeviceAndPin(device, pin);
        if (deck == null || !safeDeckFilename(deck.filename) || deck.size <= 0 || deck.size > 256L * 1024L * 1024L)
            throw new IllegalArgumentException("Choose a valid deck from VitaAnki.");
        if (!destinationFolder.isDirectory() && !destinationFolder.mkdirs())
            throw new IOException("Could not open the Android deck library.");
        File partial = File.createTempFile("vita-download-", ".part", destinationFolder);
        boolean installed = false;
        try (Socket socket = connectToVita(device)) {
            socket.setSoTimeout(15000);
            InputStream input = new BufferedInputStream(socket.getInputStream());
            OutputStream output = new BufferedOutputStream(socket.getOutputStream());
            writeLine(output, "VITAANKI/GET/1\t" + pin.trim() + "\t" + deck.filename);
            String response = readLine(input);
            if (response == null) throw new IOException("VitaAnki closed the connection before starting the download.");
            if (response.startsWith("ERR ")) throw new IOException(response.substring(4));
            String[] ready = response.split("\\t", -1);
            if (ready.length != 2 || !"READY".equals(ready[0]))
                throw new IOException("VitaAnki did not start the deck download.");
            long total;
            try { total = Long.parseLong(ready[1]); }
            catch (NumberFormatException e) { throw new IOException("VitaAnki announced an invalid deck size.", e); }
            if (total <= 0 || total > 256L * 1024L * 1024L)
                throw new IOException("The Vita deck exceeds the 256 MB transfer limit.");
            socket.setSoTimeout(120000);
            try (FileOutputStream file = new FileOutputStream(partial)) {
                byte[] buffer = new byte[32768];
                long received = 0;
                while (received < total) {
                    int wanted = (int)Math.min(buffer.length, total - received);
                    int count = input.read(buffer, 0, wanted);
                    if (count < 0) throw new IOException("VitaAnki closed the connection before the deck finished downloading.");
                    if (count == 0) continue;
                    file.write(buffer, 0, count);
                    received += count;
                    if (progress != null) progress.onProgress(received, total);
                }
                file.flush();
                file.getFD().sync();
            }
            response = readLine(input);
            if (response == null || !"OK".equals(response))
                throw new IOException(response != null && response.startsWith("ERR ")
                        ? response.substring(4) : "VitaAnki did not confirm the deck download.");
            if (!validDownloadedDeck(partial, deck.filename))
                throw new IOException("The downloaded file failed deck validation and was not added to the library.");
            File destination = uniqueDestination(destinationFolder, deck.filename);
            if (!partial.renameTo(destination)) throw new IOException("Could not add the downloaded deck to the library.");
            installed = true;
            return destination;
        } finally {
            if (!installed) partial.delete();
        }
    }

    private static void requireDeviceAndPin(Device device, String pin) {
        if (device == null || device.address == null || device.port != TRANSFER_PORT ||
                !AnkiConnectClient.isPrivateHost(device.address.getHostAddress()))
            throw new IllegalArgumentException("Find VitaAnki on the same Wi-Fi first.");
        if (pin == null || !pin.trim().matches("[0-9]{6}"))
            throw new IllegalArgumentException("Enter the six-digit code shown on the Vita.");
    }

    private static Socket connectToVita(Device device) throws IOException {
        Socket socket = new Socket();
        try {
            socket.connect(new java.net.InetSocketAddress(device.address, device.port), 6000);
            socket.setSoTimeout(120000);
            return socket;
        } catch (IOException e) {
            try { socket.close(); } catch (IOException ignored) { }
            throw new IOException("VitaAnki was found, but its transfer screen may have closed. Reopen Send from Android on the Vita and try again.", e);
        }
    }

    private static void writeLine(OutputStream output, String line) throws IOException {
        output.write((line + "\n").getBytes(StandardCharsets.US_ASCII));
        output.flush();
    }

    private static boolean safeDeckFilename(String filename) {
        if (filename == null || filename.isEmpty() || filename.charAt(0) == '.' || filename.length() > 120 || filename.contains("..") ||
                !filename.matches("[A-Za-z0-9._-]+")) return false;
        String lower = filename.toLowerCase(Locale.US);
        return lower.endsWith(".apkg") || lower.endsWith(".tsv");
    }

    private static boolean validDownloadedDeck(File file, String filename) {
        if (filename.toLowerCase(Locale.US).endsWith(".apkg")) {
            try (ZipFile zip = new ZipFile(file)) {
                ZipEntry collection = zip.getEntry("collection.anki2");
                if (collection == null) collection = zip.getEntry("collection.anki21");
                return collection != null;
            } catch (Exception ignored) { return false; }
        }
        try (InputStream input = new FileInputStream(file)) {
            byte[] sample = new byte[65536];
            int count = input.read(sample);
            if (count <= 0) return false;
            for (int i = 0; i < count; i++) if (sample[i] == '\t') return true;
            return false;
        } catch (IOException ignored) { return false; }
    }

    private static File uniqueDestination(File folder, String filename) {
        File destination = new File(folder, filename);
        if (!destination.exists()) return destination;
        int dot = filename.lastIndexOf('.');
        String base = filename.substring(0, dot);
        String extension = filename.substring(dot);
        int suffix = 2;
        do { destination = new File(folder, base + "-" + suffix++ + extension); }
        while (destination.exists());
        return destination;
    }

    static List<Device> discover() throws Exception {
        String nonce = randomNonce();
        byte[] request = ("VITAANKI_DISCOVER/1\t" + nonce).getBytes(StandardCharsets.US_ASCII);
        Set<String> sentTo = new HashSet<>();
        List<InetAddress> broadcasts = new ArrayList<>();
        Map<String, Device> devices = new LinkedHashMap<>();
        try {
            for (NetworkInterface network : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!network.isUp() || network.isLoopback()) continue;
                for (InterfaceAddress address : network.getInterfaceAddresses()) {
                    InetAddress broadcast = address.getBroadcast();
                    if (broadcast instanceof Inet4Address) broadcasts.add(broadcast);
                }
            }
        } catch (Exception ignored) {
            // The limited broadcast below remains available if interface enumeration fails.
        }
        broadcasts.add(InetAddress.getByName("255.255.255.255"));

        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setBroadcast(true);
            socket.setSoTimeout(400);
            long deadline = System.currentTimeMillis() + 5000L;
            long nextBroadcast = 0;
            byte[] responseBytes = new byte[160];
            while (System.currentTimeMillis() < deadline) {
                long now = System.currentTimeMillis();
                if (now >= nextBroadcast) {
                    for (InetAddress broadcast : broadcasts) {
                        if (!sentTo.add(broadcast.getHostAddress())) continue;
                        try {
                            socket.send(new DatagramPacket(request, request.length, broadcast, DISCOVERY_PORT));
                        } catch (IOException ignored) { }
                    }
                    // Re-send the same nonce in case the Vita receiver started just now.
                    sentTo.clear();
                    nextBroadcast = now + 900L;
                }
                DatagramPacket response = new DatagramPacket(responseBytes, responseBytes.length);
                try {
                    socket.receive(response);
                } catch (SocketTimeoutException ignored) {
                    continue;
                }
                String text = new String(response.getData(), response.getOffset(), response.getLength(), StandardCharsets.US_ASCII);
                String[] fields = text.split("\\t", -1);
                if (fields.length != 3 || !"VITAANKI_HERE/1".equals(fields[0]) || !nonce.equals(fields[1]) ||
                        !(response.getAddress() instanceof Inet4Address) ||
                        !AnkiConnectClient.isPrivateHost(response.getAddress().getHostAddress())) continue;
                int port;
                try { port = Integer.parseInt(fields[2]); }
                catch (NumberFormatException ignored) { continue; }
                if (port != TRANSFER_PORT) continue;
                String key = response.getAddress().getHostAddress() + ":" + port;
                devices.put(key, new Device(response.getAddress(), port));
            }
        }
        return new ArrayList<>(devices.values());
    }

    private static String randomNonce() {
        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        StringBuilder value = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) value.append(String.format(Locale.US, "%02x", b & 0xff));
        return value.toString();
    }

    private static String readLine(InputStream input) throws Exception {
        StringBuilder line = new StringBuilder();
        int value;
        while ((value = input.read()) >= 0) {
            if (value == '\n') break;
            if (value != '\r') line.append((char)value);
            if (line.length() > 256) throw new IllegalStateException("Invalid response from VitaAnki.");
        }
        if (value < 0 && line.length() == 0) throw new IllegalStateException("VitaAnki closed the connection.");
        return line.toString();
    }
}
