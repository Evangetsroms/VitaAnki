package app.vitaanki.mobile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

final class AnkiConnectClient {
    private final String host;
    private final String key;
    private final int port;

    AnkiConnectClient(String host, int port, String key) {
        this.host = host.trim();
        this.port = port;
        this.key = key == null ? "" : key.trim();
    }

    private JSONObject invoke(String action, JSONObject params) throws Exception {
        if (host.isEmpty()) throw new IllegalArgumentException("Enter the computer's Wi-Fi address.");
        if (!isPrivateHost(host)) throw new IllegalArgumentException("For safety, AnkiConnect must use a private home-network address (192.168.x.x, 10.x.x.x, or 172.16–31.x.x).");
        URL url = new URL("http://" + host + ":" + port + "/");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(4000);
        connection.setReadTimeout(7000);
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        JSONObject request = new JSONObject();
        request.put("action", action);
        request.put("version", 6);
        if (!key.isEmpty()) request.put("key", key);
        if (params != null) request.put("params", params);
        byte[] bytes = request.toString().getBytes(StandardCharsets.UTF_8);
        connection.setFixedLengthStreamingMode(bytes.length);
        try (BufferedOutputStream out = new BufferedOutputStream(connection.getOutputStream())) {
            out.write(bytes);
        }
        int status = connection.getResponseCode();
        InputStream input = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
        if (input == null) throw new IllegalStateException("AnkiConnect returned HTTP " + status + ".");
        ByteArrayOutputStream response = new ByteArrayOutputStream();
        try (InputStream in = new BufferedInputStream(input)) {
            byte[] buffer = new byte[8192];
            int n;
            int total = 0;
            while ((n = in.read(buffer)) >= 0) {
                total += n;
                if (total > 4 * 1024 * 1024) throw new IllegalStateException("AnkiConnect response was too large.");
                response.write(buffer, 0, n);
            }
        } finally {
            connection.disconnect();
        }
        JSONObject parsed = new JSONObject(response.toString(StandardCharsets.UTF_8.name()));
        if (!parsed.isNull("error")) throw new IllegalStateException(parsed.optString("error", "AnkiConnect error"));
        return parsed;
    }

    static boolean isPrivateHost(String host) {
        try {
            InetAddress address = InetAddress.getByName(host);
            byte[] b = address.getAddress();
            if (address.isLoopbackAddress() || address.isSiteLocalAddress()) return true;
            if (b.length == 4) {
                int a = b[0] & 255, second = b[1] & 255;
                return a == 10 || (a == 172 && second >= 16 && second <= 31) || (a == 192 && second == 168);
            }
        } catch (Exception ignored) { }
        return false;
    }

    List<String> deckNames() throws Exception {
        JSONArray result = invoke("deckNames", null).optJSONArray("result");
        if (result == null) throw new IllegalStateException("AnkiConnect did not return deck names.");
        List<String> names = new ArrayList<>();
        for (int i = 0; i < result.length(); i++) names.add(result.getString(i));
        return names;
    }

    List<CardData> fetchStudyCards(String deckName) throws Exception {
        int[] counts = studyCounts(deckName);
        int dueLimit = counts[1] + counts[2];
        List<Long> dueLearningIds = findCards(deckQuery(deckName, "due is:learn"));
        List<Long> dueReviewIds = findCards(deckQuery(deckName, "due -is:learn"));
        List<Long> newIds = findCards(deckQuery(deckName, "new"));
        List<Long> dueIds = new ArrayList<>();
        appendIds(dueIds, dueLearningIds);
        appendIds(dueIds, dueReviewIds);
        if (dueIds.size() > dueLimit) dueIds = new ArrayList<>(dueIds.subList(0, dueLimit));
        if (newIds.size() > counts[0]) newIds = new ArrayList<>(newIds.subList(0, counts[0]));
        List<Long> ids = new ArrayList<>();
        appendIds(ids, dueIds);
        appendIds(ids, newIds);
        return fetchCardInfo(ids);
    }

    List<CardData> fetchAllCards(String deckName) throws Exception {
        List<Long> ids = findCards("deck:\"" + escapeDeck(deckName) + "\"");
        return fetchCardInfo(ids);
    }

    private List<Long> findCards(String query) throws Exception {
        JSONObject params = new JSONObject();
        params.put("query", query);
        JSONArray result = invoke("findCards", params).optJSONArray("result");
        List<Long> ids = new ArrayList<>();
        if (result != null) for (int i = 0; i < result.length(); i++) ids.add(result.getLong(i));
        return ids;
    }

    private List<CardData> fetchCardInfo(List<Long> ids) throws Exception {
        List<CardData> cards = new ArrayList<>();
        for (int offset = 0; offset < ids.size() && cards.size() < 2000; offset += 20) {
            JSONArray batch = new JSONArray();
            for (int i = offset; i < Math.min(offset + 20, ids.size()); i++) batch.put(ids.get(i));
            JSONObject params = new JSONObject();
            params.put("cards", batch);
            JSONArray result = invoke("cardsInfo", params).optJSONArray("result");
            if (result == null) continue;
            for (int i = 0; i < result.length() && cards.size() < 2000; i++) {
                JSONObject entry = result.optJSONObject(i);
                if (entry == null || entry.isNull("question") || entry.isNull("answer")) continue;
                CardData card = new CardData(entry.optLong("cardId"),
                        DeckStore.plainText(entry.optString("question")),
                        DeckStore.plainText(entry.optString("answer")));
                card.intervalDays = entry.optInt("interval", 0);
                int queue = entry.optInt("queue", -1);
                card.state = queue == 1 || queue == 3 ? 1 : queue == 2 ? 2 : card.intervalDays > 0 ? 2 : 0;
                cards.add(card);
            }
        }
        return cards;
    }

    JSONObject deckStats(String deckName) throws Exception {
        JSONObject params = new JSONObject();
        JSONArray decks = new JSONArray();
        decks.put(deckName);
        params.put("decks", decks);
        return invoke("getDeckStats", params).optJSONObject("result");
    }

    int[] studyCounts(String deckName) throws Exception {
        try {
            JSONObject stats = deckStats(deckName);
            if (stats != null) {
                java.util.Iterator<String> keys = stats.keys();
                while (keys.hasNext()) {
                    JSONObject row = stats.optJSONObject(keys.next());
                    if (row != null && deckName.equals(row.optString("name")))
                        return new int[]{Math.max(0, row.optInt("new_count", 0)),
                                findCards(deckQuery(deckName, "learn")).size(),
                                Math.max(0, row.optInt("review_count", 0))};
                }
            }
        } catch (Exception ignored) { }
        return new int[]{
                findCards(deckQuery(deckName, "new")).size(),
                findCards(deckQuery(deckName, "learn")).size(),
                findCards(deckQuery(deckName, "due -is:learn")).size()
        };
    }

    int answer(long cardId, int ease) throws Exception {
        JSONArray answers = new JSONArray();
        JSONObject answer = new JSONObject();
        answer.put("cardId", cardId);
        answer.put("ease", ease);
        answers.put(answer);
        JSONObject params = new JSONObject();
        params.put("answers", answers);
        JSONArray result = invoke("answerCards", params).optJSONArray("result");
        if (result == null || result.length() == 0 || !result.optBoolean(0, false))
            throw new IllegalStateException("Anki did not accept that rating.");
        return 1;
    }

    void undo() throws Exception {
        JSONObject result = invoke("guiUndo", null);
        if (!result.optBoolean("result", false)) throw new IllegalStateException("Anki could not undo its latest action.");
    }

    File exportTsv(String deckName, File directory) throws Exception {
        List<CardData> cards = fetchAllCards(deckName);
        if (cards.isEmpty()) throw new IllegalStateException("That Anki deck has no exportable cards.");
        String safe = deckName.replaceAll("[^A-Za-z0-9._ -]", "_").trim();
        if (safe.isEmpty()) safe = "AnkiDeck";
        File output = new File(directory, safe + ".tsv");
        try (FileOutputStream out = new FileOutputStream(output)) {
            for (CardData card : cards) {
                String front = oneLine(card.front);
                String back = oneLine(card.back);
                String row = front + "\t" + back + "\n";
                out.write(row.getBytes(StandardCharsets.UTF_8));
            }
        }
        return output;
    }

    private static String oneLine(String value) {
        return value.replace('\t', ' ').replace('\r', ' ').replace('\n', ' ').trim();
    }

    private static void appendIds(List<Long> into, List<Long> additions) {
        Set<Long> existing = new HashSet<>(into);
        for (Long id : additions) if (existing.add(id)) into.add(id);
    }

    private static String deckQuery(String name, String state) {
        return "deck:\"" + escapeDeck(name) + "\" is:" + state;
    }

    private static String escapeDeck(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
