package app.vitaanki.mobile;

import android.content.Context;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class SecretStore {
    private static final String STORE = "vitaanki_secrets";
    private static final String KEY = "pc_api_key";
    private static final String ALIAS = "vitaanki_ankiconnect_key";

    static void save(Context context, String secret) {
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());
            byte[] iv = cipher.getIV();
            byte[] encrypted = cipher.doFinal(secret.getBytes(StandardCharsets.UTF_8));
            byte[] packed = new byte[iv.length + encrypted.length];
            System.arraycopy(iv, 0, packed, 0, iv.length);
            System.arraycopy(encrypted, 0, packed, iv.length, encrypted.length);
            context.getSharedPreferences(STORE, Context.MODE_PRIVATE).edit()
                    .putString(KEY, Base64.encodeToString(packed, Base64.NO_WRAP)).apply();
            Arrays.fill(packed, (byte)0);
            Arrays.fill(encrypted, (byte)0);
        } catch (Exception ignored) { }
    }

    static String load(Context context) {
        String stored = context.getSharedPreferences(STORE, Context.MODE_PRIVATE).getString(KEY, "");
        if (stored == null || stored.isEmpty()) return "";
        try {
            byte[] packed = Base64.decode(stored, Base64.NO_WRAP);
            if (packed.length < 13) return "";
            byte[] iv = Arrays.copyOfRange(packed, 0, 12);
            byte[] encrypted = Arrays.copyOfRange(packed, 12, packed.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        } catch (Exception e) {
            context.getSharedPreferences(STORE, Context.MODE_PRIVATE).edit().remove(KEY).apply();
            return "";
        }
    }

    private static SecretKey key() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        java.security.Key existing = store.getKey(ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        if (Build.VERSION.SDK_INT < 23) throw new IllegalStateException("Android Keystore is unavailable.");
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }
}
