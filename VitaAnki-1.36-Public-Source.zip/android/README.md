# VitaAnki Mobile for Android — source preview

This is the Android companion source for VitaAnki 0.4.0. It includes a generic sample deck and no personal deck or soundtrack. A verified installable APK is not included in this release.

## Features in the source

- Import compatible Anki `.apkg` packages and UTF-8 tab-separated `.tsv` decks.
- Study offline with a simple local schedule, browse cards, and show supported card images.
- Review against Anki Desktop through AnkiConnect while both devices use a trusted private Wi-Fi network.
- Send decks to VitaAnki or download decks from the Vita using local Wi-Fi and the short-lived code shown by the Vita.

Direct AnkiWeb sync is not implemented. Offline Android progress does not automatically merge with the Anki Desktop scheduler. Complex Anki templates and audio are not rendered.

## Transfer decks with Vita

1. Connect the Android device and Vita to the same local Wi-Fi network.
2. On the Vita, open **Deck Transfer** and start the receiver.
3. On Android, open **Send deck to Vita** or **Download from Vita**, enter the Vita's short-lived code, and choose a deck.
4. Keep the Vita receiver screen open until the transfer completes.

Some guest networks isolate Wi-Fi clients and block local discovery. The app does not require you to type or save the Vita's IP address.

## Connect to Anki Desktop

Anki Desktop and AnkiConnect must be running on the same trusted private network. Configure AnkiConnect with a non-empty API key and allow it on the private-network firewall. The Android app encrypts the key with Android Keystore and restricts the host to local/private addresses. Never expose the AnkiConnect port to the public internet.

## Build from source

Use JDK 17, Android SDK Platform 35, Android Build Tools 34.0.0, and Gradle 8.9. From this directory, run:

```powershell
gradle assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`. The public source uses a generic sample deck. It does not include a personal deck, sync key, debug keystore, or soundtrack.
