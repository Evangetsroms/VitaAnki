# VitaAnki roadmap

## Delivered in Vita 1.34

- Create local question-and-answer decks with the Vita text keyboard and save them as TSV.
- Delete user-added APKG/TSV decks after confirmation, including their local review progress; protect bundled decks.
- Keep the local Wi-Fi transfer receiver open for multiple requests and add PIN-protected Vita deck listing and download endpoints for the Android companion.
- Update the Android handoff with the reverse LIST/GET protocol.

## Delivered in Vita 1.33

- Add a Card Browser stick preference: move the highlight across Previous, Jump, Show Answer, and Next, or use the sticks to scroll the card. D-pad and touch remain available.

## Delivered in 1.32 / Mobile 0.3.0

- Discover the Vita automatically on the local Wi-Fi before sending a deck. Keep the short-lived confirmation code; remove the need to find, type, or share an IP address.
- Preview the selected import file's name, format, and size, and show import error codes with causes and suggested recovery steps.
- Clarify Card Browser controls for analog sticks, D-pad, flip, jump, and back.

## Delivered in 1.20 / Mobile 0.2.0

- Import compatible APKG image media on Vita and Android. Show the first embedded image beside the question on the front and show the answer text alone after flipping. The supplied Anatomy Exam 2 Pictures deck is included in both apps.

## Delivered in 1.27

- Restore Aquatic Ambience playback after adding Vita SQLite allocator setup.
- Enlarge the card image viewport while keeping the full image visible.
- Match the study card accent stripe to its New, Learning, or Review state.
- Remove the header icon from Study and fix the Card Browser selection outline.

## Delivered in 1.28

- Add an optional click sound for touch and button input, with a Settings toggle.
- Let confetti bursts accumulate while earlier pieces are still falling instead of restarting the animation.

## Delivered in 1.29

- Queue click sounds on a background audio thread so touch and button handling do not wait for audio playback.
- Reuse cached card text during live-study refreshes, fetching full details only for changed or newly due cards.

## Delivered in 1.30

- Add the Vita's serif and sans PGF families in regular, italic, bold, and bold-italic styles when the system files are available.
- Smooth card-text scrolling from either analog stick while keeping D-pad scrolling in one-line steps.
- Add Aquatic, Rose, Evergreen, and Moonlight preset palettes.

## Delivered in 1.31

- Keep the top of card text visible while clipping smooth-scroll content to the card viewport.

## Backlog

- Extend the import preview with APKG card/media counts and compatibility warnings before loading the deck.
- Move the remaining live AnkiConnect answer and queue requests off the UI thread so ratings do not pause screen input while waiting on Wi-Fi.
- Expand image handling for multiple images on one card and more Anki note-template layouts.
- Let users tap a card image in Card Browser to focus and pan it, and add a setting to hide card images.
- Add per-deck offline study settings for the daily new-card limit, learning steps, and review intervals. Keep Live mode on Anki Desktop's scheduler.
- Add a theme editor with about nine color choices for the background and accent colors.


