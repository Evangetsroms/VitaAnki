# VitaAnki for PS Vita

VitaAnki is an independent PS Vita flashcard app. Version 1.36 imports compatible Anki `.apkg` packages and tab-separated `.tsv` decks for offline study, and can optionally connect to Anki Desktop through AnkiConnect.

## Current preview

- Study offline with a local spaced-repetition schedule, or review an Anki Desktop deck while connected.
- Set the new-card limit and Again, Hard, Good, and Easy timings for each offline deck.
- Import compatible `.apkg` and `.tsv` decks from `ux0:data/VitaAnki/decks/`.
- Browse cards without rating them; supported image cards show an image beside the question.
- Create and manage decks, with a second confirmation before deleting a deck and its local study data.
- Send decks to Android or download Vita decks over local Wi-Fi.
- Use either analog stick to navigate menus, change fonts and text sizes, select themes, and configure answer flipping and controls.
- The public preview includes only a small generic sample deck. It contains no personal deck or music file.

Direct AnkiWeb sync is not implemented. Live PC review requires Anki Desktop and AnkiConnect on the same private Wi-Fi network. Offline review uses the Vita's local scheduler; live review uses Anki Desktop's scheduler.

## Import a deck

1. Export a deck from Anki Desktop as `.apkg` and enable compatibility for older Anki versions if available, or prepare a UTF-8 tab-separated `.tsv` file.
2. Copy the file to `ux0:data/VitaAnki/decks/` with VitaShell.
3. Open **Import**, choose **Rescan**, select the file, and choose **Import & Study**.

A TSV row contains a question, a tab, and an answer. Imported APKG support is limited; complex templates, audio, and some note types are not rendered.

## Transfer with Android

Connect both devices to the same local Wi-Fi. Open **Deck Transfer** on the Vita and start the receiver. Enter the short-lived code on Android, then send a deck or choose a deck to download from the Vita. Keep the receiver screen open until the transfer finishes. Device discovery can fail on guest Wi-Fi or networks that isolate clients.

## Connect to Anki Desktop

Install AnkiConnect in Anki Desktop and restart Anki. Configure its web bind address for your trusted private LAN and set a strong API key. Copy `sync.example.ini` to `ux0:data/VitaAnki/sync.ini`, then enter your PC's private LAN address, the exact deck name, and the key. In VitaAnki, choose **Sync with PC** and press **Connect to Anki Desktop**. Never post the real `sync.ini` or API key.

## Build

Install VitaSDK, CMake, Ninja, and the libraries used by this project (`libvita2d`, `libzip`, `curl`, and `jansson`). From the repository root:

```sh
cmake -S vita -B build -DCMAKE_TOOLCHAIN_FILE="$VITASDK/share/vita.toolchain.cmake" -DVITA_BUNDLE_PICTURE_DECK=OFF -DVITAANKI_ENABLE_MUSIC=OFF
cmake --build build
```

The build creates `vitaanki.vpk`. Music is disabled and no personal deck is bundled by default. The public source tree includes a generic sample deck only.

## Stability and limitations

This is an alpha preview. APKG import and long sessions have produced errors on some Vita setups. Keep a separate backup of decks and progress before upgrading. Live AnkiConnect review uses Anki Desktop's scheduler; offline scheduling is a simpler local schedule and does not automatically merge into the desktop collection.
