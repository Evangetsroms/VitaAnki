#include "anki_music.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <string.h>
#include <psp2/audiodec.h>
#include <psp2/audioout.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/sysmodule.h>

#define MUSIC_PATH "app0:/audio/aquatic_ambience.mp3"
#define MUSIC_LOG_PATH "ux0:data/VitaAnki/music.log"
#define MP3_ES_BUFFER_SIZE SCE_AUDIODEC_ROUND_UP(SCE_AUDIODEC_MP3_MAX_ES_SIZE)
#define PCM_BUFFER_SAMPLES (SCE_AUDIODEC_MP3_MAX_SAMPLES * SCE_AUDIODEC_MP3_MAX_CH_IN_DECODER)
#define CLICK_SAMPLE_RATE 48000
#define CLICK_SAMPLE_COUNT 512

static volatile int music_running = 0;
static volatile int music_muted = 0;
static volatile int music_available = 0;
static SceUID music_thread = -1;
static uint8_t mp3_es_buffer[MP3_ES_BUFFER_SIZE] __attribute__((aligned(SCE_AUDIODEC_ALIGNMENT_SIZE)));
static int16_t pcm_buffer[PCM_BUFFER_SAMPLES] __attribute__((aligned(SCE_AUDIODEC_ALIGNMENT_SIZE)));
static int16_t silence_buffer[PCM_BUFFER_SAMPLES] __attribute__((aligned(SCE_AUDIODEC_ALIGNMENT_SIZE)));
static int16_t click_pcm[CLICK_SAMPLE_COUNT * 2] __attribute__((aligned(64)));
static volatile int click_worker_running = 0;
static volatile int click_requests = 0;
static SceUID click_thread = -1;

typedef struct {
    int version;
    int channels;
    int sample_rate;
    int samples;
    int frame_size;
} Mp3FrameInfo;

static void music_log(const char *format, ...) {
    FILE *file = fopen(MUSIC_LOG_PATH, "a");
    if (!file) return;
    va_list args;
    va_start(args, format);
    vfprintf(file, format, args);
    va_end(args);
    fputc('\n', file);
    fclose(file);
}

static int parse_mp3_header(const uint8_t *bytes, Mp3FrameInfo *info) {
    static const int mpeg1_layer3_bitrates[16] = {
        0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0
    };
    static const int mpeg2_layer3_bitrates[16] = {
        0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0
    };
    static const int sample_rates[3] = {44100, 48000, 32000};

    uint32_t header = ((uint32_t)bytes[0] << 24) |
                      ((uint32_t)bytes[1] << 16) |
                      ((uint32_t)bytes[2] << 8) |
                      (uint32_t)bytes[3];
    if ((header & 0xFFE00000u) != 0xFFE00000u) return 0;

    int version = (header >> 19) & 3;
    int layer = (header >> 17) & 3;
    int bitrate_index = (header >> 12) & 15;
    int sample_index = (header >> 10) & 3;
    int padding = (header >> 9) & 1;
    int channel_mode = (header >> 6) & 3;
    if (version == 1 || layer != 1 || bitrate_index == 0 || bitrate_index == 15 || sample_index == 3)
        return 0;

    int bitrate_kbps = version == 3 ? mpeg1_layer3_bitrates[bitrate_index]
                                      : mpeg2_layer3_bitrates[bitrate_index];
    int sample_rate = sample_rates[sample_index];
    if (version == 2) sample_rate /= 2;
    else if (version == 0) sample_rate /= 4;

    int samples = version == 3 ? 1152 : 576;
    int frame_size = ((version == 3 ? 144000 : 72000) * bitrate_kbps) / sample_rate + padding;
    if (frame_size < 4 || frame_size > SCE_AUDIODEC_MP3_MAX_ES_SIZE) return 0;

    info->version = version;
    info->channels = channel_mode == 3 ? 1 : 2;
    info->sample_rate = sample_rate;
    info->samples = samples;
    info->frame_size = frame_size;
    return 1;
}

static long mp3_audio_start(FILE *file) {
    uint8_t id3[10];
    long start = 0;
    if (fseek(file, 0, SEEK_SET) != 0) return -1;
    if (fread(id3, 1, sizeof(id3), file) == sizeof(id3) &&
        id3[0] == 'I' && id3[1] == 'D' && id3[2] == '3') {
        long tag_size = ((long)(id3[6] & 0x7F) << 21) |
                        ((long)(id3[7] & 0x7F) << 14) |
                        ((long)(id3[8] & 0x7F) << 7) |
                        (long)(id3[9] & 0x7F);
        start = 10 + tag_size;
        if (id3[5] & 0x10) start += 10;
    }
    return start;
}

static int read_next_mp3_frame(FILE *file, long file_size, long *cursor,
                               Mp3FrameInfo *info, uint8_t *frame_buffer) {
    uint8_t header[4];
    while (*cursor >= 0 && *cursor + 4 <= file_size) {
        long frame_start = *cursor;
        if (fseek(file, frame_start, SEEK_SET) != 0 || fread(header, 1, sizeof(header), file) != sizeof(header))
            return 0;
        if (!parse_mp3_header(header, info)) {
            (*cursor)++;
            continue;
        }
        if (frame_start + info->frame_size > file_size ||
            (size_t)info->frame_size > sizeof(mp3_es_buffer)) {
            (*cursor)++;
            continue;
        }
        if (fseek(file, frame_start, SEEK_SET) != 0 ||
            fread(frame_buffer, 1, (size_t)info->frame_size, file) != (size_t)info->frame_size) {
            return 0;
        }
        *cursor = frame_start + info->frame_size;
        return 1;
    }
    return 0;
}

static void cleanup_decoder(SceAudiodecCtrl *decoder, int decoder_created, int library_initialized) {
    if (decoder_created) {
        int result = sceAudiodecDeleteDecoder(decoder);
        music_log("Delete MP3 decoder: %d", result);
    }
    if (library_initialized) {
        int result = sceAudiodecTermLibrary(SCE_AUDIODEC_TYPE_MP3);
        music_log("Terminate MP3 decoder library: %d", result);
    }
}

static void unload_audio_codec(void) {
    int result = sceSysmoduleUnloadModuleInternal(SCE_SYSMODULE_INTERNAL_AUDIOCODEC);
    music_log("Internal AudioCodec module unload: %d", result);
}

static int play_user_track(void) {
    int result = sceSysmoduleLoadModuleInternal(SCE_SYSMODULE_INTERNAL_AUDIOCODEC);
    music_log("Internal AudioCodec module load: %d", result);
    if (result < 0) return 0;

    FILE *file = fopen(MUSIC_PATH, "rb");
    if (!file) {
        music_log("Open track failed: %s", MUSIC_PATH);
        unload_audio_codec();
        return 0;
    }
    if (fseek(file, 0, SEEK_END) != 0) {
        music_log("Seek track failed");
        fclose(file);
        unload_audio_codec();
        return 0;
    }
    long file_size = ftell(file);
    long cursor = mp3_audio_start(file);
    if (file_size <= 0 || cursor < 0 || cursor >= file_size) {
        music_log("Invalid MP3 file size or ID3 offset: size=%ld offset=%ld", file_size, cursor);
        fclose(file);
        unload_audio_codec();
        return 0;
    }

    Mp3FrameInfo first_info;
    long first_cursor = cursor;
    if (!read_next_mp3_frame(file, file_size, &cursor, &first_info, mp3_es_buffer)) {
        music_log("No MP3 frame found after ID3 tag at offset %ld", first_cursor);
        fclose(file);
        unload_audio_codec();
        return 0;
    }
    long first_frame_offset = cursor - first_info.frame_size;
    cursor = first_frame_offset;
    music_log("MP3 found: offset=%ld size=%ld version=%d channels=%d rate=%d frame=%d samples=%d",
              first_frame_offset, file_size, first_info.version, first_info.channels,
              first_info.sample_rate, first_info.frame_size, first_info.samples);

    SceAudiodecInitParam init_param;
    memset(&init_param, 0, sizeof(init_param));
    init_param.mp3.size = sizeof(init_param.mp3);
    init_param.mp3.totalStreams = 1;
    result = sceAudiodecInitLibrary(SCE_AUDIODEC_TYPE_MP3, &init_param);
    music_log("Initialize MP3 decoder library: %d", result);
    if (result < 0) {
        fclose(file);
        unload_audio_codec();
        return 0;
    }

    SceAudiodecInfo decoder_info;
    memset(&decoder_info, 0, sizeof(decoder_info));
    decoder_info.mp3.size = sizeof(decoder_info.mp3);
    decoder_info.mp3.ch = first_info.channels;
    decoder_info.mp3.version = first_info.version;

    SceAudiodecCtrl decoder;
    memset(&decoder, 0, sizeof(decoder));
    decoder.size = sizeof(decoder);
    decoder.pEs = mp3_es_buffer;
    decoder.inputEsSize = (SceUInt32)first_info.frame_size;
    decoder.maxEsSize = sizeof(mp3_es_buffer);
    decoder.pPcm = pcm_buffer;
    decoder.maxPcmSize = sizeof(pcm_buffer);
    decoder.wordLength = SCE_AUDIODEC_WORD_LENGTH_16BITS;
    decoder.pInfo = &decoder_info;
    result = sceAudiodecCreateDecoder(&decoder, SCE_AUDIODEC_TYPE_MP3);
    music_log("Create MP3 decoder: %d handle=%d", result, decoder.handle);
    if (result < 0) {
        cleanup_decoder(&decoder, 0, 1);
        fclose(file);
        unload_audio_codec();
        return 0;
    }

    SceAudioOutMode mode = first_info.channels == 1 ? SCE_AUDIO_OUT_MODE_MONO : SCE_AUDIO_OUT_MODE_STEREO;
    int port = sceAudioOutOpenPort(SCE_AUDIO_OUT_PORT_TYPE_BGM,
                                   first_info.samples,
                                   first_info.sample_rate,
                                   mode);
    music_log("AudioOut open: %d (samples=%d rate=%d channels=%d)",
              port, first_info.samples, first_info.sample_rate, first_info.channels);
    if (port < 0) {
        cleanup_decoder(&decoder, 1, 1);
        fclose(file);
        unload_audio_codec();
        return 0;
    }

    int volume[2] = {24576, 24576};
    result = sceAudioOutSetVolume(port,
                                  SCE_AUDIO_VOLUME_FLAG_L_CH | SCE_AUDIO_VOLUME_FLAG_R_CH,
                                  volume);
    music_log("SetVolume: %d", result);

    int first_decode_logged = 0;
    int first_output_logged = 0;
    int first_decode_error_logged = 0;
    int last_samples = first_info.samples;
    int last_rate = first_info.sample_rate;
    int last_channels = first_info.channels;

    while (music_running) {
        Mp3FrameInfo frame_info;
        if (!read_next_mp3_frame(file, file_size, &cursor, &frame_info, mp3_es_buffer)) {
            int seek_result = sceAudiodecClearContext(&decoder);
            music_log("Loop track: clear decoder context=%d", seek_result);
            if (seek_result < 0) break;
            cursor = first_frame_offset;
            continue;
        }
        if (frame_info.channels != first_info.channels || frame_info.version != first_info.version) {
            if (!first_decode_error_logged) {
                music_log("MP3 stream changed decoder format at offset %ld", cursor - frame_info.frame_size);
                first_decode_error_logged = 1;
            }
            continue;
        }

        decoder.inputEsSize = (SceUInt32)frame_info.frame_size;
        decoder.outputPcmSize = 0;
        result = sceAudiodecDecode(&decoder);
        if (result < 0) {
            SceInt32 internal_error = 0;
            sceAudiodecGetInternalError(&decoder, &internal_error);
            if (!first_decode_error_logged) {
                music_log("MP3 decode failed: 0x%08X internal=0x%08X offset=%ld frame=%d",
                          (unsigned int)result, (unsigned int)internal_error,
                          cursor - frame_info.frame_size, frame_info.frame_size);
                first_decode_error_logged = 1;
            }
            break;
        }

        int bytes_per_sample = frame_info.channels * (int)sizeof(int16_t);
        if (decoder.outputPcmSize == 0 || decoder.outputPcmSize > sizeof(pcm_buffer) ||
            decoder.outputPcmSize % (SceUInt32)bytes_per_sample != 0) {
            if (!first_decode_error_logged) {
                music_log("Invalid decoded PCM size: %u", (unsigned int)decoder.outputPcmSize);
                first_decode_error_logged = 1;
            }
            break;
        }
        int samples = (int)(decoder.outputPcmSize / (SceUInt32)bytes_per_sample);
        if (samples < SCE_AUDIO_MIN_LEN || samples > SCE_AUDIODEC_MP3_MAX_SAMPLES || samples % 64 != 0) {
            if (!first_decode_error_logged) {
                music_log("Unsupported decoded PCM frame size: %d", samples);
                first_decode_error_logged = 1;
            }
            break;
        }

        if (!first_decode_logged) {
            music_log("First decoded frame: samples=%d bytes=%u rate=%d channels=%d",
                      samples, (unsigned int)decoder.outputPcmSize,
                      frame_info.sample_rate, frame_info.channels);
            first_decode_logged = 1;
        }

        if (samples != last_samples || frame_info.sample_rate != last_rate ||
            frame_info.channels != last_channels) {
            mode = frame_info.channels == 1 ? SCE_AUDIO_OUT_MODE_MONO : SCE_AUDIO_OUT_MODE_STEREO;
            result = sceAudioOutSetConfig(port, samples, frame_info.sample_rate, mode);
            if (result < 0) {
                music_log("AudioOut reconfigure failed: %d", result);
                break;
            }
            last_samples = samples;
            last_rate = frame_info.sample_rate;
            last_channels = frame_info.channels;
        }

        const void *output = pcm_buffer;
        if (music_muted) {
            memset(silence_buffer, 0, decoder.outputPcmSize);
            output = silence_buffer;
        }
        result = sceAudioOutOutput(port, output);
        if (!first_output_logged) {
            music_log("First output: %d muted=%d", result, music_muted);
            first_output_logged = 1;
        }
        if (result < 0) {
            music_log("Audio output failed: %d", result);
            break;
        }
        music_available = 1;
    }

    music_available = 0;
    result = sceAudioOutOutput(port, NULL);
    music_log("Flush output: %d", result);
    result = sceAudioOutReleasePort(port);
    music_log("Release port: %d", result);
    cleanup_decoder(&decoder, 1, 1);
    fclose(file);
    unload_audio_codec();
    return 1;
}

static int music_thread_main(SceSize args, void *argp) {
    (void)args;
    (void)argp;
    int result = play_user_track();
    music_log("Player loop ended: %d", result);
    music_available = 0;
    music_running = 0;
    return 0;
}

void anki_music_start(void) {
    if (music_thread >= 0) {
        if (music_running) return;
        sceKernelWaitThreadEnd(music_thread, NULL, NULL);
        sceKernelDeleteThread(music_thread);
        music_thread = -1;
    }
    FILE *log = fopen(MUSIC_LOG_PATH, "w");
    if (log) {
        fputs("VitaAnki music startup\n", log);
        fclose(log);
    }
    music_running = 1;
    music_available = 0;
    music_thread = sceKernelCreateThread("vitaanki_music",
                                         music_thread_main,
                                         0x10000100,
                                         0x20000,
                                         0,
                                         0,
                                         NULL);
    if (music_thread < 0 || sceKernelStartThread(music_thread, 0, NULL) < 0) {
        music_log("Music thread create/start failed: %d", music_thread);
        music_running = 0;
        music_available = 0;
        if (music_thread >= 0) sceKernelDeleteThread(music_thread);
        music_thread = -1;
    }
}

void anki_music_stop(void) {
    music_running = 0;
    if (music_thread >= 0) {
        sceKernelWaitThreadEnd(music_thread, NULL, NULL);
        sceKernelDeleteThread(music_thread);
        music_thread = -1;
    }
}

void anki_music_set_muted(int muted) {
    music_muted = muted ? 1 : 0;
    if (!music_muted && !music_running) anki_music_start();
}

int anki_music_is_muted(void) {
    return music_muted;
}

int anki_music_is_available(void) {
    return music_available;
}

int anki_music_is_running(void) {
    return music_running;
}

static void build_click_samples(void) {
    float phase = 0.0f;
    for (int i = 0; i < CLICK_SAMPLE_COUNT; i++) {
        float progress = (float)i / (float)CLICK_SAMPLE_COUNT;
        float frequency = 1850.0f - 650.0f * progress;
        float envelope = 1.0f - progress;
        int16_t sample = (int16_t)(sinf(phase) * 10500.0f * envelope);
        click_pcm[i * 2] = sample;
        click_pcm[i * 2 + 1] = sample;
        phase += 6.28318530718f * frequency / (float)CLICK_SAMPLE_RATE;
    }
}

static int take_click_request(void) {
    for (;;) {
        int pending = __sync_fetch_and_add(&click_requests, 0);
        if (pending <= 0) return 0;
        if (__sync_bool_compare_and_swap(&click_requests, pending, pending - 1)) return 1;
    }
}

static void queue_click_request(void) {
    for (;;) {
        int pending = __sync_fetch_and_add(&click_requests, 0);
        if (pending >= 3) return;
        if (__sync_bool_compare_and_swap(&click_requests, pending, pending + 1)) return;
    }
}

static int click_thread_main(SceSize args, void *argp) {
    (void)args;
    (void)argp;
    int port = sceAudioOutOpenPort(SCE_AUDIO_OUT_PORT_TYPE_MAIN,
                                   CLICK_SAMPLE_COUNT,
                                   CLICK_SAMPLE_RATE,
                                   SCE_AUDIO_OUT_MODE_STEREO);
    if (port < 0) {
        click_worker_running = 0;
        return 0;
    }

    int volume[2] = {18000, 18000};
    sceAudioOutSetVolume(port,
                         SCE_AUDIO_VOLUME_FLAG_L_CH | SCE_AUDIO_VOLUME_FLAG_R_CH,
                         volume);
    while (click_worker_running) {
        if (take_click_request()) {
            build_click_samples();
            if (sceAudioOutOutput(port, click_pcm) < 0) break;
        } else {
            sceKernelDelayThread(2000);
        }
    }
    sceAudioOutOutput(port, NULL);
    sceAudioOutReleasePort(port);
    click_worker_running = 0;
    return 0;
}

static void start_click_worker(void) {
    if (click_thread >= 0) return;
    click_requests = 0;
    click_worker_running = 1;
    click_thread = sceKernelCreateThread("vitaanki_click",
                                         click_thread_main,
                                         0x10000100,
                                         0x4000,
                                         0,
                                         0,
                                         NULL);
    if (click_thread < 0 || sceKernelStartThread(click_thread, 0, NULL) < 0) {
        click_worker_running = 0;
        if (click_thread >= 0) sceKernelDeleteThread(click_thread);
        click_thread = -1;
    }
}

void anki_music_play_click(void) {
    start_click_worker();
    if (click_thread >= 0 && click_worker_running) queue_click_request();
}

void anki_music_click_shutdown(void) {
    if (click_thread < 0) return;
    click_worker_running = 0;
    sceKernelWaitThreadEnd(click_thread, NULL, NULL);
    sceKernelDeleteThread(click_thread);
    click_thread = -1;
    click_requests = 0;
}
