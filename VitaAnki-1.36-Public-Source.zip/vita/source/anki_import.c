#include "vitaanki.h"
#include "sqlite_min.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <psp2/kernel/sysmem.h>
#include <sys/stat.h>
#include <zip.h>
#include <jansson.h>
#include <psp2/sqlite.h>

#define DATABASE_PATH "ux0:data/VitaAnki/imported.anki2"
#define DATABASE_PATH_ALT "ux0:/data/VitaAnki/imported.anki2"
#define MEDIA_INDEX_PATH "ux0:data/VitaAnki/imported.media"

static char last_import_diagnostic[192] = "No import error details available.";

static int free_user_memory_kb(void) {
    SceKernelFreeMemorySizeInfo info = {0};
    info.size = sizeof(info);
    if (sceKernelGetFreeMemorySize(&info) < 0) return -1;
    return info.size_user / 1024;
}

static int sqlite_allocator_configured = 0;

static void *sqlite_malloc(int bytes) {
    return bytes > 0 ? malloc((size_t)bytes) : NULL;
}

static void *sqlite_realloc(void *pointer, int bytes) {
    if (bytes <= 0) {
        free(pointer);
        return NULL;
    }
    return realloc(pointer, (size_t)bytes);
}

static void sqlite_free(void *pointer) {
    free(pointer);
}

static int configure_sqlite_allocator(void) {
    if (sqlite_allocator_configured) return 1;
    SceSqliteMallocMethods methods = {
        sqlite_malloc,
        sqlite_realloc,
        sqlite_free
    };
    int result = sceSqliteConfigMallocMethods(&methods);
    if (result != 0) {
        snprintf(last_import_diagnostic, sizeof(last_import_diagnostic),
                 "SQLite memory setup failed (%d).", result);
        return 0;
    }
    sqlite_allocator_configured = 1;
    return 1;
}

const char *import_apkg_diagnostic(void) {
    return last_import_diagnostic;
}

static int extract_member(zip_t *archive, const char *name, const char *destination) {
    zip_int64_t index = zip_name_locate(archive, name, 0);
    if (index < 0) return 0;

    struct zip_stat info;
    zip_stat_init(&info);
    if (zip_stat_index(archive, (zip_uint64_t)index, 0, &info) != 0 ||
        !(info.valid & ZIP_STAT_SIZE) || info.size > 256ULL * 1024 * 1024) return 0;

    zip_file_t *member = zip_fopen_index(archive, (zip_uint64_t)index, 0);
    if (!member) return 0;
    FILE *out = fopen(destination, "wb");
    if (!out) {
        zip_fclose(member);
        return 0;
    }

    char buffer[8192];
    zip_int64_t read_count;
    zip_uint64_t extracted_size = 0;
    int ok = 1;
    while ((read_count = zip_fread(member, buffer, sizeof(buffer))) > 0) {
        if (extracted_size + (zip_uint64_t)read_count > info.size) {
            ok = 0;
            break;
        }
        if (fwrite(buffer, 1, (size_t)read_count, out) != (size_t)read_count) {
            ok = 0;
            break;
        }
        extracted_size += (zip_uint64_t)read_count;
    }
    if (read_count < 0 || extracted_size != info.size) ok = 0;
    if (fclose(out) != 0) ok = 0;
    if (zip_fclose(member) != 0) ok = 0;
    if (!ok) remove(destination);
    return ok;
}

static int file_exists(const char *path) {
    FILE *file = fopen(path, "rb");
    if (!file) return 0;
    fclose(file);
    return 1;
}

static void media_basename(const char *input, char *output, size_t output_size) {
    const char *base = input;
    for (const char *p = input; *p; p++) if (*p == '/' || *p == '\\') base = p + 1;
    size_t used = 0;
    for (const char *p = base; *p && used + 1 < output_size; p++) {
        unsigned char c = (unsigned char)*p;
        output[used++] = (isalnum(c) || c == '.' || c == '_' || c == '-') ? (char)c : '_';
    }
    output[used] = '\0';
    if (!strcmp(output, ".") || !strcmp(output, "..")) output[0] = '\0';
}

static int field_index(json_t *model, const char *a, const char *b, const char *c) {
    json_t *fields = json_object_get(model, "flds");
    if (!json_is_array(fields)) return -1;
    size_t i;
    json_t *field;
    json_array_foreach(fields, i, field) {
        const char *name = json_string_value(json_object_get(field, "name"));
        if (name && ((!strcasecmp(name, a)) || (b && !strcasecmp(name, b)) ||
                     (c && !strcasecmp(name, c)))) return (int)i;
    }
    return -1;
}

static json_t *load_models(sqlite3 *db) {
    sqlite3_stmt *statement = NULL;
    if (sqlite3_prepare_v2(db, "SELECT models FROM col LIMIT 1", -1,
                           &statement, NULL) != SQLITE_OK) return NULL;
    json_t *models = NULL;
    if (sqlite3_step(statement) == SQLITE_ROW) {
        const char *raw = (const char *)sqlite3_column_text(statement, 0);
        if (raw) models = json_loads(raw, 0, NULL);
    }
    sqlite3_finalize(statement);
    return models;
}

static void extract_media_files(zip_t *archive, json_t *media_map,
                                const char *media_dir) {
    if (!json_is_object(media_map)) return;
    mkdir(media_dir, 0777);
    const char *entry_id;
    json_t *filename_value;
    json_object_foreach(media_map, entry_id, filename_value) {
        const char *filename = json_string_value(filename_value);
        if (!filename || !*filename) continue;
        char safe_name[256];
        media_basename(filename, safe_name, sizeof(safe_name));
        if (!safe_name[0]) continue;
        char path[768];
        int length = snprintf(path, sizeof(path), "%s/%s", media_dir, safe_name);
        if (length < 0 || (size_t)length >= sizeof(path) || file_exists(path)) continue;
        extract_member(archive, entry_id, path);
    }
}

static void find_front_image(const char *raw_fields, json_t *media_map,
                             const char *media_dir, char *output,
                             size_t output_size) {
    output[0] = '\0';
    if (!raw_fields || !json_is_object(media_map)) return;
    const char *p = raw_fields;
    while (*p) {
        while (*p && !(p[0] == '<' && p[1] && p[2] && p[3] && tolower((unsigned char)p[1]) == 'i' &&
                        tolower((unsigned char)p[2]) == 'm' &&
                        tolower((unsigned char)p[3]) == 'g')) p++;
        if (!*p) return;
        const char *tag_end = strchr(p, '>');
        if (!tag_end) return;
        const char *src = p;
        while (src < tag_end && strncasecmp(src, "src", 3) != 0) src++;
        if (src < tag_end) {
            src += 3;
            while (src < tag_end && isspace((unsigned char)*src)) src++;
            if (src < tag_end && *src == '=') {
                src++;
                while (src < tag_end && isspace((unsigned char)*src)) src++;
                char quote = (*src == '\'' || *src == '"') ? *src++ : 0;
                const char *end = src;
                while (end < tag_end && (quote ? *end != quote : !isspace((unsigned char)*end))) end++;
                size_t ref_len = (size_t)(end - src);
                if (ref_len > 0 && ref_len < 256) {
                    char ref[256];
                    memcpy(ref, src, ref_len);
                    ref[ref_len] = '\0';
                    char ref_base[256];
                    media_basename(ref, ref_base, sizeof(ref_base));
                    const char *entry_id;
                    json_t *mapped_value;
                    json_object_foreach(media_map, entry_id, mapped_value) {
                        const char *mapped_name = json_string_value(mapped_value);
                        if (!mapped_name) continue;
                        char mapped_base[256];
                        media_basename(mapped_name, mapped_base, sizeof(mapped_base));
                        if (strcmp(ref_base, mapped_base) != 0) continue;
                        int length = snprintf(output, output_size, "%s/%s", media_dir, mapped_base);
                        if (length < 0 || (size_t)length >= output_size) output[0] = '\0';
                        return;
                    }
                }
            }
        }
        p = tag_end + 1;
    }
}

static void copy_field(char *out, size_t out_size, const char *start, size_t length) {
    if (length >= out_size) length = out_size - 1;
    memcpy(out, start, length);
    out[length] = '\0';
}

static int split_fields(const char *fields, char out[8][FIELD_SIZE]) {
    int count = 0;
    const char *start = fields;
    const char *p = fields;
    while (1) {
        if (*p == '\x1f' || *p == '\0') {
            if (count < 8) copy_field(out[count++], FIELD_SIZE, start, (size_t)(p - start));
            if (*p == '\0' || count == 8) break;
            start = p + 1;
        }
        p++;
    }
    return count;
}

static void strip_html(char *text) {
    char output[FIELD_SIZE];
    size_t out = 0;
    int in_tag = 0;
    for (size_t i = 0; text[i] && out + 1 < sizeof(output); i++) {
        if (text[i] == '<') {
            in_tag = 1;
            if (!strncmp(text + i, "<br", 3) || !strncmp(text + i, "<BR", 3))
                output[out++] = ' ';
            continue;
        }
        if (in_tag) {
            if (text[i] == '>') in_tag = 0;
            continue;
        }
        if (!strncmp(text + i, "&nbsp;", 6)) {
            output[out++] = ' ';
            i += 5;
        } else if (!strncmp(text + i, "&amp;", 5)) {
            output[out++] = '&';
            i += 4;
        } else if (!strncmp(text + i, "&lt;", 4)) {
            output[out++] = '<';
            i += 3;
        } else if (!strncmp(text + i, "&gt;", 4)) {
            output[out++] = '>';
            i += 3;
        } else {
            output[out++] = text[i];
        }
    }
    output[out] = '\0';
    snprintf(text, FIELD_SIZE, "%s", output);
}

static void cloze_text(const char *source, int wanted, int reveal_all,
                       char *out, size_t out_size) {
    size_t used = 0;
    const char *p = source;
    while (*p && used + 1 < out_size) {
        if (p[0] == '{' && p[1] == '{' && p[2] == 'c') {
            char *number_end = NULL;
            long ordinal = strtol(p + 3, &number_end, 10);
            if (number_end != p + 3 && number_end[0] == ':' && number_end[1] == ':') {
                const char *value = number_end + 2;
                const char *hint_sep = strstr(value, "::");
                const char *close = strstr(value, "}}");
                if (close) {
                    const char *value_end = close;
                    if (hint_sep && hint_sep < close) value_end = hint_sep;
                    int hide = !reveal_all && ordinal == wanted + 1;
                    if (hide) {
                        const char *hint = (hint_sep && hint_sep < close) ? hint_sep + 2 : NULL;
                        const char *hint_end = hint ? close : NULL;
                        const char *replacement = hint ? hint : "[...]";
                        size_t len = hint ? (size_t)(hint_end - hint) : 5;
                        if (used + len >= out_size) len = out_size - used - 1;
                        memcpy(out + used, replacement, len);
                        used += len;
                    } else {
                        size_t len = (size_t)(value_end - value);
                        if (used + len >= out_size) len = out_size - used - 1;
                        memcpy(out + used, value, len);
                        used += len;
                    }
                    p = close + 2;
                    continue;
                }
            }
        }
        out[used++] = *p++;
    }
    out[used] = '\0';
}

static void make_card(Card *card, const char *raw_fields, int ord, json_t *model,
                      json_t *media_map, const char *media_dir) {
    char fields[8][FIELD_SIZE] = {{0}};
    int count = split_fields(raw_fields, fields);
    if (count == 0) return;

    if (strstr(fields[0], "{{c")) {
        cloze_text(fields[0], ord, 0, card->front, sizeof(card->front));
        cloze_text(fields[0], ord, 1, card->back, sizeof(card->back));
    } else {
        int front_field = field_index(model, "Question", "Front", "Prompt");
        int back_field = field_index(model, "Answer", "Back", "Solution");
        if (front_field < 0) front_field = ord == 1 && count > 1 ? 1 : 0;
        if (back_field < 0) back_field = count > 1 ? (front_field == 0 ? 1 : 0) : front_field;
        if (front_field >= count) front_field = 0;
        if (back_field >= count) back_field = count > 1 ? 1 : 0;
        snprintf(card->front, sizeof(card->front), "%s", fields[front_field]);
        snprintf(card->back, sizeof(card->back), "%s", fields[back_field]);
    }
    strip_html(card->front);
    strip_html(card->back);
    find_front_image(raw_fields, media_map, media_dir,
                     card->front_image, sizeof(card->front_image));
}

int import_apkg(const char *package_path, Card **cards, int *allocated_capacity,
                int max_cards) {
    snprintf(last_import_diagnostic, sizeof(last_import_diagnostic), "No import error details available.");
    if (!package_path || !cards || !allocated_capacity || max_cards <= 0) return -1;
    FILE *probe = fopen(package_path, "rb");
    if (!probe) return -1;
    fclose(probe);

    int error = 0;
    zip_t *archive = zip_open(package_path, ZIP_RDONLY, &error);
    if (!archive) return -1;

    remove(DATABASE_PATH);
    int extracted = extract_member(archive, "collection.anki2", DATABASE_PATH);
    if (!extracted) extracted = extract_member(archive, "collection.anki21", DATABASE_PATH);
    char media_dir[768];
    snprintf(media_dir, sizeof(media_dir), "%s.media", package_path);
    mkdir(media_dir, 0777);
    remove(MEDIA_INDEX_PATH);
    int media_index_extracted = extract_member(archive, "media", MEDIA_INDEX_PATH);
    zip_close(archive);
    if (!extracted) {
        remove(MEDIA_INDEX_PATH);
        return -2;
    }

    if (!configure_sqlite_allocator()) {
        remove(MEDIA_INDEX_PATH);
        return -9;
    }

    sqlite3 *db = NULL;
    int free_memory_before = free_user_memory_kb();
    const int open_flags = SQLITE_OPEN_READONLY | SQLITE_OPEN_NOMUTEX;
    int open_result = sqlite3_open_v2(DATABASE_PATH, &db, open_flags, NULL);
    int alternate_result = SQLITE_OK;
    if (open_result != SQLITE_OK || !db) {
        if (db) sqlite3_close(db);
        db = NULL;

        alternate_result = sqlite3_open_v2(DATABASE_PATH_ALT, &db, open_flags, NULL);
        if (alternate_result != SQLITE_OK || !db) {
            if (db) sqlite3_close(db);
            db = NULL;
        }
    }
    if (!db) {
        int free_memory_after = free_user_memory_kb();
        snprintf(last_import_diagnostic, sizeof(last_import_diagnostic),
                 "SQLite open %d/retry %d; free user RAM %d->%d KB.",
                 open_result, alternate_result, free_memory_before, free_memory_after);
        remove(MEDIA_INDEX_PATH);
        return -3;
    }

    /* Keep Jansson's media index out of memory while SQLite allocates its
       connection and page cache. Large picture packages can have many media
       entries, and SQLite open must get first use of the available heap. */
    json_t *media_map = NULL;
    if (media_index_extracted) {
        media_map = json_load_file(MEDIA_INDEX_PATH, 0, NULL);
        if (json_is_object(media_map)) {
            error = 0;
            zip_t *media_archive = zip_open(package_path, ZIP_RDONLY, &error);
            if (media_archive) {
                extract_media_files(media_archive, media_map, media_dir);
                zip_close(media_archive);
            }
        }
    }
    remove(MEDIA_INDEX_PATH);

    json_t *models = load_models(db);
    const char *query =
        "SELECT c.id, c.ord, c.ivl, c.queue, c.due, col.crt, n.flds, n.mid "
        "FROM cards c JOIN notes n ON n.id=c.nid CROSS JOIN col "
        "WHERE c.queue >= 0 ORDER BY c.due, c.id";
    sqlite3_stmt *statement = NULL;
    if (sqlite3_prepare_v2(db, query, -1, &statement, NULL) != SQLITE_OK) {
        if (models) json_decref(models);
        sqlite3_close(db);
        if (media_map) json_decref(media_map);
        return -4;
    }

    int count = 0;
    int step_result = SQLITE_OK;
    int allocation_failed = 0;
    while (count < max_cards && (step_result = sqlite3_step(statement)) == SQLITE_ROW) {
        const char *raw_fields = (const char *)sqlite3_column_text(statement, 6);
        if (!raw_fields) continue;
        if (!vitaanki_reserve_cards(cards, allocated_capacity, count + 1)) {
            allocation_failed = 1;
            break;
        }
        Card *card = &(*cards)[count];
        char model_id[32];
        snprintf(model_id, sizeof(model_id), "%lld", sqlite3_column_int64(statement, 7));
        json_t *model = models ? json_object_get(models, model_id) : NULL;
        card->card_id = sqlite3_column_int64(statement, 0);
        card->interval_days = (int)sqlite3_column_int64(statement, 2);
        int queue = sqlite3_column_int(statement, 3);
        long long anki_due = sqlite3_column_int64(statement, 4);
        long long collection_created = sqlite3_column_int64(statement, 5);
        if (queue == 2) {
            card->due = collection_created + anki_due * 86400LL;
            card->state = CARD_STATE_REVIEW;
        } else if (queue == 1 || queue == 3) {
            card->due = anki_due;
            card->state = CARD_STATE_LEARNING;
        } else {
            card->due = 0;
            card->state = CARD_STATE_NEW;
        }
        make_card(card, raw_fields, (int)sqlite3_column_int64(statement, 1),
                  model, media_map, media_dir);
        if (card->front[0]) count++;
    }

    sqlite3_finalize(statement);
    sqlite3_close(db);
    if (models) json_decref(models);
    if (media_map) json_decref(media_map);
    if (allocation_failed) {
        snprintf(last_import_diagnostic, sizeof(last_import_diagnostic),
                 "Not enough memory to allocate imported cards.");
        return -6;
    }
    if (count < max_cards && step_result != SQLITE_DONE) return -5;
    return count;
}
