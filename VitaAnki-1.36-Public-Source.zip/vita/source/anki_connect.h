#ifndef ANKI_CONNECT_H
#define ANKI_CONNECT_H

#include "vitaanki.h"

typedef struct {
    int new_count;
    int learning_count;
    int review_count;
} AnkiStudyCounts;

/* Reads sync.ini without opening the network. */
void anki_connect_prepare(void);
/* Reads sync.ini and only connects when explicitly called. */
int anki_connect_start(Card *cards, int capacity);
int anki_connect_is_configured(void);
const char *anki_connect_get_status(void);
int anki_connect_get_study_counts(AnkiStudyCounts *counts);
int anki_connect_has_learning_cards(void);
int anki_connect_reload(Card *cards, int capacity);
int anki_connect_answer(long long card_id, int ease);
int anki_connect_undo(void);
int anki_connect_queue_review(long long card_id, int ease);
int anki_connect_cancel_queued_review(long long card_id, int ease);
void anki_connect_note_offline_deck(void);
void anki_connect_stop(void);

#endif
