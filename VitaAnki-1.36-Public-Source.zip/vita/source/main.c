#include <ctype.h>
#include <math.h>
#include <psp2/apputil.h>
#include <psp2/common_dialog.h>
#include <psp2/ctrl.h>
#include <psp2/ime_dialog.h>
#include <psp2/io/dirent.h>
#include <psp2/kernel/processmgr.h>
#include <psp2/sysmodule.h>
#include <psp2/touch.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <vita2d.h>
#include "anki_connect.h"
#include "anki_music.h"
#include "android_transfer.h"
#include "vitaanki.h"

#define SCREEN_W 960
#define SCREEN_H 544
#define APP_VERSION "1.36"
#define UI_TEXT_SCALE (1.18f * selected_ui_text_scale())
#define CARD_FLIP_FRAMES 12
#define LIVE_REFRESH_SECONDS 10
#define DEFAULT_NEW_CARD_LIMIT 20

#define DECK_PATH "ux0:data/VitaAnki/cards.tsv"
#define APKG_PATH "ux0:data/VitaAnki/import.apkg"
#define DECK_FOLDER "ux0:data/VitaAnki/decks"
#define INCLUDED_DECK_PATH "ux0:data/VitaAnki/decks/VitaAnki_Sample.tsv"
#define BUNDLED_DECK_PATH "app0:decks/VitaAnki_Sample.tsv"
#define INCLUDED_PICTURE_DECK_PATH "ux0:data/VitaAnki/decks/VitaAnki_Sample_Pictures.apkg"
#define BUNDLED_PICTURE_DECK_PATH "app0:decks/VitaAnki_Sample_Pictures.apkg"
#define PROGRESS_PATH "ux0:data/VitaAnki/progress.tsv"
#define ACTIVE_DECK_PATH "ux0:data/VitaAnki/active-deck.txt"
#define ACTIVE_DECK_TEMP_PATH "ux0:data/VitaAnki/active-deck.tmp"
#define ACTIVE_DECK_BACKUP_PATH "ux0:data/VitaAnki/active-deck.bak"
#define SETTINGS_PATH "ux0:data/VitaAnki/settings.ini"
#define SETTINGS_TEMP_PATH "ux0:data/VitaAnki/settings.tmp"
#define SETTINGS_BACKUP_PATH "ux0:data/VitaAnki/settings.bak"
#define MIN_VALID_CLOCK_EPOCH 1577836800LL
#define MAX_VALID_CLOCK_EPOCH 4102444800LL
#define MAX_INTERVAL_DAYS 36500
#define MAX_DECKS 48
#define LIST_ROW_Y 132
#define LIST_ROW_H 62
#define LIST_VISIBLE 4
#define SPLIT_CARD_TEXT_WIDTH 340
#define SPLIT_CARD_IMAGE_X 440
#define SPLIT_CARD_IMAGE_Y 150
#define SPLIT_CARD_IMAGE_WIDTH 450
#define SPLIT_CARD_IMAGE_HEIGHT 270
#define SETTINGS_COUNT 10
#define BROWSER_STICK_BUTTONS 0
#define BROWSER_STICK_SCROLL 1
#define FONT_MODE_COUNT 10
#define CONFETTI_CAPACITY 160
#define CONFETTI_PER_SUCCESS 40

typedef enum {
    SCREEN_HOME,
    SCREEN_STUDY,
    SCREEN_BROWSER,
    SCREEN_DECKS,
    SCREEN_IMPORT,
    SCREEN_SETTINGS,
    SCREEN_SYNC,
    SCREEN_ANDROID_TRANSFER,
    SCREEN_CREATE_DECK,
    SCREEN_DECK_SETTINGS
} AppScreen;

typedef struct {
    char path[512];
    char name[128];
    int is_apkg;
} DeckEntry;

typedef struct {
    int x;
    int y;
    int w;
    int h;
} UiRect;

typedef struct {
    int new_card_limit;
    int again_minutes;
    int hard_minutes;
    int good_days;
    int easy_days;
} DeckStudySettings;

typedef struct {
    unsigned int white;
    unsigned int muted;
    unsigned int accent;
    unsigned int panel;
    unsigned int panel_hi;
    unsigned int background;
    unsigned int green;
    unsigned int yellow;
    unsigned int red;
} ColorTheme;

typedef struct {
    int valid;
    int live;
    int queued;
    long long card_id;
    int previous_index;
    int previous_interval_days;
    long long previous_due;
    CardState previous_state;
    int previous_reviewed;
    int previous_new_cards_this_session;
    int rating;
} UndoRecord;

typedef struct {
    float x;
    float y;
    float vx;
    float vy;
    int width;
    int height;
    unsigned int color;
    int active;
} ConfettiPiece;

static Card *cards = NULL;
static int card_capacity = 0;
static DeckEntry deck_entries[MAX_DECKS];
static int deck_count = 0;
static int card_count = 0;
static int card_index = 0;
static int current_deck_index = -1;
static int home_selection = 0;
static int list_selection = 0;
static int list_focus_actions = 0;
static int list_action_selection = 0;
static int settings_selection = 0;
static int deck_settings_selection = 0;
static int show_answer = 0;
static int browser_index = 0;
static int browser_show_answer = 0;
static int browser_button_selection = 2;
static int study_button_selection = 0;
static int transfer_selection = 0;
static int header_focus_active = 0;
static int analog_input_latched = 0;
static int analog_rating_latched = 0;
static int analog_browser_latched = 0;
static int analog_header_latched = 0;
static int analog_repeat_frames = 0;
static float card_scroll_position = 0.0f;
static float browser_scroll_position = 0.0f;
static int selected_rating = 2;
static int clock_warning_active = 0;
static int undo_error = 0;
static int jump_dialog_open = 0;
static int jump_selection = 13;
static int jump_error = 0;
static int delete_dialog_open = 0;
static int delete_selection = 0;
static int delete_dialog_stage = 1;
static int create_cancel_dialog_open = 0;
static int create_selection = 0;
static int create_card_count = 0;
static int create_error = 0;
static int create_ime_open = 0;
static int create_ime_field = -1;
static int ime_module_loaded = 0;
static int apputil_initialized = 0;
static char create_deck_name[96] = "";
static char create_question[FIELD_SIZE] = "";
static char create_answer[FIELD_SIZE] = "";
static char create_draft_path[512] = "";
static char create_status[160] = "";
static char deck_status[160] = "";
static int delete_error = 0;
static DeckStudySettings current_deck_settings = {DEFAULT_NEW_CARD_LIMIT, 1, 5, 1, 4};
static DeckStudySettings edit_deck_settings = {DEFAULT_NEW_CARD_LIMIT, 1, 5, 1, 4};
static char edit_deck_settings_path[512] = "";
static uint16_t create_ime_buffer[SCE_IME_DIALOG_MAX_TEXT_LENGTH + 1];
static uint16_t create_ime_initial[SCE_IME_DIALOG_MAX_TEXT_LENGTH + 1];
static char jump_input[8] = "";
static UndoRecord undo_record;
static int reviewed = 0;
static int new_cards_this_session = 0;
static int study_idle_frames = 0;
static time_t live_refresh_after = 0;
static int demo_mode = 0;
static int import_error = 0;
static int import_error_code = 0;
static int live_sync = 0;
static int sync_error = 0;
static int sync_queue_error = 0;
static char sync_message[160] = "";
static int apkg_mode = 0;
static int font_mode = 0;
static int text_size_mode = 1;
static int ui_text_mode = 1;
static int color_theme_mode = 0;
static int flip_animation_mode = 1;
static int flip_frames_remaining = 0;
static int flip_from_answer = 0;
static int flip_to_answer = 0;
static int sync_selection = 1;
static int music_muted = 0;
static int music_setting_migration = 0;
static int click_sounds_enabled = 1;
static int browser_stick_mode = BROWSER_STICK_BUTTONS;
static int confetti_mode = 1;
static int review_control_mode = 0;
static uint32_t confetti_rng = 0xA71C0FFEu;
static int confetti_next_slot = 0;
static ConfettiPiece confetti[CONFETTI_CAPACITY];
static int touch_was_down = 0;
static int touch_min_x = 0;
static int touch_min_y = 0;
static int touch_width = 1920;
static int touch_height = 1080;
static char current_deck_name[128] = "Demo deck";
static char current_deck_path[512] = "";
static char current_progress_path[96] = PROGRESS_PATH;
static char saved_deck_path[512] = "";
static AppScreen current_screen = SCREEN_HOME;
static AppScreen create_return_screen = SCREEN_IMPORT;
static vita2d_pgf *font_pgf = NULL;
static vita2d_pgf *font_serif_pgf = NULL;
static vita2d_pgf *font_sans_pgf = NULL;
static vita2d_pgf *font_serif_italic_pgf = NULL;
static vita2d_pgf *font_sans_italic_pgf = NULL;
static vita2d_pgf *font_serif_bold_pgf = NULL;
static vita2d_pgf *font_sans_bold_pgf = NULL;
static vita2d_pgf *font_serif_bold_italic_pgf = NULL;
static vita2d_pgf *font_sans_bold_italic_pgf = NULL;
static vita2d_texture *app_icon = NULL;
static vita2d_texture *card_image_texture = NULL;
static char card_image_path_cached[FIELD_SIZE] = "";

static unsigned int WHITE = RGBA8(244, 247, 255, 255);
static unsigned int MUTED = RGBA8(155, 170, 190, 255);
static unsigned int ACCENT = RGBA8(112, 184, 255, 255);
static unsigned int PANEL = RGBA8(25, 35, 53, 255);
static unsigned int PANEL_HI = RGBA8(37, 52, 75, 255);
static unsigned int BG = RGBA8(13, 19, 31, 255);
static unsigned int GREEN = RGBA8(135, 220, 165, 255);
static unsigned int YELLOW = RGBA8(255, 202, 112, 255);
static unsigned int RED = RGBA8(255, 130, 130, 255);

int vitaanki_reserve_cards(Card **target, int *allocated_capacity, int required) {
    if (!target || !allocated_capacity || required < 0 || required > MAX_CARDS) return 0;
    if (required <= *allocated_capacity) return 1;

    int new_capacity = *allocated_capacity > 0 ? *allocated_capacity : 32;
    while (new_capacity < required) {
        if (new_capacity > MAX_CARDS / 2) {
            new_capacity = MAX_CARDS;
            break;
        }
        new_capacity *= 2;
    }
    Card *resized = realloc(*target, (size_t)new_capacity * sizeof(Card));
    if (!resized) return 0;
    *target = resized;
    *allocated_capacity = new_capacity;
    return 1;
}

static const ColorTheme color_themes[] = {
    /* Cyberpunk dark: black base with bright pink and green accents. */
    {RGBA8(245, 245, 249, 255), RGBA8(165, 165, 178, 255),
     RGBA8(255, 55, 165, 255), RGBA8(20, 20, 27, 255),
     RGBA8(34, 34, 44, 255), RGBA8(5, 6, 9, 255),
     RGBA8(57, 255, 126, 255), RGBA8(255, 220, 72, 255),
     RGBA8(255, 89, 113, 255)},
    /* Cyberpunk light: white base and the same paired accents. */
    {RGBA8(28, 25, 34, 255), RGBA8(92, 86, 101, 255),
     RGBA8(198, 0, 104, 255), RGBA8(255, 255, 255, 255),
     RGBA8(237, 233, 242, 255), RGBA8(248, 248, 251, 255),
     RGBA8(0, 137, 72, 255), RGBA8(151, 98, 0, 255),
     RGBA8(194, 38, 76, 255)},
    /* Sepia: warm paper and ink, with restrained earthy accents. */
    {RGBA8(55, 43, 28, 255), RGBA8(117, 101, 78, 255),
     RGBA8(142, 90, 45, 255), RGBA8(232, 218, 190, 255),
     RGBA8(220, 199, 161, 255), RGBA8(245, 235, 213, 255),
     RGBA8(91, 116, 55, 255), RGBA8(153, 112, 44, 255),
     RGBA8(164, 78, 63, 255)},
    /* Synthwave: near-black base, electric magenta and cyan. */
    {RGBA8(246, 242, 255, 255), RGBA8(164, 151, 190, 255),
     RGBA8(231, 76, 255, 255), RGBA8(20, 14, 34, 255),
     RGBA8(39, 24, 62, 255), RGBA8(6, 4, 13, 255),
     RGBA8(54, 226, 218, 255), RGBA8(255, 181, 71, 255),
     RGBA8(255, 87, 127, 255)},
    /* Arctic: white base with deep blue and teal accents. */
    {RGBA8(25, 39, 54, 255), RGBA8(86, 108, 128, 255),
     RGBA8(0, 117, 160, 255), RGBA8(255, 255, 255, 255),
     RGBA8(228, 243, 250, 255), RGBA8(245, 251, 255, 255),
     RGBA8(0, 117, 99, 255), RGBA8(137, 96, 0, 255),
     RGBA8(178, 47, 66, 255)},
    /* Aquatic: deep blue with a coordinated family of sea-glass accents. */
    {RGBA8(231, 248, 246, 255), RGBA8(126, 177, 176, 255),
     RGBA8(75, 220, 210, 255), RGBA8(12, 34, 43, 255),
     RGBA8(23, 57, 66, 255), RGBA8(4, 18, 27, 255),
     RGBA8(89, 218, 183, 255), RGBA8(186, 218, 143, 255),
     RGBA8(221, 126, 145, 255)},
    /* Rose: light canvas, ink-dark panels, and pink shades kept together. */
    {RGBA8(48, 29, 43, 255), RGBA8(130, 96, 119, 255),
     RGBA8(210, 76, 144, 255), RGBA8(255, 247, 251, 255),
     RGBA8(245, 224, 236, 255), RGBA8(252, 242, 247, 255),
     RGBA8(120, 145, 104, 255), RGBA8(170, 121, 71, 255),
     RGBA8(192, 69, 105, 255)},
    /* Evergreen: dark forest base with calm green accents. */
    {RGBA8(233, 245, 232, 255), RGBA8(143, 173, 145, 255),
     RGBA8(126, 211, 145, 255), RGBA8(15, 31, 24, 255),
     RGBA8(28, 50, 37, 255), RGBA8(7, 17, 12, 255),
     RGBA8(118, 205, 143, 255), RGBA8(199, 196, 116, 255),
     RGBA8(208, 117, 113, 255)},
    /* Moonlight: near-black panels with cool, restrained blue-grey accents. */
    {RGBA8(239, 243, 250, 255), RGBA8(148, 163, 184, 255),
     RGBA8(151, 184, 220, 255), RGBA8(21, 27, 39, 255),
     RGBA8(35, 44, 61, 255), RGBA8(9, 12, 20, 255),
     RGBA8(130, 191, 166, 255), RGBA8(208, 180, 130, 255),
     RGBA8(209, 135, 151, 255)}
};

static const float text_scales[] = {0.84f, 1.0f, 1.18f, 1.38f};
static const char *text_size_labels[] = {"Small", "Standard", "Large", "Extra large"};
static const float ui_text_scales[] = {1.0f, 1.1f, 1.2f};
static const char *ui_text_labels[] = {"Standard", "Large", "Extra large"};
static const char *color_theme_labels[] = {"Cyberpunk dark", "Cyberpunk light", "Sepia",
                                           "Synthwave", "Arctic", "Aquatic", "Rose",
                                           "Evergreen", "Moonlight"};
static const char *flip_animation_labels[] = {"Instant", "Animated"};
static const char *confetti_labels[] = {"Off", "Good + Easy", "Easy only"};
static const char *font_labels[] = {"System default", "Bold system PGF", "Sans", "Serif",
                                    "Sans italic", "Serif italic", "Sans bold", "Serif bold",
                                    "Sans bold italic", "Serif bold italic"};
static const UiRect settings_rows[SETTINGS_COUNT] = {
    {60, 104, 840, 32}, {60, 138, 840, 32}, {60, 172, 840, 32},
    {60, 206, 840, 32}, {60, 240, 840, 32}, {60, 274, 840, 32},
    {60, 308, 840, 32}, {60, 342, 840, 32}, {60, 376, 840, 32},
    {60, 410, 840, 32}
};

static const Card demo_cards[] = {
    {"What is the functional unit of skeletal muscle?", "The sarcomere: the segment between two Z discs.", 1, 0, 0, CARD_STATE_NEW},
    {"Which neurotransmitter is released at the neuromuscular junction?", "Acetylcholine (ACh), released by the motor neuron.", 2, 0, 0, CARD_STATE_NEW},
    {"What structure stores calcium ions in a muscle fiber?", "The sarcoplasmic reticulum.", 3, 0, 0, CARD_STATE_NEW},
};

static const UiRect home_buttons[4] = {
    {60, 126, 408, 126}, {492, 126, 408, 126},
    {60, 270, 408, 126}, {492, 270, 408, 126}
};
static const UiRect music_button = {766, 18, 146, 42};
static const UiRect back_button = {48, 16, 88, 44};
static const UiRect browser_button = {60, 410, 264, 48};
static const UiRect sync_button = {348, 410, 264, 48};
static const UiRect android_transfer_button = {636, 410, 264, 48};
static const UiRect android_transfer_start_button = {60, 420, 300, 54};
static const UiRect android_transfer_decks_button = {378, 420, 210, 54};
static const UiRect sync_offline_button = {60, 116, 408, 112};
static const UiRect sync_live_button = {492, 116, 408, 112};
static const UiRect undo_button = {790, 110, 110, 36};
static const UiRect browser_jump_button = {240, 458, 190, 52};

static int file_exists(const char *path);
static void recover_atomic_file(const char *destination, const char *temporary,
                                const char *backup);
static int atomic_replace_file(const char *temporary, const char *destination,
                               const char *backup);
static void begin_pc_sync(void);
static void select_offline_source(void);
static int has_study_card(void);
static void open_create_deck(void);
static void begin_create_ime(int field);
static void update_create_ime(void);
static void activate_create_selection(void);
static void request_cancel_create(void);
static void confirm_delete_selected(void);
static void handle_touch(int x, int y);

static vita2d_pgf *custom_font_for_mode(int mode) {
    switch (mode) {
        case 2: return font_sans_pgf;
        case 3: return font_serif_pgf;
        case 4: return font_sans_italic_pgf;
        case 5: return font_serif_italic_pgf;
        case 6: return font_sans_bold_pgf;
        case 7: return font_serif_bold_pgf;
        case 8: return font_sans_bold_italic_pgf;
        case 9: return font_serif_bold_italic_pgf;
        default: return NULL;
    }
}

static void release_custom_font(int mode) {
    vita2d_pgf **font = NULL;
    switch (mode) {
        case 2: font = &font_sans_pgf; break;
        case 3: font = &font_serif_pgf; break;
        case 4: font = &font_sans_italic_pgf; break;
        case 5: font = &font_serif_italic_pgf; break;
        case 6: font = &font_sans_bold_pgf; break;
        case 7: font = &font_serif_bold_pgf; break;
        case 8: font = &font_sans_bold_italic_pgf; break;
        case 9: font = &font_serif_bold_italic_pgf; break;
    }
    if (font && *font) {
        vita2d_free_pgf(*font);
        *font = NULL;
    }
}

static void release_custom_fonts(void) {
    for (int mode = 2; mode < FONT_MODE_COUNT; mode++) release_custom_font(mode);
}

static int font_mode_available(int mode) {
    if (mode == 0 || mode == 1) return 1;
    if (mode < 2 || mode >= FONT_MODE_COUNT) return 0;
    if (custom_font_for_mode(mode)) return 1;

    char path[64];
    snprintf(path, sizeof(path), "sa0:data/font/pgf/ltn%d.pgf", mode - 2);
    vita2d_pgf *font = vita2d_load_custom_pgf(path);
    if (!font) return 0;
    switch (mode) {
        case 2: font_sans_pgf = font; break;
        case 3: font_serif_pgf = font; break;
        case 4: font_sans_italic_pgf = font; break;
        case 5: font_serif_italic_pgf = font; break;
        case 6: font_sans_bold_pgf = font; break;
        case 7: font_serif_bold_pgf = font; break;
        case 8: font_sans_bold_italic_pgf = font; break;
        case 9: font_serif_bold_italic_pgf = font; break;
    }
    return 1;
}

static float selected_text_scale(void) {
    if (text_size_mode < 0 || text_size_mode > 3) text_size_mode = 1;
    return text_scales[text_size_mode];
}

static float selected_ui_text_scale(void) {
    if (ui_text_mode < 0 || ui_text_mode > 2) ui_text_mode = 1;
    return ui_text_scales[ui_text_mode];
}

static void apply_color_theme(int mode) {
    if (mode < 0 || mode >= (int)(sizeof(color_themes) / sizeof(color_themes[0]))) mode = 0;
    color_theme_mode = mode;
    WHITE = color_themes[mode].white;
    MUTED = color_themes[mode].muted;
    ACCENT = color_themes[mode].accent;
    PANEL = color_themes[mode].panel;
    PANEL_HI = color_themes[mode].panel_hi;
    BG = color_themes[mode].background;
    GREEN = color_themes[mode].green;
    YELLOW = color_themes[mode].yellow;
    RED = color_themes[mode].red;
}

static void draw_text_scaled(int x, int y, unsigned int color, float scale,
                             const char *text, float size_factor) {
    float actual_scale = scale * size_factor * UI_TEXT_SCALE;
    if (custom_font_for_mode(font_mode))
        vita2d_pgf_draw_text(custom_font_for_mode(font_mode), x, y, color, actual_scale, text);
    else if (font_pgf) {
        vita2d_pgf_draw_text(font_pgf, x, y, color, actual_scale, text);
        if (font_mode == 1) vita2d_pgf_draw_text(font_pgf, x + 1, y, color, actual_scale, text);
    }
}

static void draw_text(int x, int y, unsigned int color, float scale, const char *text) {
    draw_text_scaled(x, y, color, scale, text, 1.0f);
}

static void draw_card_text(int x, int y, unsigned int color, float scale, const char *text) {
    draw_text_scaled(x, y, color, scale, text, selected_text_scale());
}

static int text_width_scaled(float scale, const char *text, float size_factor) {
    float actual_scale = scale * size_factor * UI_TEXT_SCALE;
    if (custom_font_for_mode(font_mode))
        return vita2d_pgf_text_width(custom_font_for_mode(font_mode), actual_scale, text);
    if (font_pgf)
        return vita2d_pgf_text_width(font_pgf, actual_scale, text);
    return 0;
}

static int text_width(float scale, const char *text) {
    return text_width_scaled(scale, text, 1.0f);
}

static int card_text_width(float scale, const char *text) {
    return text_width_scaled(scale, text, selected_text_scale());
}

static void draw_fit_text(int x, int y, unsigned int color, float scale,
                          const char *text, int max_width) {
    char fitted[160];
    size_t source_length = strlen(text);
    size_t keep = source_length < sizeof(fitted) - 1 ? source_length : sizeof(fitted) - 4;
    int truncated = source_length > keep;
    do {
        memcpy(fitted, text, keep);
        fitted[keep] = '\0';
        if (truncated) strncat(fitted, "...", sizeof(fitted) - strlen(fitted) - 1);
        if (text_width(scale, fitted) <= max_width || keep == 0) break;
        keep--;
        truncated = 1;
    } while (1);
    draw_text(x, y, color, scale, fitted);
}

static int inside(UiRect rect, int x, int y) {
    return x >= rect.x && y >= rect.y && x < rect.x + rect.w && y < rect.y + rect.h;
}

static void draw_button(UiRect rect, const char *label, const char *subtitle,
                        unsigned int accent, int selected) {
    unsigned int fill = selected ? PANEL_HI : PANEL;
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, fill);
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, 4, accent);
    if (selected) {
        vita2d_draw_rectangle(rect.x, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x + rect.w - 3, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x, rect.y + rect.h - 3, rect.w, 3, accent);
    }
    draw_fit_text(rect.x + 20, rect.y + 48, WHITE, 0.88f, label, rect.w - 40);
    if (subtitle) draw_fit_text(rect.x + 20, rect.y + 82, MUTED, 0.58f, subtitle, rect.w - 40);
}

static void draw_compact_button(UiRect rect, const char *label,
                               unsigned int accent, int selected) {
    unsigned int fill = selected ? PANEL_HI : PANEL;
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, fill);
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, 3, accent);
    if (selected) {
        vita2d_draw_rectangle(rect.x, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x + rect.w - 3, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x, rect.y + rect.h - 3, rect.w, 3, accent);
    }
    draw_fit_text(rect.x + 16, rect.y + rect.h / 2 + 6, WHITE, 0.60f,
                  label, rect.w - 32);
}

static void draw_header(const char *title, const char *subtitle) {
    if (current_screen == SCREEN_HOME) {
        if (app_icon) vita2d_draw_texture_scale(app_icon, 48, 16, 0.2f, 0.2f);
        draw_text(96, 48, ACCENT, 1.0f, title);
        if (subtitle) draw_fit_text(48, 78, MUTED, 0.5f, subtitle, 690);
    } else {
        draw_compact_button(back_button, "BACK", ACCENT, header_focus_active == 1);
        int title_x = current_screen == SCREEN_STUDY ? 148 : 184;
        if (app_icon && current_screen != SCREEN_STUDY)
            vita2d_draw_texture_scale(app_icon, 144, 20, 0.18f, 0.18f);
        draw_fit_text(title_x, 48, ACCENT, 0.94f, title, 560);
        if (subtitle) draw_fit_text(title_x, 78, MUTED, 0.5f, subtitle, 540);
    }

    UiRect music_rect = music_button;
#ifdef VITAANKI_DISABLE_MUSIC
    unsigned int music_color = MUTED;
    vita2d_draw_rectangle(music_rect.x, music_rect.y, music_rect.w, music_rect.h, PANEL);
    vita2d_draw_rectangle(music_rect.x, music_rect.y, music_rect.w, 3, music_color);
    draw_text(music_rect.x + 12, music_rect.y + 28, music_color, 0.53f, "AUDIO: OFF");
#else
    unsigned int music_color = anki_music_is_muted() ? MUTED : GREEN;
    vita2d_draw_rectangle(music_rect.x, music_rect.y, music_rect.w, music_rect.h, PANEL);
    vita2d_draw_rectangle(music_rect.x, music_rect.y, music_rect.w, 3, music_color);
    draw_text(music_rect.x + 12, music_rect.y + 28, music_color, 0.53f,
              anki_music_is_muted() ? "MUSIC: MUTED" : "MUSIC: ON");
#endif
    if (header_focus_active == 2) {
        vita2d_draw_rectangle(music_rect.x, music_rect.y, 3, music_rect.h, ACCENT);
        vita2d_draw_rectangle(music_rect.x + music_rect.w - 3, music_rect.y, 3, music_rect.h, ACCENT);
        vita2d_draw_rectangle(music_rect.x, music_rect.y + music_rect.h - 3, music_rect.w, 3, ACCENT);
    }
    vita2d_draw_rectangle(48, 94, 864, 2, PANEL_HI);
}

static void draw_wrapped_mode(const char *text, int x, int y, int max_width, float scale,
                              unsigned int color, int card_size) {
    char line[280] = {0};
    char word[120];
    const char *p = text;
    int line_y = y;
    float size_factor = card_size ? selected_text_scale() : 1.0f;
    int line_height = (int)(39.0f * size_factor * UI_TEXT_SCALE);

    while (*p) {
        int n = 0;
        while (*p == ' ' || *p == '\n' || *p == '\r') p++;
        while (*p && *p != ' ' && *p != '\n' && *p != '\r' && n < (int)sizeof(word) - 1)
            word[n++] = *p++;
        word[n] = '\0';
        if (n == 0) break;

        size_t line_length = strlen(line);
        size_t word_length = strlen(word);
        if (line[0] && line_length + 1 + word_length >= sizeof(line)) {
            if (card_size) draw_card_text(x, line_y, color, scale, line);
            else draw_text(x, line_y, color, scale, line);
            line_y += line_height;
            memcpy(line, word, word_length + 1);
            continue;
        }

        char candidate[280];
        size_t candidate_length = line[0] ? line_length + 1 + word_length : word_length;
        if (line[0]) {
            memcpy(candidate, line, line_length);
            candidate[line_length] = ' ';
            memcpy(candidate + line_length + 1, word, word_length + 1);
        } else {
            memcpy(candidate, word, word_length + 1);
        }

        if (line[0] && text_width_scaled(scale, candidate, size_factor) > max_width) {
            if (card_size) draw_card_text(x, line_y, color, scale, line);
            else draw_text(x, line_y, color, scale, line);
            line_y += line_height;
            memcpy(line, word, word_length + 1);
        } else {
            memcpy(line, candidate, candidate_length + 1);
        }
    }

    if (line[0]) {
        if (card_size) draw_card_text(x, line_y, color, scale, line);
        else draw_text(x, line_y, color, scale, line);
    }
}

static void draw_wrapped(const char *text, int x, int y, int max_width, float scale,
                         unsigned int color) {
    draw_wrapped_mode(text, x, y, max_width, scale, color, 0);
}

static int next_card_line(const char **cursor, char line[256], int max_width, float scale) {
    const char *p = *cursor;
    line[0] = '\0';
    while (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t') p++;
    if (!*p) {
        *cursor = p;
        return 0;
    }

    for (;;) {
        char word[240];
        int n = 0;
        const char *word_start = p;
        while (*p && *p != ' ' && *p != '\n' && *p != '\r' && *p != '\t' && n < (int)sizeof(word) - 1)
            word[n++] = *p++;
        word[n] = '\0';
        if (n == 0) break;

        size_t line_length = strlen(line);
        size_t candidate_length = line[0] ? line_length + 1 + (size_t)n : (size_t)n;
        if (candidate_length >= 256) {
            *cursor = word_start;
            return 1;
        }
        char candidate[256];
        if (line[0]) {
            memcpy(candidate, line, line_length);
            candidate[line_length] = ' ';
            memcpy(candidate + line_length + 1, word, (size_t)n + 1);
        } else {
            memcpy(candidate, word, (size_t)n + 1);
        }
        if (line[0] && card_text_width(scale, candidate) > max_width) {
            *cursor = word_start;
            return 1;
        }
        memcpy(line, candidate, candidate_length + 1);
        while (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t') p++;
        if (!*p) break;
    }
    *cursor = p;
    return line[0] != '\0';
}

static int card_line_height(void) {
    int height = (int)(39.0f * selected_text_scale() * UI_TEXT_SCALE);
    return height > 0 ? height : 1;
}

static int card_glyph_height(float scale) {
    float actual_scale = scale * selected_text_scale() * UI_TEXT_SCALE;
    const char *sample = "Mg";
    int height = 0;
    vita2d_pgf *custom = custom_font_for_mode(font_mode);
    if (custom) height = vita2d_pgf_text_height(custom, actual_scale, sample);
    else if (font_pgf) height = vita2d_pgf_text_height(font_pgf, actual_scale, sample);
    if (height <= 0) height = card_line_height() / 2;
    if (height > card_line_height()) height = card_line_height();
    return height;
}

static int card_line_count(const char *text, int max_width, float scale) {
    const char *cursor = text;
    int count = 0;
    char line[256];
    while (next_card_line(&cursor, line, max_width, scale)) count++;
    return count;
}

static int card_scroll_limit(const char *text, int max_width, float scale, int viewport_height) {
    int visible_lines = viewport_height / card_line_height() + 1;
    int limit = card_line_count(text, max_width, scale) - visible_lines;
    return limit > 0 ? limit : 0;
}

static void draw_card_viewport(const char *text, int x, int y, int max_width, float scale,
                               unsigned int color, float scroll_lines, int viewport_height) {
    const char *cursor = text;
    char line[256];
    int line_index = 0;
    int line_height = card_line_height();
    /* PGF's y coordinate is the text baseline, so let glyphs extend above it. */
    int clip_top = y - card_glyph_height(scale);
    vita2d_set_clip_rectangle(x, clip_top, x + max_width, y + viewport_height);
    vita2d_enable_clipping();
    while (next_card_line(&cursor, line, max_width, scale)) {
        float visible_y = (float)y + ((float)line_index - scroll_lines) * (float)line_height;
        if (visible_y >= (float)(y + viewport_height)) break;
        if (visible_y + line_height > (float)y)
            draw_card_text(x, (int)visible_y, color, scale, line);
        line_index++;
    }
    vita2d_disable_clipping();
}

static vita2d_texture *get_card_image(const char *path) {
    if (!path || !*path) return NULL;
    if (!strcmp(card_image_path_cached, path)) return card_image_texture;
    if (card_image_texture) {
        vita2d_free_texture(card_image_texture);
        card_image_texture = NULL;
    }
    snprintf(card_image_path_cached, sizeof(card_image_path_cached), "%s", path);
    const char *extension = strrchr(path, '.');
    if (extension && (!strcasecmp(extension, ".jpg") || !strcasecmp(extension, ".jpeg")))
        card_image_texture = vita2d_load_JPEG_file(path);
    else if (extension && !strcasecmp(extension, ".png"))
        card_image_texture = vita2d_load_PNG_file(path);
    return card_image_texture;
}

static void draw_card_image_half(const char *path, int x, int y, int width, int height) {
    vita2d_draw_rectangle(x, y, width, height, PANEL_HI);
    vita2d_draw_rectangle(x, y, width, 3, ACCENT);
    vita2d_texture *texture = get_card_image(path);
    if (!texture) {
        draw_fit_text(x + 12, y + height / 2, MUTED, 0.45f, "IMAGE UNAVAILABLE", width - 24);
        return;
    }
    unsigned int image_width = vita2d_texture_get_width(texture);
    unsigned int image_height = vita2d_texture_get_height(texture);
    if (!image_width || !image_height) return;
    float scale_x = (float)(width - 12) / (float)image_width;
    float scale_y = (float)(height - 12) / (float)image_height;
    float scale = scale_x < scale_y ? scale_x : scale_y;
    float draw_width = (float)image_width * scale;
    float draw_height = (float)image_height * scale;
    float draw_x = (float)x + ((float)width - draw_width) * 0.5f;
    float draw_y = (float)y + ((float)height - draw_height) * 0.5f;
    vita2d_draw_texture_scale(texture, draw_x, draw_y, scale, scale);
}

static void draw_card_scrollbar(const char *text, int x, int y, int max_width,
                               float scale, float scroll_lines, int viewport_height) {
    int total_lines = card_line_count(text, max_width, scale);
    int visible_lines = viewport_height / card_line_height() + 1;
    int maximum = total_lines - visible_lines;
    if (maximum <= 0) return;

    const int track_height = 166;
    int thumb_height = track_height * visible_lines / total_lines;
    if (thumb_height < 18) thumb_height = 18;
    if (thumb_height > track_height) thumb_height = track_height;
    int thumb_y = y + (int)((float)(track_height - thumb_height) * scroll_lines /
                            (float)maximum);
    vita2d_draw_rectangle(x, y, 5, track_height, PANEL_HI);
    vita2d_draw_rectangle(x, thumb_y, 5, thumb_height, ACCENT);
}

static const char *study_card_text(void) {
    if (card_count <= 0 || card_index < 0 || card_index >= card_count) return "";
    return show_answer ? cards[card_index].back : cards[card_index].front;
}

static int displayed_answer_side(void) {
    if (flip_frames_remaining <= 0) return show_answer;
    int progress = CARD_FLIP_FRAMES - flip_frames_remaining;
    return progress < CARD_FLIP_FRAMES / 2 ? flip_from_answer : flip_to_answer;
}

static void set_study_answer_side(int answer) {
    answer = answer ? 1 : 0;
    if (flip_frames_remaining > 0 || card_count <= 0 ||
        card_index < 0 || card_index >= card_count || answer == show_answer) return;
    card_scroll_position = 0.0f;
    if (!flip_animation_mode) {
        show_answer = answer;
        return;
    }
    flip_from_answer = show_answer;
    flip_to_answer = answer;
    show_answer = answer;
    flip_frames_remaining = CARD_FLIP_FRAMES;
}

static void advance_study_flip(void) {
    if (flip_frames_remaining > 0) flip_frames_remaining--;
}

static const char *browser_card_text(void) {
    if (card_count <= 0 || browser_index < 0 || browser_index >= card_count) return "";
    return browser_show_answer ? cards[browser_index].back : cards[browser_index].front;
}

static void scroll_visible_card_by(float delta) {
    if (current_screen == SCREEN_STUDY) {
        if (flip_frames_remaining > 0) return;
        int split = has_study_card() && !displayed_answer_side() && cards[card_index].front_image[0];
        int limit = card_scroll_limit(study_card_text(), split ? SPLIT_CARD_TEXT_WIDTH : 790,
                                      split ? 0.84f : 0.95f, split ? 210 : 160);
        card_scroll_position += delta;
        if (card_scroll_position < 0.0f) card_scroll_position = 0.0f;
        if (card_scroll_position > (float)limit) card_scroll_position = (float)limit;
    } else if (current_screen == SCREEN_BROWSER) {
        int split = card_count > 0 && !browser_show_answer && cards[browser_index].front_image[0];
        int limit = card_scroll_limit(browser_card_text(), split ? SPLIT_CARD_TEXT_WIDTH : 790,
                                      split ? 0.84f : 0.95f, split ? 210 : 160);
        browser_scroll_position += delta;
        if (browser_scroll_position < 0.0f) browser_scroll_position = 0.0f;
        if (browser_scroll_position > (float)limit) browser_scroll_position = (float)limit;
    }
}

static void scroll_visible_card(int direction) {
    scroll_visible_card_by((float)direction);
}

static void load_settings(void) {
    recover_atomic_file(SETTINGS_PATH, SETTINGS_TEMP_PATH, SETTINGS_BACKUP_PATH);
    FILE *file = fopen(SETTINGS_PATH, "r");
    if (!file) return;
    char line[128];
    while (fgets(line, sizeof(line), file)) {
        int value;
        if (sscanf(line, "font=%d", &value) == 1) font_mode = value;
        else if (sscanf(line, "text_size=%d", &value) == 1) text_size_mode = value;
        else if (sscanf(line, "ui_text=%d", &value) == 1) ui_text_mode = value;
        else if (sscanf(line, "theme_v2=%d", &value) == 1) color_theme_mode = value;
        else if (sscanf(line, "flip_animation=%d", &value) == 1) flip_animation_mode = value;
        else if (sscanf(line, "music_muted=%d", &value) == 1) music_muted = value;
        else if (sscanf(line, "music_setting_migration=%d", &value) == 1) music_setting_migration = value;
        else if (sscanf(line, "click_sounds=%d", &value) == 1) click_sounds_enabled = value;
        else if (sscanf(line, "confetti=%d", &value) == 1) confetti_mode = value;
        else if (sscanf(line, "review_controls=%d", &value) == 1) review_control_mode = value;
        else if (sscanf(line, "browser_stick_mode=%d", &value) == 1) browser_stick_mode = value;
    }
    fclose(file);
    if (font_mode < 0 || font_mode >= FONT_MODE_COUNT) font_mode = 0;
    if (text_size_mode < 0 || text_size_mode > 3) text_size_mode = 1;
    if (ui_text_mode < 0 || ui_text_mode > 2) ui_text_mode = 1;
    if (color_theme_mode < 0 || color_theme_mode >= (int)(sizeof(color_themes) / sizeof(color_themes[0])))
        color_theme_mode = 0;
    apply_color_theme(color_theme_mode);
    if (flip_animation_mode < 0 || flip_animation_mode > 1) flip_animation_mode = 1;
    music_muted = music_muted ? 1 : 0;
    music_setting_migration = music_setting_migration ? 1 : 0;
    click_sounds_enabled = click_sounds_enabled ? 1 : 0;
    if (confetti_mode < 0 || confetti_mode > 2) confetti_mode = 1;
    if (review_control_mode < 0 || review_control_mode > 1) review_control_mode = 0;
    if (browser_stick_mode < BROWSER_STICK_BUTTONS || browser_stick_mode > BROWSER_STICK_SCROLL)
        browser_stick_mode = BROWSER_STICK_BUTTONS;
}

static void save_settings(void) {
    recover_atomic_file(SETTINGS_PATH, SETTINGS_TEMP_PATH, SETTINGS_BACKUP_PATH);
    remove(SETTINGS_TEMP_PATH);
    FILE *file = fopen(SETTINGS_TEMP_PATH, "w");
    if (!file) return;
    int ok = fprintf(file, "font=%d\ntext_size=%d\nui_text=%d\ntheme_v2=%d\nflip_animation=%d\nmusic_muted=%d\nmusic_setting_migration=%d\nclick_sounds=%d\nconfetti=%d\nreview_controls=%d\nbrowser_stick_mode=%d\n",
                     font_mode, text_size_mode, ui_text_mode, color_theme_mode, flip_animation_mode,
                     music_muted, music_setting_migration, click_sounds_enabled,
                     confetti_mode, review_control_mode, browser_stick_mode) >= 0;
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(SETTINGS_TEMP_PATH, SETTINGS_PATH, SETTINGS_BACKUP_PATH))
        remove(SETTINGS_TEMP_PATH);
}

static int clock_date_is_invalid(void) {
    time_t now = time(NULL);
    if (now == (time_t)-1) return 1;
    long long epoch = (long long)now;
    return epoch < MIN_VALID_CLOCK_EPOCH || epoch >= MAX_VALID_CLOCK_EPOCH;
}

static void refresh_clock_warning(void) {
    clock_warning_active = !live_sync && !demo_mode && clock_date_is_invalid();
}

static int file_exists(const char *path) {
    FILE *file = fopen(path, "rb");
    if (!file) return 0;
    fclose(file);
    return 1;
}

static void recover_atomic_file(const char *destination, const char *temporary,
                                const char *backup) {
    int has_destination = file_exists(destination);
    int has_temporary = file_exists(temporary);
    int has_backup = file_exists(backup);
    if (has_destination) {
        if (has_temporary) remove(temporary);
        if (has_backup) remove(backup);
        return;
    }
    if (has_backup && has_temporary && rename(temporary, destination) == 0) {
        remove(backup);
        return;
    }
    if (has_backup && rename(backup, destination) == 0) {
        if (has_temporary) remove(temporary);
        return;
    }
    if (has_temporary) remove(temporary);
}

static int atomic_replace_file(const char *temporary, const char *destination,
                               const char *backup) {
    int has_destination = file_exists(destination);
    remove(backup);
    if (has_destination && rename(destination, backup) != 0) return 0;
    if (rename(temporary, destination) != 0) {
        if (has_destination) rename(backup, destination);
        return 0;
    }
    if (has_destination) remove(backup);
    return 1;
}

static void copy_file_if_missing(const char *source, const char *destination) {
    if (file_exists(destination)) return;
    FILE *input = fopen(source, "rb");
    if (!input) return;
    char temporary[640];
    int length = snprintf(temporary, sizeof(temporary), "%s.tmp", destination);
    if (length < 0 || (size_t)length >= sizeof(temporary)) {
        fclose(input);
        return;
    }
    remove(temporary);
    FILE *output = fopen(temporary, "wb");
    if (!output) {
        fclose(input);
        return;
    }

    char buffer[8192];
    size_t bytes;
    int ok = 1;
    while ((bytes = fread(buffer, 1, sizeof(buffer), input)) > 0) {
        if (fwrite(buffer, 1, bytes, output) != bytes) {
            ok = 0;
            break;
        }
    }
    if (ferror(input)) ok = 0;
    if (fclose(output) != 0) ok = 0;
    if (fclose(input) != 0) ok = 0;
    if (ok && rename(temporary, destination) == 0) return;
    remove(temporary);
}

static int has_extension(const char *name, const char *extension) {
    const char *dot = strrchr(name, '.');
    if (!dot) return 0;
    while (*dot && *extension) {
        if (tolower((unsigned char)*dot) != tolower((unsigned char)*extension)) return 0;
        dot++;
        extension++;
    }
    return *dot == '\0' && *extension == '\0';
}

static int deck_path_is_deletable(const char *path) {
    if (!path) return 0;
    char folder_prefix[128];
    int prefix_length = snprintf(folder_prefix, sizeof(folder_prefix), "%s/", DECK_FOLDER);
    if (prefix_length <= 0 || (size_t)prefix_length >= sizeof(folder_prefix) ||
        strncmp(path, folder_prefix, (size_t)prefix_length) != 0)
        return 0;
    if (!strcmp(path, INCLUDED_DECK_PATH) || !strcmp(path, INCLUDED_PICTURE_DECK_PATH))
        return 0;
    const char *filename = path + prefix_length;
    if (strchr(filename, '/') || strchr(filename, '\\')) return 0;
    struct stat info;
    return (has_extension(filename, ".apkg") || has_extension(filename, ".tsv")) &&
           stat(path, &info) == 0 && S_ISREG(info.st_mode);
}

static void add_deck(const char *path, const char *filename, int is_apkg) {
    if (deck_count >= MAX_DECKS) return;
    for (int i = 0; i < deck_count; i++)
        if (!strcmp(deck_entries[i].path, path)) return;

    DeckEntry *entry = &deck_entries[deck_count++];
    snprintf(entry->path, sizeof(entry->path), "%s", path);
    snprintf(entry->name, sizeof(entry->name), "%s", filename);
    char *dot = strrchr(entry->name, '.');
    if (dot) *dot = '\0';
    entry->is_apkg = is_apkg;
}

static int deck_index_for_path(const char *path) {
    if (!path || !path[0]) return -1;
    for (int i = 0; i < deck_count; i++)
        if (!strcmp(deck_entries[i].path, path)) return i;
    return -1;
}

static int compare_decks(const void *left, const void *right) {
    const DeckEntry *a = (const DeckEntry *)left;
    const DeckEntry *b = (const DeckEntry *)right;
    return strcmp(a->name, b->name);
}

static void scan_decks(void) {
    char selected_path[512] = "";
    if (list_selection >= 0 && list_selection < deck_count)
        snprintf(selected_path, sizeof(selected_path), "%s", deck_entries[list_selection].path);
    deck_count = 0;
    if (file_exists(APKG_PATH)) add_deck(APKG_PATH, "import.apkg", 1);

    SceUID directory = sceIoDopen(DECK_FOLDER);
    if (directory >= 0) {
        SceIoDirent item;
        memset(&item, 0, sizeof(item));
        while (sceIoDread(directory, &item) > 0) {
            if (item.d_name[0] == '.' ||
                (!has_extension(item.d_name, ".apkg") && !has_extension(item.d_name, ".tsv"))) {
                memset(&item, 0, sizeof(item));
                continue;
            }
            char path[512];
            int length = snprintf(path, sizeof(path), "%s/%s", DECK_FOLDER, item.d_name);
            if (length < 0 || (size_t)length >= sizeof(path)) {
                memset(&item, 0, sizeof(item));
                continue;
            }
            add_deck(path, item.d_name, has_extension(item.d_name, ".apkg"));
            memset(&item, 0, sizeof(item));
        }
        sceIoDclose(directory);
    }

    if (file_exists(DECK_PATH)) add_deck(DECK_PATH, "cards.tsv", 0);
    qsort(deck_entries, (size_t)deck_count, sizeof(deck_entries[0]), compare_decks);

    current_deck_index = deck_index_for_path(current_deck_path);
    int selected_index = deck_index_for_path(selected_path);
    if (selected_index >= 0) list_selection = selected_index;
    else if (current_deck_index >= 0) list_selection = current_deck_index;
    else if (deck_count == 0) list_selection = 0;
    else if (list_selection >= deck_count) list_selection = deck_count - 1;
}

static void load_saved_deck_path(void) {
    recover_atomic_file(ACTIVE_DECK_PATH, ACTIVE_DECK_TEMP_PATH, ACTIVE_DECK_BACKUP_PATH);
    FILE *file = fopen(ACTIVE_DECK_PATH, "r");
    if (!file) return;
    if (fgets(saved_deck_path, sizeof(saved_deck_path), file)) {
        char *end = strpbrk(saved_deck_path, "\r\n");
        if (end) *end = '\0';
    }
    fclose(file);
}

static void save_active_deck(void) {
    if (!current_deck_path[0]) return;
    recover_atomic_file(ACTIVE_DECK_PATH, ACTIVE_DECK_TEMP_PATH, ACTIVE_DECK_BACKUP_PATH);
    remove(ACTIVE_DECK_TEMP_PATH);
    FILE *file = fopen(ACTIVE_DECK_TEMP_PATH, "w");
    if (!file) return;
    int ok = fprintf(file, "%s\n", current_deck_path) >= 0;
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(ACTIVE_DECK_TEMP_PATH, ACTIVE_DECK_PATH,
                                    ACTIVE_DECK_BACKUP_PATH))
        remove(ACTIVE_DECK_TEMP_PATH);
}

static void progress_path_for_deck(const char *deck_path, char *output, size_t capacity) {
    if (!strcmp(deck_path, APKG_PATH) || !strcmp(deck_path, DECK_PATH)) {
        snprintf(output, capacity, "%s", PROGRESS_PATH);
        return;
    }
    unsigned int hash = 2166136261u;
    for (const unsigned char *p = (const unsigned char *)deck_path; *p; p++) {
        hash ^= *p;
        hash *= 16777619u;
    }
    snprintf(output, capacity, "ux0:data/VitaAnki/progress_%08x.tsv", hash);
}

static void set_progress_path(const char *deck_path) {
    progress_path_for_deck(deck_path, current_progress_path, sizeof(current_progress_path));
}

static DeckStudySettings default_deck_study_settings(void) {
    DeckStudySettings settings = {DEFAULT_NEW_CARD_LIMIT, 1, 5, 1, 4};
    return settings;
}

static void deck_settings_path_for(const char *deck_path, char *output, size_t capacity) {
    unsigned int hash = 2166136261u;
    for (const unsigned char *p = (const unsigned char *)deck_path; p && *p; p++) {
        hash ^= *p;
        hash *= 16777619u;
    }
    snprintf(output, capacity, "ux0:data/VitaAnki/deck_settings_%08x.ini", hash);
}

static int int_in_choices(int value, const int *choices, int count) {
    for (int i = 0; i < count; i++) if (value == choices[i]) return 1;
    return 0;
}

static DeckStudySettings load_deck_study_settings(const char *deck_path) {
    DeckStudySettings settings = default_deck_study_settings();
    if (!deck_path || !deck_path[0]) return settings;

    char path[96], temporary[112], backup[112];
    deck_settings_path_for(deck_path, path, sizeof(path));
    snprintf(temporary, sizeof(temporary), "%s.tmp", path);
    snprintf(backup, sizeof(backup), "%s.bak", path);
    recover_atomic_file(path, temporary, backup);
    FILE *file = fopen(path, "r");
    if (!file) return settings;

    char line[96];
    while (fgets(line, sizeof(line), file)) {
        int value;
        if (sscanf(line, "new_limit=%d", &value) == 1) settings.new_card_limit = value;
        else if (sscanf(line, "again_minutes=%d", &value) == 1) settings.again_minutes = value;
        else if (sscanf(line, "hard_minutes=%d", &value) == 1) settings.hard_minutes = value;
        else if (sscanf(line, "good_days=%d", &value) == 1) settings.good_days = value;
        else if (sscanf(line, "easy_days=%d", &value) == 1) settings.easy_days = value;
    }
    fclose(file);

    static const int new_limits[] = {5, 10, 20, 30, 50};
    static const int minute_steps[] = {1, 5, 10, 15, 30};
    static const int good_intervals[] = {1, 2, 3, 4, 7, 14};
    static const int easy_intervals[] = {3, 4, 7, 14, 30};
    if (!int_in_choices(settings.new_card_limit, new_limits, 5)) settings.new_card_limit = DEFAULT_NEW_CARD_LIMIT;
    if (!int_in_choices(settings.again_minutes, minute_steps, 5)) settings.again_minutes = 1;
    if (!int_in_choices(settings.hard_minutes, minute_steps, 5)) settings.hard_minutes = 5;
    if (!int_in_choices(settings.good_days, good_intervals, 6)) settings.good_days = 1;
    if (!int_in_choices(settings.easy_days, easy_intervals, 5)) settings.easy_days = 4;
    return settings;
}

static int save_deck_study_settings(const char *deck_path, DeckStudySettings settings) {
    if (!deck_path || !deck_path[0]) return 0;
    char path[96], temporary[112], backup[112];
    deck_settings_path_for(deck_path, path, sizeof(path));
    snprintf(temporary, sizeof(temporary), "%s.tmp", path);
    snprintf(backup, sizeof(backup), "%s.bak", path);
    recover_atomic_file(path, temporary, backup);
    remove(temporary);
    FILE *file = fopen(temporary, "w");
    if (!file) return 0;
    int ok = fprintf(file, "new_limit=%d\nagain_minutes=%d\nhard_minutes=%d\ngood_days=%d\neasy_days=%d\n",
                     settings.new_card_limit, settings.again_minutes, settings.hard_minutes,
                     settings.good_days, settings.easy_days) >= 0;
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(temporary, path, backup)) {
        remove(temporary);
        return 0;
    }
    return 1;
}

static void open_deck_settings(int index) {
    if (index < 0 || index >= deck_count) return;
    snprintf(edit_deck_settings_path, sizeof(edit_deck_settings_path), "%s", deck_entries[index].path);
    edit_deck_settings = load_deck_study_settings(edit_deck_settings_path);
    deck_settings_selection = 0;
    current_screen = SCREEN_DECK_SETTINGS;
}

static void change_deck_setting(int setting, int direction) {
    static const int new_limits[] = {5, 10, 20, 30, 50};
    static const int minute_steps[] = {1, 5, 10, 15, 30};
    static const int good_intervals[] = {1, 2, 3, 4, 7, 14};
    static const int easy_intervals[] = {3, 4, 7, 14, 30};
    int *value = NULL;
    const int *choices = NULL;
    int count = 0;
    if (setting == 0) { value = &edit_deck_settings.new_card_limit; choices = new_limits; count = 5; }
    else if (setting == 1) { value = &edit_deck_settings.again_minutes; choices = minute_steps; count = 5; }
    else if (setting == 2) { value = &edit_deck_settings.hard_minutes; choices = minute_steps; count = 5; }
    else if (setting == 3) { value = &edit_deck_settings.good_days; choices = good_intervals; count = 6; }
    else if (setting == 4) { value = &edit_deck_settings.easy_days; choices = easy_intervals; count = 5; }
    if (!value || !choices || count <= 0) return;
    int index = 0;
    while (index < count && choices[index] != *value) index++;
    if (index >= count) index = 0;
    index = (index + (direction >= 0 ? 1 : count - 1)) % count;
    *value = choices[index];
    if (!save_deck_study_settings(edit_deck_settings_path, edit_deck_settings))
        snprintf(deck_status, sizeof(deck_status), "Could not save deck settings. Check free storage.");
    else deck_status[0] = '\0';
    if (current_deck_path[0] && !strcmp(current_deck_path, edit_deck_settings_path))
        current_deck_settings = edit_deck_settings;
}

static int load_tsv(const char *path) {
    FILE *file = fopen(path, "r");
    if (!file) return -7;

    int count = 0;
    char row[FIELD_SIZE * 2 + 4];
    while (count < MAX_CARDS && fgets(row, sizeof(row), file)) {
        if (!strchr(row, '\n') && !feof(file)) {
            int ch;
            while ((ch = fgetc(file)) != '\n' && ch != EOF) {}
            continue;
        }
        char *end = strpbrk(row, "\r\n");
        if (end) *end = '\0';
        char *front = row;
        if (strlen(front) >= 3 && (unsigned char)front[0] == 0xEF &&
            (unsigned char)front[1] == 0xBB && (unsigned char)front[2] == 0xBF) front += 3;
        char *tab = strchr(row, '\t');
        if (!tab) continue;
        *tab++ = '\0';
        if (front != row) front = row + 3;
        char *extra_field = strchr(tab, '\t');
        if (extra_field) *extra_field = '\0';
        if (!front[0] && !tab[0]) continue;
        if (!vitaanki_reserve_cards(&cards, &card_capacity, count + 1)) {
            fclose(file);
            return -8;
        }
        snprintf(cards[count].front, FIELD_SIZE, "%.*s", FIELD_SIZE - 1, front);
        snprintf(cards[count].back, FIELD_SIZE, "%.*s", FIELD_SIZE - 1, tab);
        cards[count].front_image[0] = '\0';
        cards[count].card_id = count + 1;
        cards[count].interval_days = 0;
        cards[count].due = 0;
        cards[count].state = CARD_STATE_NEW;
        count++;
    }
    fclose(file);
    return count;
}

static void load_progress(void) {
    char temporary[128];
    char backup[128];
    snprintf(temporary, sizeof(temporary), "%s.tmp", current_progress_path);
    snprintf(backup, sizeof(backup), "%s.bak", current_progress_path);
    recover_atomic_file(current_progress_path, temporary, backup);
    FILE *file = fopen(current_progress_path, "r");
    if (!file) return;
    char row[128];
    while (fgets(row, sizeof(row), file)) {
        if (!strchr(row, '\n') && !feof(file)) {
            int ch;
            while ((ch = fgetc(file)) != '\n' && ch != EOF) {}
            continue;
        }
        long long card_id;
        long long due;
        int interval;
        int stored_state = -1;
        int fields = sscanf(row, "%lld\t%d\t%lld\t%d",
                            &card_id, &interval, &due, &stored_state);
        if (fields < 3 || card_id <= 0) continue;
        for (int i = 0; i < card_count; i++) {
            if (cards[i].card_id == card_id) {
                cards[i].interval_days = interval;
                cards[i].due = due;
                if (fields >= 4 && stored_state >= CARD_STATE_NEW &&
                    stored_state <= CARD_STATE_REVIEW)
                    cards[i].state = (CardState)stored_state;
                else if (interval > 0)
                    cards[i].state = CARD_STATE_REVIEW;
                else if (due > 0)
                    cards[i].state = CARD_STATE_LEARNING;
                else
                    cards[i].state = CARD_STATE_NEW;
                break;
            }
        }
    }
    fclose(file);
}

static void save_progress(void) {
    char temporary[128];
    char backup[128];
    snprintf(temporary, sizeof(temporary), "%s.tmp", current_progress_path);
    snprintf(backup, sizeof(backup), "%s.bak", current_progress_path);
    recover_atomic_file(current_progress_path, temporary, backup);
    remove(temporary);
    FILE *file = fopen(temporary, "w");
    if (!file) return;
    int ok = 1;
    for (int i = 0; i < card_count; i++)
        if (fprintf(file, "%lld\t%d\t%lld\t%d\n", cards[i].card_id,
                    cards[i].interval_days, cards[i].due, (int)cards[i].state) < 0) {
            ok = 0;
            break;
        }
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(temporary, current_progress_path, backup))
        remove(temporary);
}

static int find_next_due(void) {
    if (card_count <= 0) return -1;
    long long now = (long long)time(NULL);
    int start = card_index >= 0 && card_index < card_count ? card_index : 0;
    const CardState priority[] = {
        CARD_STATE_LEARNING,
        CARD_STATE_REVIEW,
        CARD_STATE_NEW
    };
    for (int pass = 0; pass < (int)(sizeof(priority) / sizeof(priority[0])); pass++) {
        for (int step = 0; step < card_count; step++) {
            int i = (start + step) % card_count;
            if (cards[i].state != priority[pass]) continue;
            if (cards[i].state == CARD_STATE_NEW) {
                if (new_cards_this_session < current_deck_settings.new_card_limit) return i;
            } else if (cards[i].due <= now) {
                return i;
            }
        }
    }
    return -1;
}

static int has_study_card(void) {
    return card_count > 0 && card_index >= 0 && card_index < card_count;
}

static AnkiStudyCounts current_study_counts(int *valid) {
    AnkiStudyCounts counts = {0, 0, 0};
    if (live_sync) {
        *valid = anki_connect_get_study_counts(&counts);
        return counts;
    }

    long long now = (long long)time(NULL);
    for (int i = 0; i < card_count; i++) {
        if (cards[i].state == CARD_STATE_NEW) counts.new_count++;
        else if (cards[i].state == CARD_STATE_LEARNING) counts.learning_count++;
        else if (cards[i].state == CARD_STATE_REVIEW && cards[i].due <= now)
            counts.review_count++;
    }
    *valid = 1;
    return counts;
}

static uint32_t confetti_random(void) {
    confetti_rng ^= confetti_rng << 13;
    confetti_rng ^= confetti_rng >> 17;
    confetti_rng ^= confetti_rng << 5;
    return confetti_rng;
}

static void clear_confetti(void) {
    for (int i = 0; i < CONFETTI_CAPACITY; i++) confetti[i].active = 0;
    confetti_next_slot = 0;
}

static void start_confetti(void) {
    if (confetti_mode == 0) return;
    const unsigned int colors[] = {ACCENT, GREEN, YELLOW, RED, ACCENT};
    int added = 0;
    for (int scanned = 0; scanned < CONFETTI_CAPACITY && added < CONFETTI_PER_SUCCESS; scanned++) {
        int slot = (confetti_next_slot + scanned) % CONFETTI_CAPACITY;
        if (confetti[slot].active) continue;
        uint32_t r = confetti_random();
        confetti[slot].x = (float)(r % SCREEN_W);
        confetti[slot].y = -(float)(confetti_random() % 90);
        confetti[slot].vx = (float)((int)(confetti_random() % 7) - 3) * 0.45f;
        confetti[slot].vy = 3.5f + (float)(confetti_random() % 5) * 0.8f;
        confetti[slot].width = 4 + (int)(confetti_random() % 5);
        confetti[slot].height = 7 + (int)(confetti_random() % 6);
        confetti[slot].color = colors[confetti_random() % (sizeof(colors) / sizeof(colors[0]))];
        confetti[slot].active = 1;
        confetti_next_slot = (slot + 1) % CONFETTI_CAPACITY;
        added++;
    }
}

static void update_confetti(void) {
    if (confetti_mode == 0) return;
    for (int i = 0; i < CONFETTI_CAPACITY; i++) {
        if (!confetti[i].active) continue;
        confetti[i].x += confetti[i].vx;
        confetti[i].y += confetti[i].vy;
        confetti[i].vy += 0.035f;
        if (confetti[i].x < -10) confetti[i].x = SCREEN_W + 8;
        else if (confetti[i].x > SCREEN_W + 10) confetti[i].x = -8;
        if (confetti[i].y > SCREEN_H + 12) confetti[i].active = 0;
    }
}

static void draw_confetti(void) {
    if (confetti_mode == 0) return;
    for (int i = 0; i < CONFETTI_CAPACITY; i++) {
        if (confetti[i].active && confetti[i].y > -15 && confetti[i].y < SCREEN_H)
            vita2d_draw_rectangle(confetti[i].x, confetti[i].y,
                                  confetti[i].width, confetti[i].height,
                                  confetti[i].color);
    }
}

static int select_deck(int index) {
    if (index < 0 || index >= deck_count) return 0;
    anki_connect_note_offline_deck();
    live_sync = 0;
    apkg_mode = 0;
    sync_queue_error = 0;
    demo_mode = 0;
    import_error = 0;
    import_error_code = 0;
    reviewed = 0;
    new_cards_this_session = 0;
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_position = 0.0f;
    selected_rating = 2;
    undo_record.valid = 0;
    undo_error = 0;
    card_count = 0;

    DeckEntry *entry = &deck_entries[index];
    int music_was_running = entry->is_apkg && anki_music_is_running();
    int resume_music = music_was_running && !anki_music_is_muted();
    if (music_was_running) anki_music_stop();
    int loaded;
    if (entry->is_apkg) {
        int reload_custom_font = font_pgf != NULL;
        if (card_image_texture) {
            vita2d_free_texture(card_image_texture);
            card_image_texture = NULL;
            card_image_path_cached[0] = '\0';
        }
        if (reload_custom_font) release_custom_fonts();
        free(cards);
        cards = NULL;
        card_capacity = 0;
        loaded = import_apkg(entry->path, &cards, &card_capacity, MAX_CARDS);
        if (reload_custom_font && !font_mode_available(font_mode)) {
            font_mode = 0;
            save_settings();
        }
    } else {
        loaded = load_tsv(entry->path);
    }
    if (resume_music) anki_music_start();
    if (loaded < 0) {
        import_error = 1;
        import_error_code = loaded;
        current_screen = SCREEN_IMPORT;
        return 0;
    }

    card_count = loaded;
    apkg_mode = entry->is_apkg;
    current_deck_index = index;
    snprintf(current_deck_name, sizeof(current_deck_name), "%s", entry->name);
    snprintf(current_deck_path, sizeof(current_deck_path), "%s", entry->path);
    set_progress_path(entry->path);
    current_deck_settings = load_deck_study_settings(entry->path);
    load_progress();
    card_index = card_count > 0 ? find_next_due() : 0;
    save_active_deck();
    current_screen = SCREEN_STUDY;
    return 1;
}

static void load_demo_deck(void) {
    demo_mode = 1;
    apkg_mode = 0;
    sync_queue_error = 0;
    import_error = 0;
    import_error_code = 0;
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_position = 0.0f;
    selected_rating = 2;
    undo_record.valid = 0;
    undo_error = 0;
    current_deck_index = -1;
    current_deck_path[0] = '\0';
    current_progress_path[0] = '\0';
    current_deck_settings = default_deck_study_settings();
    snprintf(current_deck_name, sizeof(current_deck_name), "Demo deck");
    int demo_count = (int)(sizeof(demo_cards) / sizeof(demo_cards[0]));
    if (!vitaanki_reserve_cards(&cards, &card_capacity, demo_count)) {
        card_count = 0;
        card_index = 0;
        return;
    }
    card_count = demo_count;
    for (int i = 0; i < card_count; i++) cards[i] = demo_cards[i];
    card_index = 0;
}

static int find_saved_deck(void) {
    for (int i = 0; i < deck_count; i++)
        if (saved_deck_path[0] && !strcmp(deck_entries[i].path, saved_deck_path)) return i;
    for (int i = 0; i < deck_count; i++)
        if (!strcmp(deck_entries[i].path, INCLUDED_DECK_PATH)) return i;
    return deck_count > 0 ? 0 : -1;
}

static size_t utf8_to_utf16(const char *input, uint16_t *output, size_t capacity) {
    size_t written = 0;
    const unsigned char *p = (const unsigned char *)input;
    if (!input || !output || capacity == 0) return 0;
    while (*p && written + 1 < capacity) {
        uint32_t codepoint;
        size_t count;
        if (*p < 0x80) { codepoint = *p; count = 1; }
        else if ((*p & 0xE0) == 0xC0 && p[1] && (p[1] & 0xC0) == 0x80) {
            codepoint = ((uint32_t)(p[0] & 0x1F) << 6) | (p[1] & 0x3F);
            count = 2;
        } else if ((*p & 0xF0) == 0xE0 && p[1] && p[2] &&
                   (p[1] & 0xC0) == 0x80 && (p[2] & 0xC0) == 0x80) {
            codepoint = ((uint32_t)(p[0] & 0x0F) << 12) |
                        ((uint32_t)(p[1] & 0x3F) << 6) | (p[2] & 0x3F);
            count = 3;
        } else if ((*p & 0xF8) == 0xF0 && p[1] && p[2] && p[3] &&
                   (p[1] & 0xC0) == 0x80 && (p[2] & 0xC0) == 0x80 &&
                   (p[3] & 0xC0) == 0x80) {
            codepoint = ((uint32_t)(p[0] & 0x07) << 18) |
                        ((uint32_t)(p[1] & 0x3F) << 12) |
                        ((uint32_t)(p[2] & 0x3F) << 6) | (p[3] & 0x3F);
            count = 4;
        } else { codepoint = '?'; count = 1; }
        if (codepoint <= 0xFFFF) {
            output[written++] = (uint16_t)codepoint;
        } else {
            if (written + 2 >= capacity) break;
            codepoint -= 0x10000;
            output[written++] = (uint16_t)(0xD800 | (codepoint >> 10));
            output[written++] = (uint16_t)(0xDC00 | (codepoint & 0x3FF));
        }
        p += count;
    }
    output[written] = 0;
    return written;
}

static int utf16_to_utf8(const uint16_t *input, char *output, size_t capacity) {
    size_t used = 0;
    if (!input || !output || capacity == 0) return 0;
    for (size_t i = 0; input[i]; i++) {
        uint32_t codepoint = input[i];
        if (codepoint >= 0xD800 && codepoint <= 0xDBFF &&
            input[i + 1] >= 0xDC00 && input[i + 1] <= 0xDFFF) {
            codepoint = 0x10000 + ((codepoint - 0xD800) << 10) +
                        (input[++i] - 0xDC00);
        }
        unsigned char bytes[4];
        size_t count;
        if (codepoint < 0x80) { bytes[0] = (unsigned char)codepoint; count = 1; }
        else if (codepoint < 0x800) {
            bytes[0] = 0xC0 | (codepoint >> 6);
            bytes[1] = 0x80 | (codepoint & 0x3F); count = 2;
        } else if (codepoint < 0x10000) {
            bytes[0] = 0xE0 | (codepoint >> 12);
            bytes[1] = 0x80 | ((codepoint >> 6) & 0x3F);
            bytes[2] = 0x80 | (codepoint & 0x3F); count = 3;
        } else {
            bytes[0] = 0xF0 | (codepoint >> 18);
            bytes[1] = 0x80 | ((codepoint >> 12) & 0x3F);
            bytes[2] = 0x80 | ((codepoint >> 6) & 0x3F);
            bytes[3] = 0x80 | (codepoint & 0x3F); count = 4;
        }
        if (used + count >= capacity) return 0;
        memcpy(output + used, bytes, count);
        used += count;
    }
    output[used] = '\0';
    return 1;
}

static void normalize_tsv_field(char *text) {
    if (!text) return;
    for (char *p = text; *p; p++)
        if (*p == '\t' || *p == '\r' || *p == '\n') *p = ' ';
    size_t length = strlen(text);
    while (length > 0 && (text[length - 1] == ' ' || text[length - 1] == '\t'))
        text[--length] = '\0';
    char *start = text;
    while (*start == ' ' || *start == '\t') start++;
    if (start != text) memmove(text, start, strlen(start) + 1);
}

static int ensure_text_input(void) {
    if (!apputil_initialized) {
        if (sceAppUtilInit(&(SceAppUtilInitParam){}, &(SceAppUtilBootParam){}) < 0)
            return 0;
        apputil_initialized = 1;
        sceCommonDialogSetConfigParam(&(SceCommonDialogConfigParam){});
    }
    if (!ime_module_loaded) {
        if (sceSysmoduleLoadModule(SCE_SYSMODULE_IME) < 0) return 0;
        ime_module_loaded = 1;
    }
    return 1;
}

static void begin_create_ime(int field) {
    if (field < 0 || field > 2 || !ensure_text_input()) {
        snprintf(create_status, sizeof(create_status), "Text entry is unavailable. Restart VitaAnki and try again.");
        create_error = 1;
        return;
    }
    const char *initial = field == 0 ? create_deck_name
                        : field == 1 ? create_question : create_answer;
    utf8_to_utf16(initial, create_ime_initial,
                  sizeof(create_ime_initial) / sizeof(create_ime_initial[0]));
    memset(create_ime_buffer, 0, sizeof(create_ime_buffer));
    SceImeDialogParam param;
    sceImeDialogParamInit(&param);
    param.supportedLanguages = SCE_IME_LANGUAGE_ENGLISH;
    param.languagesForced = SCE_TRUE;
    param.type = SCE_IME_TYPE_DEFAULT;
    param.option = field == 0 ? SCE_IME_OPTION_NO_ASSISTANCE
                              : (SCE_IME_OPTION_MULTILINE | SCE_IME_OPTION_NO_ASSISTANCE);
    param.dialogMode = SCE_IME_DIALOG_DIALOG_MODE_WITH_CANCEL;
    param.textBoxMode = SCE_IME_DIALOG_TEXTBOX_MODE_DEFAULT;
    param.title = field == 0 ? u"Deck name"
                 : field == 1 ? u"Question"
                              : u"Answer";
    param.maxTextLength = field == 0 ? 60 : 480;
    param.initialText = create_ime_initial;
    param.inputTextBuffer = create_ime_buffer;
    int result = sceImeDialogInit(&param);
    if (result < 0) {
        snprintf(create_status, sizeof(create_status), "Vita text keyboard could not open (0x%08X).", (unsigned int)result);
        create_error = 1;
        return;
    }
    create_ime_field = field;
    create_ime_open = 1;
    create_error = 0;
}

static void update_create_ime(void) {
    if (!create_ime_open || sceImeDialogGetStatus() != SCE_COMMON_DIALOG_STATUS_FINISHED)
        return;
    SceImeDialogResult result;
    memset(&result, 0, sizeof(result));
    sceImeDialogGetResult(&result);
    sceImeDialogTerm();
    create_ime_open = 0;
    if (result.button == SCE_IME_DIALOG_BUTTON_ENTER) {
        char converted[FIELD_SIZE];
        if (!utf16_to_utf8(create_ime_buffer, converted, sizeof(converted))) {
            snprintf(create_status, sizeof(create_status), "Text is too long. Shorten it and try again.");
            create_error = 1;
            return;
        }
        normalize_tsv_field(converted);
        if (create_ime_field == 0) {
            snprintf(create_deck_name, sizeof(create_deck_name), "%.*s", (int)sizeof(create_deck_name) - 1, converted);
        } else if (create_ime_field == 1) {
            snprintf(create_question, sizeof(create_question), "%s", converted);
        } else if (create_ime_field == 2) {
            snprintf(create_answer, sizeof(create_answer), "%s", converted);
        }
        snprintf(create_status, sizeof(create_status), "Text saved.");
        create_error = 0;
    }
    create_ime_field = -1;
}

static void open_create_deck(void) {
    create_return_screen = current_screen;
    create_deck_name[0] = '\0';
    create_question[0] = '\0';
    create_answer[0] = '\0';
    create_status[0] = '\0';
    create_card_count = 0;
    create_error = 0;
    create_selection = 0;
    create_cancel_dialog_open = 0;
    create_draft_path[0] = '\0';
    for (int attempt = 0; attempt < 100; attempt++) {
        int length = snprintf(create_draft_path, sizeof(create_draft_path),
                              "%s/.vitaanki_draft_%08lx_%02d.tmp", DECK_FOLDER,
                              (unsigned long)time(NULL), attempt);
        if (length <= 0 || (size_t)length >= sizeof(create_draft_path)) break;
        if (!file_exists(create_draft_path)) {
            FILE *draft = fopen(create_draft_path, "wb");
            if (draft && fclose(draft) == 0) break;
            create_draft_path[0] = '\0';
            break;
        }
        create_draft_path[0] = '\0';
    }
    if (!create_draft_path[0]) {
        snprintf(create_status, sizeof(create_status), "Could not create a draft in the VitaAnki decks folder.");
        create_error = 1;
    } else {
        snprintf(create_status, sizeof(create_status), "Enter a name, question, and answer. Add cards, then save.");
    }
    current_screen = SCREEN_CREATE_DECK;
}

static void create_add_card(void) {
    char question[FIELD_SIZE];
    char answer[FIELD_SIZE];
    snprintf(question, sizeof(question), "%s", create_question);
    snprintf(answer, sizeof(answer), "%s", create_answer);
    normalize_tsv_field(question);
    normalize_tsv_field(answer);
    if (!question[0] || !answer[0]) {
        snprintf(create_status, sizeof(create_status), "Enter both a question and an answer before adding a card.");
        create_error = 1;
        return;
    }
    if (create_card_count >= MAX_CARDS) {
        snprintf(create_status, sizeof(create_status), "This deck reached the %d-card limit.", MAX_CARDS);
        create_error = 1;
        return;
    }
    FILE *draft = fopen(create_draft_path, "ab");
    if (!draft) {
        snprintf(create_status, sizeof(create_status), "Draft file could not be opened. Cancel and start again.");
        create_error = 1;
        return;
    }
    int ok = fprintf(draft, "%s\t%s\n", question, answer) >= 0;
    if (fclose(draft) != 0) ok = 0;
    if (!ok) {
        snprintf(create_status, sizeof(create_status), "Card could not be saved to the draft.");
        create_error = 1;
        return;
    }
    create_card_count++;
    create_question[0] = '\0';
    create_answer[0] = '\0';
    snprintf(create_status, sizeof(create_status), "Card %d saved in this deck draft.", create_card_count);
    create_error = 0;
}

static void create_save_deck(void) {
    if (create_card_count <= 0 || !create_draft_path[0]) {
        snprintf(create_status, sizeof(create_status), "Add at least one complete card before saving.");
        create_error = 1;
        return;
    }
    char base[64] = "";
    size_t used = 0;
    int underscore = 0;
    for (const unsigned char *p = (const unsigned char *)create_deck_name;
         *p && used < sizeof(base) - 1; p++) {
        if ((*p >= 'A' && *p <= 'Z') || (*p >= 'a' && *p <= 'z') ||
            (*p >= '0' && *p <= '9')) {
            base[used++] = (char)*p;
            underscore = 0;
        } else if (used > 0 && !underscore) {
            base[used++] = '_';
            underscore = 1;
        }
    }
    while (used > 0 && base[used - 1] == '_') used--;
    base[used] = '\0';
    if (!base[0]) snprintf(base, sizeof(base), "My_Deck");

    char destination[512];
    int available = 0;
    for (int suffix = 1; suffix <= 100; suffix++) {
        struct stat info;
        if (suffix == 1)
            snprintf(destination, sizeof(destination), "%s/%s.tsv", DECK_FOLDER, base);
        else
            snprintf(destination, sizeof(destination), "%s/%s_%d.tsv", DECK_FOLDER, base, suffix);
        if (stat(destination, &info) != 0) { available = 1; break; }
    }
    if (!available || rename(create_draft_path, destination) != 0) {
        snprintf(create_status, sizeof(create_status), "Could not save the deck. Check free space and try again.");
        create_error = 1;
        return;
    }
    create_draft_path[0] = '\0';
    snprintf(deck_status, sizeof(deck_status), "Created %s with %d cards.",
             create_deck_name[0] ? create_deck_name : base, create_card_count);
    scan_decks();
    int index = deck_index_for_path(destination);
    if (index >= 0 && select_deck(index)) {
        snprintf(current_deck_name, sizeof(current_deck_name), "%.*s",
                 (int)sizeof(current_deck_name) - 1,
                 create_deck_name[0] ? create_deck_name : base);
    } else {
        snprintf(create_status, sizeof(create_status), "Deck saved, but VitaAnki could not open it. Select it from Decks.");
        create_error = 1;
        current_screen = SCREEN_DECKS;
    }
}

static void discard_create_deck(void) {
    if (create_ime_open) {
        sceImeDialogAbort();
        sceImeDialogTerm();
        create_ime_open = 0;
    }
    if (create_draft_path[0]) remove(create_draft_path);
    create_draft_path[0] = '\0';
    create_cancel_dialog_open = 0;
    current_screen = create_return_screen;
}

static void request_cancel_create(void) {
    if (create_card_count == 0 && !create_deck_name[0] &&
        !create_question[0] && !create_answer[0]) {
        discard_create_deck();
        return;
    }
    create_cancel_dialog_open = 1;
    create_selection = 0;
}

static void confirm_delete_selected(void) {
    if (list_selection < 0 || list_selection >= deck_count ||
        !deck_path_is_deletable(deck_entries[list_selection].path)) {
        delete_error = 1;
        return;
    }
    char path[512];
    char name[128];
    snprintf(path, sizeof(path), "%s", deck_entries[list_selection].path);
    snprintf(name, sizeof(name), "%s", deck_entries[list_selection].name);
    int was_current = current_deck_path[0] && !strcmp(current_deck_path, path);
    char progress[128];
    progress_path_for_deck(path, progress, sizeof(progress));
    if (remove(path) != 0) {
        delete_error = 1;
        return;
    }
    int progress_removed = !file_exists(progress) || remove(progress) == 0;
    char sidecar[160];
    snprintf(sidecar, sizeof(sidecar), "%s.tmp", progress);
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    snprintf(sidecar, sizeof(sidecar), "%s.bak", progress);
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    deck_settings_path_for(path, sidecar, sizeof(sidecar));
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    deck_settings_path_for(path, sidecar, sizeof(sidecar));
    strncat(sidecar, ".tmp", sizeof(sidecar) - strlen(sidecar) - 1);
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    deck_settings_path_for(path, sidecar, sizeof(sidecar));
    strncat(sidecar, ".bak", sizeof(sidecar) - strlen(sidecar) - 1);
    if (file_exists(sidecar) && remove(sidecar) != 0) progress_removed = 0;
    if (was_current) {
        current_deck_path[0] = '\0';
        saved_deck_path[0] = '\0';
        remove(ACTIVE_DECK_PATH);
    }
    snprintf(deck_status, sizeof(deck_status), progress_removed
             ? "Deleted %s and its local study progress."
             : "Deleted %s, but a progress sidecar could not be removed.", name);
    delete_error = 0;
    delete_dialog_open = 0;
    scan_decks();
    if (was_current) {
        int fallback = find_saved_deck();
        if (fallback >= 0) {
            if (!select_deck(fallback)) load_demo_deck();
        } else load_demo_deck();
        current_screen = SCREEN_DECKS;
        scan_decks();
    }
}

static void advance_delete_confirmation(void) {
    if (delete_selection == 0) {
        if (delete_dialog_stage == 2) {
            delete_dialog_stage = 1;
            delete_selection = 0;
            delete_error = 0;
        } else {
            delete_dialog_open = 0;
            delete_error = 0;
        }
        return;
    }
    if (delete_dialog_stage == 1) {
        delete_dialog_stage = 2;
        delete_selection = 0;
        delete_error = 0;
        return;
    }
    confirm_delete_selected();
}

static void activate_create_selection(void) {
    if (create_cancel_dialog_open) {
        if (create_selection == 0) discard_create_deck();
        else create_cancel_dialog_open = 0;
        return;
    }
    switch (create_selection) {
        case 0: begin_create_ime(0); break;
        case 1: begin_create_ime(1); break;
        case 2: begin_create_ime(2); break;
        case 3: create_add_card(); break;
        case 4: create_save_deck(); break;
        case 5: request_cancel_create(); break;
    }
}

static void maybe_start_confetti(int rating) {
    if ((confetti_mode == 1 && rating >= 2) || (confetti_mode == 2 && rating == 3))
        start_confetti();
}

static int next_interval_days(int interval, int rating) {
    long long next;
    if (rating == 0) return 0;
    if (rating == 1) next = interval < 1 ? 1 : ((long long)interval * 12 + 9) / 10;
    else if (rating == 2)
        next = interval < 1 ? current_deck_settings.good_days : (long long)interval * 2;
    else next = interval < 1 ? current_deck_settings.easy_days : (long long)interval * 3;
    if (next > MAX_INTERVAL_DAYS) next = MAX_INTERVAL_DAYS;
    return (int)next;
}

static void rate_card(int rating) {
    if (rating < 0 || rating > 3 || flip_frames_remaining > 0 || card_count <= 0 ||
        card_index < 0 || card_index >= card_count) return;
    UndoRecord last_review = {0};
    last_review.card_id = cards[card_index].card_id;
    last_review.previous_index = card_index;
    last_review.previous_reviewed = reviewed;
    last_review.previous_new_cards_this_session = new_cards_this_session;
    last_review.rating = rating;
    if (live_sync) {
        if (!anki_connect_answer(cards[card_index].card_id, rating + 1)) {
            sync_error = 1;
            return;
        }
        last_review.valid = 1;
        last_review.live = 1;
        undo_record = last_review;
        undo_error = 0;
        maybe_start_confetti(rating);
        reviewed++;
        int refreshed = anki_connect_reload(cards, card_capacity);
        live_refresh_after = time(NULL) + LIVE_REFRESH_SECONDS;
        if (refreshed < 0) {
            sync_error = 1;
            card_count = 0;
            return;
        }
        card_count = refreshed;
        card_index = 0;
        show_answer = 0;
        flip_frames_remaining = 0;
        card_scroll_position = 0.0f;
        selected_rating = 2;
        return;
    }

    Card *card = &cards[card_index];
    if (card->state == CARD_STATE_NEW) new_cards_this_session++;
    last_review.previous_interval_days = card->interval_days;
    last_review.previous_due = card->due;
    last_review.previous_state = card->state;
    int interval = card->interval_days;
    CardState previous_state = card->state;
    long long now = (long long)time(NULL);
    if (rating == 0) {
        card->interval_days = 0;
        card->due = now + (long long)current_deck_settings.again_minutes * 60LL;
        card->state = CARD_STATE_LEARNING;
    } else if (rating == 1 && previous_state != CARD_STATE_REVIEW) {
        card->interval_days = 0;
        card->due = now + (long long)current_deck_settings.hard_minutes * 60LL;
        card->state = CARD_STATE_LEARNING;
    } else {
        card->interval_days = next_interval_days(interval, rating);
        card->due = now + (long long)card->interval_days * 86400LL;
        card->state = CARD_STATE_REVIEW;
    }
    if (apkg_mode) {
        last_review.queued = anki_connect_queue_review(card->card_id, rating + 1);
        if (!last_review.queued) sync_queue_error = 1;
    }
    last_review.valid = 1;
    undo_record = last_review;
    undo_error = 0;
    maybe_start_confetti(rating);
    reviewed++;
    save_progress();
    card_index = find_next_due();
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_position = 0.0f;
    selected_rating = 2;
}

static int find_card_index_by_id(long long card_id) {
    for (int i = 0; i < card_count; i++)
        if (cards[i].card_id == card_id) return i;
    return -1;
}

static void undo_last_rating(void) {
    if (!undo_record.valid) return;
    UndoRecord last_review = undo_record;

    if (last_review.live) {
        if (!anki_connect_undo()) {
            undo_error = 1;
            return;
        }
        int refreshed = anki_connect_reload(cards, card_capacity);
        live_refresh_after = time(NULL) + LIVE_REFRESH_SECONDS;
        reviewed = last_review.previous_reviewed;
        new_cards_this_session = last_review.previous_new_cards_this_session;
        undo_record.valid = 0;
        if (refreshed < 0) {
            sync_error = 1;
            card_count = 0;
            undo_error = 1;
            return;
        }
        card_count = refreshed;
        int index = find_card_index_by_id(last_review.card_id);
        if (index < 0) {
            card_index = 0;
            show_answer = 0;
            undo_error = 1;
        } else {
            card_index = index;
            show_answer = 1;
            undo_error = 0;
        }
    } else {
        if (last_review.queued &&
            !anki_connect_cancel_queued_review(last_review.card_id, last_review.rating + 1)) {
            undo_error = 1;
            return;
        }
        int index = find_card_index_by_id(last_review.card_id);
        if (index < 0 && last_review.previous_index >= 0 &&
            last_review.previous_index < card_count)
            index = last_review.previous_index;
        if (index < 0) {
            undo_error = 1;
            return;
        }
        cards[index].interval_days = last_review.previous_interval_days;
        cards[index].due = last_review.previous_due;
        cards[index].state = last_review.previous_state;
        save_progress();
        reviewed = last_review.previous_reviewed;
        new_cards_this_session = last_review.previous_new_cards_this_session;
        card_index = index;
        show_answer = 1;
        undo_error = 0;
    }

    flip_frames_remaining = 0;
    card_scroll_position = 0.0f;
    selected_rating = last_review.rating;
    undo_record.valid = 0;
    current_screen = SCREEN_STUDY;
}

static void toggle_music(void) {
#ifdef VITAANKI_DISABLE_MUSIC
    music_muted = 1;
#else
    music_muted = !anki_music_is_muted();
    anki_music_set_muted(music_muted);
    save_settings();
#endif
}

static void draw_home(void) {
    draw_header("VitaAnki v" APP_VERSION, "A pocket-sized Anki study companion");
    char study_subtitle[160];
    if (live_sync) snprintf(study_subtitle, sizeof(study_subtitle), "Live deck  |  %d cards due", card_count);
    else snprintf(study_subtitle, sizeof(study_subtitle), "%s  |  %d cards", current_deck_name, card_count);

    draw_button(home_buttons[0], "Study", study_subtitle, ACCENT, home_selection == 0);
    draw_button(home_buttons[1], "Choose a deck", "Switch your offline study deck", GREEN, home_selection == 1);
    draw_button(home_buttons[2], "Import or create", "Add an Anki deck or make your own cards", YELLOW, home_selection == 2);
    draw_button(home_buttons[3], "Settings", "Fonts, card size, review controls, and music", ACCENT, home_selection == 3);
    draw_compact_button(browser_button, "CARD BROWSER", ACCENT, home_selection == 4);
    draw_compact_button(sync_button, "STUDY SOURCE", GREEN, home_selection == 5);
    draw_compact_button(android_transfer_button, "DECK TRANSFER", YELLOW, home_selection == 6);
    if (clock_warning_active)
        draw_fit_text(48, 488, YELLOW, 0.48f,
                      "Vita date/time looks wrong. Offline review times may be incorrect.", 860);
    else
    draw_fit_text(48, 488, MUTED, 0.52f,
#ifdef VITAANKI_DISABLE_MUSIC
                  "D-pad + X to choose  |  Audio disabled for stability  |  START exits",
#else
                  "D-pad + X to choose  |  SELECT toggles music  |  START exits",
#endif
                  864);
    draw_fit_text(48, 520, MUTED, 0.46f, anki_connect_get_status(), 860);
}

static void toggle_android_transfer_receiver(void) {
    AndroidTransferState state = android_transfer_get_state();
    if (state == ANDROID_TRANSFER_STARTING || state == ANDROID_TRANSFER_WAITING ||
        state == ANDROID_TRANSFER_RECEIVING || state == ANDROID_TRANSFER_LISTING ||
        state == ANDROID_TRANSFER_SENDING) {
        android_transfer_stop();
        return;
    }
    if (live_sync) {
        select_offline_source();
        current_screen = SCREEN_ANDROID_TRANSFER;
    }
    android_transfer_start();
}

static void draw_android_transfer(void) {
    AndroidTransferState state = android_transfer_get_state();
    draw_header("Android ↔ Vita transfer", "Automatic discovery on local Wi-Fi");
    draw_wrapped("Same Wi-Fi required. Enter this code in VitaAnki Mobile to send decks to the Vita or download decks from it. No IP address is needed.",
                 72, 122, 816, 0.62f, WHITE);

    draw_text(72, 204, MUTED, 0.58f, "SHORT-LIVED CONFIRMATION CODE");
    draw_text(72, 246, ACCENT, 1.05f,
              state == ANDROID_TRANSFER_IDLE || state == ANDROID_TRANSFER_STOPPED
                  ? "------" : android_transfer_get_pin());

    draw_fit_text(72, 306, state == ANDROID_TRANSFER_ERROR ? RED :
                  state == ANDROID_TRANSFER_RECEIVED ? GREEN : WHITE, 0.56f,
                  android_transfer_get_message(), 816);
    if (state == ANDROID_TRANSFER_RECEIVING || state == ANDROID_TRANSFER_SENDING) {
        char progress[48];
        snprintf(progress, sizeof(progress), "%s deck: %d%%",
                 state == ANDROID_TRANSFER_RECEIVING ? "Receiving" : "Sending",
                 android_transfer_get_progress());
        draw_text(72, 354, ACCENT, 0.54f, progress);
    } else if (state == ANDROID_TRANSFER_RECEIVED) {
        draw_fit_text(72, 354, GREEN, 0.50f, android_transfer_get_filename(), 420);
    }

    draw_compact_button(android_transfer_start_button,
        state == ANDROID_TRANSFER_STARTING || state == ANDROID_TRANSFER_WAITING ||
        state == ANDROID_TRANSFER_RECEIVING || state == ANDROID_TRANSFER_LISTING ||
        state == ANDROID_TRANSFER_SENDING
            ? "STOP RECEIVER" : "START RECEIVER", ACCENT, transfer_selection == 0);
    draw_compact_button(android_transfer_decks_button, "OPEN DECKS", GREEN, transfer_selection == 1);
    draw_fit_text(610, 454, MUTED, 0.42f, "Transfers .apkg and .tsv decks", 290);
}

static void draw_sync(void) {
    draw_header("Study source", live_sync ? "Live PC mode is active." : "Choose offline study or connect to Anki Desktop.");
    const char *offline_name = current_deck_index >= 0 && current_deck_index < deck_count
                             ? deck_entries[current_deck_index].name
                             : (demo_mode ? "Demo deck" : current_deck_name);
    char offline_description[160];
    if (live_sync)
        snprintf(offline_description, sizeof(offline_description),
                 "Resume offline deck: %.100s", offline_name);
    else
        snprintf(offline_description, sizeof(offline_description),
                 "Active offline deck: %.100s", offline_name);
    const char *live_title = live_sync ? "REFRESH LIVE PC DECK"
                           : anki_connect_is_configured() ? "CONNECT TO LIVE PC"
                           : "LIVE PC SETUP NEEDED";
    const char *live_description = live_sync
        ? "Connected. Refresh the due cards from Anki Desktop."
        : anki_connect_is_configured()
        ? "Connect only when you choose this source."
        : "Configure AnkiConnect to use your PC deck.";
    draw_button(sync_offline_button, live_sync ? "DISCONNECT + USE OFFLINE" : "USE OFFLINE DECK",
                offline_description, GREEN, sync_selection == 0);
    draw_button(sync_live_button, live_title, live_description, ACCENT, sync_selection == 1);

    draw_text(72, 278, MUTED, 0.62f, "Connection status");
    const char *status = sync_message[0] ? sync_message : anki_connect_get_status();
    draw_wrapped(status, 72, 316, 812, 0.58f,
                 sync_error ? RED : WHITE);
    if (!anki_connect_is_configured())
        draw_wrapped("Setup: copy sync.example.ini to ux0:data/VitaAnki/sync.ini, then enter your PC address, exact deck name, and AnkiConnect key.",
                     72, 370, 812, 0.46f, MUTED);
    else
        draw_wrapped("Offline progress stays on the Vita. Live ratings go to Anki Desktop while connected.",
                     72, 378, 812, 0.48f, MUTED);
    draw_fit_text(72, 492, MUTED, 0.46f,
                  "Touch a source or use left/right + Cross. Circle returns.", 812);
}

static void select_offline_source(void) {
    int offline_index = current_deck_index;
    if (live_sync) {
        anki_connect_note_offline_deck();
        live_sync = 0;
        live_refresh_after = 0;
        sync_error = 0;
        undo_record.valid = 0;
        if (offline_index >= 0 && offline_index < deck_count) {
            if (!select_deck(offline_index)) load_demo_deck();
        } else {
            load_demo_deck();
        }
    }
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_position = 0.0f;
    current_screen = SCREEN_STUDY;
}

static void activate_sync_selection(void) {
    if (sync_selection == 0) select_offline_source();
    else begin_pc_sync();
}

static int first_visible_deck(void) {
    int first = list_selection - 1;
    if (first < 0) first = 0;
    if (first + LIST_VISIBLE > deck_count) first = deck_count - LIST_VISIBLE;
    if (first < 0) first = 0;
    return first;
}

static int list_action_count(int importing) {
    return importing ? 3 : 4;
}

static UiRect list_action_rect(int importing, int action) {
    if (importing) {
        if (action == 0) return (UiRect){60, 458, 210, 52};
        if (action == 1) return (UiRect){282, 458, 154, 52};
        return (UiRect){450, 458, 220, 52};
    }
    if (action == 0) return (UiRect){60, 458, 228, 52};
    if (action == 1) return (UiRect){306, 458, 154, 52};
    if (action == 2) return (UiRect){478, 458, 174, 52};
    return (UiRect){670, 458, 176, 52};
}

static const char *import_error_code_name(int code) {
    switch (code) {
        case -1: return "IMP-APKG-01";
        case -2: return "IMP-APKG-02";
        case -3: return "IMP-APKG-03";
        case -4: return "IMP-APKG-04";
        case -5: return "IMP-APKG-05";
        case -6: return "IMP-APKG-06";
        case -7: return "IMP-TSV-01";
        case -8: return "IMP-TSV-02";
        case -9: return "IMP-APKG-09";
        default: return "IMP-UNKNOWN";
    }
}

static const char *import_error_cause(int code) {
    switch (code) {
        case -1: return "The file could not be opened as an Anki package.";
        case -2: return "No collection.anki2 or collection.anki21 database was found.";
        case -3: return "The Vita SQLite reader could not open the collection database.";
        case -4: return "The package opened, but its Anki card table could not be read.";
        case -5: return "The database stopped returning cards before the import finished.";
        case -6: return "The Vita ran out of memory while creating the imported cards.";
        case -7: return "The selected deck file could not be reopened.";
        case -8: return "The Vita ran out of memory while loading this TSV deck.";
        case -9: return "SQLite memory setup failed before the import could start.";
        default: return "The selected deck could not be loaded.";
    }
}

static const char *import_error_recovery(int code) {
    switch (code) {
        case -1: return "Copy a valid .apkg into the decks folder, then rescan.";
        case -2: return "Export again from Anki with Support older Anki versions enabled.";
        case -3: return "Re-export as compatible, close other apps, and retry.";
        case -4: return "Re-export from Anki with compatibility enabled.";
        case -5: return "The collection may be incomplete; export it again from Anki.";
        case -6: return "Close other apps and try a smaller deck.";
        case -7: return "Check the file in ux0:data/VitaAnki/decks, then rescan.";
        case -8: return "Try a smaller TSV or shorter card fields.";
        case -9: return "Close and reopen VitaAnki; share this code if it happens again.";
        default: return "Check the deck file and try importing it again.";
    }
}

static void draw_deck_list(int importing) {
    const char *title = importing ? "Import a deck" : "Choose a deck";
    const char *subtitle = importing
        ? "Copy a deck here or create your own cards."
        : "Select a deck source for offline study.";
    draw_header(title, subtitle);

    if (deck_count == 0) {
        draw_text(76, 188, WHITE, 0.82f, "No deck files found");
        draw_wrapped("In VitaShell, copy a .apkg or .tsv file to ux0:data/VitaAnki/decks. Then tap Rescan and open it. The built-in sample deck is normally listed here.",
                     76, 230, 790, 0.68f, MUTED);
    } else {
        int first = first_visible_deck();
        for (int row = 0; row < LIST_VISIBLE; row++) {
            int index = first + row;
            if (index >= deck_count) break;
            UiRect rect = {60, LIST_ROW_Y + row * LIST_ROW_H, 840, 54};
            int active = current_deck_path[0] &&
                         !strcmp(deck_entries[index].path, current_deck_path);
            unsigned int fill = index == list_selection ? PANEL_HI : PANEL;
            vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, fill);
            vita2d_draw_rectangle(rect.x, rect.y, 4, rect.h, active ? GREEN : (index == list_selection ? ACCENT : PANEL));
            if (index == list_selection) {
                vita2d_draw_rectangle(rect.x, rect.y, rect.w, 2, ACCENT);
                vita2d_draw_rectangle(rect.x + rect.w - 2, rect.y, 2, rect.h, ACCENT);
                vita2d_draw_rectangle(rect.x, rect.y + rect.h - 2, rect.w, 2, ACCENT);
            }
            draw_fit_text(rect.x + 18, rect.y + 26, WHITE, 0.68f, deck_entries[index].name, 660);
            draw_text(rect.x + 18, rect.y + 46, MUTED, 0.42f,
                      deck_entries[index].is_apkg ? "Anki package (.apkg)" : "Tab-separated deck (.tsv)");
            if (active) draw_text(rect.x + rect.w - 102, rect.y + 34, GREEN, 0.42f, "CURRENT");
        }
        if (importing && !import_error && deck_count > 0 &&
            list_selection >= 0 && list_selection < deck_count) {
            struct stat file_info;
            char preview[256];
            const DeckEntry *entry = &deck_entries[list_selection];
            if (stat(entry->path, &file_info) == 0 && file_info.st_size >= 0) {
                unsigned long long bytes = (unsigned long long)file_info.st_size;
                char size_text[32];
                if (bytes >= 1024ULL * 1024ULL)
                    snprintf(size_text, sizeof(size_text), "%llu MB", bytes / (1024ULL * 1024ULL));
                else
                    snprintf(size_text, sizeof(size_text), "%llu KB", bytes / 1024ULL);
                snprintf(preview, sizeof(preview), "Preview: %s  |  %s  |  %s  |  checked when opened",
                         entry->name, entry->is_apkg ? ".apkg Anki package" : ".tsv text deck", size_text);
            } else {
                snprintf(preview, sizeof(preview), "Preview: %s  |  file details unavailable; rescan before importing",
                         entry->name);
            }
            draw_fit_text(62, 406, MUTED, 0.44f, preview, 814);
        } else if (!import_error)
            draw_fit_text(62, 406, MUTED, 0.48f, importing
                          ? "Tap a row to preview it, then choose Import & Study."
                          : "Tap a row to select it, then choose Open Selected.", 814);
    }

    if (deck_status[0]) draw_fit_text(62, 434, GREEN, 0.42f, deck_status, 814);

    if (import_error) {
        char recovery[256];
        snprintf(recovery, sizeof(recovery), "%s  Fix: %s",
                 import_error_cause(import_error_code), import_error_recovery(import_error_code));
        draw_fit_text(76, 397, RED, 0.47f,
                      import_error_code_name(import_error_code), 800);
        draw_wrapped(recovery, 76, 416, 800, 0.37f, WHITE);
        if (import_error_code == -3 || import_error_code == -6 || import_error_code == -9)
            draw_fit_text(76, 447, MUTED, 0.31f, import_apkg_diagnostic(), 800);
    }

    int action_focus = list_focus_actions;
    draw_compact_button(list_action_rect(importing, 0), importing ? "IMPORT & STUDY" : "OPEN SELECTED",
                        GREEN, action_focus && list_action_selection == 0);
    draw_compact_button(list_action_rect(importing, 1), "RESCAN", YELLOW,
                        action_focus && list_action_selection == 1);
    if (importing) {
        draw_compact_button(list_action_rect(1, 2), "CREATE DECK + CARDS", ACCENT,
                            action_focus && list_action_selection == 2);
        draw_fit_text(680, 490, MUTED, 0.43f, "New deck? Start here", 220);
    } else {
        int deletable = list_selection >= 0 && list_selection < deck_count &&
                        deck_path_is_deletable(deck_entries[list_selection].path);
        draw_compact_button(list_action_rect(0, 2), "DECK SETTINGS", ACCENT,
                            action_focus && list_action_selection == 2);
        draw_compact_button(list_action_rect(0, 3), "DELETE", RED,
                            action_focus && list_action_selection == 3);
        draw_fit_text(62, 532, MUTED, 0.38f,
                      deletable ? "D-pad / either stick: select rows or actions  |  Square: delete" :
                                  "Built-in deck cannot be deleted  |  D-pad / sticks to select",
                      820);
    }
}

static void draw_create_deck(void) {
    char subtitle[80];
    snprintf(subtitle, sizeof(subtitle), "%d card%s in this draft", create_card_count,
             create_card_count == 1 ? "" : "s");
    draw_header("Create a deck", subtitle);

    UiRect name = {72, 112, 816, 56};
    UiRect question = {72, 180, 816, 104};
    UiRect answer = {72, 296, 816, 104};
    UiRect fields[] = {name, question, answer};
    const char *labels[] = {"DECK NAME", "QUESTION", "ANSWER"};
    const char *values[] = {create_deck_name, create_question, create_answer};
    for (int i = 0; i < 3; i++) {
        vita2d_draw_rectangle(fields[i].x, fields[i].y, fields[i].w, fields[i].h,
                              create_selection == i ? PANEL_HI : PANEL);
        unsigned int edge = create_selection == i ? ACCENT : PANEL_HI;
        vita2d_draw_rectangle(fields[i].x, fields[i].y, fields[i].w, 3, edge);
        vita2d_draw_rectangle(fields[i].x, fields[i].y, 3, fields[i].h, edge);
        draw_text(fields[i].x + 18, fields[i].y + 27, MUTED, 0.46f, labels[i]);
        if (i == 0) {
            draw_fit_text(fields[i].x + 158, fields[i].y + 36, values[i][0] ? WHITE : MUTED,
                          0.55f, values[i][0] ? values[i] : "Tap to name this deck", 430);
            draw_fit_text(fields[i].x + fields[i].w - 190, fields[i].y + 36,
                          ACCENT, 0.40f, "X / TAP TO EDIT", 172);
        } else if (values[i][0]) {
            draw_wrapped(values[i], fields[i].x + 18, fields[i].y + 63,
                         fields[i].w - 36, i == 0 ? 0.60f : 0.48f, WHITE);
            draw_fit_text(fields[i].x + fields[i].w - 205, fields[i].y + 27,
                          ACCENT, 0.40f, "X / TAP TO EDIT", 185);
        } else {
            draw_text(fields[i].x + 18, fields[i].y + 66, MUTED, 0.50f,
                      "Tap to enter text");
            draw_fit_text(fields[i].x + fields[i].w - 205, fields[i].y + 27,
                          ACCENT, 0.40f, "X / TAP TO EDIT", 185);
        }
    }

    if (create_status[0])
        draw_fit_text(72, 430, create_error ? RED : MUTED, 0.44f, create_status, 816);
    draw_compact_button((UiRect){60, 458, 210, 52}, "ADD CARD", ACCENT, create_selection == 3);
    draw_compact_button((UiRect){294, 458, 210, 52}, "SAVE DECK", GREEN, create_selection == 4);
    draw_compact_button((UiRect){528, 458, 170, 52}, "CANCEL", RED, create_selection == 5);
    draw_fit_text(716, 490, MUTED, 0.42f, "D-pad + X  |  Circle cancels", 196);
}

static void draw_deck_settings(void) {
    const char *name = (list_selection >= 0 && list_selection < deck_count)
        ? deck_entries[list_selection].name : "Selected deck";
    draw_header("Deck settings", name);
    const char *labels[5] = {"New cards per study session", "Again learning step",
                             "Hard learning step", "Good interval", "Easy interval"};
    char values[5][40];
    snprintf(values[0], sizeof(values[0]), "%d cards", edit_deck_settings.new_card_limit);
    snprintf(values[1], sizeof(values[1]), "%d min", edit_deck_settings.again_minutes);
    snprintf(values[2], sizeof(values[2]), "%d min", edit_deck_settings.hard_minutes);
    snprintf(values[3], sizeof(values[3]), "%d day%s", edit_deck_settings.good_days,
             edit_deck_settings.good_days == 1 ? "" : "s");
    snprintf(values[4], sizeof(values[4]), "%d day%s", edit_deck_settings.easy_days,
             edit_deck_settings.easy_days == 1 ? "" : "s");
    for (int i = 0; i < 5; i++) {
        int y = 112 + i * 62;
        UiRect row = {60, y, 840, 50};
        vita2d_draw_rectangle(row.x, row.y, row.w, row.h,
                              i == deck_settings_selection ? PANEL_HI : PANEL);
        unsigned int edge = i == deck_settings_selection ? ACCENT : PANEL_HI;
        vita2d_draw_rectangle(row.x, row.y, row.w, 3, edge);
        vita2d_draw_rectangle(row.x, row.y, 3, row.h, edge);
        draw_text(82, y + 32, WHITE, 0.58f, labels[i]);
        draw_fit_text(540, y + 32, GREEN, 0.58f, values[i], 140);
        draw_compact_button((UiRect){700, y + 4, 64, 42}, "-", YELLOW,
                            i == deck_settings_selection);
        draw_compact_button((UiRect){776, y + 4, 64, 42}, "+", ACCENT,
                            i == deck_settings_selection);
    }
    draw_fit_text(72, 456, MUTED, 0.48f,
                  "Changes save for this deck. Up/down selects; left/right or X changes.", 816);
    draw_fit_text(72, 490, MUTED, 0.45f,
                  "Study uses these due times when this deck is selected.", 816);
    if (deck_status[0]) draw_fit_text(72, 524, RED, 0.40f, deck_status, 816);
}

static void draw_delete_dialog(void) {
    vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, RGBA8(0, 0, 0, 190));
    vita2d_draw_rectangle(220, 170, 520, 220, PANEL_HI);
    vita2d_draw_rectangle(220, 170, 520, 4, RED);
    draw_text(252, 208, WHITE, 0.78f,
              delete_dialog_stage == 1 ? "Delete this deck?" : "Are you sure?");
    if (list_selection >= 0 && list_selection < deck_count)
        draw_fit_text(252, 246, ACCENT, 0.58f, deck_entries[list_selection].name, 456);
    draw_wrapped(delete_error
                 ? "The deck could not be removed. Check the Vita storage and try again."
                 : delete_dialog_stage == 1
                     ? "This removes the deck and saved study progress. Continue for a final confirmation."
                     : "This permanently removes the deck, study progress, and its deck settings.",
                 252, 284, 456, 0.46f, delete_error ? RED : MUTED);
    draw_compact_button((UiRect){286, 326, 160, 44},
                        delete_dialog_stage == 1 ? "CANCEL" : "KEEP DECK",
                        ACCENT, delete_selection == 0);
    draw_compact_button((UiRect){466, 326, 190, 44},
                        delete_dialog_stage == 1 ? "CONTINUE" : "DELETE PERMANENTLY",
                        RED, delete_selection == 1);
}

static void draw_create_cancel_dialog(void) {
    vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, RGBA8(0, 0, 0, 190));
    vita2d_draw_rectangle(240, 190, 480, 180, PANEL_HI);
    vita2d_draw_rectangle(240, 190, 480, 4, RED);
    draw_text(274, 230, WHITE, 0.74f, "Discard this draft?");
    draw_wrapped("Cards in this unsaved deck will be removed.", 274, 270, 412, 0.52f, MUTED);
    draw_compact_button((UiRect){276, 310, 168, 42}, "DISCARD", RED, create_selection == 0);
    draw_compact_button((UiRect){466, 310, 168, 42}, "KEEP EDITING", GREEN, create_selection == 1);
}

static void cycle_setting(int setting, int direction) {
    if (setting == 0) {
        int previous_font_mode = font_mode;
        for (int step = 0; step < FONT_MODE_COUNT; step++) {
            int candidate = (font_mode +
                             (direction >= 0 ? step + 1 : FONT_MODE_COUNT - 1 - step) +
                             FONT_MODE_COUNT) % FONT_MODE_COUNT;
            if (font_mode_available(candidate)) {
                font_mode = candidate;
                break;
            }
        }
        if (font_mode != previous_font_mode) release_custom_font(previous_font_mode);
    } else if (setting == 1) {
        ui_text_mode = (ui_text_mode + (direction >= 0 ? 1 : 2)) % 3;
    } else if (setting == 2) {
        text_size_mode = (text_size_mode + (direction >= 0 ? 1 : 3)) % 4;
    } else if (setting == 3) {
        flip_animation_mode = !flip_animation_mode;
        if (!flip_animation_mode) flip_frames_remaining = 0;
    } else if (setting == 4) {
#ifndef VITAANKI_DISABLE_MUSIC
        toggle_music();
#endif
        return;
    } else if (setting == 5) {
        confetti_mode = (confetti_mode + (direction >= 0 ? 1 : 2)) % 3;
        if (confetti_mode == 0) clear_confetti();
    } else if (setting == 6) {
        review_control_mode = !review_control_mode;
    } else if (setting == 7) {
        int theme_count = (int)(sizeof(color_themes) / sizeof(color_themes[0]));
        color_theme_mode = (color_theme_mode + (direction >= 0 ? 1 : theme_count - 1)) % theme_count;
        apply_color_theme(color_theme_mode);
        vita2d_set_clear_color(BG);
    } else if (setting == 8) {
        click_sounds_enabled = !click_sounds_enabled;
    } else if (setting == 9) {
        browser_stick_mode = browser_stick_mode == BROWSER_STICK_BUTTONS
                           ? BROWSER_STICK_SCROLL : BROWSER_STICK_BUTTONS;
        analog_input_latched = 0;
    }
    save_settings();
}

static void draw_settings(void) {
    draw_header("Settings", "Reading, sound, and review controls");
    const char *font_label = font_labels[font_mode];
#ifdef VITAANKI_DISABLE_MUSIC
    const char *music_label = "Disabled in this stability build";
    const char *music_title = "Background music (disabled)";
#else
    const char *music_label = anki_music_is_muted() ? "Muted"
                          : anki_music_is_available() ? "Playing"
                          : anki_music_is_running() ? "Starting..."
                          : "Unavailable / see music.log";
    const char *music_title = "Background music";
#endif
    const char *titles[SETTINGS_COUNT] = {"Font", "Menu and labels", "Card text size", "Answer flip",
                                          music_title, "Confetti", "Rating controls", "Color theme",
                                          "Button click sounds", "Card Browser stick input"};
    const char *values[SETTINGS_COUNT] = {font_label, ui_text_labels[ui_text_mode],
                                          text_size_labels[text_size_mode], flip_animation_labels[flip_animation_mode],
                                          music_label, confetti_labels[confetti_mode],
                                          review_control_mode ? "Stick + X + touch" : "Buttons + touch",
                                          color_theme_labels[color_theme_mode],
                                          click_sounds_enabled ? "On" : "Off",
                                          browser_stick_mode == BROWSER_STICK_BUTTONS
                                              ? "Button controls" : "Scroll the card"};
    unsigned int colors[SETTINGS_COUNT] = {ACCENT, ACCENT, GREEN, ACCENT, YELLOW,
                                           RED, GREEN, ACCENT, YELLOW, ACCENT};
    for (int i = 0; i < SETTINGS_COUNT; i++) {
        UiRect row = settings_rows[i];
        int chosen = i == settings_selection;
        vita2d_draw_rectangle(row.x, row.y, row.w, row.h,
                              chosen ? PANEL_HI : PANEL);
        vita2d_draw_rectangle(row.x, row.y, 4, row.h, colors[i]);
        draw_fit_text(row.x + 22, row.y + 14, WHITE, 0.45f, titles[i], 590);
        draw_fit_text(row.x + 22, row.y + 29, MUTED, 0.32f, values[i], 590);
        vita2d_draw_rectangle(row.x + 728, row.y + 1, 46, 30, PANEL);
        vita2d_draw_rectangle(row.x + 784, row.y + 1, 46, 30, PANEL);
        draw_text(row.x + 744, row.y + 23, colors[i], 0.48f, "<");
        draw_text(row.x + 801, row.y + 23, colors[i], 0.48f, ">");
    }
    draw_fit_text(72, 458, MUTED, 0.44f, "Card preview:", 132);
    draw_card_text(210, 462, WHITE, 0.68f, "Aa Bb 123");
    draw_fit_text(72, 492, MUTED, 0.43f,
                  "D-pad / stick choose; left/right change. Cross selects; Circle returns.",
                  816);
    draw_fit_text(72, 520, MUTED, 0.43f,
                  "Stick + X: left/right choose, Cross confirms. Touch ratings work in either mode.",
                  816);
}

static void draw_flip_overlay(void) {
    if (flip_frames_remaining <= 0) return;
    const int x = 70, y = 140, width = 836, height = 291;
    int progress = CARD_FLIP_FRAMES - flip_frames_remaining;
    int half = CARD_FLIP_FRAMES / 2;
    int visible_width = progress <= half
                      ? width * (half - progress) / half
                      : width * (progress - half) / half;
    int cover_width = (width - visible_width) / 2;
    if (cover_width > 0) {
        vita2d_draw_rectangle(x, y, cover_width, height, PANEL);
        vita2d_draw_rectangle(x + width - cover_width, y, cover_width, height, PANEL);
    }
    if (progress > 0 && progress < CARD_FLIP_FRAMES) {
        int edge_left = x + cover_width - 1;
        int edge_right = x + cover_width + visible_width - 1;
        vita2d_draw_rectangle(edge_left, y + 4, 2, height - 8, ACCENT);
        if (visible_width > 4)
            vita2d_draw_rectangle(edge_right, y + 4, 2, height - 8, ACCENT);
    }
}

static void draw_study(void) {
    char subtitle[160];
    if (clock_warning_active && !live_sync) snprintf(subtitle, sizeof(subtitle), "OFFLINE  |  CHECK VITA DATE/TIME");
    else if (live_sync) snprintf(subtitle, sizeof(subtitle), "LIVE ANKI DESKTOP  |  %s", sync_error ? "connection issue" : "connected");
    else if (apkg_mode && sync_queue_error) snprintf(subtitle, sizeof(subtitle), "OFFLINE REVIEW  |  QUEUE SAVE FAILED");
    else if (sync_error && apkg_mode) snprintf(subtitle, sizeof(subtitle), "OFFLINE REVIEW  |  SYNC QUEUED");
    else if (apkg_mode) snprintf(subtitle, sizeof(subtitle), "OFFLINE REVIEW  |  SYNC QUEUED");
    else if (!anki_connect_is_configured()) snprintf(subtitle, sizeof(subtitle), "OFFLINE  |  ANKICONNECT SETUP NEEDED");
    else if (sync_error) snprintf(subtitle, sizeof(subtitle), "OFFLINE  |  SYNC CONNECTION LOST");
    else if (demo_mode) snprintf(subtitle, sizeof(subtitle), "DEMO DECK");
    else if (import_error) snprintf(subtitle, sizeof(subtitle), "IMPORT FAILED");
    else snprintf(subtitle, sizeof(subtitle), "%s", current_deck_name);
    draw_header("Study", NULL);
    draw_fit_text(148, 78, MUTED, 0.5f, subtitle, 360);
    int counts_available = 0;
    AnkiStudyCounts counts = current_study_counts(&counts_available);
    char new_text[24], learning_text[24], review_text[24], done_text[24];
    if (counts_available) {
        snprintf(new_text, sizeof(new_text), "NEW %d", counts.new_count);
        snprintf(learning_text, sizeof(learning_text), "LEARN %d", counts.learning_count);
        snprintf(review_text, sizeof(review_text), "REVIEW %d", counts.review_count);
    } else {
        snprintf(new_text, sizeof(new_text), "NEW --");
        snprintf(learning_text, sizeof(learning_text), "LEARN --");
        snprintf(review_text, sizeof(review_text), "REVIEW --");
    }
    snprintf(done_text, sizeof(done_text), "DONE %d", reviewed);
    draw_fit_text(518, 78, ACCENT, 0.42f, new_text, 82);
    draw_fit_text(604, 78, YELLOW, 0.42f, learning_text, 92);
    draw_fit_text(700, 78, GREEN, 0.42f, review_text, 104);
    draw_fit_text(808, 78, MUTED, 0.42f, done_text, 100);

    int has_card = has_study_card();
    unsigned int card_state_color = ACCENT;
    if (has_card && cards[card_index].state == CARD_STATE_LEARNING)
        card_state_color = YELLOW;
    else if (has_card && cards[card_index].state == CARD_STATE_REVIEW)
        card_state_color = GREEN;
    vita2d_draw_rectangle(48, 104, 864, 334, PANEL);
    vita2d_draw_rectangle(48, 104, 7, 334, card_state_color);
    draw_compact_button(undo_button, "UNDO (L)", undo_record.valid ? YELLOW : MUTED, 0);
    int answer_visible = displayed_answer_side();
    const char *visible_text = has_card
                             ? (answer_visible ? cards[card_index].back : cards[card_index].front)
                             : "";
    const char *visible_image = has_card && !answer_visible ? cards[card_index].front_image : "";
    int split_card = visible_image[0] != '\0';
    int text_width = split_card ? SPLIT_CARD_TEXT_WIDTH : 790;
    float text_scale = split_card ? 0.84f : 0.95f;
    int text_height = split_card ? 210 : 160;
    if (has_card) {
        int limit = card_scroll_limit(visible_text, text_width, text_scale, text_height);
        if (card_scroll_position > (float)limit) card_scroll_position = (float)limit;
    }
    if (card_count <= 0) {
        if (live_sync && !sync_error) {
            int learning_pending = anki_connect_has_learning_cards();
            draw_text(82, 160, learning_pending ? YELLOW : MUTED, 0.72f,
                      learning_pending ? "LEARNING STEP WAITING" : "NO CARDS DUE");
            draw_wrapped(learning_pending
                             ? "Anki has cards in learning. VitaAnki checks for the next due learning step every 10 seconds."
                             : "This deck has no new or due cards right now. Check back after another card becomes due.",
                         82, 225, 780, 0.78f, WHITE);
        } else {
            draw_text(82, 160, MUTED, 0.72f,
                      import_error ? "DECK COULD NOT BE LOADED" : "NO STUDY CARDS LOADED");
            draw_wrapped(import_error
                             ? "The selected deck could not be read. Open Decks, rescan, and choose it again."
                             : "The current deck has no available study cards. Choose another deck, or re-import this one if cards are missing.",
                         82, 225, 780, 0.78f, WHITE);
        }
    } else if (!has_card) {
        int unseen_new = 0;
        if (!live_sync)
            for (int i = 0; i < card_count; i++)
                if (cards[i].state == CARD_STATE_NEW) unseen_new++;
        if (unseen_new > 0 && new_cards_this_session >= current_deck_settings.new_card_limit) {
            draw_text(82, 160, ACCENT, 0.72f, "NEW CARD BATCH COMPLETE");
            char batch_message[240];
            snprintf(batch_message, sizeof(batch_message),
                     "This deck's session limit is %d new card%s. Learning steps and reviews return first when due. Go Home, then choose Study to start another batch.",
                     current_deck_settings.new_card_limit,
                     current_deck_settings.new_card_limit == 1 ? "" : "s");
            draw_wrapped(batch_message, 82, 225, 780, 0.78f, WHITE);
        } else {
            draw_text(82, 160, GREEN, 0.72f, "SESSION COMPLETE");
            draw_wrapped(counts.learning_count > 0
                             ? "A learning step is waiting and will return when due. Use Card Browser for a quick review."
                             : "Nothing is due right now. Use Card Browser to preview cards, or come back when the next card is due.",
                         82, 225, 780, 0.78f, WHITE);
        }
    } else if (!answer_visible) {
        draw_text(82, 156, MUTED, 0.66f, "QUESTION");
        draw_card_viewport(visible_text, 82, split_card ? 205 : 222, text_width, text_scale,
                           WHITE, card_scroll_position, text_height);
        draw_card_scrollbar(visible_text, split_card ? 424 : 890, split_card ? 205 : 222,
                            text_width, text_scale, card_scroll_position, text_height);
        if (split_card)
            draw_card_image_half(visible_image, SPLIT_CARD_IMAGE_X, SPLIT_CARD_IMAGE_Y,
                                 SPLIT_CARD_IMAGE_WIDTH, SPLIT_CARD_IMAGE_HEIGHT);
        draw_fit_text(82, split_card ? 426 : 410, clock_warning_active ? YELLOW : MUTED, 0.46f,
                      clock_warning_active
                          ? "Clock looks wrong; offline rating times may be incorrect."
                          : "Tap card or X to reveal  |  Either stick scrolls smoothly",
                      790);
    } else {
        draw_text(82, 156, MUTED, 0.66f, "ANSWER");
        draw_card_viewport(visible_text, 82, 222, 790, 0.95f,
                           WHITE, card_scroll_position, 160);
        draw_card_scrollbar(visible_text, 890, 222, 790, 0.95f,
                            card_scroll_position, 160);
        draw_fit_text(82, 410, clock_warning_active ? YELLOW : MUTED, 0.44f,
                      clock_warning_active
                          ? "Clock looks wrong; offline rating times may be incorrect."
                          : live_sync
                          ? review_control_mode
                              ? "Either stick scrolls; left/right choose; X rates. Touch works too."
                              : "Either stick scrolls  |  Triangle/Square/Circle/R or touch to rate"
                          : review_control_mode
                              ? "Either stick scrolls; Again ~1m; Hard ~5m learning. Left/right + X rates."
                              : "Either stick scrolls; Again ~1m; Hard ~5m learning. Triangle/Square/Circle/R rate.",
                      790);
    }

    const int x = 50, y = 458, w = 164, gap = 10, h = 60;
    const char *labels[5] = {
        review_control_mode ? (answer_visible ? "X  RATE" : "X  REVEAL")
                            : (answer_visible ? "X  FLIP" : "X  REVEAL"),
        review_control_mode ? "AGAIN" : "TRIANGLE  AGAIN",
        review_control_mode ? "HARD" : "SQUARE  HARD",
        review_control_mode ? "GOOD" : "CIRCLE  GOOD",
        review_control_mode ? "EASY" : "R  EASY"
    };
    unsigned int accents[5] = {ACCENT, RED, YELLOW, GREEN, ACCENT};
    for (int i = 0; i < 5; i++) {
        UiRect rect = {x + i * (w + gap), y, w, h};
        int enabled = has_card && flip_frames_remaining == 0 && (i == 0 || answer_visible);
        int selected = review_control_mode && i > 0 && i - 1 == selected_rating;
        vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h,
                              selected ? PANEL_HI : enabled ? PANEL : BG);
        vita2d_draw_rectangle(rect.x, rect.y, rect.w, 3, enabled ? accents[i] : PANEL_HI);
        draw_fit_text(rect.x + 8, rect.y + 36, enabled ? (i == 0 ? WHITE : accents[i]) : MUTED,
                      0.45f, labels[i], rect.w - 16);
    }
    if (undo_error)
        draw_fit_text(50, 533, RED, 0.40f,
                      "Undo failed. Check the Anki connection or pending review queue.",
                      860);
    else if (undo_record.valid)
        draw_fit_text(50, 533, MUTED, 0.40f,
                      undo_record.live
                          ? "Tap Undo or press L to undo Anki Desktop's latest action."
                          : "Tap Undo or press L to reverse the latest rating.",
                      860);
    draw_flip_overlay();
}

static void move_browser(int direction) {
    if (card_count <= 0) return;
    browser_index += direction;
    if (browser_index < 0) browser_index = card_count - 1;
    else if (browser_index >= card_count) browser_index = 0;
    browser_show_answer = 0;
    browser_scroll_position = 0.0f;
}

static void draw_browser(void) {
    draw_header("Card browser", current_deck_name);
    char status[64];
    snprintf(status, sizeof(status), "CARD %d OF %d", card_count > 0 ? browser_index + 1 : 0,
             card_count);
    draw_fit_text(748, 78, MUTED, 0.46f, status, 164);

    vita2d_draw_rectangle(48, 104, 864, 334, PANEL);
    vita2d_draw_rectangle(48, 104, 7, 334, ACCENT);
    if (card_count > 0) {
        int split = !browser_show_answer && cards[browser_index].front_image[0];
        int limit = card_scroll_limit(browser_card_text(), split ? SPLIT_CARD_TEXT_WIDTH : 790,
                                      split ? 0.84f : 0.95f, split ? 210 : 160);
        if (browser_scroll_position > (float)limit) browser_scroll_position = (float)limit;
    }
    if (card_count <= 0) {
        draw_text(82, 160, MUTED, 0.72f, "NO CARDS TO BROWSE");
        draw_wrapped("Open Import to add an Anki package or tab-separated deck.",
                     82, 222, 780, 0.78f, WHITE);
    } else {
        draw_text(82, 156, MUTED, 0.66f, browser_show_answer ? "ANSWER" : "QUESTION");
        int split = !browser_show_answer && cards[browser_index].front_image[0];
        draw_card_viewport(browser_card_text(), 82, split ? 205 : 222,
                           split ? SPLIT_CARD_TEXT_WIDTH : 790,
                           split ? 0.84f : 0.95f, WHITE, browser_scroll_position, split ? 210 : 160);
        draw_card_scrollbar(browser_card_text(), split ? 424 : 890, split ? 205 : 222,
                            split ? SPLIT_CARD_TEXT_WIDTH : 790, split ? 0.84f : 0.95f,
                            browser_scroll_position, split ? 210 : 160);
        if (split)
            draw_card_image_half(cards[browser_index].front_image, SPLIT_CARD_IMAGE_X,
                                 SPLIT_CARD_IMAGE_Y, SPLIT_CARD_IMAGE_WIDTH,
                                 SPLIT_CARD_IMAGE_HEIGHT);
        draw_fit_text(82, split ? 426 : 410, MUTED, 0.47f,
                      "Either stick scrolls smoothly  |  Browse does not change progress",
                      790);
    }

    int button_focus = browser_stick_mode == BROWSER_STICK_BUTTONS;
    draw_compact_button((UiRect){50, 458, 180, 52}, "PREVIOUS", ACCENT,
                        button_focus && browser_button_selection == 0);
    draw_compact_button(browser_jump_button, "JUMP TO CARD", YELLOW,
                        button_focus && browser_button_selection == 1);
    draw_compact_button((UiRect){440, 458, 310, 52},
                        browser_show_answer ? "SHOW QUESTION" : "SHOW ANSWER", GREEN,
                        button_focus && browser_button_selection == 2);
    draw_compact_button((UiRect){760, 458, 150, 52}, "NEXT", ACCENT,
                        button_focus && browser_button_selection == 3);
    draw_fit_text(60, 530, MUTED, 0.43f,
                  button_focus
                      ? "Stick left/right selects actions  |  X activates  |  D-pad left/right browses, up/down scrolls  |  Triangle jump  |  Circle back"
                      : "Either stick up/down scrolls  |  Left stick/D-pad left-right: browse  |  X flips  |  Triangle jumps  |  Circle back",
                  840);
}

static UiRect jump_key_rect(int index) {
    int row = index / 3;
    int column = index % 3;
    return (UiRect){356 + column * 84, 204 + row * 44, 76, 38};
}

static void open_jump_dialog(void) {
    if (card_count <= 0) return;
    jump_dialog_open = 1;
    jump_selection = 13;
    jump_input[0] = '\0';
    jump_error = 0;
}

static void jump_to_entered_card(void) {
    if (!jump_input[0]) {
        jump_error = 1;
        return;
    }
    long number = strtol(jump_input, NULL, 10);
    if (number < 1 || number > card_count) {
        jump_error = 1;
        return;
    }
    browser_index = (int)number - 1;
    browser_show_answer = 0;
    browser_scroll_position = 0.0f;
    jump_dialog_open = 0;
    jump_error = 0;
}

static void activate_browser_button(void) {
    if (card_count <= 0) return;
    if (browser_button_selection == 0) move_browser(-1);
    else if (browser_button_selection == 1) open_jump_dialog();
    else if (browser_button_selection == 2) {
        browser_show_answer = !browser_show_answer;
        browser_scroll_position = 0.0f;
    } else move_browser(1);
}

static void activate_jump_selection(void) {
    if (jump_selection >= 0 && jump_selection <= 8) {
        size_t length = strlen(jump_input);
        if (length + 1 < sizeof(jump_input)) {
            jump_input[length] = (char)('1' + jump_selection);
            jump_input[length + 1] = '\0';
        }
        jump_error = 0;
    } else if (jump_selection == 9) {
        jump_input[0] = '\0';
        jump_error = 0;
    } else if (jump_selection == 10) {
        size_t length = strlen(jump_input);
        if (length + 1 < sizeof(jump_input)) {
            jump_input[length] = '0';
            jump_input[length + 1] = '\0';
        }
        jump_error = 0;
    } else if (jump_selection == 11) {
        size_t length = strlen(jump_input);
        if (length > 0) jump_input[length - 1] = '\0';
        jump_error = 0;
    } else if (jump_selection == 12) {
        jump_dialog_open = 0;
    } else if (jump_selection == 13) {
        jump_to_entered_card();
    }
}

static void move_jump_selection(unsigned int pressed) {
    if (jump_selection >= 12) {
        if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))
            jump_selection = jump_selection == 12 ? 13 : 12;
        else if (pressed & SCE_CTRL_UP)
            jump_selection = jump_selection == 12 ? 9 : 10;
        return;
    }

    int row = jump_selection / 3;
    int column = jump_selection % 3;
    if (pressed & SCE_CTRL_LEFT) column = (column + 2) % 3;
    else if (pressed & SCE_CTRL_RIGHT) column = (column + 1) % 3;
    else if (pressed & SCE_CTRL_UP) row = row > 0 ? row - 1 : 3;
    else if (pressed & SCE_CTRL_DOWN) {
        if (row < 3) row++;
        else jump_selection = column == 0 ? 12 : 13;
    }
    if (jump_selection < 12) jump_selection = row * 3 + column;
}

static void draw_jump_dialog(void) {
    vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, RGBA8(0, 0, 0, 190));
    vita2d_draw_rectangle(220, 78, 520, 398, PANEL_HI);
    vita2d_draw_rectangle(220, 78, 520, 4, ACCENT);
    draw_text(252, 112, WHITE, 0.82f, "Jump to a card");

    vita2d_draw_rectangle(356, 126, 248, 42, PANEL);
    if (jump_input[0]) draw_text(378, 155, WHITE, 0.72f, jump_input);
    else draw_text(378, 155, MUTED, 0.56f, "Card number");
    char range[80];
    snprintf(range, sizeof(range), "Enter a number from 1 to %d", card_count);
    const char *range_message = jump_error
        ? (jump_input[0] ? "That card number is out of range." : "Enter a card number first.")
        : range;
    draw_fit_text(356, 190, jump_error ? RED : MUTED, 0.46f, range_message, 350);

    static const char *labels[12] = {"1", "2", "3", "4", "5", "6", "7", "8", "9",
                                     "CLR", "0", "DEL"};
    for (int i = 0; i < 12; i++)
        draw_compact_button(jump_key_rect(i), labels[i], ACCENT, jump_selection == i);
    draw_compact_button((UiRect){340, 397, 138, 42}, "CANCEL", RED, jump_selection == 12);
    draw_compact_button((UiRect){482, 397, 138, 42}, "GO", GREEN, jump_selection == 13);
    draw_fit_text(252, 463, MUTED, 0.43f,
                  "D-pad moves  |  X chooses  |  Circle cancels", 456);
}

static void draw_ui(void) {
    vita2d_start_drawing();
    vita2d_clear_screen();
    vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, BG);
    if (current_screen == SCREEN_HOME) draw_home();
    else if (current_screen == SCREEN_STUDY) draw_study();
    else if (current_screen == SCREEN_BROWSER) draw_browser();
    else if (current_screen == SCREEN_DECKS) draw_deck_list(0);
    else if (current_screen == SCREEN_IMPORT) draw_deck_list(1);
    else if (current_screen == SCREEN_SETTINGS) draw_settings();
    else if (current_screen == SCREEN_SYNC) draw_sync();
    else if (current_screen == SCREEN_ANDROID_TRANSFER) draw_android_transfer();
    else if (current_screen == SCREEN_CREATE_DECK) draw_create_deck();
    else if (current_screen == SCREEN_DECK_SETTINGS) draw_deck_settings();
    draw_confetti();
    if (jump_dialog_open) draw_jump_dialog();
    if (delete_dialog_open) draw_delete_dialog();
    if (create_cancel_dialog_open) draw_create_cancel_dialog();
    vita2d_end_drawing();
    if (create_ime_open) vita2d_common_dialog_update();
    vita2d_swap_buffers();
}

static void begin_pc_sync(void) {
    sync_error = 0;
    sync_message[0] = '\0';
    if (!anki_connect_is_configured()) {
        sync_error = 1;
        snprintf(sync_message, sizeof(sync_message), "%s", anki_connect_get_status());
        return;
    }

    if (!vitaanki_reserve_cards(&cards, &card_capacity, MAX_CARDS)) {
        sync_error = 1;
        snprintf(sync_message, sizeof(sync_message), "Not enough memory to prepare the live card list.");
        return;
    }

    int already_live = live_sync;
    int offline_index = current_deck_index;
    int loaded = already_live ? anki_connect_reload(cards, card_capacity)
                              : anki_connect_start(cards, card_capacity);
    if (loaded >= 0 && anki_connect_is_configured()) {
        card_count = loaded;
        live_sync = 1;
        sync_error = 0;
        reviewed = 0;
        show_answer = 0;
        flip_frames_remaining = 0;
        card_scroll_position = 0.0f;
        selected_rating = 2;
        undo_record.valid = 0;
        undo_error = 0;
        card_index = 0;
        live_refresh_after = time(NULL) + LIVE_REFRESH_SECONDS;
        snprintf(current_deck_name, sizeof(current_deck_name), "AnkiConnect deck");
        snprintf(sync_message, sizeof(sync_message), "%s", anki_connect_get_status());
        current_screen = SCREEN_STUDY;
    } else {
        if (anki_connect_is_configured())
            snprintf(sync_message, sizeof(sync_message), "%s", anki_connect_get_status());
        else
            snprintf(sync_message, sizeof(sync_message), "Sync settings are missing or invalid");
        sync_error = 1;
        anki_connect_stop();
        live_sync = 0;
        live_refresh_after = 0;
        if (offline_index >= 0 && offline_index < deck_count) {
            if (!select_deck(offline_index)) load_demo_deck();
        } else {
            load_demo_deck();
        }
        sync_error = 1;
        current_screen = SCREEN_SYNC;
    }
}

static void activate_home_selection(void) {
    if (home_selection == 0) {
        if (!live_sync && card_count == 0 && current_deck_index >= 0 &&
            current_deck_index < deck_count) {
            if (!select_deck(current_deck_index)) return;
        } else if (!live_sync && card_index < 0) {
            new_cards_this_session = 0;
            card_index = find_next_due();
            show_answer = 0;
        }
        current_screen = SCREEN_STUDY;
    }
    else if (home_selection == 1) {
        scan_decks();
        list_focus_actions = 0;
        list_selection = current_deck_index >= 0 ? current_deck_index : 0;
        current_screen = SCREEN_DECKS;
    } else if (home_selection == 2) {
        scan_decks();
        list_focus_actions = 0;
        list_selection = current_deck_index >= 0 ? current_deck_index : 0;
        current_screen = SCREEN_IMPORT;
    } else if (home_selection == 3) {
        settings_selection = 0;
        current_screen = SCREEN_SETTINGS;
    } else if (home_selection == 4) {
        browser_index = card_count > 0 ? card_index : 0;
        if (browser_index < 0 || browser_index >= card_count) browser_index = 0;
        browser_show_answer = 0;
        browser_button_selection = 2;
        browser_scroll_position = 0.0f;
        jump_dialog_open = 0;
        analog_input_latched = 0;
        current_screen = SCREEN_BROWSER;
    } else if (home_selection == 5) {
        sync_message[0] = '\0';
        sync_error = 0;
        sync_selection = live_sync ? 0 : 1;
        current_screen = SCREEN_SYNC;
    } else if (home_selection == 6) {
        transfer_selection = 0;
        current_screen = SCREEN_ANDROID_TRANSFER;
    }
}

static void move_home_selection(unsigned int pressed) {
    if (pressed & SCE_CTRL_LEFT) {
        if (home_selection == 1) home_selection = 0;
        else if (home_selection == 3) home_selection = 2;
        else if (home_selection == 5) home_selection = 4;
        else if (home_selection == 6) home_selection = 5;
    } else if (pressed & SCE_CTRL_RIGHT) {
        if (home_selection == 0) home_selection = 1;
        else if (home_selection == 2) home_selection = 3;
        else if (home_selection == 4) home_selection = 5;
        else if (home_selection == 5) home_selection = 6;
    } else if (pressed & SCE_CTRL_UP) {
        if (home_selection < 2) header_focus_active = 2;
        else if (home_selection == 4) home_selection = 2;
        else if (home_selection == 5 || home_selection == 6) home_selection = 3;
        else if (home_selection >= 2) home_selection -= 2;
    } else if (pressed & SCE_CTRL_DOWN) {
        if (home_selection < 2) home_selection += 2;
        else if (home_selection == 2) home_selection = 4;
        else if (home_selection == 3) home_selection = 5;
    }
}

static float normalized_analog_axis(unsigned char value) {
    float amount = ((float)value - 128.0f) / 127.0f;
    float magnitude = fabsf(amount);
    const float deadzone = 0.18f;
    if (magnitude <= deadzone) return 0.0f;
    float normalized = (magnitude - deadzone) / (1.0f - deadzone);
    return amount < 0.0f ? -normalized : normalized;
}

static int analog_direction(const SceCtrlData *pad) {
    float axes[4] = {
        normalized_analog_axis(pad->lx), normalized_analog_axis(pad->ly),
        normalized_analog_axis(pad->rx), normalized_analog_axis(pad->ry)
    };
    int best = -1;
    float magnitude = 0.22f;
    for (int i = 0; i < 4; i++) {
        float candidate = fabsf(axes[i]);
        if (candidate > magnitude) { magnitude = candidate; best = i; }
    }
    if (best == 0) return axes[0] < 0.0f ? 1 : 3;
    if (best == 2) return axes[2] < 0.0f ? 1 : 3;
    if (best == 1) return axes[1] < 0.0f ? 4 : 2;
    if (best == 3) return axes[3] < 0.0f ? 4 : 2;
    return 0;
}

static unsigned int analog_navigation_pulse(const SceCtrlData *pad) {
    int direction = analog_direction(pad);
    if (direction == 0 || create_ime_open) {
        analog_input_latched = 0;
        analog_repeat_frames = 0;
        return 0;
    }
    unsigned int button = direction == 1 ? SCE_CTRL_LEFT :
                          direction == 2 ? SCE_CTRL_DOWN :
                          direction == 3 ? SCE_CTRL_RIGHT : SCE_CTRL_UP;
    if (direction != analog_input_latched) {
        analog_input_latched = direction;
        analog_repeat_frames = 0;
        return button;
    }
    analog_repeat_frames++;
    if (analog_repeat_frames >= 14 && (analog_repeat_frames - 14) % 7 == 0)
        return button;
    return 0;
}

static void update_analog_input(const SceCtrlData *pad) {
    if (current_screen == SCREEN_STUDY || current_screen == SCREEN_BROWSER) {
        float left_y = normalized_analog_axis(pad->ly);
        float right_y = normalized_analog_axis(pad->ry);
        float scroll = fabsf(left_y) >= fabsf(right_y) ? left_y : right_y;
        if (header_focus_active) {
            float left_x = normalized_analog_axis(pad->lx);
            float right_x = normalized_analog_axis(pad->rx);
            float horizontal = fabsf(left_x) >= fabsf(right_x) ? left_x : right_x;
            int header_direction = horizontal < -0.22f ? 1 : horizontal > 0.22f ? 3 : 0;
            if (header_direction == 0) analog_header_latched = 0;
            else if (header_direction != analog_header_latched) {
                analog_header_latched = header_direction;
                if (current_screen == SCREEN_HOME) header_focus_active = 2;
                else header_focus_active = header_focus_active == 1 ? 2 : 1;
            }
            if (scroll > 0.22f) header_focus_active = 0;
            return;
        }
        if (scroll < -0.22f && card_scroll_position <= 0.0f) {
            header_focus_active = 1;
            return;
        }
        scroll_visible_card_by(scroll * 0.32f);
    }

    float left_x = normalized_analog_axis(pad->lx);
    float right_x = normalized_analog_axis(pad->rx);
    float horizontal = fabsf(left_x) >= fabsf(right_x) ? left_x : right_x;
    int direction = horizontal < -0.22f ? 1 : horizontal > 0.22f ? 3 : 0;
    if (current_screen == SCREEN_BROWSER) {
        if (direction == 0 || card_count <= 0) {
            analog_browser_latched = 0;
        } else if (direction != analog_browser_latched) {
            analog_browser_latched = direction;
            if (browser_stick_mode == BROWSER_STICK_BUTTONS)
                browser_button_selection = (browser_button_selection +
                                            (direction == 1 ? 3 : 1)) % 4;
            else
                move_browser(direction == 1 ? -1 : 1);
        }
    } else if (current_screen == SCREEN_STUDY && show_answer && has_study_card() &&
               review_control_mode) {
        if (direction == 0) analog_rating_latched = 0;
        else if (direction != analog_rating_latched) {
            analog_rating_latched = direction;
            selected_rating = (selected_rating + (direction == 3 ? 1 : 3)) % 4;
        }
    } else {
        analog_rating_latched = 0;
        analog_browser_latched = 0;
    }
}

static void start_delete_dialog(void) {
    if (list_selection < 0 || list_selection >= deck_count ||
        !deck_path_is_deletable(deck_entries[list_selection].path)) return;
    delete_selection = 0;
    delete_dialog_stage = 1;
    delete_error = 0;
    delete_dialog_open = 1;
}

static void rescan_deck_list(void) {
    scan_decks();
    if (list_selection >= deck_count) list_selection = deck_count > 0 ? deck_count - 1 : 0;
    import_error = 0;
    import_error_code = 0;
    deck_status[0] = '\0';
}

static void activate_deck_list_action(int importing, int action) {
    if (action == 0) {
        if (deck_count > 0) select_deck(list_selection);
    } else if (action == 1) {
        rescan_deck_list();
    } else if (importing && action == 2) {
        open_create_deck();
    } else if (!importing && action == 2) {
        open_deck_settings(list_selection);
    } else if (!importing && action == 3) {
        start_delete_dialog();
    }
}

static void activate_header_back(void) {
    header_focus_active = 0;
    if (current_screen == SCREEN_ANDROID_TRANSFER) android_transfer_stop();
    if (current_screen == SCREEN_CREATE_DECK) request_cancel_create();
    else if (current_screen == SCREEN_DECK_SETTINGS) current_screen = SCREEN_DECKS;
    else current_screen = SCREEN_HOME;
}

static void handle_touch(int x, int y) {
    if (create_ime_open) return;
    if (click_sounds_enabled) anki_music_play_click();
    if (delete_dialog_open) {
        if (inside((UiRect){286, 326, 160, 44}, x, y)) {
            delete_selection = 0;
            advance_delete_confirmation();
        } else if (inside((UiRect){466, 326, 190, 44}, x, y)) {
            delete_selection = 1;
            advance_delete_confirmation();
        }
        return;
    }
    if (create_cancel_dialog_open) {
        if (inside((UiRect){276, 310, 168, 42}, x, y)) discard_create_deck();
        else if (inside((UiRect){466, 310, 168, 42}, x, y)) create_cancel_dialog_open = 0;
        return;
    }
    if (jump_dialog_open) {
        for (int i = 0; i < 12; i++) {
            if (inside(jump_key_rect(i), x, y)) {
                jump_selection = i;
                activate_jump_selection();
                return;
            }
        }
        if (inside((UiRect){340, 397, 138, 42}, x, y)) {
            jump_dialog_open = 0;
            return;
        }
        if (inside((UiRect){482, 397, 138, 42}, x, y)) {
            jump_to_entered_card();
            return;
        }
        return;
    }
    if (inside(music_button, x, y)) {
        header_focus_active = 2;
        toggle_music();
        return;
    }
    if (current_screen != SCREEN_HOME && inside(back_button, x, y)) {
        activate_header_back();
        return;
    }

    if (current_screen == SCREEN_HOME) {
        for (int i = 0; i < 4; i++) {
            if (inside(home_buttons[i], x, y)) {
                home_selection = i;
                activate_home_selection();
                return;
            }
        }
        if (inside(browser_button, x, y)) {
            home_selection = 4;
            activate_home_selection();
            return;
        }
        if (inside(sync_button, x, y)) {
            home_selection = 5;
            activate_home_selection();
            return;
        }
        if (inside(android_transfer_button, x, y)) {
            home_selection = 6;
            activate_home_selection();
            return;
        }
    } else if (current_screen == SCREEN_SYNC) {
        if (inside(sync_offline_button, x, y)) {
            sync_selection = 0;
            activate_sync_selection();
            return;
        }
        if (inside(sync_live_button, x, y)) {
            sync_selection = 1;
            activate_sync_selection();
            return;
        }
    } else if (current_screen == SCREEN_ANDROID_TRANSFER) {
        if (inside(android_transfer_start_button, x, y)) {
            transfer_selection = 0;
            toggle_android_transfer_receiver();
            return;
        }
        if (inside(android_transfer_decks_button, x, y)) {
            transfer_selection = 1;
            android_transfer_stop();
            scan_decks();
            list_selection = current_deck_index >= 0 ? current_deck_index : 0;
            current_screen = SCREEN_DECKS;
            return;
        }
    } else if (current_screen == SCREEN_CREATE_DECK) {
        if (inside((UiRect){72, 112, 816, 56}, x, y)) {
            create_selection = 0;
            begin_create_ime(0);
        } else if (inside((UiRect){72, 180, 816, 104}, x, y)) {
            create_selection = 1;
            begin_create_ime(1);
        } else if (inside((UiRect){72, 296, 816, 104}, x, y)) {
            create_selection = 2;
            begin_create_ime(2);
        } else if (inside((UiRect){60, 458, 210, 52}, x, y)) {
            create_selection = 3;
            create_add_card();
        } else if (inside((UiRect){294, 458, 210, 52}, x, y)) {
            create_selection = 4;
            create_save_deck();
        } else if (inside((UiRect){528, 458, 170, 52}, x, y)) {
            create_selection = 5;
            request_cancel_create();
        }
    } else if (current_screen == SCREEN_STUDY) {
        if (inside(undo_button, x, y)) {
            undo_last_rating();
            return;
        }
        if (y >= 458 && y < 518 && x >= 50 && x < 910) {
            static const int button_x[5] = {50, 224, 398, 572, 746};
            int index = -1;
            for (int i = 0; i < 5; i++) {
                if (x >= button_x[i] && x < button_x[i] + 164) {
                    index = i;
                    break;
                }
            }
            if (index >= 0) {
                if (!has_study_card()) return;
                if (index == 0) {
                if (review_control_mode && show_answer) rate_card(selected_rating);
                else set_study_answer_side(!show_answer);
                }
                else if (show_answer) rate_card(index - 1);
            }
        } else if (inside((UiRect){48, 104, 864, 334}, x, y) && has_study_card()) {
            set_study_answer_side(!show_answer);
        }
    } else if (current_screen == SCREEN_BROWSER) {
        if (inside((UiRect){50, 458, 180, 52}, x, y)) move_browser(-1);
        else if (inside(browser_jump_button, x, y)) open_jump_dialog();
        else if (inside((UiRect){440, 458, 310, 52}, x, y)) {
                browser_show_answer = !browser_show_answer;
                browser_scroll_position = 0.0f;
        }
        else if (inside((UiRect){760, 458, 150, 52}, x, y)) move_browser(1);
        else if (inside((UiRect){48, 104, 864, 334}, x, y) && card_count > 0) {
            browser_show_answer = !browser_show_answer;
            browser_scroll_position = 0.0f;
        }
    } else if (current_screen == SCREEN_DECKS || current_screen == SCREEN_IMPORT) {
        if (x >= 60 && x < 900 && y >= LIST_ROW_Y && y < LIST_ROW_Y + LIST_ROW_H * LIST_VISIBLE) {
            int row = (y - LIST_ROW_Y) / LIST_ROW_H;
            int index = first_visible_deck() + row;
            if (index >= 0 && index < deck_count) {
                list_selection = index;
                list_focus_actions = 0;
                if (current_screen == SCREEN_IMPORT) {
                    import_error = 0;
                    import_error_code = 0;
                } else {
                    deck_status[0] = '\0';
                }
            }
        } else {
            for (int action = 0; action < list_action_count(current_screen == SCREEN_IMPORT); action++) {
                if (inside(list_action_rect(current_screen == SCREEN_IMPORT, action), x, y)) {
                    list_focus_actions = 1;
                    list_action_selection = action;
                    activate_deck_list_action(current_screen == SCREEN_IMPORT, action);
                    return;
                }
            }
        }
    } else if (current_screen == SCREEN_SETTINGS) {
        for (int setting = 0; setting < SETTINGS_COUNT; setting++) {
            if (inside(settings_rows[setting], x, y)) {
                settings_selection = setting;
                int direction = 1;
                if (x >= settings_rows[setting].x + 728 && x < settings_rows[setting].x + 774)
                    direction = -1;
                cycle_setting(setting, direction);
                break;
            }
        }
    } else if (current_screen == SCREEN_DECK_SETTINGS) {
        for (int setting = 0; setting < 5; setting++) {
            UiRect row = {60, 112 + setting * 62, 840, 50};
            if (inside(row, x, y)) {
                deck_settings_selection = setting;
                if (x >= 776) change_deck_setting(setting, 1);
                else if (x >= 700) change_deck_setting(setting, -1);
                break;
            }
        }
    }
}

static int poll_touch(int *x, int *y) {
    SceTouchData data;
    memset(&data, 0, sizeof(data));
    if (sceTouchPeek(SCE_TOUCH_PORT_FRONT, &data, 1) < 0 || data.reportNum == 0) {
        touch_was_down = 0;
        return 0;
    }

    if (touch_was_down) return 0;
    touch_was_down = 1;
    int raw_x = data.report[0].x;
    int raw_y = data.report[0].y;
    *x = (raw_x - touch_min_x) * SCREEN_W / touch_width;
    *y = (raw_y - touch_min_y) * SCREEN_H / touch_height;
    if (*x < 0) *x = 0;
    if (*x >= SCREEN_W) *x = SCREEN_W - 1;
    if (*y < 0) *y = 0;
    if (*y >= SCREEN_H) *y = SCREEN_H - 1;
    return 1;
}

int main(void) {
    SceCtrlData pad;
    SceTouchPanelInfo touch_info;
    unsigned int previous_buttons = 0;
    AppScreen previous_screen = SCREEN_HOME;

    mkdir("ux0:data/VitaAnki", 0777);
    mkdir(DECK_FOLDER, 0777);
    copy_file_if_missing(BUNDLED_DECK_PATH, INCLUDED_DECK_PATH);
    copy_file_if_missing(BUNDLED_PICTURE_DECK_PATH, INCLUDED_PICTURE_DECK_PATH);
    copy_file_if_missing("app0:/sync.example.ini", "ux0:data/VitaAnki/sync.example.ini");
    load_settings();
#ifndef VITAANKI_DISABLE_MUSIC
    if (!music_setting_migration) {
        music_muted = 0;
        music_setting_migration = 1;
        save_settings();
    }
#endif
    sceSysmoduleLoadModule(SCE_SYSMODULE_SQLITE);
    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);
    sceTouchSetSamplingState(SCE_TOUCH_PORT_FRONT, SCE_TOUCH_SAMPLING_STATE_START);
    memset(&touch_info, 0, sizeof(touch_info));
    if (sceTouchGetPanelInfo(SCE_TOUCH_PORT_FRONT, &touch_info) >= 0) {
        int width = touch_info.maxDispX - touch_info.minDispX + 1;
        int height = touch_info.maxDispY - touch_info.minDispY + 1;
        if (width > 0) {
            touch_min_x = touch_info.minDispX;
            touch_width = width;
        }
        if (height > 0) {
            touch_min_y = touch_info.minDispY;
            touch_height = height;
        }
    }

    anki_connect_prepare();
    scan_decks();
    load_saved_deck_path();
    int index = find_saved_deck();
    if (index >= 0) {
        if (!select_deck(index)) load_demo_deck();
    } else {
        load_demo_deck();
    }

    vita2d_init();
    vita2d_set_clear_color(BG);
    font_pgf = vita2d_load_default_pgf();
    if (!font_pgf) {
        anki_music_stop();
        vita2d_fini();
        sceKernelExitProcess(1);
        return 1;
    }
    if (!font_mode_available(font_mode)) {
        font_mode = 0;
        save_settings();
    }
    app_icon = vita2d_load_PNG_file("app0:sce_sys/icon0.png");
    anki_music_set_muted(music_muted);
    current_screen = SCREEN_HOME;

    for (;;) {
        sceCtrlPeekBufferPositive(0, &pad, 1);
        if (current_screen != previous_screen) {
            header_focus_active = 0;
            previous_screen = current_screen;
        }
        unsigned int analog_pressed = 0;
        if ((!create_ime_open && current_screen != SCREEN_STUDY &&
             current_screen != SCREEN_BROWSER) || jump_dialog_open ||
            delete_dialog_open || create_cancel_dialog_open)
            analog_pressed = analog_navigation_pulse(&pad);
        unsigned int pressed = (pad.buttons & ~previous_buttons) | analog_pressed;
        previous_buttons = pad.buttons;
        refresh_clock_warning();

        if (!create_ime_open && (pressed & ~((unsigned int)SCE_CTRL_START))) {
            if (click_sounds_enabled) anki_music_play_click();
        }
        if ((pressed & SCE_CTRL_START) && !create_ime_open) break;
        if (create_ime_open) {
            update_create_ime();
        } else {
        if (pressed & SCE_CTRL_SELECT) toggle_music();

        if (jump_dialog_open) {
            if (pressed & SCE_CTRL_CIRCLE) jump_dialog_open = 0;
            else if (pressed & SCE_CTRL_CROSS) activate_jump_selection();
            else move_jump_selection(pressed);
        } else if (delete_dialog_open) {
            if (pressed & SCE_CTRL_CIRCLE) {
                delete_dialog_open = 0;
                delete_error = 0;
            } else if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT)) {
                delete_selection = delete_selection == 0 ? 1 : 0;
            } else if (pressed & SCE_CTRL_CROSS) {
                advance_delete_confirmation();
            }
        } else if (create_cancel_dialog_open) {
            if (pressed & SCE_CTRL_CIRCLE) create_cancel_dialog_open = 0;
            else if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))
                create_selection = create_selection == 0 ? 1 : 0;
            else if (pressed & SCE_CTRL_CROSS) activate_create_selection();
        } else if (header_focus_active) {
            if (pressed & SCE_CTRL_CROSS) {
                if (header_focus_active == 2) toggle_music();
                else activate_header_back();
            } else if (pressed & SCE_CTRL_CIRCLE) activate_header_back();
            else if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT)) {
                if (current_screen == SCREEN_HOME) header_focus_active = 2;
                else header_focus_active = header_focus_active == 1 ? 2 : 1;
            }
            else if (pressed & SCE_CTRL_DOWN) header_focus_active = 0;
        } else if (current_screen == SCREEN_HOME) {
            move_home_selection(pressed);
            if (pressed & SCE_CTRL_CROSS) activate_home_selection();
        } else if (current_screen == SCREEN_STUDY) {
            if (pressed & SCE_CTRL_LTRIGGER) undo_last_rating();
            else if ((pressed & SCE_CTRL_CROSS) && has_study_card()) {
                if (!show_answer) {
                    set_study_answer_side(1);
                } else if (review_control_mode) {
                    rate_card(selected_rating);
                } else {
                    set_study_answer_side(0);
                }
            }
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_TRIANGLE)) rate_card(0);
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_SQUARE)) rate_card(1);
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_CIRCLE)) rate_card(2);
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_RTRIGGER)) rate_card(3);
            else if ((pressed & SCE_CTRL_CIRCLE) && !show_answer) current_screen = SCREEN_HOME;
            else if (pressed & SCE_CTRL_UP) {
                if (card_scroll_position <= 0.0f) header_focus_active = 1;
                else scroll_visible_card(-1);
            }
            else if (pressed & SCE_CTRL_DOWN) scroll_visible_card(1);
        } else if (current_screen == SCREEN_BROWSER) {
            if (pressed & SCE_CTRL_CROSS) {
                if (browser_stick_mode == BROWSER_STICK_BUTTONS)
                    activate_browser_button();
                else {
                    browser_show_answer = !browser_show_answer;
                    browser_scroll_position = 0.0f;
                }
            }
            else if (pressed & SCE_CTRL_TRIANGLE) open_jump_dialog();
            else if (pressed & SCE_CTRL_LEFT) move_browser(-1);
            else if (pressed & SCE_CTRL_RIGHT) move_browser(1);
            else if (pressed & SCE_CTRL_UP) {
                if (browser_scroll_position <= 0.0f) header_focus_active = 1;
                else scroll_visible_card(-1);
            }
            else if (pressed & SCE_CTRL_DOWN) scroll_visible_card(1);
            else if (pressed & SCE_CTRL_CIRCLE) current_screen = SCREEN_HOME;
        } else if (current_screen == SCREEN_DECKS || current_screen == SCREEN_IMPORT) {
            int importing = current_screen == SCREEN_IMPORT;
            if ((pressed & SCE_CTRL_LEFT) && !list_focus_actions) {
                list_focus_actions = 1;
                list_action_selection = list_action_count(importing) - 1;
            } else if ((pressed & SCE_CTRL_RIGHT) && !list_focus_actions) {
                list_focus_actions = 1;
                list_action_selection = 0;
            } else if (list_focus_actions && (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))) {
                int count = list_action_count(importing);
                list_action_selection = (list_action_selection +
                    ((pressed & SCE_CTRL_RIGHT) ? 1 : count - 1)) % count;
            } else if (list_focus_actions && (pressed & SCE_CTRL_UP)) {
                list_focus_actions = 0;
            } else if (pressed & SCE_CTRL_UP) {
                if (list_selection > 0) list_selection--;
                else header_focus_active = 1;
            } else if (pressed & SCE_CTRL_DOWN) {
                if (list_focus_actions) {
                    list_focus_actions = 0;
                } else if (list_selection + 1 < deck_count) list_selection++;
                else {
                    list_focus_actions = 1;
                    list_action_selection = 0;
                }
            } else if (pressed & SCE_CTRL_TRIANGLE) {
                rescan_deck_list();
            } else if (pressed & SCE_CTRL_CROSS) {
                if (list_focus_actions) activate_deck_list_action(importing, list_action_selection);
                else if (deck_count > 0) select_deck(list_selection);
            } else if (pressed & SCE_CTRL_SQUARE) {
                if (importing) {
                    open_create_deck();
                } else start_delete_dialog();
            } else if (pressed & SCE_CTRL_CIRCLE) {
                current_screen = SCREEN_HOME;
            }
        } else if (current_screen == SCREEN_CREATE_DECK) {
            if (pressed & SCE_CTRL_UP) {
                if (create_selection == 0) header_focus_active = 1;
                else create_selection = (create_selection + 5) % 6;
            }
            else if (pressed & SCE_CTRL_DOWN)
                create_selection = (create_selection + 1) % 6;
            else if (pressed & SCE_CTRL_CROSS)
                activate_create_selection();
            else if (pressed & SCE_CTRL_CIRCLE)
                request_cancel_create();
        } else if (current_screen == SCREEN_SETTINGS) {
            if (pressed & SCE_CTRL_UP) {
                if (settings_selection == 0) header_focus_active = 1;
                else settings_selection = (settings_selection + SETTINGS_COUNT - 1) % SETTINGS_COUNT;
            }
            else if (pressed & SCE_CTRL_DOWN)
                settings_selection = (settings_selection + 1) % SETTINGS_COUNT;
            else if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT | SCE_CTRL_CROSS))
                cycle_setting(settings_selection, (pressed & SCE_CTRL_LEFT) ? -1 : 1);
            else if (pressed & SCE_CTRL_CIRCLE) current_screen = SCREEN_HOME;
        } else if (current_screen == SCREEN_SYNC) {
            if (pressed & SCE_CTRL_UP) header_focus_active = 1;
            else if (pressed & SCE_CTRL_LEFT) sync_selection = 0;
            else if (pressed & SCE_CTRL_RIGHT) sync_selection = 1;
            else if (pressed & SCE_CTRL_CROSS) activate_sync_selection();
            else if (pressed & SCE_CTRL_CIRCLE) current_screen = SCREEN_HOME;
        } else if (current_screen == SCREEN_ANDROID_TRANSFER) {
            if (pressed & SCE_CTRL_UP) header_focus_active = 1;
            else if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))
                transfer_selection = transfer_selection == 0 ? 1 : 0;
            else if (pressed & SCE_CTRL_CROSS) {
                if (transfer_selection == 0) toggle_android_transfer_receiver();
                else {
                    android_transfer_stop();
                    scan_decks();
                    list_selection = current_deck_index >= 0 ? current_deck_index : 0;
                    list_focus_actions = 0;
                    current_screen = SCREEN_DECKS;
                }
            }
            else if (pressed & SCE_CTRL_CIRCLE) {
                android_transfer_stop();
                current_screen = SCREEN_HOME;
            } else if (pressed & SCE_CTRL_DOWN) {
                android_transfer_stop();
                scan_decks();
                list_selection = current_deck_index >= 0 ? current_deck_index : 0;
                list_focus_actions = 0;
                current_screen = SCREEN_DECKS;
            }
        } else if (current_screen == SCREEN_DECK_SETTINGS) {
            if (pressed & SCE_CTRL_UP) {
                if (deck_settings_selection == 0) header_focus_active = 1;
                else deck_settings_selection = (deck_settings_selection + 4) % 5;
            }
            else if (pressed & SCE_CTRL_DOWN)
                deck_settings_selection = (deck_settings_selection + 1) % 5;
            else if (pressed & SCE_CTRL_LEFT)
                change_deck_setting(deck_settings_selection, -1);
            else if (pressed & SCE_CTRL_RIGHT)
                change_deck_setting(deck_settings_selection, 1);
            else if (pressed & SCE_CTRL_CROSS)
                change_deck_setting(deck_settings_selection, 1);
            else if (pressed & SCE_CTRL_CIRCLE)
                current_screen = SCREEN_DECKS;
        }
        }

        if (current_screen == SCREEN_STUDY && live_sync && card_count == 0 &&
            anki_connect_has_learning_cards()) {
            time_t now = time(NULL);
            if (live_refresh_after == 0 || now >= live_refresh_after) {
                live_refresh_after = now + LIVE_REFRESH_SECONDS;
                int refreshed = anki_connect_reload(cards, card_capacity);
                if (refreshed < 0) {
                    sync_error = 1;
                } else {
                    sync_error = 0;
                    card_count = refreshed;
                    if (card_count > 0) {
                        card_index = 0;
                        show_answer = 0;
                        flip_frames_remaining = 0;
                        card_scroll_position = 0.0f;
                        selected_rating = 2;
                    }
                }
            }
        } else if (card_count > 0 || !live_sync) {
            live_refresh_after = 0;
        }

        if (current_screen == SCREEN_STUDY && !live_sync && card_count > 0 && !has_study_card()) {
            if (++study_idle_frames >= 30) {
                study_idle_frames = 0;
                int next_due = find_next_due();
                if (next_due >= 0) {
                    card_index = next_due;
                    show_answer = 0;
                    card_scroll_position = 0.0f;
                    selected_rating = 2;
                }
            }
        } else {
            study_idle_frames = 0;
        }

        if (!jump_dialog_open) update_analog_input(&pad);
        update_confetti();
        int touch_x, touch_y;
        if (poll_touch(&touch_x, &touch_y)) handle_touch(touch_x, touch_y);
        draw_ui();
        advance_study_flip();
        sceKernelDelayThread(16000);
    }

    android_transfer_stop();
    if (create_ime_open) {
        sceImeDialogAbort();
        sceImeDialogTerm();
    }
    if (ime_module_loaded) sceSysmoduleUnloadModule(SCE_SYSMODULE_IME);
    if (apputil_initialized) sceAppUtilShutdown();
    anki_music_stop();
    anki_music_click_shutdown();
    if (app_icon) vita2d_free_texture(app_icon);
    if (card_image_texture) vita2d_free_texture(card_image_texture);
    release_custom_fonts();
    if (font_pgf) vita2d_free_pgf(font_pgf);
    vita2d_fini();
    anki_connect_stop();
    sceKernelExitProcess(0);
    return 0;
}
