#ifndef VITAANKI_H
#define VITAANKI_H

#define MAX_CARDS 2000
#define FIELD_SIZE 1024

typedef enum {
    CARD_STATE_NEW = 0,
    CARD_STATE_LEARNING = 1,
    CARD_STATE_REVIEW = 2
} CardState;

typedef struct {
    char front[FIELD_SIZE];
    char back[FIELD_SIZE];
    char front_image[FIELD_SIZE];
    long long card_id;
    int interval_days;
    long long due;
    CardState state;
} Card;

int vitaanki_reserve_cards(Card **cards, int *allocated_capacity, int required);
int import_apkg(const char *package_path, Card **cards, int *allocated_capacity,
                int max_cards);
const char *import_apkg_diagnostic(void);

#endif
