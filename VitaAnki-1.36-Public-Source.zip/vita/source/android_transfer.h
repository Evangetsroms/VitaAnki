#ifndef VITAANKI_ANDROID_TRANSFER_H
#define VITAANKI_ANDROID_TRANSFER_H

typedef enum {
    ANDROID_TRANSFER_IDLE = 0,
    ANDROID_TRANSFER_STARTING,
    ANDROID_TRANSFER_WAITING,
    ANDROID_TRANSFER_RECEIVING,
    ANDROID_TRANSFER_LISTING,
    ANDROID_TRANSFER_SENDING,
    ANDROID_TRANSFER_RECEIVED,
    ANDROID_TRANSFER_ERROR,
    ANDROID_TRANSFER_STOPPED
} AndroidTransferState;

int android_transfer_start(void);
void android_transfer_stop(void);
AndroidTransferState android_transfer_get_state(void);
const char *android_transfer_get_pin(void);
const char *android_transfer_get_filename(void);
const char *android_transfer_get_message(void);
int android_transfer_get_progress(void);

#endif
