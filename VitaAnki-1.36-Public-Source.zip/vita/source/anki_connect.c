#include "anki_connect.h"

#include <curl/curl.h>
#include <jansson.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdint.h>
#include <psp2/io/fcntl.h>
#include <psp2/net/net.h>
#include <psp2/net/netctl.h>
#include <psp2/sysmodule.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CONFIG_PATH "ux0:data/VitaAnki/sync.ini"
#define PENDING_PATH "ux0:data/VitaAnki/pending.tsv"
#define PENDING_TEMP_PATH "ux0:data/VitaAnki/pending.tmp"
#define PENDING_BACKUP_PATH "ux0:data/VitaAnki/pending.bak"
#define SYNC_LOG_PATH "ux0:data/VitaAnki/sync.log"
#define RESPONSE_LIMIT (2 * 1024 * 1024)
#define CARDS_INFO_BATCH_SIZE 20
#define LIVE_CARD_CACHE_LIMIT 512

static char host[80];
static char deck_name[160];
static char api_key[160];
static char endpoint[128];
static char connect_status[128] = "Sync setup required";
static int configured = 0;
static int network_started = 0;
static int network_control_started = 0;
static int network_module_loaded = 0;
static int curl_started = 0;
static int pending_queue_blocked = 0;
static int study_counts_valid = 0;
static int learning_cards_pending = 0;
static AnkiStudyCounts study_counts = {0, 0, 0};
static Card *live_card_cache = NULL;
static int live_card_cache_capacity = 0;
static int live_card_cache_count = 0;
static Card *live_card_cache_owner = NULL;
static long long last_answered_card_id = 0;
static unsigned char network_memory[1024 * 1024] __attribute__((aligned(4096)));

static void flush_pending_reviews(void);

static void clear_live_card_cache(void) {
    free(live_card_cache);
    live_card_cache = NULL;
    live_card_cache_capacity = 0;
    live_card_cache_count = 0;
    live_card_cache_owner = NULL;
    last_answered_card_id = 0;
}

static void set_connect_status(const char *message) {
    snprintf(connect_status, sizeof(connect_status), "%s", message);
}

/* Use Vita's file API so diagnostics do not allocate from the C heap. */
static void sync_log(const char *message) {
    char line[320];
    int length = snprintf(line, sizeof(line), "%s\n", message ? message : "sync: (empty)");
    if (length <= 0) return;
    if (length >= (int)sizeof(line)) length = (int)sizeof(line) - 1;
    SceUID file = sceIoOpen(SYNC_LOG_PATH, SCE_O_WRONLY | SCE_O_CREAT | SCE_O_APPEND, 0777);
    if (file >= 0) {
        sceIoWrite(file, line, (SceSize)length);
        sceIoClose(file);
    }
}

static void redact_api_key(const char *input, char *output, size_t capacity) {
    size_t out = 0;
    size_t key_length = strlen(api_key);
    if (!input || capacity == 0) return;
    for (size_t i = 0; input[i] && out + 1 < capacity;) {
        if (key_length > 0 && !strncmp(input + i, api_key, key_length)) {
            static const char redacted[] = "[redacted]";
            size_t replacement = sizeof(redacted) - 1;
            if (out + replacement >= capacity) break;
            memcpy(output + out, redacted, replacement);
            out += replacement;
            i += key_length;
        } else {
            char character = input[i++];
            output[out++] = (character == '\r' || character == '\n') ? ' ' : character;
        }
    }
    output[out] = '\0';
}

static int file_exists(const char *path) {
    FILE *file = fopen(path, "rb");
    if (!file) return 0;
    fclose(file);
    return 1;
}

static void recover_pending_queue(void) {
    int has_queue = file_exists(PENDING_PATH);
    int has_temporary = file_exists(PENDING_TEMP_PATH);
    int has_backup = file_exists(PENDING_BACKUP_PATH);
    if (has_queue) {
        if (has_temporary) remove(PENDING_TEMP_PATH);
        if (has_backup) remove(PENDING_BACKUP_PATH);
        return;
    }
    if (has_backup && has_temporary && rename(PENDING_TEMP_PATH, PENDING_PATH) == 0) {
        remove(PENDING_BACKUP_PATH);
        return;
    }
    if (has_backup && rename(PENDING_BACKUP_PATH, PENDING_PATH) == 0) {
        if (has_temporary) remove(PENDING_TEMP_PATH);
        return;
    }
    if (has_temporary) remove(PENDING_TEMP_PATH);
}

static int commit_pending_queue(void) {
    int has_queue = file_exists(PENDING_PATH);
    remove(PENDING_BACKUP_PATH);
    if (has_queue && rename(PENDING_PATH, PENDING_BACKUP_PATH) != 0) return 0;
    if (rename(PENDING_TEMP_PATH, PENDING_PATH) != 0) {
        if (has_queue) rename(PENDING_BACKUP_PATH, PENDING_PATH);
        return 0;
    }
    if (has_queue) remove(PENDING_BACKUP_PATH);
    return 1;
}

static int parse_pending_line(const char *line, long long *card_id, int *ease) {
    errno = 0;
    char *end = NULL;
    long long parsed_id = strtoll(line, &end, 10);
    if (errno == ERANGE || end == line || *end != '\t' || parsed_id <= 0) return 0;
    errno = 0;
    char *ease_end = NULL;
    long parsed_ease = strtol(end + 1, &ease_end, 10);
    if (errno == ERANGE || ease_end == end + 1 || parsed_ease < 1 || parsed_ease > 4) return 0;
    while (*ease_end == '\r' || *ease_end == '\n') ease_end++;
    if (*ease_end != '\0') return 0;
    *card_id = parsed_id;
    *ease = (int)parsed_ease;
    return 1;
}

static int is_truncated_line(const char *line, size_t capacity, FILE *file) {
    return strlen(line) == capacity - 1 && !strchr(line, '\n') && !feof(file);
}

static int fail_network_start(const char *message) {
    anki_connect_stop();
    set_connect_status(message);
    return -1;
}

typedef struct {
    char *data;
    size_t size;
} ResponseBuffer;

static size_t receive_data(char *incoming, size_t size, size_t count, void *userdata) {
    ResponseBuffer *buffer = (ResponseBuffer *)userdata;
    if (size && count > SIZE_MAX / size) return 0;
    size_t incoming_size = size * count;
    if (buffer->size > RESPONSE_LIMIT || incoming_size > RESPONSE_LIMIT - buffer->size) return 0;
    char *expanded = realloc(buffer->data, buffer->size + incoming_size + 1);
    if (!expanded) return 0;
    buffer->data = expanded;
    memcpy(buffer->data + buffer->size, incoming, incoming_size);
    buffer->size += incoming_size;
    buffer->data[buffer->size] = '\0';
    return incoming_size;
}

static void load_config(void) {
    host[0] = '\0';
    deck_name[0] = '\0';
    api_key[0] = '\0';
    endpoint[0] = '\0';
    configured = 0;
    FILE *file = fopen(CONFIG_PATH, "r");
    if (!file) {
        snprintf(connect_status, sizeof(connect_status),
                 "Sync setup: create sync.ini from sync.example.ini");
        return;
    }
    char buffer[256];
    while (fgets(buffer, sizeof(buffer), file)) {
        char *line = buffer;
        char *end = strpbrk(line, "\r\n");
        if (end) *end = '\0';
        char *start = line;
        while (isspace((unsigned char)*start)) start++;
        if (*start == '#' || *start == ';' || *start == '\0') continue;
        line = start;
        char *equals = strchr(line, '=');
        if (!equals) continue;
        char *key_end = equals;
        while (key_end > line && isspace((unsigned char)key_end[-1])) *--key_end = '\0';
        *equals++ = '\0';
        while (isspace((unsigned char)*equals)) equals++;
        char *value_end = equals + strlen(equals);
        while (value_end > equals && isspace((unsigned char)value_end[-1])) *--value_end = '\0';
        if (!strcmp(line, "host")) snprintf(host, sizeof(host), "%s", equals);
        else if (!strcmp(line, "deck")) snprintf(deck_name, sizeof(deck_name), "%s", equals);
        else if (!strcmp(line, "key")) snprintf(api_key, sizeof(api_key), "%s", equals);
    }
    fclose(file);
    if (host[0] && deck_name[0] && api_key[0] &&
        strcmp(api_key, "replace-with-your-AnkiConnect-api-key") &&
        !strstr(host, "://") && !strchr(host, '/') && !strchr(host, ' ')) {
        snprintf(endpoint, sizeof(endpoint), "http://%s:8765", host);
        configured = 1;
        snprintf(connect_status, sizeof(connect_status), "PC sync ready; connect when you choose");
    } else {
        snprintf(connect_status, sizeof(connect_status),
                 "Sync setup: fill host, deck, and key in sync.ini");
    }
}

void anki_connect_prepare(void) {
    load_config();
}

static json_t *invoke(const char *action, json_t *params) {
    if (!configured) return NULL;
    json_t *request = json_object();
    json_object_set_new(request, "action", json_string(action));
    json_object_set_new(request, "version", json_integer(6));
    json_object_set_new(request, "key", json_string(api_key));
    if (params) json_object_set(request, "params", params);

    char *payload = json_dumps(request, JSON_COMPACT);
    json_decref(request);
    if (!payload) {
        set_connect_status("Could not build AnkiConnect request");
        return NULL;
    }

    char log_message[320];
    snprintf(log_message, sizeof(log_message), "sync: request action=%s bytes=%lu",
             action, (unsigned long)strlen(payload));
    sync_log(log_message);

    ResponseBuffer response = {0};
    CURL *curl = curl_easy_init();
    if (!curl) {
        free(payload);
        set_connect_status("Could not start AnkiConnect request");
        return NULL;
    }
    struct curl_slist *headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    curl_easy_setopt(curl, CURLOPT_URL, endpoint);
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, payload);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, (long)strlen(payload));
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_data);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 4L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 3L);
    CURLcode result = curl_easy_perform(curl);
    long http_status = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_status);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    free(payload);

    snprintf(log_message, sizeof(log_message),
             "sync: response action=%s curl=%d http=%ld bytes=%lu",
             action, (int)result, http_status, (unsigned long)response.size);
    sync_log(log_message);

    if (result != CURLE_OK || !response.data) {
        free(response.data);
        snprintf(log_message, sizeof(log_message), "sync: request failed action=%s curl=%d",
                 action, (int)result);
        sync_log(log_message);
        set_connect_status("AnkiConnect unreachable; check PC and Wi-Fi");
        return NULL;
    }
    json_error_t error;
    json_t *root = json_loads(response.data, 0, &error);
    free(response.data);
    if (!root) {
        snprintf(log_message, sizeof(log_message),
                 "sync: JSON parse failed action=%s line=%d column=%d position=%d",
                 action, error.line, error.column, error.position);
        sync_log(log_message);
        set_connect_status("Invalid response; see VitaAnki sync.log");
        return NULL;
    }
    const char *server_error = json_string_value(json_object_get(root, "error"));
    if (server_error) {
        char safe_error[192];
        redact_api_key(server_error, safe_error, sizeof(safe_error));
        snprintf(log_message, sizeof(log_message), "sync: AnkiConnect error action=%s: %s",
                 action, safe_error);
        sync_log(log_message);
        snprintf(log_message, sizeof(log_message), "AnkiConnect: %.105s", safe_error);
        json_decref(root);
        set_connect_status(log_message);
        return NULL;
    }
    json_t *value = json_object_get(root, "result");
    if (value) json_incref(value);
    json_decref(root);
    if (value) {
        snprintf(log_message, sizeof(log_message), "sync: parsed action=%s successfully", action);
        sync_log(log_message);
        set_connect_status("Connected to Anki Desktop");
    } else {
        snprintf(log_message, sizeof(log_message), "sync: response missing result action=%s", action);
        sync_log(log_message);
        set_connect_status("AnkiConnect response missing result");
    }
    return value;
}

static int html_tag_matches(const char *text, size_t offset, const char *name,
                            int closing) {
    if (text[offset] != '<') return 0;
    size_t i = offset + 1;
    if (closing) {
        if (text[i] != '/') return 0;
        i++;
    } else if (text[i] == '/') {
        return 0;
    }
    while (isspace((unsigned char)text[i])) i++;
    for (size_t n = 0; name[n]; n++, i++)
        if (tolower((unsigned char)text[i]) != name[n]) return 0;
    return text[i] == '>' || text[i] == '/' || isspace((unsigned char)text[i]);
}

static size_t skip_html_tag(const char *text, size_t offset) {
    while (text[offset] && text[offset] != '>') offset++;
    return text[offset] ? offset + 1 : offset;
}

static int html_text_matches(const char *text, size_t offset, const char *token) {
    for (size_t i = 0; token[i]; i++)
        if (text[offset + i] != token[i]) return 0;
    return 1;
}

static void append_plain_space(char *output, size_t *used, size_t capacity) {
    if (*used > 0 && output[*used - 1] != ' ' && *used + 1 < capacity)
        output[(*used)++] = ' ';
}

static void strip_html(char *text) {
    char output[FIELD_SIZE];
    size_t out = 0;
    size_t i = 0;
    while (text[i] && out + 1 < sizeof(output)) {
        if (text[i] == '<') {
            if (html_tag_matches(text, i, "style", 0) ||
                html_tag_matches(text, i, "script", 0)) {
                const char *suppressed_tag = html_tag_matches(text, i, "style", 0)
                                           ? "style" : "script";
                i = skip_html_tag(text, i);
                while (text[i] && !html_tag_matches(text, i, suppressed_tag, 1)) i++;
                if (text[i]) i = skip_html_tag(text, i);
                append_plain_space(output, &out, sizeof(output));
                continue;
            }

            int is_separator = html_tag_matches(text, i, "br", 0) ||
                               html_tag_matches(text, i, "hr", 0) ||
                               html_tag_matches(text, i, "p", 0) ||
                               html_tag_matches(text, i, "p", 1) ||
                               html_tag_matches(text, i, "div", 0) ||
                               html_tag_matches(text, i, "div", 1) ||
                               html_tag_matches(text, i, "li", 0) ||
                               html_tag_matches(text, i, "li", 1) ||
                               html_tag_matches(text, i, "tr", 1);
            i = skip_html_tag(text, i);
            if (is_separator) append_plain_space(output, &out, sizeof(output));
            continue;
        }
        if (html_text_matches(text, i, "&nbsp;")) { output[out++] = ' '; i += 6; }
        else if (html_text_matches(text, i, "&amp;")) { output[out++] = '&'; i += 5; }
        else if (html_text_matches(text, i, "&lt;")) { output[out++] = '<'; i += 4; }
        else if (html_text_matches(text, i, "&gt;")) { output[out++] = '>'; i += 4; }
        else if (html_text_matches(text, i, "&quot;")) { output[out++] = '"'; i += 6; }
        else if (html_text_matches(text, i, "&#39;")) { output[out++] = '\''; i += 5; }
        else output[out++] = text[i++];
    }
    while (out > 0 && output[out - 1] == ' ') out--;
    output[out] = '\0';
    snprintf(text, FIELD_SIZE, "%s", output);
}

static void remove_front_side_prefix(const char *question, char *answer) {
    const char *q = question;
    const char *a = answer;
    while (isspace((unsigned char)*q)) q++;
    while (isspace((unsigned char)*a)) a++;
    if (!*q) return;
    const char *answer_remainder = a;

    while (*q) {
        while (isspace((unsigned char)*q)) q++;
        while (isspace((unsigned char)*a)) a++;
        if (!*q) break;
        if (!*a || tolower((unsigned char)*q) != tolower((unsigned char)*a)) return;
        q++;
        a++;
    }

    while (isspace((unsigned char)*a)) a++;
    if (a == answer_remainder) return;
    memmove(answer, a, strlen(a) + 1);
}

static json_t *find_cards_query(const char *search) {
    char query[256];
    char safe_deck[160];
    size_t used = 0;
    for (size_t i = 0; deck_name[i] && used + 2 < sizeof(safe_deck); i++) {
        if (deck_name[i] == '"' || deck_name[i] == '\\') safe_deck[used++] = '\\';
        safe_deck[used++] = deck_name[i];
    }
    safe_deck[used] = '\0';
    snprintf(query, sizeof(query), "deck:\"%s\" %s", safe_deck, search);
    json_t *params = json_pack("{s:s}", "query", query);
    json_t *result = invoke("findCards", params);
    json_decref(params);
    return result;
}

static json_t *find_cards_for(const char *state) {
    char search[128];
    snprintf(search, sizeof(search), "is:%s", state);
    return find_cards_query(search);
}

static int read_count(json_t *object, const char *key, int *count) {
    json_t *value = json_object_get(object, key);
    if (!json_is_integer(value)) return 0;
    json_int_t number = json_integer_value(value);
    if (number < 0) return 0;
    *count = number > INT_MAX ? INT_MAX : (int)number;
    return 1;
}

static int count_cards_for(const char *state, int *count) {
    json_t *result = find_cards_for(state);
    if (!json_is_array(result)) {
        if (result) json_decref(result);
        return 0;
    }
    size_t size = json_array_size(result);
    *count = size > INT_MAX ? INT_MAX : (int)size;
    json_decref(result);
    return 1;
}

static void refresh_study_counts(void) {
    study_counts_valid = 0;

    json_t *params = json_pack("{s:[s]}", "decks", deck_name);
    json_t *result = params ? invoke("getDeckStats", params) : NULL;
    if (params) json_decref(params);

    if (json_is_object(result)) {
        json_t *deck_stats = NULL;
        const char *deck_id;
        json_t *candidate;
        json_object_foreach(result, deck_id, candidate) {
            const char *name = json_string_value(json_object_get(candidate, "name"));
            if (deck_id && name && !strcmp(name, deck_name)) {
                deck_stats = candidate;
                break;
            }
        }
        AnkiStudyCounts counts;
        if (json_is_object(deck_stats) &&
            read_count(deck_stats, "new_count", &counts.new_count) &&
            read_count(deck_stats, "learn_count", &counts.learning_count) &&
            read_count(deck_stats, "review_count", &counts.review_count)) {
            int learning_total = 0;
            if (count_cards_for("learn", &learning_total)) {
                counts.learning_count = learning_total;
                learning_cards_pending = learning_total > 0;
            } else {
                learning_cards_pending = counts.learning_count > 0;
            }
            study_counts = counts;
            study_counts_valid = 1;
            json_decref(result);
            return;
        }
    }
    if (result) json_decref(result);

    /* Older AnkiConnect builds may lack getDeckStats; use Anki's search states. */
    AnkiStudyCounts fallback;
    if (count_cards_for("new", &fallback.new_count) &&
        count_cards_for("learn", &fallback.learning_count) &&
        count_cards_for("due -is:learn", &fallback.review_count)) {
        study_counts = fallback;
        learning_cards_pending = fallback.learning_count > 0;
        study_counts_valid = 1;
        return;
    }
    set_connect_status("Connected; Anki queue counts unavailable");
}

int anki_connect_get_study_counts(AnkiStudyCounts *counts) {
    if (!counts || !study_counts_valid) return 0;
    *counts = study_counts;
    return 1;
}

int anki_connect_has_learning_cards(void) {
    return learning_cards_pending;
}

static void append_ids(json_t *destination, json_t *source, size_t capacity) {
    if (!json_is_array(source)) return;
    size_t i;
    json_t *value;
    json_array_foreach(source, i, value) {
        if (json_array_size(destination) >= capacity) break;
        int duplicate = 0;
        size_t j;
        json_t *existing;
        json_array_foreach(destination, j, existing) {
            if (json_equal(value, existing)) { duplicate = 1; break; }
        }
        if (!duplicate) json_array_append(destination, value);
    }
}

int anki_connect_reload(Card *cards, int capacity) {
    study_counts_valid = 0;
    if (!configured) return 0;
    if (!cards || capacity <= 0) {
        set_connect_status("No space available for Anki cards");
        return -1;
    }
    if (capacity > MAX_CARDS) capacity = MAX_CARDS;

    int previous_count = live_card_cache_owner == cards ? live_card_cache_count : 0;
    Card *previous_cards = previous_count > 0 ? live_card_cache : NULL;
    long long answered_id = last_answered_card_id;

    /* Use Anki's scheduler counts to respect its remaining daily limits. */
    refresh_study_counts();
    size_t due_capacity = (size_t)capacity;
    size_t new_capacity = (size_t)capacity;
    if (study_counts_valid) {
        long long due_count = (long long)study_counts.learning_count +
                              (long long)study_counts.review_count;
        if (due_count < 0) due_count = 0;
        if (due_count < (long long)due_capacity) due_capacity = (size_t)due_count;
        if (study_counts.new_count < 0) study_counts.new_count = 0;
        if (study_counts.new_count < (int)new_capacity)
            new_capacity = (size_t)study_counts.new_count;
    }

    json_t *new_ids = find_cards_for("new");
    json_t *learning_due_ids = find_cards_query("is:due is:learn");
    json_t *review_due_ids = find_cards_query("is:due -is:learn");
    if (!json_is_array(new_ids) || !json_is_array(learning_due_ids) ||
        !json_is_array(review_due_ids)) {
        if (new_ids) json_decref(new_ids);
        if (learning_due_ids) json_decref(learning_due_ids);
        if (review_due_ids) json_decref(review_due_ids);
        return -1;
    }

    json_t *ids = json_array();
    if (!ids) {
        json_decref(learning_due_ids);
        json_decref(review_due_ids);
        json_decref(new_ids);
        set_connect_status("Could not allocate Anki card list");
        return -1;
    }
    append_ids(ids, learning_due_ids, due_capacity);
    append_ids(ids, review_due_ids, due_capacity);
    size_t due_added = json_array_size(ids);
    size_t new_total_capacity = due_added + new_capacity;
    if (new_total_capacity > (size_t)capacity) new_total_capacity = (size_t)capacity;
    append_ids(ids, new_ids, new_total_capacity);
    json_decref(learning_due_ids);
    json_decref(review_due_ids);
    json_decref(new_ids);
    size_t available = json_array_size(ids);
    if (available > (size_t)capacity) available = (size_t)capacity;
    if (available == 0) {
        json_decref(ids);
        return 0;
    }

    json_t *missing_ids = json_array();
    if (!missing_ids) {
        json_decref(ids);
        set_connect_status("Could not allocate Anki card cache");
        return -1;
    }
    int missing_positions[MAX_CARDS];
    unsigned char entry_ready[MAX_CARDS];
    memset(entry_ready, 0, available);
    size_t missing_count = 0;
    for (size_t i = 0; i < available; i++) {
        json_t *id_value = json_array_get(ids, i);
        if (!json_is_integer(id_value)) continue;
        long long card_id = json_integer_value(id_value);
        int cached_index = -1;
        if (previous_cards && card_id != answered_id) {
            for (int j = 0; j < previous_count; j++) {
                if (previous_cards[j].card_id == card_id) {
                    cached_index = j;
                    break;
                }
            }
        }
        if (cached_index >= 0) {
            cards[i] = previous_cards[cached_index];
            entry_ready[i] = 1;
        } else {
            if (json_array_append(missing_ids, id_value) < 0) {
                json_decref(missing_ids);
                json_decref(ids);
                set_connect_status("Could not build Anki card cache");
                return -1;
            }
            missing_positions[missing_count++] = (int)i;
        }
    }

    for (size_t offset = 0; offset < missing_count; offset += CARDS_INFO_BATCH_SIZE) {
        json_t *selected_ids = json_array();
        size_t batch_end = offset + CARDS_INFO_BATCH_SIZE;
        if (batch_end > missing_count) batch_end = missing_count;
        for (size_t i = offset; i < batch_end; i++) {
            if (json_array_append(selected_ids, json_array_get(missing_ids, i)) < 0) {
                json_decref(selected_ids);
                json_decref(missing_ids);
                json_decref(ids);
                set_connect_status("Could not build Anki card request");
                return -1;
            }
        }
        /* Keep our local reference so it can be released below. */
        json_t *params = json_pack("{s:O}", "cards", selected_ids);
        json_decref(selected_ids);
        if (!params) {
            json_decref(missing_ids);
            json_decref(ids);
            set_connect_status("Could not allocate Anki card request");
            return -1;
        }
        char batch_log[128];
        snprintf(batch_log, sizeof(batch_log), "sync: cardsInfo offset=%lu count=%lu",
                 (unsigned long)offset, (unsigned long)(batch_end - offset));
        sync_log(batch_log);
        json_t *info = invoke("cardsInfo", params);
        json_decref(params);
        if (!json_is_array(info)) {
            if (info) json_decref(info);
            json_decref(missing_ids);
            json_decref(ids);
            return -1;
        }

        size_t i;
        size_t response_index = offset;
        json_t *entry;
        json_array_foreach(info, i, entry) {
            if (response_index >= batch_end) break;
            int destination = missing_positions[response_index++];
            const char *question = json_string_value(json_object_get(entry, "question"));
            const char *answer = json_string_value(json_object_get(entry, "answer"));
            json_t *card_id_value = json_object_get(entry, "cardId");
            if (!question || !answer || !json_is_integer(card_id_value) ||
                json_integer_value(card_id_value) <= 0) continue;
            cards[destination].card_id = json_integer_value(card_id_value);
            cards[destination].front_image[0] = '\0';
            cards[destination].interval_days = (int)json_integer_value(json_object_get(entry, "interval"));
            int queue = (int)json_integer_value(json_object_get(entry, "queue"));
            if (queue == 1 || queue == 3) cards[destination].state = CARD_STATE_LEARNING;
            else if (queue == 2) cards[destination].state = CARD_STATE_REVIEW;
            else if (queue == 0) cards[destination].state = CARD_STATE_NEW;
            else cards[destination].state = cards[destination].interval_days > 0
                                    ? CARD_STATE_REVIEW : CARD_STATE_NEW;
            cards[destination].due = 0;
            snprintf(cards[destination].front, FIELD_SIZE, "%s", question);
            snprintf(cards[destination].back, FIELD_SIZE, "%s", answer);
            strip_html(cards[destination].front);
            strip_html(cards[destination].back);
            remove_front_side_prefix(cards[destination].front, cards[destination].back);
            entry_ready[destination] = 1;
        }
        json_decref(info);
    }
    json_decref(missing_ids);

    int count = 0;
    for (size_t i = 0; i < available; i++) {
        if (!entry_ready[i]) continue;
        if ((size_t)count != i) cards[count] = cards[i];
        count++;
    }
    json_decref(ids);

    if (count > 0 && count <= LIVE_CARD_CACHE_LIMIT) {
        if (count > live_card_cache_capacity) {
            Card *resized = realloc(live_card_cache, (size_t)count * sizeof(Card));
            if (resized) {
                live_card_cache = resized;
                live_card_cache_capacity = count;
            }
        }
        if (count == 0 || live_card_cache_capacity >= count) {
            if (count > 0) memcpy(live_card_cache, cards, (size_t)count * sizeof(Card));
            live_card_cache_owner = cards;
            live_card_cache_count = count;
        } else {
            free(live_card_cache);
            live_card_cache = NULL;
            live_card_cache_capacity = 0;
            live_card_cache_owner = cards;
            live_card_cache_count = 0;
        }
    } else {
        free(live_card_cache);
        live_card_cache = NULL;
        live_card_cache_capacity = 0;
        live_card_cache_owner = cards;
        live_card_cache_count = 0;
    }
    last_answered_card_id = 0;
    return count;
}

int anki_connect_start(Card *cards, int capacity) {
    clear_live_card_cache();
    pending_queue_blocked = 0;
    load_config();
    if (!configured) return 0;
    if (!cards || capacity <= 0) return fail_network_start("No space available for Anki cards");

    int module_result = sceSysmoduleLoadModule(SCE_SYSMODULE_NET);
    if (module_result < 0) {
        set_connect_status("Vita network module could not start");
        return -1;
    }
    network_module_loaded = 1;
    SceNetInitParam params;
    params.memory = network_memory;
    params.size = sizeof(network_memory);
    params.flags = 0;
    int net_result = sceNetInit(&params);
    if (net_result < 0) {
        return fail_network_start("Vita Wi-Fi could not initialize");
    }
    network_started = 1;
    int control_result = sceNetCtlInit();
    if (control_result < 0) {
        return fail_network_start("Vita Wi-Fi control could not initialize");
    }
    network_control_started = 1;
    if (curl_global_init(CURL_GLOBAL_DEFAULT) != CURLE_OK) {
        return fail_network_start("AnkiConnect network library could not initialize");
    }
    curl_started = 1;
    int state = SCE_NETCTL_STATE_DISCONNECTED;
    if (sceNetCtlInetGetState(&state) < 0 || state != SCE_NETCTL_STATE_CONNECTED) {
        return fail_network_start("Connect Vita to Wi-Fi to sync with Anki Desktop");
    }
    set_connect_status("Contacting Anki Desktop");
    recover_pending_queue();
    flush_pending_reviews();
    int count = anki_connect_reload(cards, capacity);
    if (count >= 0 && pending_queue_blocked)
        set_connect_status("Connected; some offline reviews remain queued");
    else if (count >= 0 && !study_counts_valid)
        set_connect_status("Connected; Anki queue counts unavailable");
    else if (count >= 0) set_connect_status("Connected to Anki Desktop");
    return count;
}

int anki_connect_is_configured(void) {
    return configured;
}

const char *anki_connect_get_status(void) {
    return connect_status;
}

int anki_connect_answer(long long card_id, int ease) {
    if (!configured || ease < 1 || ease > 4) return 0;
    json_t *answer = json_pack("{s:I,s:i}", "cardId", (json_int_t)card_id, "ease", ease);
    json_t *answers = json_array();
    json_array_append_new(answers, answer);
    json_t *params = json_pack("{s:o}", "answers", answers);
    json_t *result = invoke("answerCards", params);
    json_decref(params);
    int success = json_is_array(result) && json_array_size(result) > 0 &&
                  json_is_true(json_array_get(result, 0));
    if (result) json_decref(result);
    if (success) last_answered_card_id = card_id;
    if (!success && configured)
        set_connect_status("Review not accepted; check AnkiConnect and deck");
    return success;
}

int anki_connect_undo(void) {
    if (!configured) return 0;
    json_t *result = invoke("guiUndo", NULL);
    int success = result && json_is_true(result);
    if (result) json_decref(result);
    if (success) {
        live_card_cache_count = 0;
        live_card_cache_owner = NULL;
        last_answered_card_id = 0;
    }
    if (!success) set_connect_status("AnkiConnect could not undo its latest action");
    return success;
}

int anki_connect_queue_review(long long card_id, int ease) {
    if (card_id <= 0 || ease < 1 || ease > 4) {
        set_connect_status("Could not queue offline review");
        return 0;
    }
    FILE *file = fopen(PENDING_PATH, "a");
    if (!file) {
        set_connect_status("Could not save offline review to Vita storage");
        return 0;
    }
    int result = fprintf(file, "%lld\t%d\n", card_id, ease) > 0;
    if (fclose(file) != 0) result = 0;
    if (result) set_connect_status("Offline review saved for next AnkiConnect sync");
    else set_connect_status("Could not save offline review to Vita storage");
    return result;
}

int anki_connect_cancel_queued_review(long long card_id, int ease) {
    recover_pending_queue();
    FILE *input = fopen(PENDING_PATH, "r");
    if (!input) {
        set_connect_status("Could not find the queued review to undo");
        return 0;
    }

    char line[128];
    int matching_rows = 0;
    long long queued_id;
    int queued_ease;
    int valid_queue = 1;
    while (fgets(line, sizeof(line), input)) {
        if (is_truncated_line(line, sizeof(line), input) ||
            !parse_pending_line(line, &queued_id, &queued_ease)) {
            valid_queue = 0;
            break;
        }
        if (queued_id == card_id && queued_ease == ease)
            matching_rows++;
    }
    if (ferror(input)) valid_queue = 0;
    if (!valid_queue) {
        fclose(input);
        set_connect_status("Pending review queue is damaged; kept it for recovery");
        return 0;
    }
    if (matching_rows == 0) {
        fclose(input);
        set_connect_status("Could not find the queued review to undo");
        return 0;
    }
    rewind(input);
    FILE *output = fopen(PENDING_TEMP_PATH, "w");
    if (!output) {
        fclose(input);
        set_connect_status("Could not update the pending review queue");
        return 0;
    }

    int seen_matches = 0;
    int success = 1;
    while (fgets(line, sizeof(line), input)) {
        if (is_truncated_line(line, sizeof(line), input) ||
            !parse_pending_line(line, &queued_id, &queued_ease)) {
            success = 0;
            break;
        }
        int matches = queued_id == card_id && queued_ease == ease;
        if (matches && ++seen_matches == matching_rows) continue;
        if (fputs(line, output) == EOF) success = 0;
    }
    if (ferror(input)) success = 0;
    if (fclose(input) != 0) success = 0;
    if (fclose(output) != 0) success = 0;
    if (!success) {
        remove(PENDING_TEMP_PATH);
        set_connect_status("Could not update the pending review queue");
        return 0;
    }

    if (!success || !commit_pending_queue()) {
        remove(PENDING_TEMP_PATH);
        set_connect_status("Could not update the pending review queue");
        return 0;
    }
    set_connect_status("Undid offline rating in the pending sync queue");
    return 1;
}

static void flush_pending_reviews(void) {
    recover_pending_queue();
    FILE *input = fopen(PENDING_PATH, "r");
    if (!input) return;
    remove(PENDING_TEMP_PATH);
    FILE *output = fopen(PENDING_TEMP_PATH, "w");
    if (!output) {
        fclose(input);
        return;
    }

    char line[256];
    int blocked = 0;
    int success = 1;
    while (fgets(line, sizeof(line), input)) {
        int truncated = is_truncated_line(line, sizeof(line), input);
        long long card_id = 0;
        int ease = 0;
        int valid = !truncated && parse_pending_line(line, &card_id, &ease);
        if (!valid) {
            pending_queue_blocked = 1;
            blocked = 1;
            if (fputs(line, output) == EOF) {
                success = 0;
                break;
            }
            if (truncated) {
                int has_newline = strchr(line, '\n') != NULL;
                while (!has_newline) {
                    if (!fgets(line, sizeof(line), input)) break;
                    if (fputs(line, output) == EOF) {
                        success = 0;
                        break;
                    }
                    has_newline = strchr(line, '\n') != NULL;
                }
                if (!success) break;
            }
            continue;
        }
        if (blocked || !anki_connect_answer(card_id, ease)) {
            pending_queue_blocked = 1;
            blocked = 1;
            if (fputs(line, output) == EOF) {
                success = 0;
                break;
            }
        }
    }
    if (ferror(input)) success = 0;
    if (fclose(input) != 0) success = 0;
    if (fclose(output) != 0) success = 0;
    if (!success || !commit_pending_queue()) {
        remove(PENDING_TEMP_PATH);
        pending_queue_blocked = 1;
        set_connect_status("Could not safely update pending reviews; queue preserved");
    }
}

void anki_connect_stop(void) {
    clear_live_card_cache();
    study_counts_valid = 0;
    learning_cards_pending = 0;
    int was_active = curl_started || network_control_started || network_started || network_module_loaded;
    if (curl_started) {
        curl_global_cleanup();
        curl_started = 0;
    }
    if (network_control_started) {
        sceNetCtlTerm();
        network_control_started = 0;
    }
    if (network_started) {
        sceNetTerm();
        network_started = 0;
    }
    if (network_module_loaded) {
        sceSysmoduleUnloadModule(SCE_SYSMODULE_NET);
        network_module_loaded = 0;
    }
    if (was_active) set_connect_status("AnkiConnect stopped for offline deck");
}

void anki_connect_note_offline_deck(void) {
    int was_active = curl_started || network_control_started || network_started || network_module_loaded;
    anki_connect_stop();
    if (configured && was_active) set_connect_status("Using offline deck; live sync paused");
}
