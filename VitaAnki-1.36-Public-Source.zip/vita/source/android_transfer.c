#include "android_transfer.h"

#include <ctype.h>
#include <psp2/io/dirent.h>
#include <psp2/kernel/rng.h>
#include <psp2/kernel/processmgr.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/net/net.h>
#include <psp2/net/netctl.h>
#include <psp2/sysmodule.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>

#define TRANSFER_PORT 27117
#define DISCOVERY_PORT 27118
#define TRANSFER_MAX_BYTES (256ULL * 1024ULL * 1024ULL)
#define TRANSFER_FOLDER "ux0:data/VitaAnki/decks"
#define TRANSFER_MAX_DECKS 48

static unsigned char transfer_network_memory[1024 * 1024] __attribute__((aligned(4096)));
static volatile AndroidTransferState transfer_state = ANDROID_TRANSFER_IDLE;
static volatile int transfer_cancel = 0;
static volatile int transfer_percent = 0;
static volatile int listener_socket = -1;
static volatile int peer_socket = -1;
static SceUID transfer_thread_id = -1;
static int module_loaded = 0;
static int network_started = 0;
static int network_control_started = 0;
static char transfer_pin[8] = "";
static char transfer_filename[128] = "";
static char transfer_error[160] = "";

static int send_all(int socket_id, const char *data, unsigned int length) {
    unsigned int sent = 0;
    while (sent < length) {
        int result = sceNetSend(socket_id, data + sent, length - sent, 0);
        if (result <= 0) return 0;
        sent += (unsigned int)result;
    }
    return 1;
}

static void reply(int socket_id, const char *message) {
    if (socket_id >= 0 && message) send_all(socket_id, message, (unsigned int)strlen(message));
}

static int receive_header(int socket_id, char *header, size_t capacity) {
    size_t used = 0;
    while (used + 1 < capacity) {
        char character = 0;
        int result = sceNetRecv(socket_id, &character, 1, 0);
        if (result <= 0) return 0;
        if (character == '\n') break;
        if (character != '\r') header[used++] = character;
    }
    if (used + 1 >= capacity) return 0;
    header[used] = '\0';
    return used > 0;
}

static int safe_filename(const char *filename) {
    if (!filename || !filename[0] || strlen(filename) > 120 || strstr(filename, "..")) return 0;
    for (const unsigned char *p = (const unsigned char *)filename; *p; p++)
        if (!isalnum(*p) && *p != '_' && *p != '-' && *p != '.') return 0;
    size_t length = strlen(filename);
    return (length >= 5 && !strcasecmp(filename + length - 5, ".apkg")) ||
           (length >= 4 && !strcasecmp(filename + length - 4, ".tsv"));
}

static int install_received_file(const char *temporary, const char *destination,
                                 const char *backup) {
    int had_existing = 0;
    remove(backup);
    struct stat info;
    if (stat(destination, &info) == 0) {
        if (rename(destination, backup) != 0) return 0;
        had_existing = 1;
    }
    if (rename(temporary, destination) != 0) {
        if (had_existing) rename(backup, destination);
        return 0;
    }
    if (had_existing) remove(backup);
    return 1;
}

static int receive_deck(int socket_id, const char *filename, unsigned long long size) {
    char destination[256], temporary[272], backup[272];
    snprintf(destination, sizeof(destination), "%s/%s", TRANSFER_FOLDER, filename);
    snprintf(temporary, sizeof(temporary), "%s.part", destination);
    snprintf(backup, sizeof(backup), "%s.bak", destination);

    FILE *file = fopen(temporary, "wb");
    if (!file) {
        reply(socket_id, "ERR VitaAnki could not open its deck folder\n");
        return 0;
    }
    transfer_state = ANDROID_TRANSFER_RECEIVING;
    transfer_percent = 0;
    unsigned long long received = 0;
    unsigned char buffer[16384];
    unsigned char prefix[4] = {0};
    size_t prefix_size = 0;
    int contains_tab = 0;
    int ok = 1;
    while (received < size) {
        unsigned int wanted = sizeof(buffer);
        unsigned long long remaining = size - received;
        if (remaining < wanted) wanted = (unsigned int)remaining;
        int count = sceNetRecv(socket_id, buffer, wanted, 0);
        if (count <= 0) { ok = 0; break; }
        if (fwrite(buffer, 1, (size_t)count, file) != (size_t)count) { ok = 0; break; }
        for (int i = 0; i < count; i++) {
            if (prefix_size < sizeof(prefix)) prefix[prefix_size++] = buffer[i];
            if (buffer[i] == '\t') contains_tab = 1;
        }
        received += (unsigned int)count;
        transfer_percent = size ? (int)((received * 100ULL) / size) : 0;
    }
    if (fclose(file) != 0) ok = 0;
    int is_apkg = strlen(filename) >= 5 && !strcasecmp(filename + strlen(filename) - 5, ".apkg");
    if (ok && is_apkg && (prefix_size < 2 || prefix[0] != 'P' || prefix[1] != 'K')) ok = 0;
    if (ok && !is_apkg && !contains_tab) ok = 0;
    if (ok && !install_received_file(temporary, destination, backup)) ok = 0;
    if (!ok) {
        remove(temporary);
        reply(socket_id, "ERR Deck transfer was incomplete or invalid; the previous deck was kept\n");
        snprintf(transfer_error, sizeof(transfer_error), "Transfer did not validate. The previous deck file was kept.");
        transfer_state = ANDROID_TRANSFER_ERROR;
        return 0;
    }
    snprintf(transfer_filename, sizeof(transfer_filename), "%s", filename);
    transfer_percent = 100;
    transfer_state = ANDROID_TRANSFER_RECEIVED;
    reply(socket_id, "OK\n");
    return 1;
}

static int parse_request(const char *header, int *pin, unsigned long long *size,
                         char *filename, size_t filename_capacity) {
    char version[24] = "";
    char name[128] = "";
    unsigned long long parsed_size = 0;
    int parsed_pin = 0;
    if (sscanf(header, "%23s\t%d\t%llu\t%127s", version, &parsed_pin,
               &parsed_size, name) != 4 || strcmp(version, "VITAANKI/1")) return 0;
    if (parsed_pin < 100000 || parsed_pin > 999999 || parsed_size == 0 ||
        parsed_size > TRANSFER_MAX_BYTES || !safe_filename(name)) return 0;
    snprintf(filename, filename_capacity, "%s", name);
    *pin = parsed_pin;
    *size = parsed_size;
    return 1;
}

static int parse_pin_request(const char *header, const char *prefix, char pin[8]) {
    char expected[40];
    int prefix_length = snprintf(expected, sizeof(expected), "%s\t", prefix);
    if (prefix_length <= 0 || (size_t)prefix_length >= sizeof(expected) ||
        strncmp(header, expected, (size_t)prefix_length) != 0)
        return 0;
    const char *value = header + prefix_length;
    if (strlen(value) != 6) return 0;
    for (int i = 0; i < 6; i++)
        if (!isdigit((unsigned char)value[i])) return 0;
    memcpy(pin, value, 6);
    pin[6] = '\0';
    return 1;
}

static int parse_download_request(const char *header, char pin[8],
                                  char filename[128]) {
    static const char prefix[] = "VITAANKI/GET/1\t";
    if (strncmp(header, prefix, sizeof(prefix) - 1) != 0) return 0;
    const char *value = header + sizeof(prefix) - 1;
    if (strlen(value) < 8 || value[6] != '\t') return 0;
    for (int i = 0; i < 6; i++)
        if (!isdigit((unsigned char)value[i])) return 0;
    memcpy(pin, value, 6);
    pin[6] = '\0';
    const char *name = value + 7;
    if (!safe_filename(name) || strchr(name, '\t') || strchr(name, ' ')) return 0;
    snprintf(filename, 128, "%s", name);
    return 1;
}

typedef struct {
    char filename[128];
    unsigned long long size;
} TransferDeck;

static int collect_decks(TransferDeck decks[TRANSFER_MAX_DECKS]) {
    SceUID directory = sceIoDopen(TRANSFER_FOLDER);
    if (directory < 0) return 0;
    int count = 0;
    SceIoDirent item;
    memset(&item, 0, sizeof(item));
    while (count < TRANSFER_MAX_DECKS && sceIoDread(directory, &item) > 0) {
        if (item.d_name[0] == '.' || !safe_filename(item.d_name)) {
            memset(&item, 0, sizeof(item));
            continue;
        }
        char path[256];
        int length = snprintf(path, sizeof(path), "%s/%s", TRANSFER_FOLDER, item.d_name);
        struct stat info;
        if (length > 0 && (size_t)length < sizeof(path) && stat(path, &info) == 0 &&
            S_ISREG(info.st_mode) && info.st_size > 0 &&
            (unsigned long long)info.st_size <= TRANSFER_MAX_BYTES) {
            snprintf(decks[count].filename, sizeof(decks[count].filename), "%s", item.d_name);
            decks[count].size = (unsigned long long)info.st_size;
            count++;
        }
        memset(&item, 0, sizeof(item));
    }
    sceIoDclose(directory);
    return count;
}

static void send_deck_list(int socket_id) {
    TransferDeck decks[TRANSFER_MAX_DECKS];
    int count = collect_decks(decks);
    char line[192];
    int length = snprintf(line, sizeof(line), "OKLIST/1\t%d\n", count);
    if (length <= 0 || (size_t)length >= sizeof(line) ||
        !send_all(socket_id, line, (unsigned int)length)) return;
    transfer_state = ANDROID_TRANSFER_LISTING;
    for (int i = 0; i < count; i++) {
        length = snprintf(line, sizeof(line), "%s\t%llu\n", decks[i].filename,
                          decks[i].size);
        if (length <= 0 || (size_t)length >= sizeof(line) ||
            !send_all(socket_id, line, (unsigned int)length)) return;
    }
    reply(socket_id, "END\n");
}

static int send_deck_file(int socket_id, const char *filename) {
    char path[256];
    int length = snprintf(path, sizeof(path), "%s/%s", TRANSFER_FOLDER, filename);
    if (length <= 0 || (size_t)length >= sizeof(path)) {
        reply(socket_id, "ERR Invalid deck path\n");
        return 0;
    }
    struct stat info;
    if (stat(path, &info) != 0 || !S_ISREG(info.st_mode) || info.st_size <= 0 ||
        (unsigned long long)info.st_size > TRANSFER_MAX_BYTES) {
        reply(socket_id, "ERR Deck is missing, empty, or too large\n");
        return 0;
    }
    FILE *file = fopen(path, "rb");
    if (!file) {
        reply(socket_id, "ERR VitaAnki could not open that deck\n");
        return 0;
    }
    unsigned long long size = (unsigned long long)info.st_size;
    char response[64];
    length = snprintf(response, sizeof(response), "READY\t%llu\n", size);
    if (length <= 0 || (size_t)length >= sizeof(response) ||
        !send_all(socket_id, response, (unsigned int)length)) {
        fclose(file);
        return 0;
    }
    transfer_state = ANDROID_TRANSFER_SENDING;
    transfer_percent = 0;
    snprintf(transfer_filename, sizeof(transfer_filename), "%s", filename);
    unsigned char buffer[16384];
    unsigned long long sent = 0;
    int ok = 1;
    while (sent < size) {
        size_t wanted = sizeof(buffer);
        if (size - sent < wanted) wanted = (size_t)(size - sent);
        size_t count = fread(buffer, 1, wanted, file);
        if (count == 0 || !send_all(socket_id, (const char *)buffer, (unsigned int)count)) {
            ok = 0;
            break;
        }
        sent += count;
        transfer_percent = (int)((sent * 100ULL) / size);
    }
    if (fclose(file) != 0) ok = 0;
    if (!ok) {
        snprintf(transfer_error, sizeof(transfer_error), "Deck download stopped before all bytes were sent.");
        transfer_state = ANDROID_TRANSFER_ERROR;
        return 0;
    }
    reply(socket_id, "OK\n");
    transfer_percent = 100;
    return 1;
}

static void answer_discovery(int socket_id) {
    static const char request_prefix[] = "VITAANKI_DISCOVER/1\t";
    char request[96];
    SceNetSockaddrIn sender;
    unsigned int sender_length = sizeof(sender);
    int count = sceNetRecvfrom(socket_id, request, sizeof(request) - 1, 0,
                               (SceNetSockaddr *)&sender, &sender_length);
    if (count <= (int)(sizeof(request_prefix) - 1)) return;
    request[count] = '\0';
    if (strncmp(request, request_prefix, sizeof(request_prefix) - 1) != 0) return;

    const char *nonce = request + sizeof(request_prefix) - 1;
    size_t nonce_length = strlen(nonce);
    if (nonce_length < 8 || nonce_length > 32) return;
    for (size_t i = 0; i < nonce_length; i++)
        if (!isxdigit((unsigned char)nonce[i])) return;

    char response[112];
    int response_length = snprintf(response, sizeof(response),
                                   "VITAANKI_HERE/1\t%s\t%d", nonce, TRANSFER_PORT);
    if (response_length > 0 && (size_t)response_length < sizeof(response))
        sceNetSendto(socket_id, response, (unsigned int)response_length, 0,
                     (SceNetSockaddr *)&sender, sender_length);
}

static int transfer_server(SceSize args, void *argp) {
    (void)args;
    (void)argp;
    int server = sceNetSocket("vitaanki-transfer", SCE_NET_AF_INET,
                              SCE_NET_SOCK_STREAM, 0);
    if (server < 0) {
        snprintf(transfer_error, sizeof(transfer_error), "Could not create the Wi-Fi receiver socket.");
        transfer_state = ANDROID_TRANSFER_ERROR;
        return 0;
    }
    listener_socket = server;
    int reuse = 1;
    sceNetSetsockopt(server, SCE_NET_SOL_SOCKET, SCE_NET_SO_REUSEADDR,
                     &reuse, sizeof(reuse));
    SceNetSockaddrIn address;
    memset(&address, 0, sizeof(address));
    address.sin_len = sizeof(address);
    address.sin_family = SCE_NET_AF_INET;
    address.sin_port = sceNetHtons(TRANSFER_PORT);
    address.sin_addr.s_addr = SCE_NET_INADDR_ANY;
    if (sceNetBind(server, (SceNetSockaddr *)&address, sizeof(address)) < 0 ||
        sceNetListen(server, 1) < 0) {
        snprintf(transfer_error, sizeof(transfer_error), "Could not listen on port %d. Restart VitaAnki and try again.", TRANSFER_PORT);
        transfer_state = ANDROID_TRANSFER_ERROR;
        sceNetSocketClose(server);
        listener_socket = -1;
        return 0;
    }

    int discovery = sceNetSocket("vitaanki-discovery", SCE_NET_AF_INET,
                                 SCE_NET_SOCK_DGRAM, SCE_NET_IPPROTO_UDP);
    if (discovery < 0) {
        snprintf(transfer_error, sizeof(transfer_error), "Could not start local Wi-Fi discovery.");
        transfer_state = ANDROID_TRANSFER_ERROR;
        sceNetSocketClose(server);
        listener_socket = -1;
        return 0;
    }
    sceNetSetsockopt(discovery, SCE_NET_SOL_SOCKET, SCE_NET_SO_REUSEADDR,
                     &reuse, sizeof(reuse));
    int nonblocking = 1;
    if (sceNetSetsockopt(server, SCE_NET_SOL_SOCKET, SCE_NET_SO_NBIO,
                         &nonblocking, sizeof(nonblocking)) < 0 ||
        sceNetSetsockopt(discovery, SCE_NET_SOL_SOCKET, SCE_NET_SO_NBIO,
                         &nonblocking, sizeof(nonblocking)) < 0) {
        snprintf(transfer_error, sizeof(transfer_error), "Could not prepare local Wi-Fi discovery.");
        transfer_state = ANDROID_TRANSFER_ERROR;
        sceNetSocketClose(discovery);
        sceNetSocketClose(server);
        listener_socket = -1;
        return 0;
    }
    SceNetSockaddrIn discovery_address;
    memset(&discovery_address, 0, sizeof(discovery_address));
    discovery_address.sin_len = sizeof(discovery_address);
    discovery_address.sin_family = SCE_NET_AF_INET;
    discovery_address.sin_port = sceNetHtons(DISCOVERY_PORT);
    discovery_address.sin_addr.s_addr = SCE_NET_INADDR_ANY;
    if (sceNetBind(discovery, (SceNetSockaddr *)&discovery_address,
                   sizeof(discovery_address)) < 0) {
        snprintf(transfer_error, sizeof(transfer_error), "Could not open the discovery port. Restart VitaAnki and try again.");
        transfer_state = ANDROID_TRANSFER_ERROR;
        sceNetSocketClose(discovery);
        sceNetSocketClose(server);
        listener_socket = -1;
        return 0;
    }
    transfer_state = ANDROID_TRANSFER_WAITING;

    while (!transfer_cancel) {
        answer_discovery(discovery);
        SceNetSockaddrIn peer;
        unsigned int peer_length = sizeof(peer);
        int client = sceNetAccept(server, (SceNetSockaddr *)&peer, &peer_length);
        if (client < 0) {
            if (transfer_cancel) break;
            sceKernelDelayThread(50000);
            continue;
        }
        int blocking = 0;
        sceNetSetsockopt(client, SCE_NET_SOL_SOCKET, SCE_NET_SO_NBIO,
                         &blocking, sizeof(blocking));
        peer_socket = client;
        char header[256] = {0};
        int parsed_pin = 0;
        unsigned long long size = 0;
        char filename[128] = {0};
        if (!receive_header(client, header, sizeof(header))) {
            reply(client, "ERR Could not read the transfer request\n");
        } else if (strncmp(header, "VITAANKI/LIST/1\t", 16) == 0) {
            char request_pin[8];
            if (!parse_pin_request(header, "VITAANKI/LIST/1", request_pin)) {
                reply(client, "ERR Invalid deck-list request\n");
            } else if (strcmp(request_pin, transfer_pin) != 0) {
                reply(client, "ERR The one-time code does not match\n");
            } else {
                send_deck_list(client);
            }
        } else if (strncmp(header, "VITAANKI/GET/1\t", 15) == 0) {
            char request_pin[8] = "";
            char filename[128] = "";
            if (!parse_download_request(header, request_pin, filename)) {
                reply(client, "ERR Invalid deck-download request\n");
            } else if (strcmp(request_pin, transfer_pin) != 0) {
                reply(client, "ERR The one-time code does not match\n");
            } else {
                send_deck_file(client, filename);
            }
        } else if (!parse_request(header, &parsed_pin, &size, filename, sizeof(filename))) {
            reply(client, "ERR Invalid deck transfer request\n");
        } else if (parsed_pin != atoi(transfer_pin)) {
            reply(client, "ERR The one-time code does not match\n");
        } else {
            reply(client, "READY\n");
            receive_deck(client, filename, size);
        }
        sceNetSocketClose(client);
        peer_socket = -1;
        if (!transfer_cancel && transfer_state != ANDROID_TRANSFER_ERROR)
            transfer_state = ANDROID_TRANSFER_WAITING;
    }
    if (discovery >= 0) sceNetSocketClose(discovery);
    if (server >= 0) sceNetSocketClose(server);
    listener_socket = -1;
    if (transfer_cancel && transfer_state != ANDROID_TRANSFER_RECEIVED &&
        transfer_state != ANDROID_TRANSFER_ERROR)
        transfer_state = ANDROID_TRANSFER_STOPPED;
    return 0;
}

static void stop_network(void) {
    if (network_control_started) {
        sceNetCtlTerm();
        network_control_started = 0;
    }
    if (network_started) {
        sceNetTerm();
        network_started = 0;
    }
    if (module_loaded) {
        sceSysmoduleUnloadModule(SCE_SYSMODULE_NET);
        module_loaded = 0;
    }
}

int android_transfer_start(void) {
    if (transfer_thread_id >= 0 || module_loaded || network_started || network_control_started)
        android_transfer_stop();
    transfer_cancel = 0;
    transfer_percent = 0;
    transfer_filename[0] = '\0';
    transfer_error[0] = '\0';
    unsigned int pin_random = 0;
    if (sceKernelGetRandomNumber(&pin_random, sizeof(pin_random)) < 0) {
        snprintf(transfer_error, sizeof(transfer_error), "Could not create a secure one-time code.");
        transfer_state = ANDROID_TRANSFER_ERROR;
        return -1;
    }
    snprintf(transfer_pin, sizeof(transfer_pin), "%06u", 100000 + pin_random % 900000);

    if (sceSysmoduleLoadModule(SCE_SYSMODULE_NET) < 0) {
        snprintf(transfer_error, sizeof(transfer_error), "Vita Wi-Fi module could not start.");
        transfer_state = ANDROID_TRANSFER_ERROR;
        return -1;
    }
    module_loaded = 1;
    SceNetInitParam params;
    params.memory = transfer_network_memory;
    params.size = sizeof(transfer_network_memory);
    params.flags = 0;
    if (sceNetInit(&params) < 0) {
        snprintf(transfer_error, sizeof(transfer_error), "Vita Wi-Fi could not initialize.");
        stop_network();
        transfer_state = ANDROID_TRANSFER_ERROR;
        return -1;
    }
    network_started = 1;
    if (sceNetCtlInit() < 0) {
        snprintf(transfer_error, sizeof(transfer_error), "Vita Wi-Fi status could not initialize.");
        stop_network();
        transfer_state = ANDROID_TRANSFER_ERROR;
        return -1;
    }
    network_control_started = 1;
    int network_state = SCE_NETCTL_STATE_DISCONNECTED;
    if (sceNetCtlInetGetState(&network_state) < 0 || network_state != SCE_NETCTL_STATE_CONNECTED) {
        snprintf(transfer_error, sizeof(transfer_error), "Connect the Vita to Wi-Fi, then start the receiver again.");
        stop_network();
        transfer_state = ANDROID_TRANSFER_ERROR;
        return -1;
    }
    mkdir(TRANSFER_FOLDER, 0777);
    transfer_state = ANDROID_TRANSFER_STARTING;
    transfer_thread_id = sceKernelCreateThread("vitaanki_receive", transfer_server,
                                                0x10000100, 0x10000, 0, 0, NULL);
    if (transfer_thread_id < 0 || sceKernelStartThread(transfer_thread_id, 0, NULL) < 0) {
        transfer_thread_id = -1;
        snprintf(transfer_error, sizeof(transfer_error), "Could not start the deck receiver thread.");
        stop_network();
        transfer_state = ANDROID_TRANSFER_ERROR;
        return -1;
    }
    return 0;
}

void android_transfer_stop(void) {
    transfer_cancel = 1;
    if (peer_socket >= 0) sceNetSocketClose(peer_socket);
    if (listener_socket >= 0) sceNetSocketClose(listener_socket);
    if (transfer_thread_id >= 0) {
        sceKernelWaitThreadEnd(transfer_thread_id, NULL, NULL);
        sceKernelDeleteThread(transfer_thread_id);
        transfer_thread_id = -1;
    }
    listener_socket = -1;
    peer_socket = -1;
    stop_network();
    if (transfer_state == ANDROID_TRANSFER_WAITING || transfer_state == ANDROID_TRANSFER_STARTING ||
        transfer_state == ANDROID_TRANSFER_RECEIVING)
        transfer_state = ANDROID_TRANSFER_STOPPED;
}

AndroidTransferState android_transfer_get_state(void) { return transfer_state; }
const char *android_transfer_get_pin(void) { return transfer_pin; }
const char *android_transfer_get_filename(void) { return transfer_filename; }
const char *android_transfer_get_message(void) {
    switch (transfer_state) {
        case ANDROID_TRANSFER_STARTING: return "Starting the one-time receiver…";
        case ANDROID_TRANSFER_WAITING: return "Receiver is ready for sending or downloading decks over local Wi-Fi.";
        case ANDROID_TRANSFER_RECEIVING: return "Receiving deck from Android…";
        case ANDROID_TRANSFER_LISTING: return "Sending the Vita deck list to Android…";
        case ANDROID_TRANSFER_SENDING: return "Sending a deck to Android…";
        case ANDROID_TRANSFER_RECEIVED: return "Deck received and saved. Open Decks to select it.";
        case ANDROID_TRANSFER_ERROR: return transfer_error[0] ? transfer_error : "Transfer receiver encountered an error.";
        case ANDROID_TRANSFER_STOPPED: return "Receiver stopped.";
        default: return "Receiver is off.";
    }
}
int android_transfer_get_progress(void) { return transfer_percent; }
