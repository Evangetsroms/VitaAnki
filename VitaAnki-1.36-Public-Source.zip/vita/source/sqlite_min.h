/* Minimal declarations for the Vita system SQLite exports. */
#ifndef SQLITE_MIN_H
#define SQLITE_MIN_H

typedef struct sqlite3 sqlite3;
typedef struct sqlite3_stmt sqlite3_stmt;
typedef long long sqlite3_int64;

#define SQLITE_OK 0
#define SQLITE_ROW 100
#define SQLITE_DONE 101
#define SQLITE_OPEN_READONLY 0x00000001
#define SQLITE_OPEN_NOMUTEX 0x00008000

int sqlite3_open(const char *filename, sqlite3 **db);
int sqlite3_open_v2(const char *filename, sqlite3 **db, int flags, const char *vfs);
int sqlite3_close(sqlite3 *db);
int sqlite3_prepare_v2(sqlite3 *db, const char *sql, int bytes,
                       sqlite3_stmt **stmt, const char **tail);
int sqlite3_step(sqlite3_stmt *stmt);
int sqlite3_finalize(sqlite3_stmt *stmt);
sqlite3_int64 sqlite3_column_int64(sqlite3_stmt *stmt, int column);
const unsigned char *sqlite3_column_text(sqlite3_stmt *stmt, int column);
int sqlite3_column_int(sqlite3_stmt *stmt, int column);
const char *sqlite3_errmsg(sqlite3 *db);

#endif
