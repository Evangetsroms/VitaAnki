#include <ctype.h>
#include <psp2/ctrl.h>
#include <psp2/io/dirent.h>
#include <psp2/kernel/processmgr.h>
#include <psp2/sysmodule.h>
#include <psp2/touch.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <vita2d.h>
#include "anki_connect.h"
#include "anki_music.h"
#include "android_transfer.h"
#include "vitaanki.h"

#define SCREEN_W 960
#define SCREEN_H 544
#define APP_VERSION "1.26"
#define UI_TEXT_SCALE (1.18f * selected_ui_text_scale())
#define CARD_FLIP_FRAMES 12
#define AGAIN_STEP_SECONDS 60
#define HARD_STEP_SECONDS 300
#define LIVE_REFRESH_SECONDS 10
#define NEW_CARD_BATCH_SIZE 20

#define DECK_PATH "ux0:data/VitaAnki/cards.tsv"
#define APKG_PATH "ux0:data/VitaAnki/import.apkg"
#define DECK_FOLDER "ux0:data/VitaAnki/decks"
#define INCLUDED_DECK_PATH "ux0:data/VitaAnki/decks/VitaAnki_Sample.tsv"
#define BUNDLED_DECK_PATH "app0:decks/VitaAnki_Sample.tsv"
#define PROGRESS_PATH "ux0:data/VitaAnki/progress.tsv"
#define ACTIVE_DECK_PATH "ux0:data/VitaAnki/active-deck.txt"
#define ACTIVE_DECK_TEMP_PATH "ux0:data/VitaAnki/active-deck.tmp"
#define ACTIVE_DECK_BACKUP_PATH "ux0:data/VitaAnki/active-deck.bak"
#define SETTINGS_PATH "ux0:data/VitaAnki/settings.ini"
#define SETTINGS_TEMP_PATH "ux0:data/VitaAnki/settings.tmp"
#define SETTINGS_BACKUP_PATH "ux0:data/VitaAnki/settings.bak"
#define MIN_VALID_CLOCK_EPOCH 1577836800LL
#define MAX_VALID_CLOCK_EPOCH 4102444800LL
#define MAX_INTERVAL_DAYS 36500
#define MAX_DECKS 48
#define LIST_ROW_Y 132
#define LIST_ROW_H 62
#define LIST_VISIBLE 4

typedef enum {
    SCREEN_HOME,
    SCREEN_STUDY,
    SCREEN_BROWSER,
    SCREEN_DECKS,
    SCREEN_IMPORT,
    SCREEN_SETTINGS,
    SCREEN_SYNC,
    SCREEN_ANDROID_TRANSFER
} AppScreen;

typedef struct {
    char path[512];
    char name[128];
    int is_apkg;
} DeckEntry;

typedef struct {
    int x;
    int y;
    int w;
    int h;
} UiRect;

typedef struct {
    unsigned int white;
    unsigned int muted;
    unsigned int accent;
    unsigned int panel;
    unsigned int panel_hi;
    unsigned int background;
    unsigned int green;
    unsigned int yellow;
    unsigned int red;
} ColorTheme;

typedef struct {
    int valid;
    int live;
    int queued;
    long long card_id;
    int previous_index;
    int previous_interval_days;
    long long previous_due;
    CardState previous_state;
    int previous_reviewed;
    int previous_new_cards_this_session;
    int rating;
} UndoRecord;

typedef struct {
    float x;
    float y;
    float vx;
    float vy;
    int width;
    int height;
    unsigned int color;
} ConfettiPiece;

static Card *cards = NULL;
static int card_capacity = 0;
static DeckEntry deck_entries[MAX_DECKS];
static int deck_count = 0;
static int card_count = 0;
static int card_index = 0;
static int current_deck_index = -1;
static int home_selection = 0;
static int list_selection = 0;
static int settings_selection = 0;
static int show_answer = 0;
static int browser_index = 0;
static int browser_show_answer = 0;
static int analog_input_latched = 0;
static int analog_scroll_direction = 0;
static int analog_scroll_repeat_frames = 0;
static int card_scroll_lines = 0;
static int browser_scroll_lines = 0;
static int selected_rating = 2;
static int clock_warning_active = 0;
static int undo_error = 0;
static int jump_dialog_open = 0;
static int jump_selection = 13;
static int jump_error = 0;
static char jump_input[8] = "";
static UndoRecord undo_record;
static int reviewed = 0;
static int new_cards_this_session = 0;
static int study_idle_frames = 0;
static time_t live_refresh_after = 0;
static int demo_mode = 0;
static int import_error = 0;
static int import_error_code = 0;
static int live_sync = 0;
static int sync_error = 0;
static int sync_queue_error = 0;
static char sync_message[160] = "";
static int apkg_mode = 0;
static int font_mode = 0;
static int text_size_mode = 1;
static int ui_text_mode = 1;
static int color_theme_mode = 0;
static int flip_animation_mode = 1;
static int flip_frames_remaining = 0;
static int flip_from_answer = 0;
static int flip_to_answer = 0;
static int sync_selection = 1;
static int music_muted = 0;
static int confetti_mode = 1;
static int review_control_mode = 0;
static int confetti_frames = 0;
static uint32_t confetti_rng = 0xA71C0FFEu;
static ConfettiPiece confetti[40];
static int touch_was_down = 0;
static int touch_min_x = 0;
static int touch_min_y = 0;
static int touch_width = 1920;
static int touch_height = 1080;
static char current_deck_name[128] = "Demo deck";
static char current_deck_path[512] = "";
static char current_progress_path[96] = PROGRESS_PATH;
static char saved_deck_path[512] = "";
static AppScreen current_screen = SCREEN_HOME;
static vita2d_pgf *font_pgf = NULL;
static vita2d_pgf *font_serif_pgf = NULL;
static vita2d_pgf *font_sans_pgf = NULL;
static vita2d_pgf *font_serif_bold_pgf = NULL;
static vita2d_pgf *font_sans_bold_pgf = NULL;
static vita2d_texture *app_icon = NULL;
static vita2d_texture *card_image_texture = NULL;
static char card_image_path_cached[FIELD_SIZE] = "";

static unsigned int WHITE = RGBA8(244, 247, 255, 255);
static unsigned int MUTED = RGBA8(155, 170, 190, 255);
static unsigned int ACCENT = RGBA8(112, 184, 255, 255);
static unsigned int PANEL = RGBA8(25, 35, 53, 255);
static unsigned int PANEL_HI = RGBA8(37, 52, 75, 255);
static unsigned int BG = RGBA8(13, 19, 31, 255);
static unsigned int GREEN = RGBA8(135, 220, 165, 255);
static unsigned int YELLOW = RGBA8(255, 202, 112, 255);
static unsigned int RED = RGBA8(255, 130, 130, 255);

int vitaanki_reserve_cards(Card **target, int *allocated_capacity, int required) {
    if (!target || !allocated_capacity || required < 0 || required > MAX_CARDS) return 0;
    if (required <= *allocated_capacity) return 1;

    int new_capacity = *allocated_capacity > 0 ? *allocated_capacity : 32;
    while (new_capacity < required) {
        if (new_capacity > MAX_CARDS / 2) {
            new_capacity = MAX_CARDS;
            break;
        }
        new_capacity *= 2;
    }
    Card *resized = realloc(*target, (size_t)new_capacity * sizeof(Card));
    if (!resized) return 0;
    *target = resized;
    *allocated_capacity = new_capacity;
    return 1;
}

static const ColorTheme color_themes[] = {
    /* Cyberpunk dark: black base with bright pink and green accents. */
    {RGBA8(245, 245, 249, 255), RGBA8(165, 165, 178, 255),
     RGBA8(255, 55, 165, 255), RGBA8(20, 20, 27, 255),
     RGBA8(34, 34, 44, 255), RGBA8(5, 6, 9, 255),
     RGBA8(57, 255, 126, 255), RGBA8(255, 220, 72, 255),
     RGBA8(255, 89, 113, 255)},
    /* Cyberpunk light: white base and the same paired accents. */
    {RGBA8(28, 25, 34, 255), RGBA8(92, 86, 101, 255),
     RGBA8(198, 0, 104, 255), RGBA8(255, 255, 255, 255),
     RGBA8(237, 233, 242, 255), RGBA8(248, 248, 251, 255),
     RGBA8(0, 137, 72, 255), RGBA8(151, 98, 0, 255),
     RGBA8(194, 38, 76, 255)},
    /* Sepia: warm paper and ink, with restrained earthy accents. */
    {RGBA8(55, 43, 28, 255), RGBA8(117, 101, 78, 255),
     RGBA8(142, 90, 45, 255), RGBA8(232, 218, 190, 255),
     RGBA8(220, 199, 161, 255), RGBA8(245, 235, 213, 255),
     RGBA8(91, 116, 55, 255), RGBA8(153, 112, 44, 255),
     RGBA8(164, 78, 63, 255)},
    /* Synthwave: near-black base, electric magenta and cyan. */
    {RGBA8(246, 242, 255, 255), RGBA8(164, 151, 190, 255),
     RGBA8(231, 76, 255, 255), RGBA8(20, 14, 34, 255),
     RGBA8(39, 24, 62, 255), RGBA8(6, 4, 13, 255),
     RGBA8(54, 226, 218, 255), RGBA8(255, 181, 71, 255),
     RGBA8(255, 87, 127, 255)},
    /* Arctic: white base with deep blue and teal accents. */
    {RGBA8(25, 39, 54, 255), RGBA8(86, 108, 128, 255),
     RGBA8(0, 117, 160, 255), RGBA8(255, 255, 255, 255),
     RGBA8(228, 243, 250, 255), RGBA8(245, 251, 255, 255),
     RGBA8(0, 117, 99, 255), RGBA8(137, 96, 0, 255),
     RGBA8(178, 47, 66, 255)}
};

static const float text_scales[] = {0.84f, 1.0f, 1.18f, 1.38f};
static const char *text_size_labels[] = {"Small", "Standard", "Large", "Extra large"};
static const float ui_text_scales[] = {1.0f, 1.1f, 1.2f};
static const char *ui_text_labels[] = {"Standard", "Large", "Extra large"};
static const char *color_theme_labels[] = {"Cyberpunk dark", "Cyberpunk light", "Sepia",
                                           "Synthwave", "Arctic"};
static const char *flip_animation_labels[] = {"Instant", "Animated"};
static const char *confetti_labels[] = {"Off", "Good + Easy", "Easy only"};
static const char *font_labels[] = {"System default", "Bold system PGF", "Serif", "Sans", "Serif bold", "Sans bold"};
static const UiRect settings_rows[8] = {
    {60, 106, 840, 38}, {60, 148, 840, 38}, {60, 190, 840, 38},
    {60, 232, 840, 38}, {60, 274, 840, 38}, {60, 316, 840, 38},
    {60, 358, 840, 38}, {60, 400, 840, 38}
};

static const Card demo_cards[] = {
    {"What is the functional unit of skeletal muscle?", "The sarcomere: the segment between two Z discs.", 1, 0, 0, CARD_STATE_NEW},
    {"Which neurotransmitter is released at the neuromuscular junction?", "Acetylcholine (ACh), released by the motor neuron.", 2, 0, 0, CARD_STATE_NEW},
    {"What structure stores calcium ions in a muscle fiber?", "The sarcoplasmic reticulum.", 3, 0, 0, CARD_STATE_NEW},
};

static const UiRect home_buttons[4] = {
    {60, 126, 408, 126}, {492, 126, 408, 126},
    {60, 270, 408, 126}, {492, 270, 408, 126}
};
static const UiRect music_button = {766, 18, 146, 42};
static const UiRect back_button = {48, 16, 88, 44};
static const UiRect browser_button = {60, 410, 408, 48};
static const UiRect sync_button = {348, 410, 264, 48};
static const UiRect android_transfer_button = {636, 410, 264, 48};
static const UiRect android_transfer_start_button = {60, 420, 300, 54};
static const UiRect android_transfer_decks_button = {378, 420, 210, 54};
static const UiRect sync_offline_button = {60, 116, 408, 112};
static const UiRect sync_live_button = {492, 116, 408, 112};
static const UiRect undo_button = {790, 110, 110, 36};
static const UiRect browser_jump_button = {240, 458, 190, 52};

static int file_exists(const char *path);
static void recover_atomic_file(const char *destination, const char *temporary,
                                const char *backup);
static int atomic_replace_file(const char *temporary, const char *destination,
                               const char *backup);
static void begin_pc_sync(void);
static void select_offline_source(void);
static int has_study_card(void);

static vita2d_pgf *custom_font_for_mode(int mode) {
    if (mode == 2) return font_serif_pgf;
    if (mode == 3) return font_sans_pgf;
    if (mode == 4) return font_serif_bold_pgf;
    if (mode == 5) return font_sans_bold_pgf;
    return NULL;
}

static void release_custom_font(int mode) {
    vita2d_pgf **font = NULL;
    if (mode == 2) font = &font_serif_pgf;
    else if (mode == 3) font = &font_sans_pgf;
    else if (mode == 4) font = &font_serif_bold_pgf;
    else if (mode == 5) font = &font_sans_bold_pgf;
    if (font && *font) {
        vita2d_free_pgf(*font);
        *font = NULL;
    }
}

static void release_custom_fonts(void) {
    release_custom_font(2);
    release_custom_font(3);
    release_custom_font(4);
    release_custom_font(5);
}

static int font_mode_available(int mode) {
    if (mode == 0 || mode == 1) return 1;
    if (mode < 2 || mode > 5) return 0;
    if (custom_font_for_mode(mode)) return 1;

    const char *path = mode == 2 ? "sa0:data/font/ltn0.pgf"
                       : mode == 3 ? "sa0:data/font/ltn2.pgf"
                       : mode == 4 ? "sa0:data/font/ltn4.pgf"
                                   : "sa0:data/font/ltn6.pgf";
    vita2d_pgf *font = vita2d_load_custom_pgf(path);
    if (!font) return 0;
    if (mode == 2) font_serif_pgf = font;
    else if (mode == 3) font_sans_pgf = font;
    else if (mode == 4) font_serif_bold_pgf = font;
    else font_sans_bold_pgf = font;
    return 1;
}

static float selected_text_scale(void) {
    if (text_size_mode < 0 || text_size_mode > 3) text_size_mode = 1;
    return text_scales[text_size_mode];
}

static float selected_ui_text_scale(void) {
    if (ui_text_mode < 0 || ui_text_mode > 2) ui_text_mode = 1;
    return ui_text_scales[ui_text_mode];
}

static void apply_color_theme(int mode) {
    if (mode < 0 || mode >= (int)(sizeof(color_themes) / sizeof(color_themes[0]))) mode = 0;
    color_theme_mode = mode;
    WHITE = color_themes[mode].white;
    MUTED = color_themes[mode].muted;
    ACCENT = color_themes[mode].accent;
    PANEL = color_themes[mode].panel;
    PANEL_HI = color_themes[mode].panel_hi;
    BG = color_themes[mode].background;
    GREEN = color_themes[mode].green;
    YELLOW = color_themes[mode].yellow;
    RED = color_themes[mode].red;
}

static void draw_text_scaled(int x, int y, unsigned int color, float scale,
                             const char *text, float size_factor) {
    float actual_scale = scale * size_factor * UI_TEXT_SCALE;
    if (custom_font_for_mode(font_mode))
        vita2d_pgf_draw_text(custom_font_for_mode(font_mode), x, y, color, actual_scale, text);
    else if (font_pgf) {
        vita2d_pgf_draw_text(font_pgf, x, y, color, actual_scale, text);
        if (font_mode == 1) vita2d_pgf_draw_text(font_pgf, x + 1, y, color, actual_scale, text);
    }
}

static void draw_text(int x, int y, unsigned int color, float scale, const char *text) {
    draw_text_scaled(x, y, color, scale, text, 1.0f);
}

static void draw_card_text(int x, int y, unsigned int color, float scale, const char *text) {
    draw_text_scaled(x, y, color, scale, text, selected_text_scale());
}

static int text_width_scaled(float scale, const char *text, float size_factor) {
    float actual_scale = scale * size_factor * UI_TEXT_SCALE;
    if (custom_font_for_mode(font_mode))
        return vita2d_pgf_text_width(custom_font_for_mode(font_mode), actual_scale, text);
    if (font_pgf)
        return vita2d_pgf_text_width(font_pgf, actual_scale, text);
    return 0;
}

static int text_width(float scale, const char *text) {
    return text_width_scaled(scale, text, 1.0f);
}

static int card_text_width(float scale, const char *text) {
    return text_width_scaled(scale, text, selected_text_scale());
}

static void draw_fit_text(int x, int y, unsigned int color, float scale,
                          const char *text, int max_width) {
    char fitted[160];
    size_t source_length = strlen(text);
    size_t keep = source_length < sizeof(fitted) - 1 ? source_length : sizeof(fitted) - 4;
    int truncated = source_length > keep;
    do {
        memcpy(fitted, text, keep);
        fitted[keep] = '\0';
        if (truncated) strncat(fitted, "...", sizeof(fitted) - strlen(fitted) - 1);
        if (text_width(scale, fitted) <= max_width || keep == 0) break;
        keep--;
        truncated = 1;
    } while (1);
    draw_text(x, y, color, scale, fitted);
}

static int inside(UiRect rect, int x, int y) {
    return x >= rect.x && y >= rect.y && x < rect.x + rect.w && y < rect.y + rect.h;
}

static void draw_button(UiRect rect, const char *label, const char *subtitle,
                        unsigned int accent, int selected) {
    unsigned int fill = selected ? PANEL_HI : PANEL;
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, fill);
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, 4, accent);
    if (selected) {
        vita2d_draw_rectangle(rect.x, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x + rect.w - 3, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x, rect.y + rect.h - 3, rect.w, 3, accent);
    }
    draw_fit_text(rect.x + 20, rect.y + 48, WHITE, 0.88f, label, rect.w - 40);
    if (subtitle) draw_fit_text(rect.x + 20, rect.y + 82, MUTED, 0.58f, subtitle, rect.w - 40);
}

static void draw_compact_button(UiRect rect, const char *label,
                               unsigned int accent, int selected) {
    unsigned int fill = selected ? PANEL_HI : PANEL;
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, fill);
    vita2d_draw_rectangle(rect.x, rect.y, rect.w, 3, accent);
    if (selected) {
        vita2d_draw_rectangle(rect.x, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x + rect.w - 3, rect.y, 3, rect.h, accent);
        vita2d_draw_rectangle(rect.x, rect.y + rect.h - 3, rect.w, 3, accent);
    }
    draw_fit_text(rect.x + 16, rect.y + rect.h / 2 + 6, WHITE, 0.60f,
                  label, rect.w - 32);
}

static void draw_header(const char *title, const char *subtitle) {
    if (current_screen == SCREEN_HOME) {
        if (app_icon) vita2d_draw_texture_scale(app_icon, 48, 16, 0.2f, 0.2f);
        draw_text(96, 48, ACCENT, 1.0f, title);
        if (subtitle) draw_fit_text(48, 78, MUTED, 0.5f, subtitle, 690);
    } else {
        draw_compact_button(back_button, "BACK", ACCENT, 0);
        if (app_icon) vita2d_draw_texture_scale(app_icon, 144, 20, 0.18f, 0.18f);
        draw_fit_text(184, 48, ACCENT, 0.94f, title, 560);
        if (subtitle) draw_fit_text(184, 78, MUTED, 0.5f, subtitle, 540);
    }

    UiRect music_rect = music_button;
#ifdef VITAANKI_DISABLE_MUSIC
    unsigned int music_color = MUTED;
    vita2d_draw_rectangle(music_rect.x, music_rect.y, music_rect.w, music_rect.h, PANEL);
    vita2d_draw_rectangle(music_rect.x, music_rect.y, music_rect.w, 3, music_color);
    draw_text(music_rect.x + 12, music_rect.y + 28, music_color, 0.53f, "AUDIO: OFF");
#else
    unsigned int music_color = anki_music_is_muted() ? MUTED : GREEN;
    vita2d_draw_rectangle(music_rect.x, music_rect.y, music_rect.w, music_rect.h, PANEL);
    vita2d_draw_rectangle(music_rect.x, music_rect.y, music_rect.w, 3, music_color);
    draw_text(music_rect.x + 12, music_rect.y + 28, music_color, 0.53f,
              anki_music_is_muted() ? "MUSIC: MUTED" : "MUSIC: ON");
#endif
    vita2d_draw_rectangle(48, 94, 864, 2, PANEL_HI);
}

static void draw_wrapped_mode(const char *text, int x, int y, int max_width, float scale,
                              unsigned int color, int card_size) {
    char line[280] = {0};
    char word[120];
    const char *p = text;
    int line_y = y;
    float size_factor = card_size ? selected_text_scale() : 1.0f;
    int line_height = (int)(39.0f * size_factor * UI_TEXT_SCALE);

    while (*p) {
        int n = 0;
        while (*p == ' ' || *p == '\n' || *p == '\r') p++;
        while (*p && *p != ' ' && *p != '\n' && *p != '\r' && n < (int)sizeof(word) - 1)
            word[n++] = *p++;
        word[n] = '\0';
        if (n == 0) break;

        size_t line_length = strlen(line);
        size_t word_length = strlen(word);
        if (line[0] && line_length + 1 + word_length >= sizeof(line)) {
            if (card_size) draw_card_text(x, line_y, color, scale, line);
            else draw_text(x, line_y, color, scale, line);
            line_y += line_height;
            memcpy(line, word, word_length + 1);
            continue;
        }

        char candidate[280];
        size_t candidate_length = line[0] ? line_length + 1 + word_length : word_length;
        if (line[0]) {
            memcpy(candidate, line, line_length);
            candidate[line_length] = ' ';
            memcpy(candidate + line_length + 1, word, word_length + 1);
        } else {
            memcpy(candidate, word, word_length + 1);
        }

        if (line[0] && text_width_scaled(scale, candidate, size_factor) > max_width) {
            if (card_size) draw_card_text(x, line_y, color, scale, line);
            else draw_text(x, line_y, color, scale, line);
            line_y += line_height;
            memcpy(line, word, word_length + 1);
        } else {
            memcpy(line, candidate, candidate_length + 1);
        }
    }

    if (line[0]) {
        if (card_size) draw_card_text(x, line_y, color, scale, line);
        else draw_text(x, line_y, color, scale, line);
    }
}

static void draw_wrapped(const char *text, int x, int y, int max_width, float scale,
                         unsigned int color) {
    draw_wrapped_mode(text, x, y, max_width, scale, color, 0);
}

static int next_card_line(const char **cursor, char line[256], int max_width, float scale) {
    const char *p = *cursor;
    line[0] = '\0';
    while (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t') p++;
    if (!*p) {
        *cursor = p;
        return 0;
    }

    for (;;) {
        char word[240];
        int n = 0;
        const char *word_start = p;
        while (*p && *p != ' ' && *p != '\n' && *p != '\r' && *p != '\t' && n < (int)sizeof(word) - 1)
            word[n++] = *p++;
        word[n] = '\0';
        if (n == 0) break;

        size_t line_length = strlen(line);
        size_t candidate_length = line[0] ? line_length + 1 + (size_t)n : (size_t)n;
        if (candidate_length >= 256) {
            *cursor = word_start;
            return 1;
        }
        char candidate[256];
        if (line[0]) {
            memcpy(candidate, line, line_length);
            candidate[line_length] = ' ';
            memcpy(candidate + line_length + 1, word, (size_t)n + 1);
        } else {
            memcpy(candidate, word, (size_t)n + 1);
        }
        if (line[0] && card_text_width(scale, candidate) > max_width) {
            *cursor = word_start;
            return 1;
        }
        memcpy(line, candidate, candidate_length + 1);
        while (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t') p++;
        if (!*p) break;
    }
    *cursor = p;
    return line[0] != '\0';
}

static int card_line_height(void) {
    int height = (int)(39.0f * selected_text_scale() * UI_TEXT_SCALE);
    return height > 0 ? height : 1;
}

static int card_line_count(const char *text, int max_width, float scale) {
    const char *cursor = text;
    int count = 0;
    char line[256];
    while (next_card_line(&cursor, line, max_width, scale)) count++;
    return count;
}

static int card_scroll_limit(const char *text, int max_width, float scale, int viewport_height) {
    int visible_lines = viewport_height / card_line_height() + 1;
    int limit = card_line_count(text, max_width, scale) - visible_lines;
    return limit > 0 ? limit : 0;
}

static void draw_card_viewport(const char *text, int x, int y, int max_width, float scale,
                               unsigned int color, int scroll_lines, int viewport_height) {
    const char *cursor = text;
    char line[256];
    int line_index = 0;
    int line_height = card_line_height();
    while (next_card_line(&cursor, line, max_width, scale)) {
        if (line_index >= scroll_lines) {
            int visible_y = y + (line_index - scroll_lines) * line_height;
            if (visible_y > y + viewport_height) break;
            draw_card_text(x, visible_y, color, scale, line);
        }
        line_index++;
    }
}

static vita2d_texture *get_card_image(const char *path) {
    if (!path || !*path) return NULL;
    if (!strcmp(card_image_path_cached, path)) return card_image_texture;
    if (card_image_texture) {
        vita2d_free_texture(card_image_texture);
        card_image_texture = NULL;
    }
    snprintf(card_image_path_cached, sizeof(card_image_path_cached), "%s", path);
    const char *extension = strrchr(path, '.');
    if (extension && (!strcasecmp(extension, ".jpg") || !strcasecmp(extension, ".jpeg")))
        card_image_texture = vita2d_load_JPEG_file(path);
    else if (extension && !strcasecmp(extension, ".png"))
        card_image_texture = vita2d_load_PNG_file(path);
    return card_image_texture;
}

static void draw_card_image_half(const char *path, int x, int y, int width, int height) {
    vita2d_draw_rectangle(x, y, width, height, PANEL_HI);
    vita2d_draw_rectangle(x, y, width, 3, ACCENT);
    vita2d_texture *texture = get_card_image(path);
    if (!texture) {
        draw_fit_text(x + 12, y + height / 2, MUTED, 0.45f, "IMAGE UNAVAILABLE", width - 24);
        return;
    }
    unsigned int image_width = vita2d_texture_get_width(texture);
    unsigned int image_height = vita2d_texture_get_height(texture);
    if (!image_width || !image_height) return;
    float scale_x = (float)(width - 12) / (float)image_width;
    float scale_y = (float)(height - 12) / (float)image_height;
    float scale = scale_x < scale_y ? scale_x : scale_y;
    if (scale > 1.0f) scale = 1.0f;
    float draw_width = (float)image_width * scale;
    float draw_height = (float)image_height * scale;
    float draw_x = (float)x + ((float)width - draw_width) * 0.5f;
    float draw_y = (float)y + ((float)height - draw_height) * 0.5f;
    vita2d_draw_texture_scale(texture, draw_x, draw_y, scale, scale);
}

static void draw_card_scrollbar(const char *text, int x, int y, int max_width,
                               float scale, int scroll_lines, int viewport_height) {
    int total_lines = card_line_count(text, max_width, scale);
    int visible_lines = viewport_height / card_line_height() + 1;
    int maximum = total_lines - visible_lines;
    if (maximum <= 0) return;

    const int track_height = 166;
    int thumb_height = track_height * visible_lines / total_lines;
    if (thumb_height < 18) thumb_height = 18;
    if (thumb_height > track_height) thumb_height = track_height;
    int thumb_y = y + (track_height - thumb_height) * scroll_lines / maximum;
    vita2d_draw_rectangle(x, y, 5, track_height, PANEL_HI);
    vita2d_draw_rectangle(x, thumb_y, 5, thumb_height, ACCENT);
}

static const char *study_card_text(void) {
    if (card_count <= 0 || card_index < 0 || card_index >= card_count) return "";
    return show_answer ? cards[card_index].back : cards[card_index].front;
}

static int displayed_answer_side(void) {
    if (flip_frames_remaining <= 0) return show_answer;
    int progress = CARD_FLIP_FRAMES - flip_frames_remaining;
    return progress < CARD_FLIP_FRAMES / 2 ? flip_from_answer : flip_to_answer;
}

static void set_study_answer_side(int answer) {
    answer = answer ? 1 : 0;
    if (flip_frames_remaining > 0 || card_count <= 0 ||
        card_index < 0 || card_index >= card_count || answer == show_answer) return;
    card_scroll_lines = 0;
    if (!flip_animation_mode) {
        show_answer = answer;
        return;
    }
    flip_from_answer = show_answer;
    flip_to_answer = answer;
    show_answer = answer;
    flip_frames_remaining = CARD_FLIP_FRAMES;
}

static void advance_study_flip(void) {
    if (flip_frames_remaining > 0) flip_frames_remaining--;
}

static const char *browser_card_text(void) {
    if (card_count <= 0 || browser_index < 0 || browser_index >= card_count) return "";
    return browser_show_answer ? cards[browser_index].back : cards[browser_index].front;
}

static void scroll_visible_card(int direction) {
    if (current_screen == SCREEN_STUDY) {
        if (flip_frames_remaining > 0) return;
        int split = has_study_card() && !displayed_answer_side() && cards[card_index].front_image[0];
        int limit = card_scroll_limit(study_card_text(), split ? 380 : 790,
                                      split ? 0.84f : 0.95f, split ? 210 : 160);
        card_scroll_lines += direction;
        if (card_scroll_lines < 0) card_scroll_lines = 0;
        if (card_scroll_lines > limit) card_scroll_lines = limit;
    } else if (current_screen == SCREEN_BROWSER) {
        int split = card_count > 0 && !browser_show_answer && cards[browser_index].front_image[0];
        int limit = card_scroll_limit(browser_card_text(), split ? 380 : 790,
                                      split ? 0.84f : 0.95f, split ? 210 : 160);
        browser_scroll_lines += direction;
        if (browser_scroll_lines < 0) browser_scroll_lines = 0;
        if (browser_scroll_lines > limit) browser_scroll_lines = limit;
    }
}

static void load_settings(void) {
    recover_atomic_file(SETTINGS_PATH, SETTINGS_TEMP_PATH, SETTINGS_BACKUP_PATH);
    FILE *file = fopen(SETTINGS_PATH, "r");
    if (!file) return;
    char line[128];
    while (fgets(line, sizeof(line), file)) {
        int value;
        if (sscanf(line, "font=%d", &value) == 1) font_mode = value;
        else if (sscanf(line, "text_size=%d", &value) == 1) text_size_mode = value;
        else if (sscanf(line, "ui_text=%d", &value) == 1) ui_text_mode = value;
        else if (sscanf(line, "theme_v2=%d", &value) == 1) color_theme_mode = value;
        else if (sscanf(line, "flip_animation=%d", &value) == 1) flip_animation_mode = value;
        else if (sscanf(line, "music_muted=%d", &value) == 1) music_muted = value;
        else if (sscanf(line, "confetti=%d", &value) == 1) confetti_mode = value;
        else if (sscanf(line, "review_controls=%d", &value) == 1) review_control_mode = value;
    }
    fclose(file);
    if (font_mode < 0 || font_mode > 5) font_mode = 0;
    if (text_size_mode < 0 || text_size_mode > 3) text_size_mode = 1;
    if (ui_text_mode < 0 || ui_text_mode > 2) ui_text_mode = 1;
    if (color_theme_mode < 0 || color_theme_mode >= (int)(sizeof(color_themes) / sizeof(color_themes[0])))
        color_theme_mode = 0;
    apply_color_theme(color_theme_mode);
    if (flip_animation_mode < 0 || flip_animation_mode > 1) flip_animation_mode = 1;
    music_muted = music_muted ? 1 : 0;
    if (confetti_mode < 0 || confetti_mode > 2) confetti_mode = 1;
    if (review_control_mode < 0 || review_control_mode > 1) review_control_mode = 0;
}

static void save_settings(void) {
    recover_atomic_file(SETTINGS_PATH, SETTINGS_TEMP_PATH, SETTINGS_BACKUP_PATH);
    remove(SETTINGS_TEMP_PATH);
    FILE *file = fopen(SETTINGS_TEMP_PATH, "w");
    if (!file) return;
    int ok = fprintf(file, "font=%d\ntext_size=%d\nui_text=%d\ntheme_v2=%d\nflip_animation=%d\nmusic_muted=%d\nconfetti=%d\nreview_controls=%d\n",
                     font_mode, text_size_mode, ui_text_mode, color_theme_mode, flip_animation_mode,
                     music_muted, confetti_mode, review_control_mode) >= 0;
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(SETTINGS_TEMP_PATH, SETTINGS_PATH, SETTINGS_BACKUP_PATH))
        remove(SETTINGS_TEMP_PATH);
}

static int clock_date_is_invalid(void) {
    time_t now = time(NULL);
    if (now == (time_t)-1) return 1;
    long long epoch = (long long)now;
    return epoch < MIN_VALID_CLOCK_EPOCH || epoch >= MAX_VALID_CLOCK_EPOCH;
}

static void refresh_clock_warning(void) {
    clock_warning_active = !live_sync && !demo_mode && clock_date_is_invalid();
}

static int file_exists(const char *path) {
    FILE *file = fopen(path, "rb");
    if (!file) return 0;
    fclose(file);
    return 1;
}

static void recover_atomic_file(const char *destination, const char *temporary,
                                const char *backup) {
    int has_destination = file_exists(destination);
    int has_temporary = file_exists(temporary);
    int has_backup = file_exists(backup);
    if (has_destination) {
        if (has_temporary) remove(temporary);
        if (has_backup) remove(backup);
        return;
    }
    if (has_backup && has_temporary && rename(temporary, destination) == 0) {
        remove(backup);
        return;
    }
    if (has_backup && rename(backup, destination) == 0) {
        if (has_temporary) remove(temporary);
        return;
    }
    if (has_temporary) remove(temporary);
}

static int atomic_replace_file(const char *temporary, const char *destination,
                               const char *backup) {
    int has_destination = file_exists(destination);
    remove(backup);
    if (has_destination && rename(destination, backup) != 0) return 0;
    if (rename(temporary, destination) != 0) {
        if (has_destination) rename(backup, destination);
        return 0;
    }
    if (has_destination) remove(backup);
    return 1;
}

static void copy_file_if_missing(const char *source, const char *destination) {
    if (file_exists(destination)) return;
    FILE *input = fopen(source, "rb");
    if (!input) return;
    char temporary[640];
    int length = snprintf(temporary, sizeof(temporary), "%s.tmp", destination);
    if (length < 0 || (size_t)length >= sizeof(temporary)) {
        fclose(input);
        return;
    }
    remove(temporary);
    FILE *output = fopen(temporary, "wb");
    if (!output) {
        fclose(input);
        return;
    }

    char buffer[8192];
    size_t bytes;
    int ok = 1;
    while ((bytes = fread(buffer, 1, sizeof(buffer), input)) > 0) {
        if (fwrite(buffer, 1, bytes, output) != bytes) {
            ok = 0;
            break;
        }
    }
    if (ferror(input)) ok = 0;
    if (fclose(output) != 0) ok = 0;
    if (fclose(input) != 0) ok = 0;
    if (ok && rename(temporary, destination) == 0) return;
    remove(temporary);
}

static int has_extension(const char *name, const char *extension) {
    const char *dot = strrchr(name, '.');
    if (!dot) return 0;
    while (*dot && *extension) {
        if (tolower((unsigned char)*dot) != tolower((unsigned char)*extension)) return 0;
        dot++;
        extension++;
    }
    return *dot == '\0' && *extension == '\0';
}

static void add_deck(const char *path, const char *filename, int is_apkg) {
    if (deck_count >= MAX_DECKS) return;
    for (int i = 0; i < deck_count; i++)
        if (!strcmp(deck_entries[i].path, path)) return;

    DeckEntry *entry = &deck_entries[deck_count++];
    snprintf(entry->path, sizeof(entry->path), "%s", path);
    snprintf(entry->name, sizeof(entry->name), "%s", filename);
    char *dot = strrchr(entry->name, '.');
    if (dot) *dot = '\0';
    entry->is_apkg = is_apkg;
}

static int deck_index_for_path(const char *path) {
    if (!path || !path[0]) return -1;
    for (int i = 0; i < deck_count; i++)
        if (!strcmp(deck_entries[i].path, path)) return i;
    return -1;
}

static int compare_decks(const void *left, const void *right) {
    const DeckEntry *a = (const DeckEntry *)left;
    const DeckEntry *b = (const DeckEntry *)right;
    return strcmp(a->name, b->name);
}

static void scan_decks(void) {
    char selected_path[512] = "";
    if (list_selection >= 0 && list_selection < deck_count)
        snprintf(selected_path, sizeof(selected_path), "%s", deck_entries[list_selection].path);
    deck_count = 0;
    if (file_exists(APKG_PATH)) add_deck(APKG_PATH, "import.apkg", 1);

    SceUID directory = sceIoDopen(DECK_FOLDER);
    if (directory >= 0) {
        SceIoDirent item;
        memset(&item, 0, sizeof(item));
        while (sceIoDread(directory, &item) > 0) {
            if (item.d_name[0] == '.' ||
                (!has_extension(item.d_name, ".apkg") && !has_extension(item.d_name, ".tsv"))) {
                memset(&item, 0, sizeof(item));
                continue;
            }
            char path[512];
            int length = snprintf(path, sizeof(path), "%s/%s", DECK_FOLDER, item.d_name);
            if (length < 0 || (size_t)length >= sizeof(path)) {
                memset(&item, 0, sizeof(item));
                continue;
            }
            add_deck(path, item.d_name, has_extension(item.d_name, ".apkg"));
            memset(&item, 0, sizeof(item));
        }
        sceIoDclose(directory);
    }

    if (file_exists(DECK_PATH)) add_deck(DECK_PATH, "cards.tsv", 0);
    qsort(deck_entries, (size_t)deck_count, sizeof(deck_entries[0]), compare_decks);

    current_deck_index = deck_index_for_path(current_deck_path);
    int selected_index = deck_index_for_path(selected_path);
    if (selected_index >= 0) list_selection = selected_index;
    else if (current_deck_index >= 0) list_selection = current_deck_index;
    else if (deck_count == 0) list_selection = 0;
    else if (list_selection >= deck_count) list_selection = deck_count - 1;
}

static void load_saved_deck_path(void) {
    recover_atomic_file(ACTIVE_DECK_PATH, ACTIVE_DECK_TEMP_PATH, ACTIVE_DECK_BACKUP_PATH);
    FILE *file = fopen(ACTIVE_DECK_PATH, "r");
    if (!file) return;
    if (fgets(saved_deck_path, sizeof(saved_deck_path), file)) {
        char *end = strpbrk(saved_deck_path, "\r\n");
        if (end) *end = '\0';
    }
    fclose(file);
}

static void save_active_deck(void) {
    if (!current_deck_path[0]) return;
    recover_atomic_file(ACTIVE_DECK_PATH, ACTIVE_DECK_TEMP_PATH, ACTIVE_DECK_BACKUP_PATH);
    remove(ACTIVE_DECK_TEMP_PATH);
    FILE *file = fopen(ACTIVE_DECK_TEMP_PATH, "w");
    if (!file) return;
    int ok = fprintf(file, "%s\n", current_deck_path) >= 0;
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(ACTIVE_DECK_TEMP_PATH, ACTIVE_DECK_PATH,
                                    ACTIVE_DECK_BACKUP_PATH))
        remove(ACTIVE_DECK_TEMP_PATH);
}

static void set_progress_path(const char *deck_path) {
    if (!strcmp(deck_path, APKG_PATH) || !strcmp(deck_path, DECK_PATH)) {
        snprintf(current_progress_path, sizeof(current_progress_path), "%s", PROGRESS_PATH);
        return;
    }
    unsigned int hash = 2166136261u;
    for (const unsigned char *p = (const unsigned char *)deck_path; *p; p++) {
        hash ^= *p;
        hash *= 16777619u;
    }
    snprintf(current_progress_path, sizeof(current_progress_path),
             "ux0:data/VitaAnki/progress_%08x.tsv", hash);
}

static int load_tsv(const char *path) {
    FILE *file = fopen(path, "r");
    if (!file) return -7;

    int count = 0;
    char row[FIELD_SIZE * 2 + 4];
    while (count < MAX_CARDS && fgets(row, sizeof(row), file)) {
        if (!strchr(row, '\n') && !feof(file)) {
            int ch;
            while ((ch = fgetc(file)) != '\n' && ch != EOF) {}
            continue;
        }
        char *end = strpbrk(row, "\r\n");
        if (end) *end = '\0';
        char *front = row;
        if (strlen(front) >= 3 && (unsigned char)front[0] == 0xEF &&
            (unsigned char)front[1] == 0xBB && (unsigned char)front[2] == 0xBF) front += 3;
        char *tab = strchr(row, '\t');
        if (!tab) continue;
        *tab++ = '\0';
        if (front != row) front = row + 3;
        char *extra_field = strchr(tab, '\t');
        if (extra_field) *extra_field = '\0';
        if (!front[0] && !tab[0]) continue;
        if (!vitaanki_reserve_cards(&cards, &card_capacity, count + 1)) {
            fclose(file);
            return -8;
        }
        snprintf(cards[count].front, FIELD_SIZE, "%.*s", FIELD_SIZE - 1, front);
        snprintf(cards[count].back, FIELD_SIZE, "%.*s", FIELD_SIZE - 1, tab);
        cards[count].front_image[0] = '\0';
        cards[count].card_id = count + 1;
        cards[count].interval_days = 0;
        cards[count].due = 0;
        cards[count].state = CARD_STATE_NEW;
        count++;
    }
    fclose(file);
    return count;
}

static void load_progress(void) {
    char temporary[128];
    char backup[128];
    snprintf(temporary, sizeof(temporary), "%s.tmp", current_progress_path);
    snprintf(backup, sizeof(backup), "%s.bak", current_progress_path);
    recover_atomic_file(current_progress_path, temporary, backup);
    FILE *file = fopen(current_progress_path, "r");
    if (!file) return;
    char row[128];
    while (fgets(row, sizeof(row), file)) {
        if (!strchr(row, '\n') && !feof(file)) {
            int ch;
            while ((ch = fgetc(file)) != '\n' && ch != EOF) {}
            continue;
        }
        long long card_id;
        long long due;
        int interval;
        int stored_state = -1;
        int fields = sscanf(row, "%lld\t%d\t%lld\t%d",
                            &card_id, &interval, &due, &stored_state);
        if (fields < 3 || card_id <= 0) continue;
        for (int i = 0; i < card_count; i++) {
            if (cards[i].card_id == card_id) {
                cards[i].interval_days = interval;
                cards[i].due = due;
                if (fields >= 4 && stored_state >= CARD_STATE_NEW &&
                    stored_state <= CARD_STATE_REVIEW)
                    cards[i].state = (CardState)stored_state;
                else if (interval > 0)
                    cards[i].state = CARD_STATE_REVIEW;
                else if (due > 0)
                    cards[i].state = CARD_STATE_LEARNING;
                else
                    cards[i].state = CARD_STATE_NEW;
                break;
            }
        }
    }
    fclose(file);
}

static void save_progress(void) {
    char temporary[128];
    char backup[128];
    snprintf(temporary, sizeof(temporary), "%s.tmp", current_progress_path);
    snprintf(backup, sizeof(backup), "%s.bak", current_progress_path);
    recover_atomic_file(current_progress_path, temporary, backup);
    remove(temporary);
    FILE *file = fopen(temporary, "w");
    if (!file) return;
    int ok = 1;
    for (int i = 0; i < card_count; i++)
        if (fprintf(file, "%lld\t%d\t%lld\t%d\n", cards[i].card_id,
                    cards[i].interval_days, cards[i].due, (int)cards[i].state) < 0) {
            ok = 0;
            break;
        }
    if (fclose(file) != 0) ok = 0;
    if (!ok || !atomic_replace_file(temporary, current_progress_path, backup))
        remove(temporary);
}

static int find_next_due(void) {
    if (card_count <= 0) return -1;
    long long now = (long long)time(NULL);
    int start = card_index >= 0 && card_index < card_count ? card_index : 0;
    const CardState priority[] = {
        CARD_STATE_LEARNING,
        CARD_STATE_REVIEW,
        CARD_STATE_NEW
    };
    for (int pass = 0; pass < (int)(sizeof(priority) / sizeof(priority[0])); pass++) {
        for (int step = 0; step < card_count; step++) {
            int i = (start + step) % card_count;
            if (cards[i].state != priority[pass]) continue;
            if (cards[i].state == CARD_STATE_NEW) {
                if (new_cards_this_session < NEW_CARD_BATCH_SIZE) return i;
            } else if (cards[i].due <= now) {
                return i;
            }
        }
    }
    return -1;
}

static int has_study_card(void) {
    return card_count > 0 && card_index >= 0 && card_index < card_count;
}

static AnkiStudyCounts current_study_counts(int *valid) {
    AnkiStudyCounts counts = {0, 0, 0};
    if (live_sync) {
        *valid = anki_connect_get_study_counts(&counts);
        return counts;
    }

    long long now = (long long)time(NULL);
    for (int i = 0; i < card_count; i++) {
        if (cards[i].state == CARD_STATE_NEW) counts.new_count++;
        else if (cards[i].state == CARD_STATE_LEARNING) counts.learning_count++;
        else if (cards[i].state == CARD_STATE_REVIEW && cards[i].due <= now)
            counts.review_count++;
    }
    *valid = 1;
    return counts;
}

static uint32_t confetti_random(void) {
    confetti_rng ^= confetti_rng << 13;
    confetti_rng ^= confetti_rng >> 17;
    confetti_rng ^= confetti_rng << 5;
    return confetti_rng;
}

static void start_confetti(void) {
    if (confetti_mode == 0) return;
    const unsigned int colors[] = {ACCENT, GREEN, YELLOW, RED, ACCENT};
    for (int i = 0; i < (int)(sizeof(confetti) / sizeof(confetti[0])); i++) {
        uint32_t r = confetti_random();
        confetti[i].x = (float)(r % SCREEN_W);
        confetti[i].y = -(float)(confetti_random() % 150);
        confetti[i].vx = (float)((int)(confetti_random() % 7) - 3) * 0.45f;
        confetti[i].vy = 3.5f + (float)(confetti_random() % 5) * 0.8f;
        confetti[i].width = 4 + (int)(confetti_random() % 5);
        confetti[i].height = 7 + (int)(confetti_random() % 6);
        confetti[i].color = colors[confetti_random() % (sizeof(colors) / sizeof(colors[0]))];
    }
    confetti_frames = 96;
}

static void update_confetti(void) {
    if (confetti_mode == 0) {
        confetti_frames = 0;
        return;
    }
    if (confetti_frames <= 0) return;
    for (int i = 0; i < (int)(sizeof(confetti) / sizeof(confetti[0])); i++) {
        confetti[i].x += confetti[i].vx;
        confetti[i].y += confetti[i].vy;
        confetti[i].vy += 0.035f;
        if (confetti[i].x < -10) confetti[i].x = SCREEN_W + 8;
        else if (confetti[i].x > SCREEN_W + 10) confetti[i].x = -8;
    }
    confetti_frames--;
}

static void draw_confetti(void) {
    if (confetti_mode == 0 || confetti_frames <= 0) return;
    for (int i = 0; i < (int)(sizeof(confetti) / sizeof(confetti[0])); i++) {
        if (confetti[i].y > -15 && confetti[i].y < SCREEN_H)
            vita2d_draw_rectangle(confetti[i].x, confetti[i].y,
                                  confetti[i].width, confetti[i].height,
                                  confetti[i].color);
    }
}

static int select_deck(int index) {
    if (index < 0 || index >= deck_count) return 0;
    anki_connect_note_offline_deck();
    live_sync = 0;
    apkg_mode = 0;
    sync_queue_error = 0;
    demo_mode = 0;
    import_error = 0;
    import_error_code = 0;
    reviewed = 0;
    new_cards_this_session = 0;
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_lines = 0;
    selected_rating = 2;
    undo_record.valid = 0;
    undo_error = 0;
    card_count = 0;

    DeckEntry *entry = &deck_entries[index];
    int music_was_running = entry->is_apkg && anki_music_is_running();
    int resume_music = music_was_running && !anki_music_is_muted();
    if (music_was_running) anki_music_stop();
    int loaded;
    if (entry->is_apkg) {
        int reload_custom_font = font_pgf != NULL;
        if (card_image_texture) {
            vita2d_free_texture(card_image_texture);
            card_image_texture = NULL;
            card_image_path_cached[0] = '\0';
        }
        if (reload_custom_font) release_custom_fonts();
        free(cards);
        cards = NULL;
        card_capacity = 0;
        loaded = import_apkg(entry->path, &cards, &card_capacity, MAX_CARDS);
        if (reload_custom_font && !font_mode_available(font_mode)) {
            font_mode = 0;
            save_settings();
        }
    } else {
        loaded = load_tsv(entry->path);
    }
    if (resume_music) anki_music_start();
    if (loaded < 0) {
        import_error = 1;
        import_error_code = loaded;
        current_screen = SCREEN_IMPORT;
        return 0;
    }

    card_count = loaded;
    apkg_mode = entry->is_apkg;
    current_deck_index = index;
    snprintf(current_deck_name, sizeof(current_deck_name), "%s", entry->name);
    snprintf(current_deck_path, sizeof(current_deck_path), "%s", entry->path);
    set_progress_path(entry->path);
    load_progress();
    card_index = card_count > 0 ? find_next_due() : 0;
    save_active_deck();
    current_screen = SCREEN_STUDY;
    return 1;
}

static void load_demo_deck(void) {
    demo_mode = 1;
    apkg_mode = 0;
    sync_queue_error = 0;
    import_error = 0;
    import_error_code = 0;
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_lines = 0;
    selected_rating = 2;
    undo_record.valid = 0;
    undo_error = 0;
    current_deck_index = -1;
    current_deck_path[0] = '\0';
    current_progress_path[0] = '\0';
    snprintf(current_deck_name, sizeof(current_deck_name), "Demo deck");
    int demo_count = (int)(sizeof(demo_cards) / sizeof(demo_cards[0]));
    if (!vitaanki_reserve_cards(&cards, &card_capacity, demo_count)) {
        card_count = 0;
        card_index = 0;
        return;
    }
    card_count = demo_count;
    for (int i = 0; i < card_count; i++) cards[i] = demo_cards[i];
    card_index = 0;
}

static int find_saved_deck(void) {
    for (int i = 0; i < deck_count; i++)
        if (saved_deck_path[0] && !strcmp(deck_entries[i].path, saved_deck_path)) return i;
    for (int i = 0; i < deck_count; i++)
        if (!strcmp(deck_entries[i].path, INCLUDED_DECK_PATH)) return i;
    return deck_count > 0 ? 0 : -1;
}

static void maybe_start_confetti(int rating) {
    if ((confetti_mode == 1 && rating >= 2) || (confetti_mode == 2 && rating == 3))
        start_confetti();
}

static int next_interval_days(int interval, int rating) {
    long long next;
    if (rating == 0) return 0;
    if (rating == 1) next = interval < 1 ? 1 : ((long long)interval * 12 + 9) / 10;
    else if (rating == 2) next = interval < 1 ? 1 : (long long)interval * 2;
    else next = interval < 1 ? 4 : (long long)interval * 3;
    if (next > MAX_INTERVAL_DAYS) next = MAX_INTERVAL_DAYS;
    return (int)next;
}

static void rate_card(int rating) {
    if (rating < 0 || rating > 3 || flip_frames_remaining > 0 || card_count <= 0 ||
        card_index < 0 || card_index >= card_count) return;
    UndoRecord last_review = {0};
    last_review.card_id = cards[card_index].card_id;
    last_review.previous_index = card_index;
    last_review.previous_reviewed = reviewed;
    last_review.previous_new_cards_this_session = new_cards_this_session;
    last_review.rating = rating;
    if (live_sync) {
        if (!anki_connect_answer(cards[card_index].card_id, rating + 1)) {
            sync_error = 1;
            return;
        }
        last_review.valid = 1;
        last_review.live = 1;
        undo_record = last_review;
        undo_error = 0;
        maybe_start_confetti(rating);
        reviewed++;
        int refreshed = anki_connect_reload(cards, card_capacity);
        live_refresh_after = time(NULL) + LIVE_REFRESH_SECONDS;
        if (refreshed < 0) {
            sync_error = 1;
            card_count = 0;
            return;
        }
        card_count = refreshed;
        card_index = 0;
        show_answer = 0;
        flip_frames_remaining = 0;
        card_scroll_lines = 0;
        selected_rating = 2;
        return;
    }

    Card *card = &cards[card_index];
    if (card->state == CARD_STATE_NEW) new_cards_this_session++;
    last_review.previous_interval_days = card->interval_days;
    last_review.previous_due = card->due;
    last_review.previous_state = card->state;
    int interval = card->interval_days;
    CardState previous_state = card->state;
    long long now = (long long)time(NULL);
    if (rating == 0) {
        card->interval_days = 0;
        card->due = now + AGAIN_STEP_SECONDS;
        card->state = CARD_STATE_LEARNING;
    } else if (rating == 1 && previous_state != CARD_STATE_REVIEW) {
        card->interval_days = 0;
        card->due = now + HARD_STEP_SECONDS;
        card->state = CARD_STATE_LEARNING;
    } else {
        card->interval_days = next_interval_days(interval, rating);
        card->due = now + (long long)card->interval_days * 86400LL;
        card->state = CARD_STATE_REVIEW;
    }
    if (apkg_mode) {
        last_review.queued = anki_connect_queue_review(card->card_id, rating + 1);
        if (!last_review.queued) sync_queue_error = 1;
    }
    last_review.valid = 1;
    undo_record = last_review;
    undo_error = 0;
    maybe_start_confetti(rating);
    reviewed++;
    save_progress();
    card_index = find_next_due();
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_lines = 0;
    selected_rating = 2;
}

static int find_card_index_by_id(long long card_id) {
    for (int i = 0; i < card_count; i++)
        if (cards[i].card_id == card_id) return i;
    return -1;
}

static void undo_last_rating(void) {
    if (!undo_record.valid) return;
    UndoRecord last_review = undo_record;

    if (last_review.live) {
        if (!anki_connect_undo()) {
            undo_error = 1;
            return;
        }
        int refreshed = anki_connect_reload(cards, card_capacity);
        live_refresh_after = time(NULL) + LIVE_REFRESH_SECONDS;
        reviewed = last_review.previous_reviewed;
        new_cards_this_session = last_review.previous_new_cards_this_session;
        undo_record.valid = 0;
        if (refreshed < 0) {
            sync_error = 1;
            card_count = 0;
            undo_error = 1;
            return;
        }
        card_count = refreshed;
        int index = find_card_index_by_id(last_review.card_id);
        if (index < 0) {
            card_index = 0;
            show_answer = 0;
            undo_error = 1;
        } else {
            card_index = index;
            show_answer = 1;
            undo_error = 0;
        }
    } else {
        if (last_review.queued &&
            !anki_connect_cancel_queued_review(last_review.card_id, last_review.rating + 1)) {
            undo_error = 1;
            return;
        }
        int index = find_card_index_by_id(last_review.card_id);
        if (index < 0 && last_review.previous_index >= 0 &&
            last_review.previous_index < card_count)
            index = last_review.previous_index;
        if (index < 0) {
            undo_error = 1;
            return;
        }
        cards[index].interval_days = last_review.previous_interval_days;
        cards[index].due = last_review.previous_due;
        cards[index].state = last_review.previous_state;
        save_progress();
        reviewed = last_review.previous_reviewed;
        new_cards_this_session = last_review.previous_new_cards_this_session;
        card_index = index;
        show_answer = 1;
        undo_error = 0;
    }

    flip_frames_remaining = 0;
    card_scroll_lines = 0;
    selected_rating = last_review.rating;
    confetti_frames = 0;
    undo_record.valid = 0;
    current_screen = SCREEN_STUDY;
}

static void toggle_music(void) {
#ifdef VITAANKI_DISABLE_MUSIC
    music_muted = 1;
#else
    music_muted = !anki_music_is_muted();
    anki_music_set_muted(music_muted);
    save_settings();
#endif
}

static void draw_home(void) {
    draw_header("VitaAnki v" APP_VERSION, "A pocket-sized Anki study companion");
    char study_subtitle[160];
    if (live_sync) snprintf(study_subtitle, sizeof(study_subtitle), "Live deck  |  %d cards due", card_count);
    else snprintf(study_subtitle, sizeof(study_subtitle), "%s  |  %d cards", current_deck_name, card_count);

    draw_button(home_buttons[0], "Study", study_subtitle, ACCENT, home_selection == 0);
    draw_button(home_buttons[1], "Choose a deck", "Switch your offline study deck", GREEN, home_selection == 1);
    draw_button(home_buttons[2], "Import a deck", "Add an Anki .apkg or .tsv", YELLOW, home_selection == 2);
    draw_button(home_buttons[3], "Settings", "Fonts, card size, and review controls", ACCENT, home_selection == 3);
    draw_compact_button(browser_button, "CARD BROWSER", ACCENT, home_selection == 4);
    draw_compact_button(sync_button, "STUDY SOURCE", GREEN, home_selection == 5);
    draw_compact_button(android_transfer_button, "SEND FROM ANDROID", YELLOW, home_selection == 6);
    if (clock_warning_active)
        draw_fit_text(48, 488, YELLOW, 0.48f,
                      "Vita date/time looks wrong. Offline review times may be incorrect.", 860);
    else
    draw_fit_text(48, 488, MUTED, 0.52f,
                  "D-pad + X to choose  |  Audio disabled for stability  |  START exits", 864);
    draw_fit_text(48, 520, MUTED, 0.46f, anki_connect_get_status(), 860);
}

static void toggle_android_transfer_receiver(void) {
    AndroidTransferState state = android_transfer_get_state();
    if (state == ANDROID_TRANSFER_STARTING || state == ANDROID_TRANSFER_WAITING ||
        state == ANDROID_TRANSFER_RECEIVING) {
        android_transfer_stop();
        return;
    }
    if (live_sync) {
        select_offline_source();
        current_screen = SCREEN_ANDROID_TRANSFER;
    }
    android_transfer_start();
}

static void draw_android_transfer(void) {
    AndroidTransferState state = android_transfer_get_state();
    draw_header("Receive from Android", "One-time local Wi-Fi transfer into this app");
    draw_wrapped("Keep the Vita and phone on the same Wi-Fi. Start the receiver here, then enter the address, port, and one-time code shown below in VitaAnki Mobile.",
                 72, 124, 816, 0.68f, WHITE);

    draw_text(72, 224, MUTED, 0.58f, "VITA ADDRESS");
    draw_fit_text(72, 264, WHITE, 0.96f,
                  state == ANDROID_TRANSFER_IDLE || state == ANDROID_TRANSFER_STOPPED
                      ? "Start receiver to show the Wi-Fi address"
                      : android_transfer_get_ip(), 800);
    draw_text(72, 316, MUTED, 0.58f, "PORT");
    draw_text(160, 316, WHITE, 0.62f, "27117");
    draw_text(292, 316, MUTED, 0.58f, "ONE-TIME CODE");
    draw_text(490, 316, ACCENT, 0.72f,
              state == ANDROID_TRANSFER_IDLE || state == ANDROID_TRANSFER_STOPPED
                  ? "------" : android_transfer_get_pin());

    draw_wrapped(android_transfer_get_message(), 72, 362, 816, 0.62f,
                 state == ANDROID_TRANSFER_ERROR ? RED : state == ANDROID_TRANSFER_RECEIVED ? GREEN : WHITE);
    if (state == ANDROID_TRANSFER_RECEIVING) {
        char progress[48];
        snprintf(progress, sizeof(progress), "Receiving deck: %d%%", android_transfer_get_progress());
        draw_text(72, 406, ACCENT, 0.54f, progress);
    } else if (state == ANDROID_TRANSFER_RECEIVED) {
        draw_fit_text(72, 408, GREEN, 0.50f, android_transfer_get_filename(), 280);
    }

    draw_compact_button(android_transfer_start_button,
        state == ANDROID_TRANSFER_STARTING || state == ANDROID_TRANSFER_WAITING || state == ANDROID_TRANSFER_RECEIVING
            ? "STOP RECEIVER" : "START RECEIVER", ACCENT, 0);
    draw_compact_button(android_transfer_decks_button, "OPEN DECKS", GREEN, 0);
    draw_fit_text(610, 454, MUTED, 0.42f, "Accepts one .apkg or .tsv deck", 290);
}

static void draw_sync(void) {
    draw_header("Study source", live_sync ? "Live PC mode is active." : "Choose offline study or connect to Anki Desktop.");
    const char *offline_name = current_deck_index >= 0 && current_deck_index < deck_count
                             ? deck_entries[current_deck_index].name
                             : (demo_mode ? "Demo deck" : current_deck_name);
    char offline_description[160];
    if (live_sync)
        snprintf(offline_description, sizeof(offline_description),
                 "Resume offline deck: %.100s", offline_name);
    else
        snprintf(offline_description, sizeof(offline_description),
                 "Active offline deck: %.100s", offline_name);
    const char *live_title = live_sync ? "REFRESH LIVE PC DECK"
                           : anki_connect_is_configured() ? "CONNECT TO LIVE PC"
                           : "LIVE PC SETUP NEEDED";
    const char *live_description = live_sync
        ? "Connected. Refresh the due cards from Anki Desktop."
        : anki_connect_is_configured()
        ? "Connect only when you choose this source."
        : "Configure AnkiConnect to use your PC deck.";
    draw_button(sync_offline_button, live_sync ? "DISCONNECT + USE OFFLINE" : "USE OFFLINE DECK",
                offline_description, GREEN, sync_selection == 0);
    draw_button(sync_live_button, live_title, live_description, ACCENT, sync_selection == 1);

    draw_text(72, 278, MUTED, 0.62f, "Connection status");
    const char *status = sync_message[0] ? sync_message : anki_connect_get_status();
    draw_wrapped(status, 72, 316, 812, 0.58f,
                 sync_error ? RED : WHITE);
    if (!anki_connect_is_configured())
        draw_wrapped("Setup: copy sync.example.ini to ux0:data/VitaAnki/sync.ini, then enter your PC address, exact deck name, and AnkiConnect key.",
                     72, 370, 812, 0.46f, MUTED);
    else
        draw_wrapped("Offline progress stays on the Vita. Live ratings go to Anki Desktop while connected.",
                     72, 378, 812, 0.48f, MUTED);
    draw_fit_text(72, 492, MUTED, 0.46f,
                  "Touch a source or use left/right + Cross. Circle returns.", 812);
}

static void select_offline_source(void) {
    int offline_index = current_deck_index;
    if (live_sync) {
        anki_connect_note_offline_deck();
        live_sync = 0;
        live_refresh_after = 0;
        sync_error = 0;
        undo_record.valid = 0;
        if (offline_index >= 0 && offline_index < deck_count) {
            if (!select_deck(offline_index)) load_demo_deck();
        } else {
            load_demo_deck();
        }
    }
    show_answer = 0;
    flip_frames_remaining = 0;
    card_scroll_lines = 0;
    current_screen = SCREEN_STUDY;
}

static void activate_sync_selection(void) {
    if (sync_selection == 0) select_offline_source();
    else begin_pc_sync();
}

static int first_visible_deck(void) {
    int first = list_selection - 1;
    if (first < 0) first = 0;
    if (first + LIST_VISIBLE > deck_count) first = deck_count - LIST_VISIBLE;
    if (first < 0) first = 0;
    return first;
}

static void draw_deck_list(int importing) {
    const char *title = importing ? "Import a deck" : "Choose a deck";
    const char *subtitle = importing
        ? "Copy a .apkg or .tsv deck here, rescan, then tap its row."
        : "Select a deck source for offline study.";
    draw_header(title, subtitle);

    const char *error_message = NULL;
    if (import_error) {
        error_message = "The package could not be imported.";
        if (import_error_code == -1) error_message = "This .apkg file could not be opened. Re-export it from Anki as a compatible package.";
        else if (import_error_code == -2) error_message = "This package has no collection.anki2 or collection.anki21 database.";
        else if (import_error_code == -3) error_message = import_apkg_diagnostic();
        else if (import_error_code == -4) error_message = "This Anki database uses a card format the importer could not read.";
        else if (import_error_code == -6) error_message = import_apkg_diagnostic();
        else if (import_error_code == -7) error_message = "The selected deck file could not be opened. Check that it is still present, then rescan.";
        else if (import_error_code == -8) error_message = "Not enough memory to load this deck. Try a smaller TSV deck.";
        else if (import_error_code == -9) error_message = import_apkg_diagnostic();
    }

    if (deck_count == 0) {
        draw_text(76, 188, WHITE, 0.82f, "No deck files found");
        draw_wrapped("In VitaShell, copy a .apkg or .tsv file to ux0:data/VitaAnki/decks. Then tap Rescan and open it. The built-in Anatomy deck is normally listed here.",
                     76, 230, 790, 0.68f, MUTED);
    } else {
        int first = first_visible_deck();
        for (int row = 0; row < LIST_VISIBLE; row++) {
            int index = first + row;
            if (index >= deck_count) break;
            UiRect rect = {60, LIST_ROW_Y + row * LIST_ROW_H, 840, 54};
            int active = current_deck_path[0] &&
                         !strcmp(deck_entries[index].path, current_deck_path);
            unsigned int fill = index == list_selection ? PANEL_HI : PANEL;
            vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h, fill);
            vita2d_draw_rectangle(rect.x, rect.y, 4, rect.h, active ? GREEN : (index == list_selection ? ACCENT : PANEL));
            draw_fit_text(rect.x + 18, rect.y + 26, WHITE, 0.68f, deck_entries[index].name, 660);
            draw_text(rect.x + 18, rect.y + 46, MUTED, 0.42f,
                      deck_entries[index].is_apkg ? "Anki package (.apkg)" : "Tab-separated deck (.tsv)");
            if (active) draw_text(rect.x + rect.w - 102, rect.y + 34, GREEN, 0.42f, "CURRENT");
        }
        if (!import_error)
            draw_fit_text(62, 406, MUTED, 0.48f, importing
                          ? "Tap a row or choose Import & Study."
                          : "Tap a row or choose Open Selected.", 814);
    }

    if (error_message)
        draw_wrapped(error_message, 76, 392, 800, 0.40f, RED);

    UiRect open_selected = {60, 458, 226, 52};
    UiRect rescan = {304, 458, 172, 52};
    draw_compact_button(open_selected, importing ? "IMPORT & STUDY" : "OPEN SELECTED", GREEN, 0);
    draw_compact_button(rescan, "RESCAN", YELLOW, 0);
    draw_fit_text(500, 490, MUTED, 0.48f, "Triangle rescan  |  Circle back", 410);
}

static void cycle_setting(int setting, int direction) {
    if (setting == 0) {
        int previous_font_mode = font_mode;
        for (int step = 0; step < 6; step++) {
            int candidate = (font_mode + (direction >= 0 ? step + 1 : 5 - step) + 6) % 6;
            if (font_mode_available(candidate)) {
                font_mode = candidate;
                break;
            }
        }
        if (font_mode != previous_font_mode) release_custom_font(previous_font_mode);
    } else if (setting == 1) {
        ui_text_mode = (ui_text_mode + (direction >= 0 ? 1 : 2)) % 3;
    } else if (setting == 2) {
        text_size_mode = (text_size_mode + (direction >= 0 ? 1 : 3)) % 4;
    } else if (setting == 3) {
        flip_animation_mode = !flip_animation_mode;
        if (!flip_animation_mode) flip_frames_remaining = 0;
    } else if (setting == 4) {
#ifndef VITAANKI_DISABLE_MUSIC
        toggle_music();
#endif
        return;
    } else if (setting == 5) {
        confetti_mode = (confetti_mode + (direction >= 0 ? 1 : 2)) % 3;
        if (confetti_mode == 0) confetti_frames = 0;
    } else if (setting == 6) {
        review_control_mode = !review_control_mode;
    } else if (setting == 7) {
        int theme_count = (int)(sizeof(color_themes) / sizeof(color_themes[0]));
        color_theme_mode = (color_theme_mode + (direction >= 0 ? 1 : theme_count - 1)) % theme_count;
        apply_color_theme(color_theme_mode);
        vita2d_set_clear_color(BG);
    }
    save_settings();
}

static void draw_settings(void) {
    draw_header("Settings", "Reading and review controls");
    const char *font_label = font_labels[font_mode];
#ifdef VITAANKI_DISABLE_MUSIC
    const char *music_label = "Disabled in this stability build";
    const char *music_title = "Background music (disabled)";
#else
    const char *music_label = anki_music_is_muted() ? "Muted"
                          : anki_music_is_available() ? "Playing"
                          : anki_music_is_running() ? "Starting..."
                          : "Unavailable / see music.log";
    const char *music_title = "Background music";
#endif
    const char *titles[8] = {"Font", "Menu and labels", "Card text size", "Answer flip",
                             music_title, "Confetti", "Rating controls", "Color theme"};
    const char *values[8] = {font_label, ui_text_labels[ui_text_mode],
                             text_size_labels[text_size_mode], flip_animation_labels[flip_animation_mode],
                             music_label, confetti_labels[confetti_mode],
                             review_control_mode ? "Stick + X + touch" : "Buttons + touch",
                             color_theme_labels[color_theme_mode]};
    unsigned int colors[8] = {ACCENT, ACCENT, GREEN, ACCENT, YELLOW, RED, GREEN, ACCENT};
    for (int i = 0; i < 8; i++) {
        UiRect row = settings_rows[i];
        int chosen = i == settings_selection;
        vita2d_draw_rectangle(row.x, row.y, row.w, row.h,
                              chosen ? PANEL_HI : PANEL);
        vita2d_draw_rectangle(row.x, row.y, 4, row.h, colors[i]);
        draw_fit_text(row.x + 22, row.y + 15, WHITE, 0.47f, titles[i], 590);
        draw_fit_text(row.x + 22, row.y + 33, MUTED, 0.33f, values[i], 590);
        vita2d_draw_rectangle(row.x + 728, row.y + 2, 46, 34, PANEL);
        vita2d_draw_rectangle(row.x + 784, row.y + 2, 46, 34, PANEL);
        draw_text(row.x + 744, row.y + 26, colors[i], 0.50f, "<");
        draw_text(row.x + 801, row.y + 26, colors[i], 0.50f, ">");
    }
    draw_fit_text(72, 458, MUTED, 0.44f, "Card preview:", 132);
    draw_card_text(210, 462, WHITE, 0.68f, "Aa Bb 123");
    draw_fit_text(72, 492, MUTED, 0.43f,
                  "D-pad / stick choose; left/right change. Cross selects; Circle returns.",
                  816);
    draw_fit_text(72, 520, MUTED, 0.43f,
                  "Stick + X: left/right choose, Cross confirms. Touch ratings work in either mode.",
                  816);
}

static void draw_flip_overlay(void) {
    if (flip_frames_remaining <= 0) return;
    const int x = 70, y = 140, width = 836, height = 291;
    int progress = CARD_FLIP_FRAMES - flip_frames_remaining;
    int half = CARD_FLIP_FRAMES / 2;
    int visible_width = progress <= half
                      ? width * (half - progress) / half
                      : width * (progress - half) / half;
    int cover_width = (width - visible_width) / 2;
    if (cover_width > 0) {
        vita2d_draw_rectangle(x, y, cover_width, height, PANEL);
        vita2d_draw_rectangle(x + width - cover_width, y, cover_width, height, PANEL);
    }
    if (progress > 0 && progress < CARD_FLIP_FRAMES) {
        int edge_left = x + cover_width - 1;
        int edge_right = x + cover_width + visible_width - 1;
        vita2d_draw_rectangle(edge_left, y + 4, 2, height - 8, ACCENT);
        if (visible_width > 4)
            vita2d_draw_rectangle(edge_right, y + 4, 2, height - 8, ACCENT);
    }
}

static void draw_study(void) {
    char subtitle[160];
    if (clock_warning_active && !live_sync) snprintf(subtitle, sizeof(subtitle), "OFFLINE  |  CHECK VITA DATE/TIME");
    else if (live_sync) snprintf(subtitle, sizeof(subtitle), "LIVE ANKI DESKTOP  |  %s", sync_error ? "connection issue" : "connected");
    else if (apkg_mode && sync_queue_error) snprintf(subtitle, sizeof(subtitle), "OFFLINE REVIEW  |  QUEUE SAVE FAILED");
    else if (sync_error && apkg_mode) snprintf(subtitle, sizeof(subtitle), "OFFLINE REVIEW  |  SYNC QUEUED");
    else if (apkg_mode) snprintf(subtitle, sizeof(subtitle), "OFFLINE REVIEW  |  SYNC QUEUED");
    else if (!anki_connect_is_configured()) snprintf(subtitle, sizeof(subtitle), "OFFLINE  |  ANKICONNECT SETUP NEEDED");
    else if (sync_error) snprintf(subtitle, sizeof(subtitle), "OFFLINE  |  SYNC CONNECTION LOST");
    else if (demo_mode) snprintf(subtitle, sizeof(subtitle), "DEMO DECK");
    else if (import_error) snprintf(subtitle, sizeof(subtitle), "IMPORT FAILED");
    else snprintf(subtitle, sizeof(subtitle), "%s", current_deck_name);
    draw_header("Study", NULL);
    draw_fit_text(184, 78, MUTED, 0.5f, subtitle, 320);
    int counts_available = 0;
    AnkiStudyCounts counts = current_study_counts(&counts_available);
    char new_text[24], learning_text[24], review_text[24], done_text[24];
    if (counts_available) {
        snprintf(new_text, sizeof(new_text), "NEW %d", counts.new_count);
        snprintf(learning_text, sizeof(learning_text), "LEARN %d", counts.learning_count);
        snprintf(review_text, sizeof(review_text), "REVIEW %d", counts.review_count);
    } else {
        snprintf(new_text, sizeof(new_text), "NEW --");
        snprintf(learning_text, sizeof(learning_text), "LEARN --");
        snprintf(review_text, sizeof(review_text), "REVIEW --");
    }
    snprintf(done_text, sizeof(done_text), "DONE %d", reviewed);
    draw_fit_text(518, 78, ACCENT, 0.42f, new_text, 82);
    draw_fit_text(604, 78, YELLOW, 0.42f, learning_text, 92);
    draw_fit_text(700, 78, GREEN, 0.42f, review_text, 104);
    draw_fit_text(808, 78, MUTED, 0.42f, done_text, 100);

    vita2d_draw_rectangle(48, 104, 864, 334, PANEL);
    vita2d_draw_rectangle(48, 104, 7, 334, ACCENT);
    draw_compact_button(undo_button, "UNDO (L)", undo_record.valid ? YELLOW : MUTED, 0);
    int has_card = has_study_card();
    int answer_visible = displayed_answer_side();
    const char *visible_text = has_card
                             ? (answer_visible ? cards[card_index].back : cards[card_index].front)
                             : "";
    const char *visible_image = has_card && !answer_visible ? cards[card_index].front_image : "";
    int split_card = visible_image[0] != '\0';
    int text_width = split_card ? 380 : 790;
    float text_scale = split_card ? 0.84f : 0.95f;
    int text_height = split_card ? 210 : 160;
    if (has_card) {
        int limit = card_scroll_limit(visible_text, text_width, text_scale, text_height);
        if (card_scroll_lines > limit) card_scroll_lines = limit;
    }
    if (card_count <= 0) {
        if (live_sync && !sync_error) {
            int learning_pending = anki_connect_has_learning_cards();
            draw_text(82, 160, learning_pending ? YELLOW : MUTED, 0.72f,
                      learning_pending ? "LEARNING STEP WAITING" : "NO CARDS DUE");
            draw_wrapped(learning_pending
                             ? "Anki has cards in learning. VitaAnki checks for the next due learning step every 10 seconds."
                             : "This deck has no new or due cards right now. Check back after another card becomes due.",
                         82, 225, 780, 0.78f, WHITE);
        } else {
            draw_text(82, 160, MUTED, 0.72f,
                      import_error ? "DECK COULD NOT BE LOADED" : "NO STUDY CARDS LOADED");
            draw_wrapped(import_error
                             ? "The selected deck could not be read. Open Decks, rescan, and choose it again."
                             : "The current deck has no available study cards. Choose another deck, or re-import this one if cards are missing.",
                         82, 225, 780, 0.78f, WHITE);
        }
    } else if (!has_card) {
        int unseen_new = 0;
        if (!live_sync)
            for (int i = 0; i < card_count; i++)
                if (cards[i].state == CARD_STATE_NEW) unseen_new++;
        if (unseen_new > 0 && new_cards_this_session >= NEW_CARD_BATCH_SIZE) {
            draw_text(82, 160, ACCENT, 0.72f, "NEW CARD BATCH COMPLETE");
            draw_wrapped("This batch is paced at 20 new cards. Learning steps and reviews return first when due. Go Home, then choose Study to start another batch.",
                         82, 225, 780, 0.78f, WHITE);
        } else {
            draw_text(82, 160, GREEN, 0.72f, "SESSION COMPLETE");
            draw_wrapped(counts.learning_count > 0
                             ? "A learning step is waiting and will return when due. Use Card Browser for a quick review."
                             : "Nothing is due right now. Use Card Browser to preview cards, or come back when the next card is due.",
                         82, 225, 780, 0.78f, WHITE);
        }
    } else if (!answer_visible) {
        draw_text(82, 156, MUTED, 0.66f, "QUESTION");
        draw_card_viewport(visible_text, 82, split_card ? 205 : 222, text_width, text_scale,
                           WHITE, card_scroll_lines, text_height);
        draw_card_scrollbar(visible_text, split_card ? 465 : 890, split_card ? 205 : 222,
                            text_width, text_scale, card_scroll_lines, text_height);
        if (split_card) draw_card_image_half(visible_image, 480, 205, 392, 210);
        draw_fit_text(82, split_card ? 426 : 410, clock_warning_active ? YELLOW : MUTED, 0.46f,
                      clock_warning_active
                          ? "Clock looks wrong; offline rating times may be incorrect."
                          : "Tap card or X to reveal  |  Left stick up/down scrolls",
                      790);
    } else {
        draw_text(82, 156, MUTED, 0.66f, "ANSWER");
        draw_card_viewport(visible_text, 82, 222, 790, 0.95f,
                           WHITE, card_scroll_lines, 160);
        draw_card_scrollbar(visible_text, 890, 222, 790, 0.95f,
                            card_scroll_lines, 160);
        draw_fit_text(82, 410, clock_warning_active ? YELLOW : MUTED, 0.44f,
                      clock_warning_active
                          ? "Clock looks wrong; offline rating times may be incorrect."
                          : live_sync
                          ? review_control_mode
                              ? "Stick up/down scroll; left/right choose; X rates. Touch ratings work too."
                              : "Stick up/down scroll  |  Triangle/Square/Circle/R or touch to rate"
                          : review_control_mode
                              ? "Offline: Again ~1m; Hard ~5m while learning. Left/right + X to rate."
                              : "Offline: Again ~1m; Hard ~5m while learning. Triangle/Square/Circle/R rate.",
                      790);
    }

    const int x = 50, y = 458, w = 164, gap = 10, h = 60;
    const char *labels[5] = {
        review_control_mode ? (answer_visible ? "X  RATE" : "X  REVEAL")
                            : (answer_visible ? "X  FLIP" : "X  REVEAL"),
        review_control_mode ? "AGAIN" : "TRIANGLE  AGAIN",
        review_control_mode ? "HARD" : "SQUARE  HARD",
        review_control_mode ? "GOOD" : "CIRCLE  GOOD",
        review_control_mode ? "EASY" : "R  EASY"
    };
    unsigned int accents[5] = {ACCENT, RED, YELLOW, GREEN, ACCENT};
    for (int i = 0; i < 5; i++) {
        UiRect rect = {x + i * (w + gap), y, w, h};
        int enabled = has_card && flip_frames_remaining == 0 && (i == 0 || answer_visible);
        int selected = review_control_mode && i > 0 && i - 1 == selected_rating;
        vita2d_draw_rectangle(rect.x, rect.y, rect.w, rect.h,
                              selected ? PANEL_HI : enabled ? PANEL : BG);
        vita2d_draw_rectangle(rect.x, rect.y, rect.w, 3, enabled ? accents[i] : PANEL_HI);
        draw_fit_text(rect.x + 8, rect.y + 36, enabled ? (i == 0 ? WHITE : accents[i]) : MUTED,
                      0.45f, labels[i], rect.w - 16);
    }
    if (undo_error)
        draw_fit_text(50, 533, RED, 0.40f,
                      "Undo failed. Check the Anki connection or pending review queue.",
                      860);
    else if (undo_record.valid)
        draw_fit_text(50, 533, MUTED, 0.40f,
                      undo_record.live
                          ? "Tap Undo or press L to undo Anki Desktop's latest action."
                          : "Tap Undo or press L to reverse the latest rating.",
                      860);
    draw_flip_overlay();
}

static void move_browser(int direction) {
    if (card_count <= 0) return;
    browser_index += direction;
    if (browser_index < 0) browser_index = card_count - 1;
    else if (browser_index >= card_count) browser_index = 0;
    browser_show_answer = 0;
    browser_scroll_lines = 0;
}

static void draw_browser(void) {
    draw_header("Card browser", current_deck_name);
    char status[64];
    snprintf(status, sizeof(status), "CARD %d OF %d", card_count > 0 ? browser_index + 1 : 0,
             card_count);
    draw_fit_text(748, 78, MUTED, 0.46f, status, 164);

    vita2d_draw_rectangle(48, 104, 864, 334, PANEL);
    vita2d_draw_rectangle(48, 104, 7, 334, ACCENT);
    if (card_count > 0) {
        int split = !browser_show_answer && cards[browser_index].front_image[0];
        int limit = card_scroll_limit(browser_card_text(), split ? 380 : 790,
                                      split ? 0.84f : 0.95f, split ? 210 : 160);
        if (browser_scroll_lines > limit) browser_scroll_lines = limit;
    }
    if (card_count <= 0) {
        draw_text(82, 160, MUTED, 0.72f, "NO CARDS TO BROWSE");
        draw_wrapped("Open Import to add an Anki package or tab-separated deck.",
                     82, 222, 780, 0.78f, WHITE);
    } else {
        draw_text(82, 156, MUTED, 0.66f, browser_show_answer ? "ANSWER" : "QUESTION");
        int split = !browser_show_answer && cards[browser_index].front_image[0];
        draw_card_viewport(browser_card_text(), 82, split ? 205 : 222, split ? 380 : 790,
                           split ? 0.84f : 0.95f, WHITE, browser_scroll_lines, split ? 210 : 160);
        draw_card_scrollbar(browser_card_text(), split ? 465 : 890, split ? 205 : 222,
                            split ? 380 : 790, split ? 0.84f : 0.95f,
                            browser_scroll_lines, split ? 210 : 160);
        if (split) draw_card_image_half(cards[browser_index].front_image, 480, 205, 392, 210);
        draw_fit_text(82, split ? 426 : 410, MUTED, 0.47f,
                      "Left stick up/down scrolls  |  Browse mode never changes study progress",
                      790);
    }

    draw_compact_button((UiRect){50, 458, 180, 52}, "PREVIOUS", ACCENT, 0);
    draw_compact_button(browser_jump_button, "JUMP TO CARD", YELLOW, 0);
    draw_compact_button((UiRect){440, 458, 310, 52},
                        browser_show_answer ? "SHOW QUESTION" : "SHOW ANSWER", GREEN, 0);
    draw_compact_button((UiRect){760, 458, 150, 52}, "NEXT", ACCENT, 0);
    draw_fit_text(60, 530, MUTED, 0.45f,
                  "Left/right move  |  Up/down scroll  |  Triangle jumps  |  Circle back", 840);
}

static UiRect jump_key_rect(int index) {
    int row = index / 3;
    int column = index % 3;
    return (UiRect){356 + column * 84, 204 + row * 44, 76, 38};
}

static void open_jump_dialog(void) {
    if (card_count <= 0) return;
    jump_dialog_open = 1;
    jump_selection = 13;
    jump_input[0] = '\0';
    jump_error = 0;
}

static void jump_to_entered_card(void) {
    if (!jump_input[0]) {
        jump_error = 1;
        return;
    }
    long number = strtol(jump_input, NULL, 10);
    if (number < 1 || number > card_count) {
        jump_error = 1;
        return;
    }
    browser_index = (int)number - 1;
    browser_show_answer = 0;
    browser_scroll_lines = 0;
    jump_dialog_open = 0;
    jump_error = 0;
}

static void activate_jump_selection(void) {
    if (jump_selection >= 0 && jump_selection <= 8) {
        size_t length = strlen(jump_input);
        if (length + 1 < sizeof(jump_input)) {
            jump_input[length] = (char)('1' + jump_selection);
            jump_input[length + 1] = '\0';
        }
        jump_error = 0;
    } else if (jump_selection == 9) {
        jump_input[0] = '\0';
        jump_error = 0;
    } else if (jump_selection == 10) {
        size_t length = strlen(jump_input);
        if (length + 1 < sizeof(jump_input)) {
            jump_input[length] = '0';
            jump_input[length + 1] = '\0';
        }
        jump_error = 0;
    } else if (jump_selection == 11) {
        size_t length = strlen(jump_input);
        if (length > 0) jump_input[length - 1] = '\0';
        jump_error = 0;
    } else if (jump_selection == 12) {
        jump_dialog_open = 0;
    } else if (jump_selection == 13) {
        jump_to_entered_card();
    }
}

static void move_jump_selection(unsigned int pressed) {
    if (jump_selection >= 12) {
        if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT))
            jump_selection = jump_selection == 12 ? 13 : 12;
        else if (pressed & SCE_CTRL_UP)
            jump_selection = jump_selection == 12 ? 9 : 10;
        return;
    }

    int row = jump_selection / 3;
    int column = jump_selection % 3;
    if (pressed & SCE_CTRL_LEFT) column = (column + 2) % 3;
    else if (pressed & SCE_CTRL_RIGHT) column = (column + 1) % 3;
    else if (pressed & SCE_CTRL_UP) row = row > 0 ? row - 1 : 3;
    else if (pressed & SCE_CTRL_DOWN) {
        if (row < 3) row++;
        else jump_selection = column == 0 ? 12 : 13;
    }
    if (jump_selection < 12) jump_selection = row * 3 + column;
}

static void draw_jump_dialog(void) {
    vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, RGBA8(0, 0, 0, 190));
    vita2d_draw_rectangle(220, 78, 520, 398, PANEL_HI);
    vita2d_draw_rectangle(220, 78, 520, 4, ACCENT);
    draw_text(252, 112, WHITE, 0.82f, "Jump to a card");

    vita2d_draw_rectangle(356, 126, 248, 42, PANEL);
    if (jump_input[0]) draw_text(378, 155, WHITE, 0.72f, jump_input);
    else draw_text(378, 155, MUTED, 0.56f, "Card number");
    char range[80];
    snprintf(range, sizeof(range), "Enter a number from 1 to %d", card_count);
    const char *range_message = jump_error
        ? (jump_input[0] ? "That card number is out of range." : "Enter a card number first.")
        : range;
    draw_fit_text(356, 190, jump_error ? RED : MUTED, 0.46f, range_message, 350);

    static const char *labels[12] = {"1", "2", "3", "4", "5", "6", "7", "8", "9",
                                     "CLR", "0", "DEL"};
    for (int i = 0; i < 12; i++)
        draw_compact_button(jump_key_rect(i), labels[i], ACCENT, jump_selection == i);
    draw_compact_button((UiRect){340, 397, 138, 42}, "CANCEL", RED, jump_selection == 12);
    draw_compact_button((UiRect){482, 397, 138, 42}, "GO", GREEN, jump_selection == 13);
    draw_fit_text(252, 463, MUTED, 0.43f,
                  "D-pad moves  |  X chooses  |  Circle cancels", 456);
}

static void draw_ui(void) {
    vita2d_start_drawing();
    vita2d_clear_screen();
    vita2d_draw_rectangle(0, 0, SCREEN_W, SCREEN_H, BG);
    if (current_screen == SCREEN_HOME) draw_home();
    else if (current_screen == SCREEN_STUDY) draw_study();
    else if (current_screen == SCREEN_BROWSER) draw_browser();
    else if (current_screen == SCREEN_DECKS) draw_deck_list(0);
    else if (current_screen == SCREEN_IMPORT) draw_deck_list(1);
    else if (current_screen == SCREEN_SETTINGS) draw_settings();
    else if (current_screen == SCREEN_SYNC) draw_sync();
    else if (current_screen == SCREEN_ANDROID_TRANSFER) draw_android_transfer();
    draw_confetti();
    if (jump_dialog_open) draw_jump_dialog();
    vita2d_end_drawing();
    vita2d_swap_buffers();
}

static void begin_pc_sync(void) {
    sync_error = 0;
    sync_message[0] = '\0';
    if (!anki_connect_is_configured()) {
        sync_error = 1;
        snprintf(sync_message, sizeof(sync_message), "%s", anki_connect_get_status());
        return;
    }

    if (!vitaanki_reserve_cards(&cards, &card_capacity, MAX_CARDS)) {
        sync_error = 1;
        snprintf(sync_message, sizeof(sync_message), "Not enough memory to prepare the live card list.");
        return;
    }

    int already_live = live_sync;
    int offline_index = current_deck_index;
    int loaded = already_live ? anki_connect_reload(cards, card_capacity)
                              : anki_connect_start(cards, card_capacity);
    if (loaded >= 0 && anki_connect_is_configured()) {
        card_count = loaded;
        live_sync = 1;
        sync_error = 0;
        reviewed = 0;
        show_answer = 0;
        flip_frames_remaining = 0;
        card_scroll_lines = 0;
        selected_rating = 2;
        undo_record.valid = 0;
        undo_error = 0;
        card_index = 0;
        live_refresh_after = time(NULL) + LIVE_REFRESH_SECONDS;
        snprintf(current_deck_name, sizeof(current_deck_name), "AnkiConnect deck");
        snprintf(sync_message, sizeof(sync_message), "%s", anki_connect_get_status());
        current_screen = SCREEN_STUDY;
    } else {
        if (anki_connect_is_configured())
            snprintf(sync_message, sizeof(sync_message), "%s", anki_connect_get_status());
        else
            snprintf(sync_message, sizeof(sync_message), "Sync settings are missing or invalid");
        sync_error = 1;
        anki_connect_stop();
        live_sync = 0;
        live_refresh_after = 0;
        if (offline_index >= 0 && offline_index < deck_count) {
            if (!select_deck(offline_index)) load_demo_deck();
        } else {
            load_demo_deck();
        }
        sync_error = 1;
        current_screen = SCREEN_SYNC;
    }
}

static void activate_home_selection(void) {
    if (home_selection == 0) {
        if (!live_sync && card_count == 0 && current_deck_index >= 0 &&
            current_deck_index < deck_count) {
            if (!select_deck(current_deck_index)) return;
        } else if (!live_sync && card_index < 0) {
            new_cards_this_session = 0;
            card_index = find_next_due();
            show_answer = 0;
        }
        current_screen = SCREEN_STUDY;
    }
    else if (home_selection == 1) {
        scan_decks();
        list_selection = current_deck_index >= 0 ? current_deck_index : 0;
        current_screen = SCREEN_DECKS;
    } else if (home_selection == 2) {
        scan_decks();
        list_selection = current_deck_index >= 0 ? current_deck_index : 0;
        current_screen = SCREEN_IMPORT;
    } else if (home_selection == 3) {
        settings_selection = 0;
        current_screen = SCREEN_SETTINGS;
    } else if (home_selection == 4) {
        browser_index = card_count > 0 ? card_index : 0;
        if (browser_index < 0 || browser_index >= card_count) browser_index = 0;
        browser_show_answer = 0;
        browser_scroll_lines = 0;
        jump_dialog_open = 0;
        current_screen = SCREEN_BROWSER;
    } else if (home_selection == 5) {
        sync_message[0] = '\0';
        sync_error = 0;
        sync_selection = live_sync ? 0 : 1;
        current_screen = SCREEN_SYNC;
    } else if (home_selection == 6) {
        current_screen = SCREEN_ANDROID_TRANSFER;
    }
}

static void move_home_selection(unsigned int pressed) {
    if (pressed & SCE_CTRL_LEFT) {
        if (home_selection == 1) home_selection = 0;
        else if (home_selection == 3) home_selection = 2;
        else if (home_selection == 5) home_selection = 4;
        else if (home_selection == 6) home_selection = 5;
    } else if (pressed & SCE_CTRL_RIGHT) {
        if (home_selection == 0) home_selection = 1;
        else if (home_selection == 2) home_selection = 3;
        else if (home_selection == 4) home_selection = 5;
        else if (home_selection == 5) home_selection = 6;
    } else if (pressed & SCE_CTRL_UP) {
        if (home_selection == 4) home_selection = 2;
        else if (home_selection == 5 || home_selection == 6) home_selection = 3;
        else if (home_selection >= 2) home_selection -= 2;
    } else if (pressed & SCE_CTRL_DOWN) {
        if (home_selection < 2) home_selection += 2;
        else if (home_selection == 2) home_selection = 4;
        else if (home_selection == 3) home_selection = 5;
    }
}

static int analog_direction(const SceCtrlData *pad) {
    if (pad->lx < 64) return 1;
    if (pad->ly > 192) return 2;
    if (pad->lx > 192) return 3;
    if (pad->ly < 64) return 4;
    return 0;
}

static void update_analog_input(const SceCtrlData *pad) {
    int direction = analog_direction(pad);
    if ((current_screen == SCREEN_STUDY || current_screen == SCREEN_BROWSER) &&
        (direction == 2 || direction == 4)) {
        if (direction != analog_scroll_direction) {
            analog_scroll_direction = direction;
            analog_scroll_repeat_frames = 0;
            scroll_visible_card(direction == 2 ? 1 : -1);
        } else if (++analog_scroll_repeat_frames >= 6) {
            analog_scroll_repeat_frames = 0;
            scroll_visible_card(direction == 2 ? 1 : -1);
        }
        analog_input_latched = direction;
        return;
    }
    analog_scroll_direction = 0;
    analog_scroll_repeat_frames = 0;
    if (direction == 0) {
        analog_input_latched = 0;
        return;
    }
    if (direction == analog_input_latched) return;
    analog_input_latched = direction;

    if (current_screen == SCREEN_STUDY && show_answer && has_study_card() && review_control_mode &&
        (direction == 1 || direction == 3)) {
        selected_rating = (selected_rating + (direction == 3 ? 1 : 3)) % 4;
    } else if (current_screen == SCREEN_BROWSER && card_count > 0 &&
               (direction == 1 || direction == 3))
        move_browser(direction == 1 ? -1 : 1);
    else if (current_screen == SCREEN_SYNC && (direction == 1 || direction == 3))
        sync_selection = direction == 1 ? 0 : 1;
    else if (current_screen == SCREEN_SETTINGS) {
        if (direction == 4) settings_selection = (settings_selection + 7) % 8;
        else if (direction == 2) settings_selection = (settings_selection + 1) % 8;
        else if (direction == 1) cycle_setting(settings_selection, -1);
        else if (direction == 3) cycle_setting(settings_selection, 1);
    }
}

static void handle_touch(int x, int y) {
    if (jump_dialog_open) {
        for (int i = 0; i < 12; i++) {
            if (inside(jump_key_rect(i), x, y)) {
                jump_selection = i;
                activate_jump_selection();
                return;
            }
        }
        if (inside((UiRect){340, 397, 138, 42}, x, y)) {
            jump_dialog_open = 0;
            return;
        }
        if (inside((UiRect){482, 397, 138, 42}, x, y)) {
            jump_to_entered_card();
            return;
        }
        return;
    }
    if (inside(music_button, x, y)) {
        toggle_music();
        return;
    }
    if (current_screen != SCREEN_HOME && inside(back_button, x, y)) {
        if (current_screen == SCREEN_ANDROID_TRANSFER) android_transfer_stop();
        current_screen = SCREEN_HOME;
        return;
    }

    if (current_screen == SCREEN_HOME) {
        for (int i = 0; i < 4; i++) {
            if (inside(home_buttons[i], x, y)) {
                home_selection = i;
                activate_home_selection();
                return;
            }
        }
        if (inside(browser_button, x, y)) {
            home_selection = 4;
            activate_home_selection();
            return;
        }
        if (inside(sync_button, x, y)) {
            home_selection = 5;
            activate_home_selection();
            return;
        }
        if (inside(android_transfer_button, x, y)) {
            home_selection = 6;
            activate_home_selection();
            return;
        }
    } else if (current_screen == SCREEN_SYNC) {
        if (inside(sync_offline_button, x, y)) {
            sync_selection = 0;
            activate_sync_selection();
            return;
        }
        if (inside(sync_live_button, x, y)) {
            sync_selection = 1;
            activate_sync_selection();
            return;
        }
    } else if (current_screen == SCREEN_ANDROID_TRANSFER) {
        if (inside(android_transfer_start_button, x, y)) {
            toggle_android_transfer_receiver();
            return;
        }
        if (inside(android_transfer_decks_button, x, y)) {
            android_transfer_stop();
            scan_decks();
            list_selection = current_deck_index >= 0 ? current_deck_index : 0;
            current_screen = SCREEN_DECKS;
            return;
        }
    } else if (current_screen == SCREEN_STUDY) {
        if (inside(undo_button, x, y)) {
            undo_last_rating();
            return;
        }
        if (y >= 458 && y < 518 && x >= 50 && x < 910) {
            static const int button_x[5] = {50, 224, 398, 572, 746};
            int index = -1;
            for (int i = 0; i < 5; i++) {
                if (x >= button_x[i] && x < button_x[i] + 164) {
                    index = i;
                    break;
                }
            }
            if (index >= 0) {
                if (!has_study_card()) return;
                if (index == 0) {
                if (review_control_mode && show_answer) rate_card(selected_rating);
                else set_study_answer_side(!show_answer);
                }
                else if (show_answer) rate_card(index - 1);
            }
        } else if (inside((UiRect){48, 104, 864, 334}, x, y) && has_study_card()) {
            set_study_answer_side(!show_answer);
        }
    } else if (current_screen == SCREEN_BROWSER) {
        if (inside((UiRect){50, 458, 180, 52}, x, y)) move_browser(-1);
        else if (inside(browser_jump_button, x, y)) open_jump_dialog();
        else if (inside((UiRect){440, 458, 310, 52}, x, y)) {
                browser_show_answer = !browser_show_answer;
                browser_scroll_lines = 0;
        }
        else if (inside((UiRect){760, 458, 150, 52}, x, y)) move_browser(1);
        else if (inside((UiRect){48, 104, 864, 334}, x, y) && card_count > 0) {
            browser_show_answer = !browser_show_answer;
            browser_scroll_lines = 0;
        }
    } else if (current_screen == SCREEN_DECKS || current_screen == SCREEN_IMPORT) {
        if (x >= 60 && x < 900 && y >= LIST_ROW_Y && y < LIST_ROW_Y + LIST_ROW_H * LIST_VISIBLE) {
            int row = (y - LIST_ROW_Y) / LIST_ROW_H;
            int index = first_visible_deck() + row;
            if (index >= 0 && index < deck_count) {
                list_selection = index;
                select_deck(index);
            }
        } else if (y >= 458 && y < 510 && x >= 60 && x < 286 && deck_count > 0) {
            select_deck(list_selection);
        } else if (y >= 458 && y < 510 && x >= 304 && x < 476) {
            scan_decks();
            if (list_selection >= deck_count) list_selection = deck_count > 0 ? deck_count - 1 : 0;
            import_error = 0;
        }
    } else if (current_screen == SCREEN_SETTINGS) {
        for (int setting = 0; setting < 8; setting++) {
            if (inside(settings_rows[setting], x, y)) {
                settings_selection = setting;
                int direction = 1;
                if (x >= settings_rows[setting].x + 728 && x < settings_rows[setting].x + 774)
                    direction = -1;
                cycle_setting(setting, direction);
                break;
            }
        }
    }
}

static int poll_touch(int *x, int *y) {
    SceTouchData data;
    memset(&data, 0, sizeof(data));
    if (sceTouchPeek(SCE_TOUCH_PORT_FRONT, &data, 1) < 0 || data.reportNum == 0) {
        touch_was_down = 0;
        return 0;
    }

    if (touch_was_down) return 0;
    touch_was_down = 1;
    int raw_x = data.report[0].x;
    int raw_y = data.report[0].y;
    *x = (raw_x - touch_min_x) * SCREEN_W / touch_width;
    *y = (raw_y - touch_min_y) * SCREEN_H / touch_height;
    if (*x < 0) *x = 0;
    if (*x >= SCREEN_W) *x = SCREEN_W - 1;
    if (*y < 0) *y = 0;
    if (*y >= SCREEN_H) *y = SCREEN_H - 1;
    return 1;
}

int main(void) {
    SceCtrlData pad;
    SceTouchPanelInfo touch_info;
    unsigned int previous_buttons = 0;

    mkdir("ux0:data/VitaAnki", 0777);
    mkdir(DECK_FOLDER, 0777);
    copy_file_if_missing(BUNDLED_DECK_PATH, INCLUDED_DECK_PATH);
    copy_file_if_missing("app0:/sync.example.ini", "ux0:data/VitaAnki/sync.example.ini");
    load_settings();
    sceSysmoduleLoadModule(SCE_SYSMODULE_SQLITE);
    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);
    sceTouchSetSamplingState(SCE_TOUCH_PORT_FRONT, SCE_TOUCH_SAMPLING_STATE_START);
    memset(&touch_info, 0, sizeof(touch_info));
    if (sceTouchGetPanelInfo(SCE_TOUCH_PORT_FRONT, &touch_info) >= 0) {
        int width = touch_info.maxDispX - touch_info.minDispX + 1;
        int height = touch_info.maxDispY - touch_info.minDispY + 1;
        if (width > 0) {
            touch_min_x = touch_info.minDispX;
            touch_width = width;
        }
        if (height > 0) {
            touch_min_y = touch_info.minDispY;
            touch_height = height;
        }
    }

    anki_connect_prepare();
    scan_decks();
    load_saved_deck_path();
    int index = find_saved_deck();
    if (index >= 0) {
        if (!select_deck(index)) load_demo_deck();
    } else {
        load_demo_deck();
    }

    vita2d_init();
    vita2d_set_clear_color(BG);
    font_pgf = vita2d_load_default_pgf();
    if (!font_pgf) {
        anki_music_stop();
        vita2d_fini();
        sceKernelExitProcess(1);
        return 1;
    }
    if (!font_mode_available(font_mode)) {
        font_mode = 0;
        save_settings();
    }
    app_icon = vita2d_load_PNG_file("app0:sce_sys/icon0.png");
    anki_music_set_muted(music_muted);
    current_screen = SCREEN_HOME;

    for (;;) {
        sceCtrlPeekBufferPositive(0, &pad, 1);
        unsigned int pressed = pad.buttons & ~previous_buttons;
        previous_buttons = pad.buttons;
        refresh_clock_warning();

        if (pressed & SCE_CTRL_START) break;
        if (pressed & SCE_CTRL_SELECT) toggle_music();

        if (jump_dialog_open) {
            if (pressed & SCE_CTRL_CIRCLE) jump_dialog_open = 0;
            else if (pressed & SCE_CTRL_CROSS) activate_jump_selection();
            else move_jump_selection(pressed);
        } else if (current_screen == SCREEN_HOME) {
            move_home_selection(pressed);
            if (pressed & SCE_CTRL_CROSS) activate_home_selection();
        } else if (current_screen == SCREEN_STUDY) {
            if (pressed & SCE_CTRL_LTRIGGER) undo_last_rating();
            else if ((pressed & SCE_CTRL_CROSS) && has_study_card()) {
                if (!show_answer) {
                    set_study_answer_side(1);
                } else if (review_control_mode) {
                    rate_card(selected_rating);
                } else {
                    set_study_answer_side(0);
                }
            }
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_TRIANGLE)) rate_card(0);
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_SQUARE)) rate_card(1);
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_CIRCLE)) rate_card(2);
            else if (!review_control_mode && show_answer && has_study_card() && (pressed & SCE_CTRL_RTRIGGER)) rate_card(3);
            else if ((pressed & SCE_CTRL_CIRCLE) && !show_answer) current_screen = SCREEN_HOME;
            else if (pressed & SCE_CTRL_UP) scroll_visible_card(-1);
            else if (pressed & SCE_CTRL_DOWN) scroll_visible_card(1);
        } else if (current_screen == SCREEN_BROWSER) {
            if (pressed & SCE_CTRL_CROSS) {
                browser_show_answer = !browser_show_answer;
                browser_scroll_lines = 0;
            }
            else if (pressed & SCE_CTRL_TRIANGLE) open_jump_dialog();
            else if (pressed & SCE_CTRL_LEFT) move_browser(-1);
            else if (pressed & SCE_CTRL_RIGHT) move_browser(1);
            else if (pressed & SCE_CTRL_UP) scroll_visible_card(-1);
            else if (pressed & SCE_CTRL_DOWN) scroll_visible_card(1);
            else if (pressed & SCE_CTRL_CIRCLE) current_screen = SCREEN_HOME;
        } else if (current_screen == SCREEN_DECKS || current_screen == SCREEN_IMPORT) {
            if (pressed & SCE_CTRL_UP) {
                if (list_selection > 0) list_selection--;
            } else if (pressed & SCE_CTRL_DOWN) {
                if (list_selection + 1 < deck_count) list_selection++;
            } else if (pressed & SCE_CTRL_TRIANGLE) {
                scan_decks();
                if (list_selection >= deck_count) list_selection = deck_count > 0 ? deck_count - 1 : 0;
                import_error = 0;
            } else if ((pressed & SCE_CTRL_CROSS) && deck_count > 0) {
                select_deck(list_selection);
            } else if (pressed & SCE_CTRL_CIRCLE) {
                current_screen = SCREEN_HOME;
            }
        } else if (current_screen == SCREEN_SETTINGS) {
            if (pressed & SCE_CTRL_UP) settings_selection = (settings_selection + 7) % 8;
            else if (pressed & SCE_CTRL_DOWN) settings_selection = (settings_selection + 1) % 8;
            else if (pressed & (SCE_CTRL_LEFT | SCE_CTRL_RIGHT | SCE_CTRL_CROSS))
                cycle_setting(settings_selection, (pressed & SCE_CTRL_LEFT) ? -1 : 1);
            else if (pressed & SCE_CTRL_CIRCLE) current_screen = SCREEN_HOME;
        } else if (current_screen == SCREEN_SYNC) {
            if (pressed & SCE_CTRL_LEFT) sync_selection = 0;
            else if (pressed & SCE_CTRL_RIGHT) sync_selection = 1;
            else if (pressed & SCE_CTRL_CROSS) activate_sync_selection();
            else if (pressed & SCE_CTRL_CIRCLE) current_screen = SCREEN_HOME;
        } else if (current_screen == SCREEN_ANDROID_TRANSFER) {
            if (pressed & SCE_CTRL_CROSS) toggle_android_transfer_receiver();
            else if (pressed & SCE_CTRL_CIRCLE) {
                android_transfer_stop();
                current_screen = SCREEN_HOME;
            } else if (pressed & SCE_CTRL_DOWN) {
                android_transfer_stop();
                scan_decks();
                list_selection = current_deck_index >= 0 ? current_deck_index : 0;
                current_screen = SCREEN_DECKS;
            }
        }

        if (current_screen == SCREEN_STUDY && live_sync && card_count == 0 &&
            anki_connect_has_learning_cards()) {
            time_t now = time(NULL);
            if (live_refresh_after == 0 || now >= live_refresh_after) {
                live_refresh_after = now + LIVE_REFRESH_SECONDS;
                int refreshed = anki_connect_reload(cards, card_capacity);
                if (refreshed < 0) {
                    sync_error = 1;
                } else {
                    sync_error = 0;
                    card_count = refreshed;
                    if (card_count > 0) {
                        card_index = 0;
                        show_answer = 0;
                        flip_frames_remaining = 0;
                        card_scroll_lines = 0;
                        selected_rating = 2;
                    }
                }
            }
        } else if (card_count > 0 || !live_sync) {
            live_refresh_after = 0;
        }

        if (current_screen == SCREEN_STUDY && !live_sync && card_count > 0 && !has_study_card()) {
            if (++study_idle_frames >= 30) {
                study_idle_frames = 0;
                int next_due = find_next_due();
                if (next_due >= 0) {
                    card_index = next_due;
                    show_answer = 0;
                    card_scroll_lines = 0;
                    selected_rating = 2;
                }
            }
        } else {
            study_idle_frames = 0;
        }

        if (!jump_dialog_open) update_analog_input(&pad);
        update_confetti();
        int touch_x, touch_y;
        if (poll_touch(&touch_x, &touch_y)) handle_touch(touch_x, touch_y);
        draw_ui();
        advance_study_flip();
        sceKernelDelayThread(16000);
    }

    android_transfer_stop();
    anki_music_stop();
    if (app_icon) vita2d_free_texture(app_icon);
    if (card_image_texture) vita2d_free_texture(card_image_texture);
    release_custom_fonts();
    if (font_pgf) vita2d_free_pgf(font_pgf);
    vita2d_fini();
    anki_connect_stop();
    sceKernelExitProcess(0);
    return 0;
}
