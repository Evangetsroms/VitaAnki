#ifndef VITAANKI_MUSIC_H
#define VITAANKI_MUSIC_H

#ifdef VITAANKI_DISABLE_MUSIC
static inline void anki_music_start(void) {}
static inline void anki_music_stop(void) {}
static inline void anki_music_set_muted(int muted) { (void)muted; }
static inline int anki_music_is_muted(void) { return 1; }
static inline int anki_music_is_available(void) { return 0; }
static inline int anki_music_is_running(void) { return 0; }
#else
void anki_music_start(void);
void anki_music_stop(void);
void anki_music_set_muted(int muted);
int anki_music_is_muted(void);
int anki_music_is_available(void);
int anki_music_is_running(void);
#endif

#endif
